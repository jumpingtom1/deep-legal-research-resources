#!/usr/bin/env python3
"""update_check.py — is a newer deep-legal-research release published?
Has this copy been changed since it was released?

    python3 scripts/update_check.py [--out DIR] [--manifest-url URL] [--json]

1. Local integrity (no network). Every release ships MANIFEST.sha256 — one
   sha256 per file. Files that differ, are missing or were added are listed
   under `local_changes`. Upgrading replaces the whole skill, so such changes
   are lost; suggestions go to the maintainer (`feedback`).
2. Release check. Compares VERSION with the manifest published in the
   deep-legal-research-resources repository. When a newer release exists it
   downloads the zip, checks its sha256 and layout, copies the locally held
   files the public release deliberately omits (scripts/govinfo.key — the
   api.data.gov key that is shared with colleagues but never posted publicly)
   into it, writes  deep-legal-research-v<X.Y>.zip  ready to upload, and
   prints what's new in every release since the installed one.

Never blocks research: any network or format problem prints UNREACHABLE /
INVALID and exits 0, and the run carries on with the installed version.

Output: the first line is a status word — UP-TO-DATE, UPDATE, UNREACHABLE or
INVALID — then details; with --json, one JSON object instead.
Stdlib only; one small request when already current.
"""
import argparse
import hashlib
import io
import json
import os
import re
import sys
import urllib.request
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True

SKILL_DIR = Path(__file__).resolve().parent.parent
NAME = "deep-legal-research"
MANIFEST_URL = os.environ.get(
    "DLR_RELEASE_MANIFEST",
    "https://raw.githubusercontent.com/jumpingtom1/deep-legal-research-resources/main/skill/latest.json")
ALLOWED_HOSTS = ("raw.githubusercontent.com",)
UA = "deep-legal-research-update-check/1.1"
MAX_ZIP = 50 * 1024 * 1024
LOCAL_MANIFEST = "MANIFEST.sha256"
LOCAL_ONLY = {"scripts/govinfo.key", LOCAL_MANIFEST}   # never part of the fingerprint

UPGRADE_STEPS = [
    "Download the zip file attached above.",
    "In Claude, open Customize > Skills.",
    f"Find \"{NAME}\", switch it off, click the \"...\" next to the toggle, choose Delete and confirm. "
    "(An uploaded skill cannot be replaced in place; delete it first.)",
    "Click \"+\", then \"+ Create skill\", then \"Upload a skill\", and choose the downloaded zip.",
    "Switch the new skill on, then start a new chat so the new version loads.",
]
ORG_NOTE = ("If your organization provisions this skill for you (Team/Enterprise), you cannot replace it "
            "yourself: send the zip to your Claude organization owner to publish the new version.")
KEY_NOTE = ("The zip includes your GovInfo API key, copied from your current installation. Share it only "
            "with colleagues; never post it publicly.")


def local_version():
    m = re.search(r"version:\s*([\d.]+)", (SKILL_DIR / "VERSION").read_text())
    if not m:
        raise ValueError("VERSION has no version: line")
    return m.group(1)


def author_contact():
    try:
        m = re.search(r"author:.*?([\w.+-]+@[\w-]+\.[\w.]+)", (SKILL_DIR / "VERSION").read_text())
        return m.group(1) if m else ""
    except OSError:
        return ""


def vtuple(v):
    return tuple(int(x) for x in v.split("."))


def _ignored(rel):
    parts = rel.split("/")
    return (rel in LOCAL_ONLY or "__pycache__" in parts or rel.endswith(".pyc")
            or parts[-1] in (".DS_Store",) or parts[0].startswith("."))


def local_changes():
    """Compare this installation with the MANIFEST.sha256 it shipped with.
    Returns None when the release predates the manifest (v10.4 and earlier)."""
    mf = SKILL_DIR / LOCAL_MANIFEST
    if not mf.is_file():
        return None
    expected = {}
    for line in mf.read_text().splitlines():
        if line.strip() and "  " in line:
            h, rel = line.split("  ", 1)
            expected[rel.strip()] = h.strip()
    changed, missing = [], []
    for rel, h in sorted(expected.items()):
        p = SKILL_DIR / rel
        if not p.is_file():
            missing.append(rel)
        elif hashlib.sha256(p.read_bytes()).hexdigest() != h:
            changed.append(rel)
    added = sorted(p.relative_to(SKILL_DIR).as_posix() for p in SKILL_DIR.rglob("*")
                   if p.is_file() and p.relative_to(SKILL_DIR).as_posix() not in expected
                   and not _ignored(p.relative_to(SKILL_DIR).as_posix()))
    return {"changed": changed, "missing": missing, "added": added}


def fetch(url, limit):
    host = re.match(r"https://([^/]+)/", url)
    if not host or host.group(1) not in ALLOWED_HOSTS:
        raise ValueError(f"refusing non-GitHub URL {url}")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{url} is larger than {limit} bytes")
    return data


def default_out():
    for d in ("/mnt/user-data/outputs",):
        if os.path.isdir(d) and os.access(d, os.W_OK):
            return Path(d)
    return Path.cwd()


def whats_new(man, mine):
    """Notes for every release newer than the installed one, newest first."""
    out = []
    for h in sorted(man.get("history", []), key=lambda h: vtuple(h["version"]), reverse=True):
        try:
            if vtuple(h["version"]) > vtuple(mine):
                out.append({"version": h["version"], "released": h.get("released", ""),
                            "notes": list(h.get("notes", []))})
        except (KeyError, ValueError):
            continue
    if not out and man.get("notes"):
        out = [{"version": man["version"], "released": man.get("released", ""),
                "notes": list(man["notes"])}]
    return out


def changes_note(ch, feedback, upgrading):
    n = len(ch["changed"]) + len(ch["missing"]) + len(ch["added"])
    who = f" Send suggested improvements to the maintainer ({feedback}) so they can go into a release." \
        if feedback else " Send suggested improvements to whoever maintains the skill."
    lead = (f"This copy of the skill differs from its release in {n} file(s). Upgrading replaces the "
            "whole skill, so these local changes will be lost." if upgrading else
            f"This copy of the skill differs from its release in {n} file(s); the next upgrade will "
            "replace them.")
    return lead + who


def emit(args, status, **info):
    if args.json:
        print(json.dumps({"status": status, **info}, indent=1))
        return
    print(status)
    for k, v in info.items():
        if k == "whats_new":
            print("whats_new:")
            for rel in v:
                print(f"  v{rel['version']} ({rel['released']})")
                for b in rel["notes"]:
                    print(f"    - {b}")
        elif k == "local_changes":
            print("local_changes:")
            for kind in ("changed", "missing", "added"):
                for f in v[kind][:15]:
                    print(f"  {kind}: {f}")
        elif isinstance(v, list):
            print(f"{k}:")
            for i, x in enumerate(v, 1):
                print(f"  {i}. {x}")
        else:
            print(f"{k}: {v}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--manifest-url", default=MANIFEST_URL)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    try:
        mine = local_version()
    except Exception as e:  # noqa: BLE001
        emit(args, "INVALID", reason=f"cannot read local VERSION: {e}")
        return
    ch = local_changes()
    dirty = bool(ch and (ch["changed"] or ch["missing"] or ch["added"]))
    feedback = author_contact()
    extra = {}

    try:
        man = json.loads(fetch(args.manifest_url, 200_000))
        latest = man["version"]
        vtuple(latest)
    except Exception as e:  # noqa: BLE001
        if dirty:
            extra = {"local_changes": ch, "local_changes_note": changes_note(ch, feedback, False)}
        emit(args, "UNREACHABLE", installed=mine,
             reason=f"release manifest not available ({type(e).__name__}); continuing with v{mine}", **extra)
        return
    if man.get("name") != NAME:
        emit(args, "INVALID", installed=mine, reason=f"manifest is for {man.get('name')!r}")
        return
    feedback = man.get("feedback") or feedback
    if vtuple(latest) <= vtuple(mine):
        if dirty:
            extra = {"local_changes": ch, "local_changes_note": changes_note(ch, feedback, False)}
        emit(args, "UP-TO-DATE", installed=mine, latest=latest, **extra)
        return

    # A newer release exists: fetch, verify, add local-only files, write.
    try:
        zurl = man["zip_url"]
        blob = fetch(zurl, MAX_ZIP)
        if hashlib.sha256(blob).hexdigest() != man["sha256"]:
            raise ValueError("sha256 does not match the release manifest")
        src = zipfile.ZipFile(io.BytesIO(blob))
        names = src.namelist()
        if not all(n.startswith(f"{NAME}/") for n in names) or f"{NAME}/SKILL.md" not in names:
            raise ValueError(f"zip is not a single {NAME}/ folder with SKILL.md")
        vtext = src.read(f"{NAME}/VERSION").decode()
        if f"version: {latest}" not in vtext:
            raise ValueError("zip VERSION does not match the manifest")
    except Exception as e:  # noqa: BLE001
        emit(args, "INVALID", installed=mine, latest=latest,
             reason=f"release download failed verification: {e}. Not offered; continuing with v{mine}")
        return

    added, missing = [], []
    for rel in man.get("preserve_local", []):
        arc = f"{NAME}/{rel}"
        if arc in names:
            continue
        p = SKILL_DIR / rel
        if p.is_file():
            added.append((arc, p.read_bytes()))
        else:
            missing.append(rel)

    out_dir = args.out or default_out()
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{NAME}-v{latest}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            dst.writestr(info, src.read(info.filename))
        for arc, data in added:
            zi = zipfile.ZipInfo(arc, date_time=(2026, 1, 1, 0, 0, 0))
            zi.external_attr = 0o644 << 16
            dst.writestr(zi, data, zipfile.ZIP_DEFLATED)

    notes = [KEY_NOTE] if any(a.endswith("govinfo.key") for a, _ in added) else []
    if missing:
        notes.append("Not found in your installation, so not included: " + ", ".join(missing)
                     + ". Ask whoever gave you the skill for them before uploading.")
    if dirty:
        extra = {"local_changes": ch, "local_changes_note": changes_note(ch, feedback, True)}
    emit(args, "UPDATE", installed=mine, latest=latest, released=man.get("released", ""),
         whats_new=whats_new(man, mine), file=str(out), upgrade_steps=UPGRADE_STEPS,
         organization=ORG_NOTE, notes=notes or ["—"], **extra)


if __name__ == "__main__":
    main()
