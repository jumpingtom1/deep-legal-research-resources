#!/usr/bin/env python3
"""update_check.py — is a newer deep-legal-research release published?

    python3 scripts/update_check.py [--out DIR] [--manifest-url URL] [--json]

Compares this skill's VERSION with the release manifest published in the
deep-legal-research-resources repository. When a newer release exists it
downloads the zip, checks its sha256 and layout, copies the locally held
files the public release deliberately omits (scripts/govinfo.key — the
api.data.gov key that is shared with colleagues but never posted publicly)
into it, and writes  deep-legal-research-v<X.Y>.zip  ready to upload.

Never blocks research: any network or format problem prints UNREACHABLE /
INVALID and exits 0, and the run carries on with the installed version.

Output: the first line is a status word — UP-TO-DATE, UPDATE, UNREACHABLE or
INVALID — then details; with --json, one JSON object instead.
Stdlib only; one small request when already current.
"""
import argparse
import hashlib
import io
import json
import os
import re
import sys
import urllib.request
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True

SKILL_DIR = Path(__file__).resolve().parent.parent
NAME = "deep-legal-research"
MANIFEST_URL = os.environ.get(
    "DLR_RELEASE_MANIFEST",
    "https://raw.githubusercontent.com/jumpingtom1/deep-legal-research-resources/main/skill/latest.json")
ALLOWED_HOSTS = ("raw.githubusercontent.com",)
UA = "deep-legal-research-update-check/1.0"
MAX_ZIP = 50 * 1024 * 1024

UPGRADE_STEPS = [
    "Download the zip file attached above.",
    "In Claude, open Customize > Skills.",
    f"Find \"{NAME}\", switch it off, click the \"...\" next to the toggle, choose Delete and confirm. "
    "(An uploaded skill cannot be replaced in place; delete it first.)",
    "Click \"+\", then \"+ Create skill\", then \"Upload a skill\", and choose the downloaded zip.",
    "Switch the new skill on, then start a new chat so the new version loads.",
]
ORG_NOTE = ("If your organization provisions this skill for you (Team/Enterprise), you cannot replace it "
            "yourself: send the zip to your Claude organization owner to publish the new version.")
KEY_NOTE = ("The zip includes your GovInfo API key, copied from your current installation. Share it only "
            "with colleagues; never post it publicly.")


def local_version():
    m = re.search(r"version:\s*([\d.]+)", (SKILL_DIR / "VERSION").read_text())
    if not m:
        raise ValueError("VERSION has no version: line")
    return m.group(1)


def vtuple(v):
    return tuple(int(x) for x in v.split("."))


def fetch(url, limit):
    host = re.match(r"https://([^/]+)/", url)
    if not host or host.group(1) not in ALLOWED_HOSTS:
        raise ValueError(f"refusing non-GitHub URL {url}")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{url} is larger than {limit} bytes")
    return data


def default_out():
    for d in ("/mnt/user-data/outputs",):
        if os.path.isdir(d) and os.access(d, os.W_OK):
            return Path(d)
    return Path.cwd()


def emit(args, status, **info):
    if args.json:
        print(json.dumps({"status": status, **info}, indent=1))
        return
    print(status)
    for k, v in info.items():
        if isinstance(v, list):
            print(f"{k}:")
            for i, x in enumerate(v, 1):
                print(f"  {i}. {x}")
        else:
            print(f"{k}: {v}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument("--manifest-url", default=MANIFEST_URL)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    try:
        mine = local_version()
    except Exception as e:  # noqa: BLE001
        emit(args, "INVALID", reason=f"cannot read local VERSION: {e}")
        return
    try:
        man = json.loads(fetch(args.manifest_url, 200_000))
        latest = man["version"]
        vtuple(latest)
    except Exception as e:  # noqa: BLE001
        emit(args, "UNREACHABLE", installed=mine,
             reason=f"release manifest not available ({type(e).__name__}); continuing with v{mine}")
        return
    if man.get("name") != NAME:
        emit(args, "INVALID", installed=mine, reason=f"manifest is for {man.get('name')!r}")
        return
    if vtuple(latest) <= vtuple(mine):
        emit(args, "UP-TO-DATE", installed=mine, latest=latest)
        return

    # A newer release exists: fetch, verify, add local-only files, write.
    try:
        zurl = man["zip_url"]
        blob = fetch(zurl, MAX_ZIP)
        if hashlib.sha256(blob).hexdigest() != man["sha256"]:
            raise ValueError("sha256 does not match the release manifest")
        src = zipfile.ZipFile(io.BytesIO(blob))
        names = src.namelist()
        if not all(n.startswith(f"{NAME}/") for n in names) or f"{NAME}/SKILL.md" not in names:
            raise ValueError(f"zip is not a single {NAME}/ folder with SKILL.md")
        vtext = src.read(f"{NAME}/VERSION").decode()
        if f"version: {latest}" not in vtext:
            raise ValueError("zip VERSION does not match the manifest")
    except Exception as e:  # noqa: BLE001
        emit(args, "INVALID", installed=mine, latest=latest,
             reason=f"release download failed verification: {e}. Not offered; continuing with v{mine}")
        return

    added, missing = [], []
    for rel in man.get("preserve_local", []):
        arc = f"{NAME}/{rel}"
        if arc in names:
            continue
        p = SKILL_DIR / rel
        if p.is_file():
            added.append((arc, p.read_bytes()))
        else:
            missing.append(rel)

    out_dir = args.out or default_out()
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{NAME}-v{latest}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            dst.writestr(info, src.read(info.filename))
        for arc, data in added:
            zi = zipfile.ZipInfo(arc, date_time=(2026, 1, 1, 0, 0, 0))
            zi.external_attr = 0o644 << 16
            dst.writestr(zi, data, zipfile.ZIP_DEFLATED)

    notes = [KEY_NOTE] if any(a.endswith("govinfo.key") for a, _ in added) else []
    if missing:
        notes.append("Not found in your installation, so not included: " + ", ".join(missing)
                     + ". Ask whoever gave you the skill for them before uploading.")
    emit(args, "UPDATE", installed=mine, latest=latest, released=man.get("released", ""),
         summary=man.get("summary", ""), file=str(out), upgrade_steps=UPGRADE_STEPS,
         organization=ORG_NOTE, notes=notes or ["—"])


if __name__ == "__main__":
    main()
