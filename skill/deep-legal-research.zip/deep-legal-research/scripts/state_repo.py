#!/usr/bin/env python3
"""state_repo.py — the state-sources repository, read at a pinned commit.

Federal, Oregon and Washington sources are bundled in this skill. Every other
state and D.C. lives in github.com/jumpingtom1/deep-legal-research-resources,
read at the exact commit recorded in references/state-repo.lock.json. Every
file is checked against a sha256 before use: the lock pins the index, the
host allowlist, the corpus index and the four reading scripts; the index pins
each jurisdiction's record. A file that fails its check is never used.

    python3 scripts/state_repo.py setup
        Download and verify the pinned files once per session (idempotent).
    python3 scripts/state_repo.py route "<query text or citations>" [--known xx,yy]
        Which jurisdictions do the citations in the text belong to? Only
        distinctive patterns pick a jurisdiction; generic forms (bare rule
        numbers, docket numbers, regional reporters …) match only inside a
        jurisdiction named with --known.
    python3 scripts/state_repo.py rows <xx> [--family statutes ...] [--source <id>]
        The approved sources for one jurisdiction, for the families you need:
        how to build or find the URL, which route reads it, its status,
        currency statement and hazards. Plus that family's absent entries.
    python3 scripts/state_repo.py doc <read|grep|section|verify|links|check|info> <url> [args...]
        Exact official text through the repo's fetch_doc.py (allowlist,
        robots.txt, bot-wall refusal, 1.1 s per host).
    python3 scripts/state_repo.py corpus <list|resolve|get|search|verify|check> [args...]
        Pre-built official text through the repo's corpus.py.
    python3 scripts/state_repo.py probe
        Release-checklist probe: setup, one route, one rows, one corpus resolve.
    python3 scripts/state_repo.py pin <sha> --repo <local clone>     (maintainer)
        Write references/state-repo.lock.json for that commit.

Exit codes from `doc` and `corpus` are passed through: 0 ok, 2 not found,
3 refused (robots.txt / bot wall / 401-403 — that source is off for the run;
never try another route to it), 4 network (the host is not reachable from
this sandbox — fall back to the next route the row lists).
Stdlib only.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import urllib.request
from datetime import date
from pathlib import Path

sys.dont_write_bytecode = True

SKILL_DIR = Path(__file__).resolve().parent.parent
LOCK = SKILL_DIR / "references" / "state-repo.lock.json"
RAW = "https://raw.githubusercontent.com/{repo}/{sha}/{path}"
UA = "deep-legal-research-state-repo/1.0"
WORK = Path(os.environ.get("DLR_STATE_REPO_DIR", "/tmp/dlr-state-repo"))
PINNED_FILES = ["index.json", "hosts.json", "corpus/index.json",
                "scripts/lsnet.py", "scripts/lstext.py", "scripts/fetch_doc.py", "scripts/corpus.py"]
BUNDLED = {"or": "Oregon", "wa": "Washington"}       # handled by the skill itself
FAMILIES = ["statutes", "constitution", "court_rules", "admin_code", "admin_register",
            "case_law", "subsequent_history"]


def lock():
    return json.loads(LOCK.read_text())


def base_dir(lk=None):
    lk = lk or lock()
    return WORK / lk["sha"]


def _get(url, limit=8_000_000):
    if not url.startswith("https://raw.githubusercontent.com/"):
        raise ValueError(f"refusing non-GitHub URL {url}")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"{url} too large")
    return data


def _fetch_verified(lk, path, sha256):
    dest = base_dir(lk) / path
    if dest.is_file() and hashlib.sha256(dest.read_bytes()).hexdigest() == sha256:
        return dest
    data = _get(RAW.format(repo=lk["repo"], sha=lk["sha"], path=path))
    got = hashlib.sha256(data).hexdigest()
    if got != sha256:
        raise ValueError(f"{path}: sha256 {got[:12]} does not match the pinned {sha256[:12]}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return dest


def setup(quiet=False):
    lk = lock()
    for path in PINNED_FILES:
        _fetch_verified(lk, path, lk["files"][path])
    if not quiet:
        idx = json.loads((base_dir(lk) / "index.json").read_text())
        print(f"OK state-sources repo @{lk['sha'][:7]} (pinned {lk['pinned']}): "
              f"{len(idx['jurisdictions'])} jurisdictions; files verified in {base_dir(lk)}")
    return lk


def index(lk):
    return json.loads((base_dir(lk) / "index.json").read_text())


def record(lk, xx):
    idx = index(lk)
    j = idx["jurisdictions"].get(xx)
    if not j:
        sys.exit(f"NO RECORD for {xx!r}" + (f" — {BUNDLED[xx]} is bundled in the skill "
                                              "(references/statute-sources.md, state-sources.md)"
                                              if xx in BUNDLED else ""))
    p = _fetch_verified(lk, j["data_file"], j["data_sha256"])
    return json.loads(p.read_text()), j


def cmd_route(a):
    lk = setup(quiet=True)
    idx = index(lk)
    known = {k.strip().lower() for k in (a.known or "").split(",") if k.strip()}
    hits = []
    for xx, j in sorted(idx["jurisdictions"].items()):
        for p in j["citation_patterns"]:
            if p["context_required"] and xx not in known:
                continue
            try:
                for m in re.finditer(p["regex"], a.text, re.I):
                    hits.append({"jurisdiction": xx, "name": j["name"], "pattern": p["label"],
                                 "family": p.get("family"), "routes_to": p.get("routes_to", []),
                                 "generic": p["context_required"], "match": m.group(0)})
            except re.error:
                continue
    picked = sorted({h["jurisdiction"] for h in hits if not h["generic"]} | (known & set(idx["jurisdictions"])))
    print(json.dumps({"repo_sha": lk["sha"][:7], "jurisdictions": picked, "matches": hits}, indent=1))


def _routes(src, corpus_ids):
    out = []
    v = src.get("verification", {}).get("status")
    if src["id"] in corpus_ids:
        out.append("corpus")
    auto = src.get("automation", {})
    if v != "blocked" and auto.get("shell") == "ok" and src.get("text") == "fetch-and-quote":
        out.append("script (state_repo.py doc)")
    if str(auto.get("webfetch", "")).startswith("ok"):
        out.append("fetch tool")
    return out


def cmd_rows(a):
    lk = setup(quiet=True)
    rec, j = record(lk, a.jurisdiction.lower())
    fams = set(a.family or FAMILIES)
    try:
        ci = json.loads((base_dir(lk) / "corpus" / "index.json").read_text())
        corpus_ids = {c.get("source_id"): k for k, c in ci.get("collections", {}).items()}
    except (OSError, ValueError):
        corpus_ids = {}
    print(f"# {rec['name']} — state-sources repo @{lk['sha'][:7]}, record compiled {rec['compiled']} "
          f"(sha256 verified)\n{rec.get('summary', '')}\n")
    pats = [p for p in rec["citation_map"]["citation_patterns"] if p.get("family") in fams]
    if pats:
        print("## Citation forms")
        for p in pats:
            print(f"- {p['label']}{' (generic: only once the state is known)' if p.get('context_required') else ''}"
                  f" → {', '.join(p.get('routes_to', []))}. e.g. {'; '.join(p.get('examples', [])[:3])}")
        print()
    for s in rec["sources"]:
        if s["family"] not in fams or (a.source and s["id"] != a.source):
            continue
        v, ac, au, cu = s["verification"], s["access"], s.get("automation", {}), s.get("currency", {})
        quotable = v["status"] == "verified" and s.get("text") == "fetch-and-quote"
        print(f"## [{s['id']}] {s['title']} — {s['publisher']} (tier {s['tier']}, {s.get('official_status', '?')})")
        print(f"STATUS: {v['status'].upper()} by {v['by']} {v['date']} — "
              + ("may be QUOTED" if quotable else "LINK ONLY — never quote") +
              (" — BLOCKED: never fetch by any route" if v["status"] == "blocked" else ""))
        print(f"coverage: {s.get('coverage', '')}")
        for k in ("mode", "url_pattern", "pattern_rules", "index_url", "navigation", "format", "read_via"):
            if ac.get(k):
                print(f"{k}: {ac[k]}")
        print(f"read routes: {' → '.join(_routes(s, corpus_ids)) or 'none (link only)'}"
              f"   [fetch tool: {au.get('webfetch', '?')}; script: {au.get('shell', '?')}]")
        if au.get("notes"):
            print(f"automation notes: {au['notes']}")
        if s["id"] in corpus_ids:
            print(f"corpus collection: {corpus_ids[s['id']]}")
        if cu:
            print(f"currency: {cu.get('where', '')} — seen: \"{cu.get('observed', '')}\"")
        for h in s.get("hazards", []):
            print(f"hazard: {h}")
        pr = s.get("probe", {})
        if pr:
            print(f"probe: {pr.get('citation', '')} → {pr.get('url', '')}  expect \"{pr.get('expect', '')}\"")
        if s.get("notes"):
            print(f"notes: {s['notes']}")
        print()
    ab = [x for x in rec.get("absent", []) if x.get("family") in fams]
    if ab:
        print("## Looked for and NOT available (do not search for these)")
        for x in ab:
            print(f"- [{x['family']}] {x['what']}")


def _run_tool(script, argv):
    lk = setup(quiet=True)
    env = dict(os.environ,
               LEGAL_SOURCES_BASE=f"https://raw.githubusercontent.com/{lk['repo']}/{lk['sha']}",
               LEGAL_SOURCES_CACHE=str(WORK / "cache"),
               PYTHONDONTWRITEBYTECODE="1")
    r = subprocess.run([sys.executable, str(base_dir(lk) / "scripts" / script)] + argv, env=env)
    sys.exit(r.returncode)


def cmd_probe(_a):
    lk = setup()
    idx = index(lk)
    probe_cite = "6 Del. C. § 18-101"
    hits = [p["label"] for p in idx["jurisdictions"]["de"]["citation_patterns"]
            if not p["context_required"] and re.search(p["regex"], probe_cite, re.I)]
    print(f"route {probe_cite!r}: {'de / ' + hits[0] if hits else 'NO MATCH'}")
    rec, _ = record(lk, "de")
    print(f"rows de: {len(rec['sources'])} sources, data sha256 verified")
    env = dict(os.environ, LEGAL_SOURCES_BASE=f"https://raw.githubusercontent.com/{lk['repo']}/{lk['sha']}",
               LEGAL_SOURCES_CACHE=str(WORK / "cache"))
    r = subprocess.run([sys.executable, str(base_dir(lk) / "scripts" / "corpus.py"), "resolve",
                        "Del. Super. Ct. Crim. R. 5.2"], env=env, capture_output=True, text=True)
    print("corpus resolve:", (r.stdout.strip().splitlines() or ["(no output)"])[0], f"[exit {r.returncode}]")
    ok = bool(hits) and r.returncode == 0
    print("PROBE OK" if ok else "PROBE FAILED")
    sys.exit(0 if ok else 1)


def cmd_pin(a):
    repo = Path(a.repo)
    files = {}
    for path in PINNED_FILES:
        data = subprocess.run(["git", "-C", str(repo), "show", f"{a.sha}:{path}"],
                              capture_output=True, check=True).stdout
        files[path] = hashlib.sha256(data).hexdigest()
    full = subprocess.run(["git", "-C", str(repo), "rev-parse", a.sha], capture_output=True,
                          text=True, check=True).stdout.strip()
    lk = {"repo": "jumpingtom1/deep-legal-research-resources", "sha": full,
          "pinned": date.today().isoformat(), "files": files}
    LOCK.write_text(json.dumps(lk, indent=1) + "\n")
    print(f"pinned {full[:12]} — {len(files)} files")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("setup")
    r = sp.add_parser("route"); r.add_argument("text"); r.add_argument("--known", default="")
    w = sp.add_parser("rows"); w.add_argument("jurisdiction")
    w.add_argument("--family", nargs="*", choices=FAMILIES); w.add_argument("--source")
    d = sp.add_parser("doc"); d.add_argument("rest", nargs=argparse.REMAINDER)
    c = sp.add_parser("corpus"); c.add_argument("rest", nargs=argparse.REMAINDER)
    sp.add_parser("probe")
    p = sp.add_parser("pin"); p.add_argument("sha"); p.add_argument("--repo", required=True)
    a = ap.parse_args()
    try:
        if a.cmd == "setup":
            setup()
        elif a.cmd == "route":
            cmd_route(a)
        elif a.cmd == "rows":
            cmd_rows(a)
        elif a.cmd == "doc":
            _run_tool("fetch_doc.py", a.rest)
        elif a.cmd == "corpus":
            _run_tool("corpus.py", a.rest)
        elif a.cmd == "probe":
            cmd_probe(a)
        elif a.cmd == "pin":
            cmd_pin(a)
    except BrokenPipeError:
        os._exit(0)
    except (OSError, ValueError) as e:
        print(f"UNAVAILABLE: {e}", file=sys.stderr)
        print("The state-sources repo could not be read or verified; states other than "
              "Oregon and Washington have no approved source this run — cite by number only.",
              file=sys.stderr)
        sys.exit(4)


if __name__ == "__main__":
    main()
