#!/usr/bin/env python3
"""Ingest a bundled legal document into a queryable corpus.

Converts PDF/HTML/DOCX/TXT into a JSONL file of individual provisions, so that
`or_lookup.py` can return ONE provision without any model reading the whole
document. The big file is read by Python, never by the model.

Usage:
    or_corpus_build.py SOURCE --corpus orcp --pattern orcp --captured 2026-07-29
    or_corpus_build.py SOURCE --corpus utcr --pattern numbered --captured 2026-07-29
    or_corpus_build.py SOURCE --corpus manual --pattern heading --captured 2026-07-29

Patterns:
    orcp      "RULE 47" / "RULE 47 SUMMARY JUDGMENT" headers
    numbered  leading dotted numbers, e.g. "5.100 Title" (UTCR, ORS-style)
    heading   ALL-CAPS or Title-Case headings (prose manuals)
    auto      try orcp, then numbered, then heading; pick the most provisions
"""
import argparse
import collections
import json
import pathlib
import re
import subprocess
import sys

PATTERNS = {
    # RULE 47  /  RULE 47 SUMMARY JUDGMENT  /  Rule 47.
    "orcp": re.compile(r"^\s*RULE\s+([0-9]+[A-Z]?)\.?\s*(.*)$", re.I | re.M),
    # 5.100 Title    /    12.080 Title
    "numbered": re.compile(r"^\s*([0-9]+\.[0-9]+[A-Za-z]?)\s+(\S.*)$", re.M),
    # CHAPTER 3 — EX PARTE MATTERS  /  3.2 Ex Parte Matters
    "heading": re.compile(
        r"^\s*((?:CHAPTER|SECTION|PART)\s+[0-9IVXL]+[A-Za-z0-9.\-]*)\s*[—\-:]?\s*(.*)$",
        re.M,
    ),
}


def extract_text(path: pathlib.Path) -> str:
    s = path.suffix.lower()
    if s == ".pdf":
        out = subprocess.run(
            ["pdftotext", "-layout", str(path), "-"],
            capture_output=True, text=True, check=True,
        )
        return out.stdout
    if s in (".html", ".htm"):
        from bs4 import BeautifulSoup
        raw = path.read_bytes()
        # Let bs4 sniff the charset; legislature pages are often cp1252, and
        # decoding them as utf-8 silently turns § into a replacement char.
        soup = BeautifulSoup(raw, "lxml")
        for t in soup(["script", "style"]):
            t.decompose()
        txt = soup.get_text("\n")
        if txt.count("�") > 50:  # sniffing failed — retry as cp1252
            soup = BeautifulSoup(raw.decode("cp1252", errors="replace"), "lxml")
            for t in soup(["script", "style"]):
                t.decompose()
            txt = soup.get_text("\n")
        return txt.replace("\xa0", " ")
    if s == ".docx":
        import docx
        return "\n".join(p.text for p in docx.Document(str(path)).paragraphs)
    return path.read_text(errors="replace")


def strip_page_furniture(text: str, min_repeats: int = 12) -> str:
    """Remove running headers/footers from PDF text. PDF ONLY — see caller.

    Do not run this on HTML. HTML has no page furniture, but it is full of
    short structural markers that repeat legitimately: ORCP subdivision labels
    ("A(1)", "B(2)", bare "C") and amendment histories ("[CCP 12/2/78;") each
    recur dozens of times. Applying this to ORCP.html deleted ~11k characters
    of real legal structure while the heading guard rescued only the 79 "RULE n"
    lines. Frequency is a good signal for page furniture and a terrible one for
    legal structure.

    Page furniture repeats on every page with only the page number changing, so
    normalise digit runs before counting. Only short lines are eligible, and a
    line that looks like a provision heading is never stripped — losing a real
    heading would silently drop a provision, which is far worse than leaving a
    header in place.
    """
    EDGE = 3  # lines at the top/bottom of a page that may be furniture

    def norm(ln):
        return re.sub(r"\d+", "#", ln.strip())

    # Furniture is defined POSITIONALLY, not by frequency alone. Counting
    # frequency across the whole document also matches real content that recurs
    # — "1987 Commentary:", "1991 Commentary:" appear 20 times in the UTCR and
    # are substantive headings. Only lines near a page boundary are candidates.
    pages = text.split("\f")
    candidates = collections.Counter()
    for pg in pages:
        ls = [l for l in pg.split("\n") if l.strip()]
        for ln in ls[:EDGE] + ls[-EDGE:]:
            candidates[norm(ln)] += 1

    heading_like = re.compile(r"^\s*(?:RULE\s+\d|\d+\.\d+(\s|$))")
    drop = {n for n, c in candidates.items() if c >= min_repeats and len(n) < 90}

    out, removed = [], 0
    for pg in pages:
        ls = pg.split("\n")
        # index the edge positions of this page among its non-empty lines
        nonempty = [i for i, l in enumerate(ls) if l.strip()]
        edge_idx = set(nonempty[:EDGE] + nonempty[-EDGE:])
        for i, ln in enumerate(ls):
            # NB: test heading-likeness on the ORIGINAL line — in normalised form
            # "RULE 47" reads "RULE #", so a \d check silently fails and every
            # rule header gets stripped.
            if i in edge_idx and norm(ln) in drop and not heading_like.match(ln.strip()):
                removed += 1
                continue
            out.append(ln)
    if removed:
        print(f"  stripped {removed:,} page-furniture lines at page edges "
              f"({len(drop)} distinct patterns)", file=sys.stderr)
    return "\n".join(out)


def normalize_cite(corpus: str, raw: str) -> str:
    """Canonical lookup key, e.g. 'orcp 47', 'utcr 5.100'."""
    return f"{corpus} {raw.strip().lower()}"


CAPS_LINE = re.compile(r"^[A-Z0-9][A-Z0-9 ,.;:'\-/&()]*$")


def _orcp_title_before(text: str, pos: int) -> str:
    """ORCP titles sit ABOVE the 'RULE n' header and wrap across several lines,
    with blank lines between the fragments — so blanks must be skipped, not
    treated as the end of the title. Stop at the prior rule's amendment-history
    bracket, at any line containing lowercase, or at another RULE header."""
    lines = text[:pos].rstrip().split("\n")
    picked = []
    for ln in reversed(lines[-30:]):
        s = ln.strip()
        if not s:
            continue  # blank lines are internal to the title block
        if s.startswith("[") or s.endswith("]"):
            break
        if re.match(r"^RULE\s+[0-9]", s):
            break
        if CAPS_LINE.match(s) and len(s) > 1:
            picked.insert(0, s)
        else:
            break
    return " ".join(picked).strip()


def split_orcp(text: str, corpus: str):
    """ORCP needs its own splitter: uppercase-only headers (so cross-references
    like 'Rule 9 A.' are not mistaken for headers), titles above the header,
    and each rule's trailing text ending where the next rule's title begins."""
    rx = re.compile(r"^\s*RULE\s+([0-9]+[A-Z]?)\.?\s*$", re.M)  # case-SENSITIVE
    marks = [(m.start(), m.end(), m.group(1)) for m in rx.finditer(text)]
    out = []
    for i, (start, hdr_end, num) in enumerate(marks):
        title = _orcp_title_before(text, start)
        if i + 1 < len(marks):
            nxt_start = marks[i + 1][0]
            nxt_title = _orcp_title_before(text, nxt_start)
            end = nxt_start
            if nxt_title:  # trim the next rule's title off this rule's tail
                idx = text.rfind(nxt_title.split()[0], start, nxt_start)
                if idx > hdr_end:  # never trim back into this rule's own header
                    end = idx
        else:
            end = len(text)
        body = text[start:end].strip()
        # Keep short entries: ORCP has reserved/repealed rule numbers, and an
        # agent looking one up must learn it is reserved rather than be told
        # NOT FOUND, which would wrongly imply the corpus is incomplete.
        if len(body) < 10:
            continue
        out.append({
            "citation": f"ORCP {num}",
            "key": f"{corpus} {num.lower()}",
            "title": title[:200],
            "text": body,
            "chars": len(body),
        })
    return out


def split_provisions(text: str, pattern_name: str, corpus: str):
    if pattern_name == "orcp":
        return split_orcp(text, corpus)
    if pattern_name == "auto":
        best, best_name = [], None
        for name in ("orcp", "numbered", "heading"):
            got = split_provisions(text, name, corpus)
            if len(got) > len(best):
                best, best_name = got, name
        if best_name:
            print(f"  auto-detected pattern: {best_name}", file=sys.stderr)
        return best

    rx = PATTERNS[pattern_name]
    marks = [(m.start(), m.group(1), (m.group(2) or "").strip()) for m in rx.finditer(text)]
    if not marks:
        return []

    if pattern_name == "numbered":
        # Documents like the UTCR carry a dotted-leader table of contents whose
        # entries match the same pattern as real headings. Drop those, and drop
        # mid-sentence cross-references that begin lowercase.
        marks = [
            (p, n, t) for (p, n, t) in marks
            if not re.search(r"\.{4,}", t) and (not t or not t[:1].islower())
        ]
        if not marks:
            return []

    out = []
    for i, (pos, num, title) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(text)
        body = text[pos:end].strip()
        if len(body) < 10:
            continue
        out.append({
            "citation": f"{corpus.upper()} {num}",
            "key": normalize_cite(corpus, num),
            "title": title[:200],
            "text": body,
            "chars": len(body),
        })

    # If a number still appears more than once, keep the longest body — the
    # table-of-contents copy is always the short one.
    best = {}
    for rec in out:
        cur = best.get(rec["key"])
        if cur is None or rec["chars"] > cur["chars"]:
            best[rec["key"]] = rec
    return sorted(best.values(), key=lambda r: [
        int(x) if x.isdigit() else x
        for x in re.split(r"[.\s]", r["citation"].split(maxsplit=1)[1])
    ])


def write_manifest(outdir: pathlib.Path):
    """Regenerate MANIFEST.md from the .meta.json files after every ingest, so
    it can never drift from what is actually bundled."""
    rows = []
    for mp in sorted(outdir.glob("*.meta.json")):
        m = json.loads(mp.read_text())
        rows.append(m)
    lines = [
        "# Bundled Oregon corpora",
        "",
        "Auto-generated by `scripts/or_corpus_build.py` — do not hand-edit.",
        "",
        "**Never `Read` the `.jsonl` files.** They are hundreds of thousands of",
        "characters. Query them with `scripts/or_lookup.py`, which returns one",
        "provision at a time.",
        "",
        "| Corpus | Provisions | Chars | Captured | Source |",
        "|---|---|---|---|---|",
    ]
    for m in rows:
        lines.append(
            f"| `{m['corpus']}` | {m['provisions']} | {m['total_chars']:,} | "
            f"{m['captured']} | {m.get('source_url') or m.get('source_file','')} |"
        )
    lines += [
        "",
        "Staleness is evaluated at query time: `or_lookup.py` flags a corpus",
        "STALE after 365 days and EXPIRED after 730, and prints the capture date",
        "on every result. Run `or_lookup.py --list` for current status.",
        "",
    ]
    (outdir / "MANIFEST.md").write_text("\n".join(lines))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source")
    ap.add_argument("--corpus", required=True, help="short name, e.g. orcp / utcr / manual")
    ap.add_argument("--pattern", default="auto", choices=[*PATTERNS, "auto"])
    ap.add_argument("--captured", required=True, help="YYYY-MM-DD the source was downloaded")
    ap.add_argument("--source-url", default="", help="where it came from, for the manifest")
    ap.add_argument("--no-strip", action="store_true", help="keep PDF running headers/footers")
    ap.add_argument("--outdir", default=str(pathlib.Path(__file__).resolve().parent.parent
                                             / "references" / "or-corpus"))
    a = ap.parse_args()

    src = pathlib.Path(a.source)
    if not src.exists():
        sys.exit(f"ERROR: no such file: {src}")

    outdir = pathlib.Path(a.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    print(f"extracting {src.name} ...", file=sys.stderr)
    text = extract_text(src)
    # PDF only: HTML has no page furniture, and the frequency heuristic
    # destroys legitimate repeated structure (see strip_page_furniture).
    if src.suffix.lower() == '.pdf' and not a.no_strip:
        text = strip_page_furniture(text)
    provisions = split_provisions(text, a.pattern, a.corpus)

    if not provisions:
        sys.exit(
            f"ERROR: no provisions matched pattern '{a.pattern}'.\n"
            f"       Extracted {len(text):,} chars. Inspect the head of the text and pick\n"
            f"       a different --pattern, or add one to PATTERNS in this script.\n"
            f"       Do NOT ship a corpus that silently matched nothing."
        )

    jsonl = outdir / f"{a.corpus}.jsonl"
    with jsonl.open("w") as f:
        for p in provisions:
            p["captured"] = a.captured
            p["source_url"] = a.source_url
            f.write(json.dumps(p) + "\n")

    meta = outdir / f"{a.corpus}.meta.json"
    meta.write_text(json.dumps({
        "corpus": a.corpus,
        "captured": a.captured,
        "source_file": src.name,
        "source_url": a.source_url,
        "provisions": len(provisions),
        "total_chars": sum(p["chars"] for p in provisions),
        "pattern": a.pattern,
    }, indent=2))

    write_manifest(outdir)
    print(f"  {len(provisions)} provisions -> {jsonl}", file=sys.stderr)
    print(f"  first: {provisions[0]['citation']}   last: {provisions[-1]['citation']}",
          file=sys.stderr)


if __name__ == "__main__":
    main()
