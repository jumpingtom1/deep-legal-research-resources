#!/usr/bin/env python3
"""statecourts.py - official state-court opinion text outside CourtListener's pool.

Three sources, three different levels of access (measured 2026-10-05; see
references/state-sources.md):

  OREGON      Oregon Judicial Department digital collection (CONTENTdm JSON
              API, ojd.contentdm.oclc.org). The OFFICIAL Oregon Reports pages
              as PDF, with official page numbers: Supreme Court from 326 Or
              (1997), Court of Appeals from 152 Or App (1998), Tax Court.
              Full-text search, lookup by citation or case number, and the
              Supreme Court's petitions-for-review lists. Scripted here.
  WASHINGTON  courts.wa.gov SLIP opinions (2013 on; Court of Appeals published
              opinions from 2012), found through the court's year listings.
              Not the official reports: the official Wn.2d / Wn. App. /
              Wn. App. 2d text is hosted by LexisNexis, whose
              robots.txt disallows automated access, so it is never fetched.
  NEW YORK    No scripted text. The Westlaw-hosted Official Reports collection
              blocks automated access; the Law Reporting Bureau's own pages on
              nycourts.gov are reachable through WebFetch only. `ny-url`
              builds the page address from a slip-opinion citation.

Commands
  probe                                   which sources answer right now
  resolve-batch rows.json                 CourtListener rows -> ids (Oregon, Washington) or a URL (New York)
  or-resolve  --court or|orctapp|ortc [--cite "326 Or. App. 117"] [--docket A176132] --date YYYY-MM-DD --name "..."
  or-search   "phrase one" [more terms...] [--court or|orctapp|ortc|all] [--any] [--after D] [--before D] [-n 20]
  or-history  <OJD id | case number such as A176132> [--cite "326 Or App 117"]
  wa-resolve  --court wash|washctapp --docket 101045-1 --date YYYY-MM-DD --name "..."
  wa-list     --year 2024 --court wash|washctapp [--status PUB|UNP|PAR] [--grep text]
  ny-url      "2024 NY Slip Op 04911"

Text commands are govinfo.py's and take the ids printed here unchanged:
  python3 scripts/govinfo.py fetch|read|grep|triage|verify <OJD-... | WA-...>
(`statecourts.py fetch|read|grep|triage|verify ...` forwards to them.)

Ids:  OJD-<collection alias>-<item id>     e.g. OJD-p17027coll5-35851
      WA-<pdf file name without .pdf, percent-encoded>   e.g. WA-1010451

Requests to each host are spaced at least a second apart across every process
sharing the cache directory (OJD's robots.txt asks for Crawl-Delay: 1). No key,
no login, no CourtListener calls. Nothing here circumvents an access control:
a host that refuses automated access is reported as refused.
"""
import argparse
import datetime
import difflib
import fcntl
import html
import json
import os
import pathlib
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

sys.dont_write_bytecode = True            # never leave __pycache__ in the skill folder (it ships as a zip)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import govinfo as G  # noqa: E402  (shared engine: cache, name matching, text commands)

OJD_HOST = "https://ojd.contentdm.oclc.org"
OJD = OJD_HOST + "/digital/api"
WA_HOST = "https://www.courts.wa.gov"
UA = "deep-legal-research-skill/10.0 (legal research; one request per second)"

# CourtListener court id -> (collection alias, citation field, court name, coverage note)
OR_COURTS = {
    "or": ("p17027coll3", "cita", "Oregon Supreme Court", "326 Or 1 (Aug. 1997) to date"),
    "orctapp": ("p17027coll5", "identia", "Oregon Court of Appeals", "152 Or App 1 (Jan. 1998) to date"),
    "ortc": ("p17027coll6", "cita", "Oregon Tax Court", "1 OTR (1962) to date; Magistrate Division decisions carry no citation"),
}
ALIAS_COURT = {v[0]: k for k, v in OR_COURTS.items()}
OR_FIRST = {"or": 326, "orctapp": 152}          # first reporter volume in the collection
WA_COURTS = {"wash": "S", "washctapp": "C"}
WA_FIRST_YEAR = 2012          # Court of Appeals published opinions from 2012; every other listing from 2013
NY_FEDERAL = {"nyed", "nynd", "nysd", "nywd", "nyeb", "nynb", "nysb", "nywb", "nyd"}   # GovInfo's, not ours


def is_ny_state(court):
    return court.startswith("ny") and court not in NY_FEDERAL


# Words that say nothing about WHICH case this is: 'State v. Momeni' and 'State v. Marshall' share one.
GENERIC = set("""state oregon washington people dept department human services service city county matter marriage
estate revenue rev board parole post prison supervision commission respondent respondents appellant appellants
petitioner petitioners plaintiff plaintiffs defendant defendants review cross personal restraint detention
dependency guardianship welfare interest domestic partnership compensation claimant employment division
superintendent correctional institution penitentiary corrections licensing labor industries social health
national american bank insurance ins mut mutual assn association""".split())


NAME_GLUE = {"v", "vs", "in", "re", "of", "the", "and", "ex", "rel", "et", "al", "a", "an", "for", "on", "by"}


def _sides(name):
    """Distinctive words of each side of a caption ('A v. B' -> [{a}, {b}]; no 'v.' -> one side)."""
    parts = re.split(r"\s+v(?:s)?\.?\s+", name or "", maxsplit=1, flags=re.I)
    return [G._name_tokens(p) - GENERIC for p in parts]


def _same(A, B):
    """Two sets of distinctive party words name the same party."""
    if not A or not B:
        return None                           # nothing to compare on this side
    shared, small = len(A & B), min(len(A), len(B))     # exact words only: 'Johnson' is not 'Johnston'
    return shared == small if small == 1 else shared / small > 0.5


def _residue(name):
    """What is left of a name once generic words go - initials included ('trs' for '... v. T. R. S.')."""
    words = re.findall(r"[a-z]+", (name or "").lower().replace("'", ""))
    return "".join(w for w in words if w not in GENERIC and w not in NAME_GLUE and w != "dept")


def name_agrees(a, b):
    """(score, agrees) for two case names.

    Each side of the caption that has a distinctive word in both names must
    agree ('SAIF v. Smith' is not 'SAIF v. Jones'; 'State v. Momeni' is not
    'State v. Marshall'), the sides may be swapped (a listing can print the
    appellant first), and at least one side must be compared. Where neither
    name has a distinctive word (initials only, as in juvenile cases) what
    remains after the generic words must be identical ('T. R. S.' is not
    'T. R. M.')."""
    sa, sb = _sides(a), _sides(b)
    A, B = set().union(*sa), set().union(*sb)
    if A and B:
        ov = round(len(A & B) / min(len(A), len(B)), 2)
        if len(sa) == 2 and len(sb) == 2:
            straight = [_same(sa[0], sb[0]), _same(sa[1], sb[1])]
            swapped = [_same(sa[0], sb[1]), _same(sa[1], sb[0])]
            for pair in (straight, swapped):
                if False not in pair and True in pair:
                    return ov, True
            return ov, False
        return ov, bool(_same(A, B))
    ra, rb = _residue(a), _residue(b)
    if not ra or not rb:
        return 0.0, False
    return (1.0, True) if ra == rb else (round(difflib.SequenceMatcher(None, ra, rb).ratio(), 2), False)


# --------------------------------------------------------------------------- #
# HTTP, politely
# --------------------------------------------------------------------------- #
def _throttle(host, gap):
    """At least `gap` seconds between request starts to one host, across processes."""
    G.CACHE.mkdir(parents=True, exist_ok=True)
    with open(G.CACHE / f".throttle-{host}", "a+") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        fh.seek(0)
        try:
            last = float(fh.read().strip() or 0)
        except ValueError:
            last = 0.0
        wait = last + gap - time.time()
        if wait > 0:
            time.sleep(min(wait, gap))
        fh.seek(0)
        fh.truncate()
        fh.write(repr(time.time()))
        fh.flush()


class Refused(Exception):
    """The host answered with an access-control page instead of content."""


def _get(url, timeout=90, tries=3):
    host = urllib.parse.urlsplit(url).netloc
    last = None
    for i in range(tries):
        _throttle(host, 1.1)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code in (401, 403, 451):
                raise Refused(f"HTTP {e.code} from {host}: automated access refused; not retried, not worked around")
            if e.code in (400, 404, 410):
                raise
            last = e
            time.sleep(4 * (i + 1))
        except Exception as e:          # network
            last = e
            time.sleep(3 * (i + 1))
    raise last


def _json(url):
    raw = _get(url)
    try:
        return json.loads(raw)
    except ValueError:
        raise ValueError("the collection answered with a web page instead of data (query form not accepted)")


def _q(s):
    # CONTENTdm path syntax: '!' separates terms and '/' separates parameters
    return urllib.parse.quote(re.sub(r"[!/\\^]", " ", s).strip(), safe="*")


def _date(s):
    return (s or "")[:10]


# --------------------------------------------------------------------------- #
# Oregon - OJD digital collection
# --------------------------------------------------------------------------- #
def ojd_id(alias, item):
    return f"OJD-{alias}-{item}"


def ojd_parse(gid):
    m = re.fullmatch(r"OJD-(p\d+coll\d+)-(\d+)", gid)
    if not m:
        raise ValueError(f"not an Oregon id (OJD-<alias>-<item>): {gid}")
    return m.group(1), m.group(2)


def ojd_search(alias, terms, n=20, page=1, order="dated", conn="and"):
    """terms: [(text, field, mode)], mode one of exact | all | any. Newest first."""
    path = (f"{OJD}/search/collection/{alias}/searchterm/" + "!".join(_q(t) for t, _, _ in terms) +
            "/field/" + "!".join(f for _, f, _ in terms) + "/mode/" + "!".join(m for _, _, m in terms) +
            "/conn/" + "!".join(conn for _ in terms) + f"/order/{order}/ad/desc/maxRecords/{n}")
    if page > 1:
        path += f"/page/{page}"
    d = _json(path)
    out = []
    for it in d.get("items", []):
        f = {m["field"]: (m.get("value") or "").strip() for m in it.get("metadataFields", [])}
        out.append({"id": ojd_id(alias, it["itemId"]), "title": f.get("title", ""), "case_name": f.get("subjec", ""),
                    "citation": f.get("cita") or f.get("identia") or "", "date": f.get("dated") or f.get("date") or ""})
    return int(d.get("totalResults") or 0), out


def ojd_item(gid, refresh=False):
    """Metadata for one item, cached beside the PDF. Compound objects carry
    their metadata on the parent, and the PDF is the parent's download."""
    side = G.CACHE / f"{gid}.json"
    if side.exists() and not refresh:
        try:
            return json.loads(side.read_text())
        except ValueError:
            pass
    alias, item = ojd_parse(gid)
    d = _json(f"{OJD}/collections/{alias}/items/{item}/false")
    src = d.get("parent") or d
    f = {x["key"]: (str(x.get("value") or "")).strip() for x in src.get("fields", [])}
    if not f.get("title") and not d.get("downloadUri"):
        raise LookupError(f"no such item in {alias}: {item}")
    title = f.get("title", "")
    court = ALIAS_COURT.get(alias, "")
    meta = {
        "source": "Oregon Judicial Department digital collection (official Oregon Reports pages)",
        "id": gid, "court_id": court, "court": OR_COURTS.get(court, ("", "", alias))[2],
        "title": title, "case_name": f.get("subjec", ""), "case_number": f.get("relispt", ""),
        "citation": f.get("cita") or f.get("identia") or "", "date": f.get("dated", ""),
        "document_type": f.get("type", ""), "author": f.get("judge", ""), "disposition_note": f.get("descri", ""),
        "lower_court_case_number": f.get("relhapt", ""), "parties": f.get("subjec1", ""),
        # a compound object answers with its first page; the whole document is the parent's download
        "pdf_url": OJD_HOST + (d.get("downloadParentUri") or
                               "/digital" + (d.get("downloadUri") or f"/api/collection/{alias}/id/{item}/download")),
        "public_url": f"{OJD_HOST}/digital/collection/{alias}/id/{item}",
    }
    if re.search(r"nonprecedential", meta["document_type"], re.I):
        meta["nonprecedential"] = True
        meta["nonprecedential_note"] = ("a nonprecedential memorandum opinion (ORAP 10.30): not binding precedent; "
                                        "say so wherever it is cited")
    if not re.search(r"opinion", meta["document_type"] + " " + title, re.I):
        meta["not_an_opinion_note"] = f"this item is catalogued as '{meta['document_type'] or title}', not an opinion"
    G.CACHE.mkdir(parents=True, exist_ok=True)
    side.write_text(json.dumps(meta, indent=1))
    return meta


def or_cite(strings, court=None):
    """The official Oregon citation, in the collection's form, from CourtListener
    citation strings ('326 Or. App. 117' -> '326 Or App 117'). (cite, court id)."""
    if isinstance(strings, str):
        strings = [strings]
    found = {}
    for s in strings or []:
        m = re.search(r"\b(\d{1,3})\s+Or\.?\s*App\.?\s+(\d{1,4})\b", s or "", re.I)
        if m:
            found.setdefault("orctapp", f"{m.group(1)} Or App {m.group(2)}")
        m = re.search(r"\b(\d{1,3})\s+Or\.?\s+(\d{1,4})\b", s or "", re.I)
        if m:
            found.setdefault("or", f"{m.group(1)} Or {m.group(2)}")
        m = re.search(r"\b(\d{1,3})\s+(?:O\.?\s?T\.?\s?R\.?|Or\.?\s?Tax)\s+(\d{1,4})\b", s or "", re.I)
        if m:
            found.setdefault("ortc", f"{m.group(1)} OTR {m.group(2)}")
    if court in found:                       # a Supreme Court row can also carry the decision below's citation
        return found[court], court
    for c in ("orctapp", "or", "ortc"):
        if c in found and court not in OR_COURTS:
            return found[c], c
    if found and court in OR_COURTS:         # the row's court has no citation of its own in the array
        return None, court
    return None, court


def or_case_numbers(docket, court):
    """Appellate case numbers in a CourtListener docket string. The Court of
    Appeals uses A-numbers ('130622; A154637', 'CAA102946'), the Supreme Court
    S-numbers ('SC S071185'), the Tax Court 'TC 5171'."""
    d = docket or ""
    if court == "orctapp":
        return list(dict.fromkeys("A" + m for m in re.findall(r"(?<![A-Za-z0-9])(?:CA\s?)?A\s?(\d{5,6})(?!\d)", d)))
    if court == "or":
        return list(dict.fromkeys("S" + m for m in re.findall(r"(?<![A-Za-z0-9])(?:SC\s?)?S\s?(\d{5,6})(?!\d)", d)))
    if court == "ortc":
        return list(dict.fromkeys("TC " + m for m in re.findall(r"(?<![A-Za-z0-9])TC[\s\-]?(\d{4})(?!\d)", d)))
    return []


def or_resolve(court, cites=None, docket=None, date=None, name=None):
    """One CourtListener row -> one OJD item. Never guesses: the citation (or
    the case number), the decision date AND the case name must all agree."""
    date = _date(date)
    res = {"court": court, "docket": docket, "date": date, "found": False, "collection": "OJD"}
    cite, court2 = or_cite(cites, court)
    court = court2 or court
    if court not in OR_COURTS:
        res["reason"] = "court must be 'or', 'orctapp' or 'ortc' (CourtListener `court_id`)"
        return res
    alias, field, cname, cover = OR_COURTS[court]
    res["court"] = court
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
        res["reason"] = "no decision date (YYYY-MM-DD) supplied; an item is never chosen without one"
        return res
    if not name or not G._name_tokens(name):
        res["reason"] = "no case name supplied; an item is never chosen without a citation or case number, date AND name"
        return res
    early = bool(cite and court in OR_FIRST and int(cite.split()[0]) < OR_FIRST[court])
    tried, cands = [], []
    if cite:
        tried.append(f"citation {cite}")
        _, hits = ojd_search(alias, [(cite, field, "exact")], n=10)
        cands += [dict(h, how="citation") for h in hits if cite in [c.strip() for c in h["citation"].split(";")]
                  or h["citation"] == cite]
    if not cands:
        for num in or_case_numbers(docket, court)[:3]:
            tried.append(f"case number {num}")
            _, hits = ojd_search(alias, [(num, "relispt", "exact")], n=10)
            cands += [dict(h, how="case number") for h in hits]
    if not tried:
        res["reason"] = ("no Oregon Reports citation and no appellate case number (A-/S-number) in the row; "
                         "nothing to look up - use `or-search` on the case name, or read through CourtListener")
        return res
    res["looked_up_by"] = tried
    near = None
    for c in cands:
        ov, name_ok = name_agrees(name, c["case_name"])
        c["name_overlap"] = ov
        if date not in [x.strip() for x in c["date"].split(";")]:
            near = near or dict(candidate=c, reason=f"the collection's item is dated {c['date'] or '(no date)'}, "
                                f"not {date}; not used (an opinion on reconsideration or a different decision in the "
                                "same case carries a different date)")
            continue
        if not name_ok:
            near = dict(candidate=c, reason="an item with this citation or case number and date exists but its case "
                        "name does not match (generic words such as 'State' do not count); not used")
            continue
        meta = ojd_item(c["id"])
        row_numbers = or_case_numbers(docket, court)
        item_number = re.sub(r"\s+", "", meta.get("case_number") or "").upper()
        if c["how"] == "citation" and row_numbers and item_number and \
                item_number not in [re.sub(r"\s+", "", n).upper() for n in row_numbers]:
            near = dict(candidate=c, reason=f"citation, date and name match, but the row's case number "
                        f"({', '.join(row_numbers)}) is not the item's ({meta.get('case_number')}); not used - the "
                        "row's citation or number is wrong")
            continue
        res.update(found=True, granule_id=c["id"], matched_by=c["how"], name_overlap=ov,
                   title=meta["case_name"], citation=meta["citation"], case_number=meta["case_number"],
                   document_type=meta["document_type"], author=meta["author"],
                   disposition_note=meta["disposition_note"], pdf_url=meta["pdf_url"], public_url=meta["public_url"],
                   text_is="official Oregon Reports pages; cite the official page (the `pin` on each page label)")
        for k in ("nonprecedential", "nonprecedential_note", "not_an_opinion_note", "lower_court_case_number"):
            if meta.get(k):
                res[k] = meta[k]
        if cite and meta["citation"] and cite not in [x.strip() for x in meta["citation"].split(";")]:
            res["citation_differs"] = f"CourtListener gives {cite}; the collection gives {meta['citation']}"
        same = [x["id"] for x in cands if date in x["date"] and x["id"] != c["id"]]
        if same:
            res["ambiguous"] = True
            res["other_items_same_date"] = same
            res["ambiguity_note"] = "several items share this citation/number and date; read the opening of each"
        return res
    if near:
        res.update(near)
    elif early:
        res["reason"] = (f"{cite} predates the collection's systematic coverage ({cname}: {cover}) and no stray "
                         "item carries it; read through CourtListener")
    else:
        res["reason"] = (f"no item found by {' or '.join(tried)} in the {cname} collection (coverage: {cover}); "
                         "read through CourtListener")
    return res


def or_search(terms, court="all", any_word=False, after=None, before=None, n=20):
    courts = list(OR_COURTS) if court == "all" else [court]
    out = {"terms": terms, "courts": courts, "results": [], "totals": {}}
    for c in courts:
        if c not in OR_COURTS:
            return {"error": "--court takes or, orctapp, ortc or all"}
        alias = OR_COURTS[c][0]
        spec = [(t, "all", ("exact" if " " in t.strip() else "all")) for t in terms]
        got, page, total, max_pages = [], 1, 0, (40 if before else 8)
        while len(got) < n and page <= max_pages:
            total, hits = ojd_search(alias, spec, n=50, page=page, conn=("or" if any_word else "and"))
            if not hits:
                break
            for h in hits:
                if after and h["date"] and h["date"] < after:
                    continue
                if before and h["date"] and h["date"] > before:
                    continue
                got.append(dict(h, court_id=c))
            if page * 50 >= total or (after and hits[-1]["date"] and hits[-1]["date"] < after):
                break
            page += 1
        if len(got) < n and page > max_pages and page * 50 < total:
            out.setdefault("truncated", {})[c] = (f"stopped after the {max_pages * 50} newest of {total} matches "
                                                  "without filling -n: narrow the terms or the dates")
        out["totals"][c] = total
        out["results"] += got[:n]
    out["results"].sort(key=lambda r: r["date"], reverse=True)
    out["returned"] = len(out["results"])
    out["note"] = ("full-text search of the collection (a phrase in quotes on the shell is matched exactly; the "
                   "terms are ANDed unless --any, which ORs them; * is a wildcard). Newest first, not relevance-ranked, no proximity "
                   "operator. A discovery aid outside the CourtListener pool - not a completeness guarantee: every "
                   "candidate still needs its CourtListener row (Phase 4) for the citator.")
    return out


HEADING = re.compile(r"^\s{6,}([A-Z][A-Z ,\-]{3,60})\s*$")
DATELINE = re.compile(r"^\s{6,}((?:January|February|March|April|May|June|July|August|September|October|November|"
                      r"December)\s+\d{1,2},\s+\d{4})\s*$")


def parse_review_list(text):
    """Entries of a 'Petitions for review' list: [(disposition heading, date, entry text)]."""
    out, head, date, cur = [], None, None, None
    for ln in text.replace("\f", "\n").split("\n"):
        if not ln.strip():
            continue
        m = HEADING.match(ln)
        if m and not re.search(r"\(\w?\d", ln):
            h = re.sub(r"\s+", " ", m.group(1)).strip()
            if h not in ("PETITIONS FOR REVIEW",) and not re.fullmatch(r"\d+", h):
                head = h
            cur = None
            continue
        m = DATELINE.match(ln)
        if m:
            date, cur = m.group(1), None
            continue
        if re.fullmatch(r"\s*\d{1,4}\s*", ln):
            continue
        if ln[:1].strip():                       # an entry starts at the left margin
            cur = [head, date, ln.strip()]
            out.append(cur)
        elif cur:                                # continuation lines are indented
            cur[2] += " " + ln.strip()
    return [tuple(x) for x in out]


def _text_of(gid):
    r = G.fetch(gid)
    if not r.get("found"):
        return None, r
    return pathlib.Path(r["text_path"]).read_text(errors="replace"), r


CAPTION_HISTORY = re.compile(r"(petitions?\s+for\s+review\s+(?:allowed|denied|dismissed|held in abeyance|withdrawn)"
                             r"[^()]{0,90}\(\s*\d{1,3}\s*Or\s*\d{1,4}\s*\))", re.I | re.S)
OCR_DIGIT = {"0": "[0OoQD]", "1": "[1lI|!]", "2": "[2Z]", "5": "[5S]", "6": "[6G]", "8": "[8B]"}


def _ocr_tolerant(s):
    """A pattern for a case number or citation as an OCR'd list may print it ('(Al40553)', '2360r App 665')."""
    out = []
    for ch in s:
        if ch.isdigit():
            out.append(OCR_DIGIT.get(ch, ch))
        elif ch == " ":
            out.append(r"\s*")
        else:
            out.append(re.escape(ch))
    return "".join(out)


def entry_head(entry):
    """The part of a review-list entry that identifies ITS case: the name and the
    run of parentheses after it - '(A176132)(S070339)(326 Or App 117)'. Whatever
    follows is commentary and may name other cases."""
    e = entry.translate({ord("{"): "(", ord("}"): ")", ord("["): "(", ord("]"): ")"})     # OCR misreads of ( )
    m = re.search(r"\([^()]{1,60}\)(?:\s*\([^()]{1,60}\))*", e)
    return e[:m.end()] if m else e


def or_history(target, cite=None):
    """What happened to an Oregon appellate decision afterwards, from the
    Judicial Department's own records - no CourtListener calls."""
    out = {"target": target, "checks": {}, "found_any": False, "complete": True, "not_checked": []}
    meta = {}
    if target.startswith("OJD-"):
        meta = ojd_item(target)
        number = re.sub(r"\s+", "", meta.get("case_number") or "").upper()
        cite = cite or meta.get("citation")
        out["case"] = {k: meta.get(k) for k in ("case_name", "citation", "case_number", "date", "court")}
    else:
        number = re.sub(r"\s+", "", target).upper()
    if not re.fullmatch(r"[AS]\d{5,6}", number):
        out["error"] = ("needs a Court of Appeals or Supreme Court case number (A176132, S071185) or an OJD id whose "
                        "record carries one")
        return out
    if cite:                                   # accept '326 Or. App. 117' as well as the catalogue's '326 Or App 117'
        norm = or_cite(cite)[0]
        if not norm:
            out["error"] = f"could not read --cite '{cite}' as an Oregon citation (e.g. 326 Or App 117, 375 Or 580)"
            return out
        cite = norm
    num = number
    out["case_number"] = num
    is_sc = num.startswith("S")
    if not meta:                               # a bare case number: find the decision it names, for its name and date
        try:
            alias, field = ("p17027coll3", "cita") if is_sc else ("p17027coll5", "identia")
            _, items = ojd_search(alias, [(num, "relispt", "exact")], n=10)
            items = [x for x in items if "opinion" in x["title"].lower()]
            pick = ([x for x in items if cite and x["citation"] == cite] or
                    (items if len(items) == 1 and not cite else []))
            if cite and items and not pick:
                out["decision_not_in_catalogue"] = (
                    f"the catalogue holds {'; '.join(x['citation'] for x in items)} under {num}, not {cite} - the "
                    "decision checked may have been issued without opinion, or the citation or number is wrong")
            if pick:
                meta = ojd_item(pick[0]["id"])
                cite = cite or meta.get("citation")
                out["case"] = {k: meta.get(k) for k in ("case_name", "citation", "case_number", "date", "court")}
            elif len(items) > 1:
                out["several_decisions_under_this_number"] = [
                    {"id": x["id"], "citation": x["citation"], "date": x["date"]} for x in items]
        except Exception as e:
            out["not_checked"].append(f"catalogue lookup of {num}: {G._clean(e)}")
    out["citation_checked"] = cite
    decided = _date(meta.get("date"))

    # 1. The opinion's own caption. Bound-volume pages (older items) print later
    #    history in the caption; advance-sheet pages (recent items) cannot.
    if meta.get("id") and not is_sc:
        text, r = _text_of(meta["id"])
        if text:
            first = re.sub(r"\s+", " ", text.split("\f")[0])
            hits = [re.sub(r"\s+", " ", h) for h in CAPTION_HISTORY.findall(first)]
            out["checks"]["caption_of_the_opinion"] = {
                "history_printed": hits or None,
                "relates_to": (None if not hits else "this decision (printed on its own first page)"
                               if not cite or meta.get("citation") == cite else
                               f"a DIFFERENT decision: this is the caption of {meta.get('citation')}, not {cite}"),
                "ocr_layer": bool(r.get("ocr_layer")),
                "note": ("printed in the opinion's own caption (official bound-volume page); catalogue/caption "
                         "text, reported as history - not the court's reasoning" if hits else
                         "nothing recognised - recent items are advance-sheet pages, which predate any review, and "
                         "an OCR scan can garble the line; this is NOT evidence that review was not sought")}
            out["found_any"] |= bool(hits)
        else:
            out["not_checked"].append(f"caption of {meta['id']}: {r.get('reason')}")

    # 2. A Supreme Court opinion that reviewed this Court of Appeals case.
    if not is_sc:
        try:
            _, hits = ojd_search("p17027coll3", [(num, "relhapt", "exact")], n=10)
        except Exception as e:
            hits = []
            out["not_checked"].append(f"Supreme Court opinions on review: {G._clean(e)}")
        ops = []
        for h in hits:
            m = ojd_item(h["id"])
            o = {"id": h["id"], "case_name": m["case_name"], "citation": m["citation"], "date": m["date"],
                 "supreme_court_case_number": m["case_number"],
                 "catalogue_disposition_note": m["disposition_note"], "public_url": m["public_url"]}
            if decided and m["date"] and m["date"] <= decided:
                o["relates_to"] = (f"an EARLIER Supreme Court decision in the same case number (it predates the "
                                   f"{decided} decision checked here) - prior history, not review of this decision")
            elif decided:
                o["relates_to"] = ("decided after the decision checked here: it reviews this case number - read it "
                                   "on the state lane and report what it did")
            else:
                o["relates_to"] = ("unconfirmed: reviews this case number, which can have more than one Court of "
                                   "Appeals decision - confirm which from the opinion's first page")
            ops.append(o)
        out["checks"]["supreme_court_opinion_on_review"] = ops or None
        out["found_any"] |= bool(ops)

    # 3. The Supreme Court's petitions-for-review lists. Found two ways: by the case
    #    number in the list's text, and - because lists before about 2012 are scans
    #    whose numbers the OCR often misreads - by a distinctive party name.
    num_pat = re.compile(r"(?<![A-Za-z0-9])" + _ocr_tolerant(num) + r"(?!\d)")
    cite_pat = re.compile(r"(?<!\d)" + _ocr_tolerant(cite) + r"(?!\d)") if cite else None
    entries, mentions, seen, searched = [], [], set(), []

    def in_window(h):                           # a petition is decided after the decision, within about three years
        d = h["date"].split(";")[0].strip()
        return not (decided and d and (d < decided or d > f"{int(decided[:4]) + 3}{decided[4:]}"))

    def gather(term, mode="all", cap=12, windowed=False):
        searched.append(term)
        try:
            got = ojd_search("p17027coll3", [("Petitions for review", "title", "all"), (term, "all", mode)], n=40)[1]
        except Exception as e:
            out["not_checked"].append(f"petitions-for-review lists, search '{term}': {G._clean(e)}")
            return []
        return [h for h in got if h["id"] not in seen and (not windowed or in_window(h))][:cap]

    def read_lists(found):
        for h in sorted(found, key=lambda x: x["date"]):
            if h["id"] in seen or len(seen) >= 30:
                continue
            seen.add(h["id"])
            text, r = _text_of(h["id"])
            if not text:
                out["not_checked"].append(f"{h['title']} ({h['id']}): {r.get('reason')}")
                continue
            for head, date, entry in parse_review_list(text):
                ehead = entry_head(entry)
                in_head = bool(num_pat.search(ehead))
                cite_in_head = bool(cite_pat and cite_pat.search(ehead))
                if not in_head:                 # the citation alone is not enough: decisions without opinion
                    if num_pat.search(entry):   # share a page, and so a citation, with dozens of other cases
                        mentions.append({"list": h["title"], "id": h["id"], "entry": entry,
                                         "note": "this entry is about ANOTHER case and only mentions the one "
                                                 "checked - not a disposition of it"})
                    continue
                e = {"disposition": head, "date": date, "entry": entry, "list": h["title"],
                     "list_citation": h["citation"], "id": h["id"],
                     "public_url": f"{OJD_HOST}/digital/collection/p17027coll3/id/{h['id'].rsplit('-', 1)[1]}"}
                exact = re.search(r"(?<![A-Za-z0-9])" + re.escape(num) + r"(?!\d)", ehead)
                if r.get("ocr_layer") or not exact:
                    e["ocr_layer"] = bool(r.get("ocr_layer"))
                    e["view_the_list"] = ("matched in OCR text" + ("" if exact else " with a misread character") +
                                          " - view the list page (Read the cached PDF) and confirm the heading, "
                                          "the case and the date before reporting")
                printed = re.findall(r"\b\d{1,3}\s+Or(?:\s+App)?\s+\d{1,4}\b", ehead)
                if is_sc:
                    e["relates_to"] = ("this Supreme Court case: the petition that brought it up (the entry prints "
                                       "the decision under review" + (": " + "; ".join(printed) if printed else "")
                                       + ")")
                elif cite_in_head:
                    e["relates_to"] = f"this decision ({cite} is printed in the entry's own citation)"
                elif cite and printed:
                    e["relates_to"] = (f"a DIFFERENT decision in the same case number: the entry prints "
                                       f"{'; '.join(printed)}, not {cite}")
                elif cite:
                    e["relates_to"] = f"unconfirmed: the entry prints no citation; confirm it concerns {cite}"
                else:
                    e["relates_to"] = ("unconfirmed: no citation was given to compare - the entry prints " +
                                       ("; ".join(printed) if printed else "none") + "; a case number can have "
                                       "more than one decision, so pass --cite or compare it yourself")
                entries.append(e)

    read_lists(gather(num))
    if not any("this decision" in e["relates_to"] or "this Supreme Court case" in e["relates_to"] for e in entries):
        # Lists before about 2012 are scans: the OCR prints 'Al40553' for A140553. Try the usual misreadings,
        # the citation as a phrase, and the first party's name.
        variants = {num.replace("1", "l"), num.replace("1", "I"), num.replace("0", "O"),
                    num.replace("1", "l").replace("0", "O"), num.replace("1", "I").replace("0", "O")} - {num}
        for v in sorted(variants):
            read_lists(gather(v))
        if cite and not is_sc:
            read_lists(gather(cite, mode="exact", windowed=True))
        distinctive = G._name_tokens(meta.get("case_name") or "") - GENERIC
        for nm in [w for w in dict.fromkeys(re.findall(r"[a-z]{4,}", (meta.get("case_name") or "").lower()))
                   if w in distinctive][:1]:
            read_lists(gather(nm, windowed=True, cap=8))
    out["searched_by"] = searched
    out["lists_read"] = len(seen)
    out["checks"]["petitions_for_review_lists"] = entries or None
    if mentions:
        out["checks"]["mentioned_in_other_entries"] = mentions
    out["found_any"] |= bool(entries)
    try:
        _, newest = ojd_search("p17027coll3", [("Petitions for review", "title", "all")], n=1)
        out["newest_list_in_collection"] = newest[0]["title"] if newest else None
    except Exception:
        out["newest_list_in_collection"] = None
    if out["not_checked"]:
        out["complete"] = False
    else:
        del out["not_checked"]
    out["meaning"] = (
        "Dispositions above are read from the Oregon Supreme Court's own published lists and opinions; report only "
        "entries whose `relates_to` is this decision. `complete: false` means some record could not be read "
        "(`not_checked`): say what was not checked - that is not an empty result. An empty, complete result means "
        "only that no list or opinion found names this case: a petition may be pending, may postdate the newest "
        "list, may sit under a consolidated number (A180517-19), or - for decisions before about 2012, whose lists "
        "are scans - may be printed in a form the search did not match. Report 'no review disposition located in "
        "the official source', never 'review was not sought'.")
    return out


# --------------------------------------------------------------------------- #
# Washington - courts.wa.gov slip opinions
# --------------------------------------------------------------------------- #
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                      "dec"], 1)}
WA_ROW = re.compile(
    r"<tr[^>]*>\s*<td[^>]*>\s*([A-Z][a-z]{2})[a-z]*\.?\s+(\d{1,2}),\s+(\d{4})\s*</td>(.*?)</tr>", re.S | re.I)


def wa_id(basename):
    return "WA-" + urllib.parse.quote(basename, safe=".-")


def wa_basename(gid):
    if not gid.startswith("WA-"):
        raise ValueError(f"not a Washington id: {gid}")
    return urllib.parse.unquote(gid[3:])


def wa_pdf_url(gid):
    return f"{WA_HOST}/opinions/pdf/{urllib.parse.quote(wa_basename(gid))}.pdf"


def wa_digits_all(docket):
    """Every appellate docket number in the string, as the listing's digit string:
    '101,045-1' / 'No. 32978-0-III' / '59773-0' -> '1010451' / '329780' / '597730'.
    A superior-court number ('19-2-01234-34') is not one."""
    out = []
    for m in re.finditer(r"(?<![\d\-])(\d{1,3},\d{3}|\d{5,6})\s*-\s*(\d)(?!\d)", docket or ""):
        d = re.sub(r"\D", "", m.group(1)) + m.group(2)
        if d not in out:
            out.append(d)
    return out


def wa_digits(docket):
    d = wa_digits_all(docket)
    return d[0] if d else None


def wa_listing(year, level, status, fresh=False):
    """The court's own listing for one year, court level (S|C) and publication
    status (PUB|UNP|PAR), parsed. Cached for the day unless ``fresh``."""
    G.CACHE.mkdir(parents=True, exist_ok=True)
    stamp = datetime.date.today().isoformat()
    cache = G.CACHE / f"wa-list-{year}-{level}-{status}-{stamp}.json"
    if cache.exists() and not fresh:
        return json.loads(cache.read_text())
    url = f"{WA_HOST}/opinions/index.cfm?fa=opinions.byYear&fileYear={year}&crtLevel={level}&pubStatus={status}"
    page = _get(url).decode("latin-1", "replace")
    if "File Date" not in page:
        if re.search(r"error occurred|ColdFusion", page, re.I):
            raise ValueError("courts.wa.gov returned an error page for this listing")
        rows = []
    else:
        rows = []
        for m in WA_ROW.finditer(page):
            mon, day, yr, rest = m.groups()
            if mon.lower() not in MONTHS:
                continue
            pdf = re.search(r'HREF="/opinions/pdf/([^"]+?)\.pdf"', rest, re.I)
            num = re.search(r'showOpinion&(?:amp;)?filename=([^"]+)"[^>]*>\s*([^<]+?)\s*</A>', rest, re.I)
            cells = re.findall(r"<td[^>]*>(.*?)</td>", rest, re.S | re.I)
            if not pdf or not num or len(cells) < 3:
                continue
            clean = [re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", c))).strip() for c in cells]
            division = clean[1] if level == "C" and len(clean) >= 4 else None
            title = clean[-2]
            star = title.startswith("*")
            rows.append({"file_date": f"{int(yr):04d}-{MONTHS[mon.lower()]:02d}-{int(day):02d}",
                         "docket": num.group(2).strip(), "docket_digits": re.sub(r"\D", "", num.group(2)),
                         "division": division, "title": title.lstrip("* ").strip(), "file_contains": clean[-1],
                         "pdf": html.unescape(pdf.group(1)), "superseded_slip": star,
                         "court": "wash" if level == "S" else "washctapp", "pub_status": status})
    cache.write_text(json.dumps(rows))
    return rows


def wa_resolve(court, docket=None, date=None, name=None, cites=None):
    """One CourtListener row -> one courts.wa.gov slip opinion. The docket
    number, the filing date AND the case title must all agree."""
    date = _date(date)
    res = {"court": court, "docket": docket, "date": date, "found": False, "collection": "WA slip opinions"}
    if court not in WA_COURTS:
        res["reason"] = "court must be 'wash' or 'washctapp' (CourtListener `court_id`)"
        return res
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
        res["reason"] = "no decision date (YYYY-MM-DD) supplied; an opinion is never chosen without one"
        return res
    year = int(date[:4])
    if year < WA_FIRST_YEAR:
        res["reason"] = ("courts.wa.gov lists slip opinions from 2013 on (Court of Appeals published opinions from "
                         "2012); read through CourtListener")
        return res
    numbers = wa_digits_all(docket)
    if not numbers:
        res["reason"] = "docket number not in a recognizable form (e.g. 101045-1 or 32978-0-III)"
        return res
    if not name or not G._name_tokens(name):
        res["reason"] = "no case name supplied; an opinion is never chosen without a docket, date AND name match"
        return res
    level = WA_COURTS[court]
    published = any(re.search(r"Wn\.|Wash\.|P\.\s?[23]d", c or "") for c in (cites or []))
    order = ["PUB"] if level == "S" else (["PUB", "PAR", "UNP"] if published else ["UNP", "PUB", "PAR"])
    near, searched = None, []
    for status in order:
        rows = wa_listing(year, level, status)
        searched.append(f"{year} {status} ({len(rows)} rows)")
        for r in [x for x in rows if x["docket_digits"] in numbers]:
            digits = r["docket_digits"]
            ov, name_ok = name_agrees(name, r["title"])
            if r["file_date"] != date:
                near = near or dict(candidate=r, reason=f"the court lists this docket number with a file date of "
                                    f"{r['file_date']}, not {date}; not used (an amended or substituted opinion "
                                    "carries its own date)")
                continue
            if not name_ok:
                near = dict(candidate=r, reason="docket number and date match but the case title does not (generic "
                            "words such as 'State' do not count); not used")
                continue
            gid = wa_id(r["pdf"])
            same = [x for x in rows if x["docket_digits"] == digits and x["file_date"] == date and x is not r]
            meta = dict(r, source="Washington Courts slip opinion (courts.wa.gov) - NOT the official report",
                        id=gid, pdf_url=wa_pdf_url(gid), case_name=r["title"], date=r["file_date"])
            if r["superseded_slip"]:
                meta["superseded_note"] = (
                    "the court marks this slip opinion as no longer its official opinion: the official report "
                    "(Wn.2d / Wn. App. / Wn. App. 2d) has replaced it and may differ in wording. A quote verified here is "
                    "verified against the SLIP opinion; say so.")
            if re.search(r"order", r["file_contains"], re.I):
                meta["order_note"] = (f"the file contains '{r['file_contains']}': an order changed, withdrew or "
                                      "accompanies the opinion - read the order before relying on the text")
            if status == "UNP":
                meta["publication_note"] = ("UNPUBLISHED opinion: not precedent; GR 14.1 limits citation - say "
                                            "'unpublished' wherever it is cited")
            elif status == "PAR":
                meta["publication_note"] = ("PUBLISHED IN PART: only the part before the court's dividing statement "
                                            "is precedent; the rest is unpublished (GR 14.1)")
            (G.CACHE / f"{gid}.json").write_text(json.dumps(meta, indent=1))
            res.update(found=True, granule_id=gid, name_overlap=ov, title=r["title"], division=r["division"],
                       pub_status=status, file_contains=r["file_contains"], pdf_url=meta["pdf_url"],
                       superseded_slip=r["superseded_slip"],
                       text_is="slip opinion; cite pages as 'slip op. at N' - reporter pages are not in this text")
            for k in ("superseded_note", "order_note", "publication_note"):
                if meta.get(k):
                    res[k] = meta[k]
            if same:
                res["ambiguous"] = True
                res["other_files_same_date"] = [wa_id(x["pdf"]) for x in same]
            return res
    if near:
        res.update(near)
    else:
        res["reason"] = (f"docket {docket} not in the court's listings searched: {', '.join(searched)}; "
                         "read through CourtListener")
    return res


# --------------------------------------------------------------------------- #
# New York - address of the Law Reporting Bureau's page (WebFetch only)
# --------------------------------------------------------------------------- #
def ny_url(cite):
    """'2024 NY Slip Op 04911' -> the Law Reporting Bureau page. The page is
    behind a browser check that this script does not attempt to pass: fetch the
    URL with WebFetch, never with curl or a script."""
    m = re.search(r"\b((?:19|20)\d{2})\s+N\.?\s?Y\.?\s+Slip\s+Op\.?\s+(\d{1,6})\s*(\(U\))?", cite or "", re.I)
    if not m:
        return {"found": False, "reason": "no 'YYYY NY Slip Op NNNNN' citation in the row; nothing to build from"}
    year, num, unrep = int(m.group(1)), int(m.group(2)), bool(m.group(3))
    if year < 2003:
        return {"found": False, "reason": "the Bureau's slip-opinion numbering starts in 2003"}
    slip = f"{year} NY Slip Op {num:05d}" + ("(U)" if unrep else "")
    url = f"https://www.nycourts.gov/reporter/3dseries/{year}/{year}_{num:05d}.htm"
    return {"found": True, "slip_opinion": slip, "url": url, "fetch_with": "WebFetch only",
            "unreported": unrep,
            "use": ("an official-page check, not a reading lane: confirm the case name, the court and date, the "
                    "official citation printed in brackets at the top ([219 AD3d 1251]) and any 'As corrected "
                    "through' date. Read and quote-verify the opinion through CourtListener."),
            "note": ("address built from the slip-opinion number, not looked up: a page that does not name the "
                     "same case is a miss, not a correction. " +
                     ("Unreported '(U)' dispositions are not published in the Official Reports." if unrep else ""))}


# --------------------------------------------------------------------------- #
# Engine hooks (called by govinfo.fetch)
# --------------------------------------------------------------------------- #
def download(gid, cache):
    """PDF bytes for an OJD- or WA- id. Writes the metadata sidecar."""
    if gid.startswith("OJD-"):
        meta = ojd_item(gid)
        data = _get(meta["pdf_url"], timeout=180)
        if not data.startswith(b"%PDF"):                 # the collection sometimes answers once with a web page
            time.sleep(2)
            data = _get(meta["pdf_url"], timeout=180)
        return data
    if gid.startswith("WA-"):
        side = cache / f"{gid}.json"
        if not side.exists():
            side.write_text(json.dumps({"source": "Washington Courts slip opinion (courts.wa.gov) - NOT the official "
                                        "report", "id": gid, "pdf_url": wa_pdf_url(gid),
                                        "unresolved_note": "fetched by file name without `wa-resolve`: the docket, "
                                        "date and title were not checked against the court's listing"}, indent=1))
        return _get(wa_pdf_url(gid), timeout=180)
    raise ValueError(f"unknown id prefix: {gid}")


def identity(gid, text, meta):
    """Does the document say it is the case the catalogue says it is?"""
    first = re.sub(r"\s+", " ", "\f".join(text.split("\f")[:3]))
    squash = re.sub(r"[^A-Za-z0-9]", "", first).upper()
    out = {}
    if gid.startswith("OJD-"):
        num = re.sub(r"[^A-Za-z0-9]", "", meta.get("case_number") or "").upper()
        if num:
            out["case_number_in_document"] = num in squash
        cite = meta.get("citation") or ""
        m = re.match(r"\s*(\d+)\s+(Or(?:\s+App)?|OTR)\s+(\d+)", cite)
        if m:
            out["citation_in_document"] = bool(re.search(
                r"(?:Cite as|Memo Op:)\s+" + m.group(1) + r"\s+" + m.group(2).replace(" ", r"\s+") + r"\s+" +
                m.group(3), first))
    elif gid.startswith("WA-"):
        d = meta.get("docket_digits")
        if d:
            out["docket_number_in_document"] = d in re.sub(r"\D", "", first[:6000]) or d[:-1] in re.sub(r"\D", "", first[:6000])
    if out and not any(out.values()):
        out["warning"] = ("neither the case number nor the citation in the catalogue record appears in the opening "
                          "pages (an OCR scan can hide them) - confirm the caption before relying on this text")
    return out


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def resolve_row(r):
    if not isinstance(r, dict):
        return {"found": False, "reason": "row is not an object"}
    court = (r.get("court_id") or r.get("court_code") or "").strip()
    docket = r.get("docketNumber") or r.get("docket_number") or ""
    date = r.get("dateFiled") or r.get("date_filed") or ""
    name = r.get("caseName") or r.get("case_name") or r.get("title") or ""
    cites = r.get("citation") or r.get("citation_strings") or []
    if isinstance(cites, str):
        cites = [cites]
    try:
        if court in OR_COURTS:
            x = or_resolve(court, cites, docket, date, name)
        elif court in WA_COURTS:
            x = wa_resolve(court, docket, date, name, cites)
        elif is_ny_state(court):
            u = ny_url(" ; ".join(cites))
            x = {"found": False, "collection": "nycourts.gov Law Reporting Bureau (WebFetch only; not a text lane)",
                 "lane": "CourtListener",
                 "reason": "New York: no scripted text lane - read and verify through CourtListener"}
            if u.get("found"):
                x["official_page_url"] = u["url"]
                x["slip_opinion"] = u["slip_opinion"]
                x["unreported"] = u["unreported"]
                x["official_page_use"] = u["use"]
            else:
                x["official_page_url"] = None
                x["official_page_reason"] = u.get("reason")
        else:
            x = {"found": False, "reason": f"court '{court}' is not served by statecourts.py (Oregon: or, orctapp, "
                 "ortc; Washington: wash, washctapp; New York: URL only). Federal rows go to govinfo.py."}
    except Refused as e:
        x = {"found": False, "reason": str(e)}
    except Exception as e:
        x = {"found": False, "reason": f"could not check ({type(e).__name__}): {G._clean(e)}"}
    x["cluster_id"] = r.get("cluster_id")
    x["case_name"] = name
    x.setdefault("court", court)
    return x


def probe():
    out = {}
    try:
        t3, new3 = ojd_search("p17027coll3", [("Opinion", "title", "all")], n=1)
        t5, new5 = ojd_search("p17027coll5", [("Opinion", "title", "all")], n=1)
        out["oregon"] = {"ok": bool(new3 and new5), "supreme_court_items_titled_opinion": t3,
                         "newest_supreme_court": new3[0] if new3 else None,
                         "court_of_appeals_items_titled_opinion": t5,
                         "newest_court_of_appeals": new5[0] if new5 else None}
    except Exception as e:
        out["oregon"] = {"ok": False, "error": G._clean(e),
                         "meaning": "Oregon lane unavailable this run: read Oregon cases through CourtListener"}
    try:
        year = datetime.date.today().year
        rows = wa_listing(year, "S", "PUB", fresh=True)          # a live request, not the day's cache
        if not rows:                                             # early January: nothing filed yet this year
            year -= 1
            rows = wa_listing(year, "S", "PUB", fresh=True)
        out["washington"] = {"ok": bool(rows), "listing_year": year, "supreme_court_published_that_year": len(rows),
                             "newest": max(rows, key=lambda r: r["file_date"]) if rows else None,
                             "text_is": "slip opinions; the official reports are not available to automation"}
        if not rows:
            out["washington"]["meaning"] = "listing parsed to zero rows: treat the Washington lane as unavailable"
    except Exception as e:
        out["washington"] = {"ok": False, "error": G._clean(e),
                             "meaning": "Washington lane unavailable this run: read through CourtListener"}
    out["new_york"] = {"ok": None, "scripted": False,
                       "meaning": "no scripted access by design; `ny-url` builds the Law Reporting Bureau address "
                                  "for a WebFetch official-page check"}
    out["pdftotext"] = subprocess.run(["which", "pdftotext"], capture_output=True).returncode == 0
    out["cache_dir"] = str(G.CACHE)
    return out


def main():
    if len(sys.argv) > 1 and sys.argv[1] in ("fetch", "read", "grep", "triage", "verify"):
        try:
            return G.main()
        except SystemExit:
            raise
        except Exception as e:                   # never a traceback
            print(json.dumps({"found": False, "ok": False, "error": G._clean(f"{type(e).__name__}: {e}")}, indent=1))
            return
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("probe")
    p = sub.add_parser("resolve-batch")
    p.add_argument("rows")
    p = sub.add_parser("or-resolve")
    p.add_argument("--court", default="orctapp")
    p.add_argument("--cite", action="append")
    p.add_argument("--docket")
    p.add_argument("--date")
    p.add_argument("--name")
    p = sub.add_parser("or-search")
    p.add_argument("terms", nargs="+")
    p.add_argument("--court", default="all")
    p.add_argument("--any", action="store_true")
    p.add_argument("--after")
    p.add_argument("--before")
    p.add_argument("-n", type=int, default=20)
    p = sub.add_parser("or-history")
    p.add_argument("target")
    p.add_argument("--cite")
    p = sub.add_parser("wa-resolve")
    p.add_argument("--court", default="washctapp")
    p.add_argument("--docket")
    p.add_argument("--date")
    p.add_argument("--name")
    p.add_argument("--cite", action="append")
    p = sub.add_parser("wa-list")
    p.add_argument("--year", type=int, required=True)
    p.add_argument("--court", default="wash")
    p.add_argument("--status", default="PUB", choices=["PUB", "UNP", "PAR"])
    p.add_argument("--grep")
    p = sub.add_parser("ny-url")
    p.add_argument("cite")
    a = ap.parse_args()

    def emit(x):
        print(json.dumps(x, indent=1, ensure_ascii=False))

    try:
        if a.cmd == "probe":
            emit(probe())
        elif a.cmd == "resolve-batch":
            rows = json.load(open(a.rows))
            out = [resolve_row(r) for r in rows]          # sequential: one request a second per host
            emit({"resolved": sum(1 for o in out if o.get("found") and o.get("granule_id")),
                  "new_york_page_urls": sum(1 for o in out if o.get("official_page_url")),
                  "of": len(out), "rows": out})
        elif a.cmd == "or-resolve":
            emit(or_resolve(a.court, a.cite, a.docket, a.date, a.name))
        elif a.cmd == "or-search":
            emit(or_search(a.terms, a.court, a.any, a.after, a.before, a.n))
        elif a.cmd == "or-history":
            emit(or_history(a.target, a.cite))
        elif a.cmd == "wa-resolve":
            emit(wa_resolve(a.court, a.docket, a.date, a.name, a.cite))
        elif a.cmd == "wa-list":
            if a.court not in WA_COURTS:
                emit({"error": "--court takes wash or washctapp"})
                return
            rows = wa_listing(a.year, WA_COURTS[a.court], a.status)
            if a.grep:
                g = a.grep.lower()
                rows = [r for r in rows if g in (r["title"] + " " + r["docket"]).lower()]
            emit({"count": len(rows), "rows": [dict(r, id=wa_id(r["pdf"])) for r in rows[:200]]})
        elif a.cmd == "ny-url":
            emit(ny_url(a.cite))
    except Refused as e:
        emit({"ok": False, "error": str(e)})
    except Exception as e:
        emit({"ok": False, "error": f"{type(e).__name__}: {G._clean(e)}"})


if __name__ == "__main__":
    main()
