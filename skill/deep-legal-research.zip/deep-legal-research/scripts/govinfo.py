#!/usr/bin/env python3
"""GovInfo (api.govinfo.gov) helper for deep-legal-research (v10.0).

GovInfo is the Government Publishing Office's repository. Two collections
matter here:

  USCOURTS   the courts' own PDFs of federal appellate, district and
             bankruptcy opinions, generally 2004-present, PARTICIPATING
             COURTS ONLY. No Supreme Court. No state courts.
  USREPORTS  the bound United States Reports, volumes 1-586 (through early
             2019): Supreme Court opinions with official page numbers.

The API allows 36,000 requests an hour against CourtListener's 125 a day, so
this script moves the READING, the TRIAGE and the QUOTE CHECKING of federal
opinions off the CourtListener budget. CourtListener remains the only source
of reporter citations for USCOURTS cases and the only citator.

Nothing here composes a citation and nothing here invents text. Every command
prints JSON, and "not found" is always a valid answer (``"found": false``).

Commands
--------
  probe                               reachability, rate-limit headers, tools
  resolve  --court ord --docket "3:20-cv-01695" --date 2021-08-12 --name "Escobar v. ..."
  resolve  --court scotus --cite "563 U.S. 333" --name "AT&T Mobility v. Concepcion"
                                      one CourtListener row -> one GovInfo granule
  resolve-batch rows.json             the same for a JSON array of CourtListener rows
                                      (keys: court_id, docketNumber, dateFiled, caseName, citation[])
  fetch    GRANULE [GRANULE ...]      download the PDF(s), extract text, cache both
  read     GRANULE [--pages 3-7] [--raw]
                                      print the cached text, page by page
  grep     GRANULE "phrase" [...]     normalized literal search, with page numbers
  triage   GRANULE [...] --terms "a" "b"
                                      fetch many, count term hits, one snippet each
  verify   GRANULE quotes.json        grade quotes verified / likely / not_found
  search   "terms" [--court ord] [--circuit 9th] [--courttype district]
           [--after YYYY-MM-DD] [--before YYYY-MM-DD] [-n 20]
                                      full-text search of USCOURTS (discovery)
  cites    --name "Bielski v. Coinbase" [--cite "87 F.4th 1003"] [--negative]
           [--after YYYY-MM-DD] [-n 30] [--context 5]
                                      federal opinions that mention a case
  docket   GRANULE                    the docket's other filings: same-case history for a search-found decision
  usc      --title 15 --section 1692k [--year 2008]
                                      one U.S.C. section from GPO's annual edition

The API key is read from $GOVINFO_API_KEY, else from ``govinfo.key`` beside
this script. Cache: $GOVINFO_CACHE, else ~/.cache/govinfo.
"""
import argparse
import bisect
import concurrent.futures as cf
import difflib
import json
import os
import pathlib
import re
import subprocess
import sys
import time
import unicodedata
import urllib.error
import urllib.request

sys.dont_write_bytecode = True            # never leave __pycache__ in the skill folder (it ships as a zip)
API = "https://api.govinfo.gov"
HERE = pathlib.Path(__file__).resolve().parent
CACHE = pathlib.Path(os.environ.get("GOVINFO_CACHE", pathlib.Path.home() / ".cache" / "govinfo"))

# CourtListener court_id -> GovInfo court code, where they differ. Everything
# else (ord, waed, ca9, cand, orb ...) is the same string in both systems.
COURT_ALIASES = {"cafc": "ca13", "cadc": "caDC", "uscfc": "cofc"}

# District courts measured ABSENT from USCOURTS on 2026-10-03 (0 district
# granules; their bankruptcy courts do publish). resolve() answers found:false
# for these without spending a request.
KNOWN_ABSENT = {"wawd", "nysd", "cacd"}

NEGATIVE = ('(overrul* OR abrogat* OR disavow* OR "no longer good law" OR "declined to follow" '
            'OR "decline to follow" OR "superseded by" OR "called into doubt")')


def _clean(e):
    """Text of an error with the API key removed. Nothing this script prints
    may contain the key."""
    return re.sub(r"api_key=[^&\s'\"]+", "api_key=***", str(e))

STATES = {"al": "Alabama", "ak": "Alaska", "az": "Arizona", "ar": "Arkansas", "ca": "California", "co": "Colorado",
          "ct": "Connecticut", "de": "Delaware", "dc": "Columbia", "fl": "Florida", "ga": "Georgia", "hi": "Hawaii",
          "id": "Idaho", "il": "Illinois", "in": "Indiana", "ia": "Iowa", "ks": "Kansas", "ky": "Kentucky",
          "la": "Louisiana", "me": "Maine", "md": "Maryland", "ma": "Massachusetts", "mi": "Michigan",
          "mn": "Minnesota", "ms": "Mississippi", "mo": "Missouri", "mt": "Montana", "ne": "Nebraska",
          "nv": "Nevada", "nh": "New Hampshire", "nj": "New Jersey", "nm": "New Mexico", "ny": "New York",
          "nc": "North Carolina", "nd": "North Dakota", "oh": "Ohio", "ok": "Oklahoma", "or": "Oregon",
          "pa": "Pennsylvania", "pr": "Puerto Rico", "ri": "Rhode Island", "sc": "South Carolina",
          "sd": "South Dakota", "tn": "Tennessee", "tx": "Texas", "ut": "Utah", "vt": "Vermont", "va": "Virginia",
          "wa": "Washington", "wv": "West Virginia", "wi": "Wisconsin", "wy": "Wyoming"}
DIRS = {"n": "Northern", "s": "Southern", "e": "Eastern", "w": "Western", "m": "Middle", "c": "Central"}
ORD = {1: "First", 2: "Second", 3: "Third", 4: "Fourth", 5: "Fifth", 6: "Sixth", 7: "Seventh", 8: "Eighth",
       9: "Ninth", 10: "Tenth", 11: "Eleventh"}


BB_STATE = {"al": "Ala.", "ak": "Alaska", "az": "Ariz.", "ar": "Ark.", "ca": "Cal.", "co": "Colo.", "ct": "Conn.",
            "de": "Del.", "dc": "D.C.", "fl": "Fla.", "ga": "Ga.", "hi": "Haw.", "id": "Idaho", "il": "Ill.",
            "in": "Ind.", "ia": "Iowa", "ks": "Kan.", "ky": "Ky.", "la": "La.", "me": "Me.", "md": "Md.",
            "ma": "Mass.", "mi": "Mich.", "mn": "Minn.", "ms": "Miss.", "mo": "Mo.", "mt": "Mont.", "ne": "Neb.",
            "nv": "Nev.", "nh": "N.H.", "nj": "N.J.", "nm": "N.M.", "ny": "N.Y.", "nc": "N.C.", "nd": "N.D.",
            "oh": "Ohio", "ok": "Okla.", "or": "Or.", "pa": "Pa.", "pr": "P.R.", "ri": "R.I.", "sc": "S.C.",
            "sd": "S.D.", "tn": "Tenn.", "tx": "Tex.", "ut": "Utah", "vt": "Vt.", "va": "Va.", "wa": "Wash.",
            "wv": "W. Va.", "wi": "Wis.", "wy": "Wyo."}
BB_CIR = {1: "1st", 2: "2d", 3: "3d", 4: "4th", 5: "5th", 6: "6th", 7: "7th", 8: "8th", 9: "9th", 10: "10th",
          11: "11th"}


def court_citation_string(code):
    """Court abbreviation for a slip-opinion citation, derived mechanically
    from the GovInfo court code (a fixed table, never from memory): 'ord' ->
    'D. Or.', 'waed' -> 'E.D. Wash.', 'ca9' -> '9th Cir.', 'orb' -> 'Bankr. D. Or.'.
    None when the code has no regular form - then cite the full court name."""
    code = COURT_ALIASES.get(code, code)
    m = re.fullmatch(r"ca(\d{1,2})", code)
    if m and int(m.group(1)) in BB_CIR:
        return f"{BB_CIR[int(m.group(1))]} Cir."
    if code == "ca13":
        return "Fed. Cir."
    if code == "caDC":
        return "D.C. Cir."
    m = re.fullmatch(r"([a-z]{2})([nsewmc]?)([db])", code)
    if m and m.group(1) in BB_STATE:
        st, d, kind = m.groups()
        if st == "dc":
            base = "D.D.C."
        else:
            ab = BB_STATE[st]
            # Bluebook closes up adjacent single capitals: S.D.N.Y., D.N.J., but E.D. Wash., S.D. W. Va.
            sep = "" if re.fullmatch(r"([A-Z]\.)+", ab) else " "
            base = (f"{d.upper()}.D." if d else "D.") + sep + ab
        return ("Bankr. " + base) if kind == "b" else base
    return None


def court_name(code):
    """CourtListener/GovInfo court code -> the exact ``courtname:`` phrase
    GovInfo indexes, or None when the code has no regular form."""
    code = COURT_ALIASES.get(code, code)
    m = re.fullmatch(r"ca(\d{1,2})", code)
    if m and int(m.group(1)) in ORD:
        return f"United States Court of Appeals for the {ORD[int(m.group(1))]} Circuit"
    if code == "ca13":
        return "United States Court of Appeals for the Federal Circuit"
    if code == "caDC":
        return "United States Court of Appeals for the District of Columbia Circuit"
    m = re.fullmatch(r"([a-z]{2})([nsewmc]?)([db])", code)
    if m and m.group(1) in STATES:
        st, d, kind = m.groups()
        where = (f"{DIRS[d]} District of " if d else "District of ") + STATES[st]
        return ("United States District Court " if kind == "d" else "United States Bankruptcy Court ") + where
    return None


# --------------------------------------------------------------------------- #
# HTTP
# --------------------------------------------------------------------------- #
def api_key():
    k = os.environ.get("GOVINFO_API_KEY")
    if k:
        return k.strip()
    f = HERE / "govinfo.key"
    if f.exists():
        return f.read_text().strip()
    raise RuntimeError("no GovInfo API key: set GOVINFO_API_KEY or create scripts/govinfo.key")


def _open(url, data=None, timeout=60, tries=3):
    sep = "&" if "?" in url else "?"
    full = f"{url}{sep}api_key={api_key()}"
    headers = {"Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    last = None
    for i in range(tries):
        try:
            return urllib.request.urlopen(urllib.request.Request(full, data=data, headers=headers), timeout=timeout)
        except urllib.error.HTTPError as e:
            if e.code in (400, 401, 403, 404):
                raise
            last = e
            wait = 5 * (i + 1)
            if e.code == 429:
                wait = min(int(e.headers.get("Retry-After", "30") or 30), 90)
            time.sleep(wait)
        except Exception as e:  # network
            last = e
            time.sleep(3 * (i + 1))
    raise last


def get_json(path):
    with _open(f"{API}{path}") as r:
        return json.load(r), r.headers


# --------------------------------------------------------------------------- #
# Crosswalk: CourtListener row -> GovInfo granule
# --------------------------------------------------------------------------- #
DIST = re.compile(r"(\d{1,2})\s*:\s*(\d{2})\s*-\s*([A-Za-z]{2,4})\s*-\s*0*(\d{1,6})")
DIST_NO_OFFICE = re.compile(r"(?<![\d:])(\d{2})\s*-\s*([A-Za-z]{2,4})\s*-\s*0*(\d{1,6})")
APP = re.compile(r"(?<![\d:])((?:19|20)?\d{2})\s*-\s*0*(\d{1,6})(?!\d)")
US_CITE = re.compile(r"\b(\d{1,3})\s+U\.\s?S\.\s+(\d{1,4})\b")


def package_candidates(court, docket):
    """Candidate USCOURTS package ids for a court code + docket number.

    District / bankruptcy:  '3:20-cv-01695-SI' -> USCOURTS-ord-3_20-cv-01695
    Appellate:              '21-3234'          -> USCOURTS-ca3-21-03234, and the
                            unpadded form, which newer Ninth Circuit numbers use
    A docket string may hold several numbers (consolidated cases); each is tried.
    Returns (candidates, guessed) - guessed is True when the office digit had to
    be guessed, in which case resolve() demands a date AND a name match.
    """
    court = COURT_ALIASES.get(court, court)
    out, guessed = [], False
    appellate = bool(re.fullmatch(r"ca(\d{1,2}|DC)", court))
    for m in DIST.finditer(docket or ""):
        office, yy, typ, num = m.groups()
        c = f"USCOURTS-{court}-{int(office)}_{yy}-{typ.lower()}-{int(num):05d}"
        if c not in out:
            out.append(c)
    if not out and not appellate:
        # '18-cv-03395-PJH' (no office digit - common in reporter text) and a
        # bare 'Civil Action No. 15-1294': try every office.
        m = DIST_NO_OFFICE.search(docket or "")
        if m:
            yy, typ, num = m.groups()
            out = [f"USCOURTS-{court}-{o}_{yy}-{typ.lower()}-{int(num):05d}" for o in range(1, 10)]
            guessed = True
        else:
            m = APP.search(docket or "")
            if m:
                yy, num = m.groups()
                out = [f"USCOURTS-{court}-{o}_{yy[-2:]}-cv-{int(num):05d}" for o in range(1, 10)]
                guessed = True
    if not out:
        for m in APP.finditer(docket or ""):
            yy, num = m.groups()
            yy = yy[-2:]                                  # Fed. Cir. '2020-1234' -> '20'
            for c in (f"USCOURTS-{court}-{yy}-{int(num):05d}", f"USCOURTS-{court}-{yy}-{int(num)}"):
                if c not in out:
                    out.append(c)
    return out, guessed


def _name_tokens(s):
    s = unicodedata.normalize("NFKD", s or "").lower()
    s = re.sub(r"\b(et al|et ux|inc|llc|llp|corp|corporation|company|co|ltd|lp|the|of|and|for|on behalf|"
               r"themselves|others|similarly|situated|individually|dba|united states)\b", " ", s)
    return set(re.findall(r"[a-z]{3,}", s))


def name_overlap(a, b):
    A, B = _name_tokens(a), _name_tokens(b)
    if not A or not B:
        return 0.0
    return round(len(A & B) / min(len(A), len(B)), 2)


def list_granules(pkg, cap=1000):
    """Every granule of a package (a docket), following GovInfo's pagination."""
    out, path = [], f"/packages/{pkg}/granules?offsetMark=*&pageSize=100"
    count = None
    while path and len(out) < cap:
        d, _ = get_json(path)
        count = d.get("count", count)
        out += d.get("granules", [])
        nxt = d.get("nextPage")
        path = nxt.replace(API, "").split("&api_key")[0] if nxt else None
    return out, (count if count is not None else len(out))


def resolve_usreports(citations, name):
    res = {"court": "scotus", "found": False, "collection": "USREPORTS"}
    if not name:
        res["reason"] = "no case name supplied; a granule is never chosen without one"
        return res
    if isinstance(citations, str):
        citations = [citations]
    cites = [m.groups() for c in (citations or []) for m in US_CITE.finditer(str(c))]
    if not cites:
        res["reason"] = "no 'U.S.' citation supplied; U.S. Reports granules are addressed by volume and page"
        return res
    vol, page = cites[0]
    gid = f"USREPORTS-{int(vol)}-{int(page)}"
    try:
        gs, _ = get_json(f"/packages/USREPORTS-{int(vol)}/granules/{gid}/summary")
    except urllib.error.HTTPError as e:
        if e.code in (400, 404):
            res["reason"] = (f"{gid} is not in GovInfo (U.S. Reports coverage is volumes 1-586, through early 2019; "
                             "a case that does not begin on that page also misses)")
            return res
        raise
    res.update(granule_id=gid, package_id=f"USREPORTS-{int(vol)}", title=gs.get("title"),
               us_citation=gs.get("usCitation"), full_citation=gs.get("fullCitation"),
               decision_date=(gs.get("decisionDate") or {}).get("date"), disposition=gs.get("disposition"),
               details_url=gs.get("detailsLink"))
    if name:
        res["name_overlap"] = name_overlap(name, gs.get("title", ""))
        if res["name_overlap"] < 0.34:
            res["reason"] = "a case begins at that U.S. page but its title does not match the case name; not used"
            return res
    res["found"] = True
    return res


def resolve(court, docket=None, date=None, name=None, citations=None):
    """Map one CourtListener row to a GovInfo granule. Never guesses: a miss on
    the docket, the date or the name is ``found: false`` with the reason."""
    if court == "scotus":
        return resolve_usreports(citations, name)
    date = (date or "")[:10]
    res = {"court": court, "docket": docket, "date": date, "found": False, "collection": "USCOURTS"}
    if not re.fullmatch(r"[A-Za-z0-9]{2,8}", court or ""):
        res["reason"] = ("court must be a CourtListener court id such as 'ord' or 'ca9' (the search field "
                         "`court_id`), not a court name")
        return res
    if court in KNOWN_ABSENT:
        res["reason"] = f"court '{court}' does not publish to GovInfo USCOURTS (measured 2026-10-03)"
        return res
    cands, guessed = package_candidates(court, docket)
    if not cands:
        res["reason"] = "docket number not in a constructible form (pre-CM/ECF or malformed)"
        return res
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
        res["reason"] = "no decision date (YYYY-MM-DD) supplied; a granule is never chosen without one"
        return res
    if not name or not _name_tokens(name):
        res["reason"] = "no case name supplied; a granule is never chosen without a docket, date AND name match"
        return res
    near = None
    for pkg in cands:
        try:
            summ, _ = get_json(f"/packages/{pkg}/summary")
        except urllib.error.HTTPError as e:
            if e.code in (400, 404):
                continue
            raise
        gl, gcount = list_granules(pkg)
        same_day = [g for g in gl if (g.get("dateIssued") or "")[:10] == date]
        ov = name_overlap(name, summ.get("title", "")) if name else None
        info = {"package_id": pkg, "title": summ.get("title"), "granule_count": gcount,
                "details_url": summ.get("detailsLink")}
        if ov is not None:
            info["name_overlap"] = ov
        if guessed and (not same_day or (ov is not None and ov < 0.5)):
            continue                      # an office guess that fails either check is not this case
        if not same_day:
            near = dict(info, reason="package exists but no granule is dated " + date +
                        " (an amended or superseding opinion may have replaced it - see granule_dates)",
                        granule_dates=sorted({g.get("dateIssued") for g in gl if g.get("dateIssued")}))
            continue
        if ov is not None and ov < 0.34:
            near = dict(info, reason="a package with this docket number and date exists but its title does not "
                                     "match the case name - probably a different or consolidated case; not used")
            continue
        res.update(info)
        res["found"] = True
        res["granule_id"] = same_day[0]["granuleId"]
        res["granules_same_date"] = [g["granuleId"] for g in same_day]
        res["ambiguous"] = len(same_day) > 1
        res["docket_text"] = {}
        for g in same_day:
            try:
                gs, _ = get_json(f"/packages/{pkg}/granules/{g['granuleId']}/summary")
                res["docket_text"][g["granuleId"]] = gs.get("docketText")
            except Exception as e:        # metadata only; never fatal
                res["docket_text"][g["granuleId"]] = f"(unavailable: {_clean(e)})"
        dt_all = " ".join(v or "" for v in res["docket_text"].values())
        res.update(_hints(dt_all))
        if res["ambiguous"]:
            res["ambiguity_note"] = ("several filings share this date; granule_id is only the first. Choose by "
                                     "docket_text and by reading the opening of each.")
        res["pdf_url"] = pdf_url(res["granule_id"])
        res["other_granules"] = [{"granuleId": g["granuleId"], "dateIssued": g.get("dateIssued")}
                                 for g in gl if g not in same_day][:60]
        return res
    if near:
        res.update(near)
    else:
        res["reason"] = "no GovInfo package for this docket (the court may not have published this document)"
    return res


RECOMMENDATION = re.compile(r"(findings?,?\s*(and|&)\s*recommendations?|report,?\s*(and|&)?\s*recommendations?|"
                            r"memorandum\s*(and|&)\s*recommendations?|proposed findings|recommended disposition|"
                            r"\bF\s*&\s*R\b|\bR\s*&\s*R\b)", re.I)
ADOPTS = re.compile(r"\b(adopt|accept|affirm|approv|reject|overrul|sustain|modif|declin)\w*", re.I)


def looks_like_recommendation(text):
    """True when a docket entry or a document's opening reads as a magistrate
    judge's findings/report and recommendation rather than an order acting on one."""
    head = (text or "")[:400]
    m = RECOMMENDATION.search(head)
    return bool(m) and not ADOPTS.search(head[:m.end() + 40])


CAPTION_RECO = re.compile(r"FINDINGS?,?\s+(AND|&)\s+(?:[A-Za-z,.()' ]{0,30}\s+)?RECOMMENDATIONS?|"
                          r"REPORT,?\s+(AND\s+|&\s+)?(?:[A-Za-z,.()' ]{0,30}\s+)?RECOMMENDATIONS?|"
                          r"MEMORANDUM\s+(AND|&)\s+(?:[A-Za-z,.()' ]{0,30}\s+)?RECOMMENDATIONS?")


def caption_recommendation(text):
    """True when the document's own caption (its first ~1,200 characters) is
    titled as findings/report and recommendation, in capitals, and is not an
    order adopting one."""
    cap = re.sub(r"\s+", " ", (text or "")[:4000])[:1200]
    return bool(CAPTION_RECO.search(cap)) and not re.search(r"ADOPTING|ORDER ON (REPORT|FINDINGS)", cap)


def _hints(docket_text):
    out = {}
    if re.search(r"\badopt|findings?\s*(and|&)\s*recommendation|\bF\s*&\s*R\b|report and recommendation|"
                 r"\bR\s*&\s*R\b", docket_text or "", re.I):
        out["adoption_hint"] = ("docket text mentions a magistrate judge's findings/recommendation: the reasoning "
                                "may be in an EARLIER filing in this docket (resolve: other_granules; docket: "
                                "earlier_granules). The reporter version usually prints both; read both.")
    if looks_like_recommendation(docket_text):
        out["recommendation_hint"] = ("this filing is a magistrate judge's FINDINGS AND RECOMMENDATION - a "
                                      "recommendation, not a ruling, until a district judge adopts it. Run `docket` "
                                      "and read adopting_orders; cite the adopting order and attribute the reasoning "
                                      "to the F&R 'as adopted'. With no adopting order it is not authority.")
    if re.search(r"vacated pursuant|opinion[^.]{0,60}(vacated|withdrawn|superseded)|amended opinion|"
                 r"order (and )?amended|withdrawn", docket_text or "", re.I):
        out["history_hint"] = ("docket text suggests THIS filing was vacated, withdrawn or amended - read "
                               "docket_text and other_granules before relying on it")
    return out


def pdf_url(gid):
    return f"https://www.govinfo.gov/content/pkg/{package_of(gid)}/pdf/{gid}.pdf"


def docket(gid, later_text=12):
    """Everything GovInfo knows about the docket a USCOURTS granule sits in:
    this filing's docket text and hints, and every other filing with its date -
    the later ones with their docket text. This is the history check for a
    decision found by `search` (which `resolve-batch` never saw)."""
    if not gid.startswith("USCOURTS-"):
        return {"granule_id": gid, "found": False, "reason": "docket history exists only for USCOURTS granules"}
    pkg = package_of(gid)
    try:
        summ, _ = get_json(f"/packages/{pkg}/summary")
        gl, gcount = list_granules(pkg)
        mine, _ = get_json(f"/packages/{pkg}/granules/{gid}/summary")
    except urllib.error.HTTPError as e:
        why = "no such granule or package" if e.code in (400, 404) else "request refused or failed (not a 'no')"
        return {"granule_id": gid, "found": False, "reason": f"HTTP {e.code} - {why}"}
    my_date = (mine.get("dateIssued") or "")[:10]
    res = {"granule_id": gid, "found": True, "package_id": pkg, "title": summ.get("title"),
           "date_issued": my_date, "docket_text": mine.get("docketText"), "granule_count": gcount,
           "details_url": mine.get("detailsLink"), "pdf_url": pdf_url(gid)}
    res.update(_hints(mine.get("docketText")))
    same = [g["granuleId"] for g in gl if (g.get("dateIssued") or "")[:10] == my_date and g["granuleId"] != gid]
    if same:
        res["same_date_granules"] = same
    later = sorted((g for g in gl if (g.get("dateIssued") or "")[:10] > my_date),
                   key=lambda g: g.get("dateIssued") or "")
    res["earlier_granules"] = [{"granuleId": g["granuleId"], "dateIssued": g.get("dateIssued")}
                               for g in gl if (g.get("dateIssued") or "")[:10] < my_date][-30:]
    res["later_granules"] = []
    for g in later:
        item = {"granuleId": g["granuleId"], "dateIssued": g.get("dateIssued")}
        if len(res["later_granules"]) < later_text:
            try:
                gs, _ = get_json(f"/packages/{pkg}/granules/{g['granuleId']}/summary")
                item["docket_text"] = gs.get("docketText")
            except Exception as e:
                item["docket_text"] = f"(unavailable: {_clean(e)})"
        res["later_granules"].append(item)
    res["is_recommendation"] = looks_like_recommendation(mine.get("docketText"))
    res["adopting_orders"] = [{"granuleId": g["granuleId"], "dateIssued": g["dateIssued"],
                               "docket_text": g.get("docket_text")}
                              for g in res["later_granules"]
                              if re.search(r"\badopt", g.get("docket_text") or "", re.I)]
    if res["adopting_orders"]:
        res["adopting_orders_note"] = ("orders in this docket that adopt A recommendation - not necessarily this "
                                       "one: match the document number (ECF/Doc. No.) or date named in the order, "
                                       "and read 'adopted in part' / 'as modified' orders in full")
        if not res["is_recommendation"]:
            res["possible_recommendation"] = ("later orders adopt a report/recommendation and this filing's docket "
                                              "text does not say what it is - read its caption (fetch: `opening`, "
                                              "`recommendation_in_caption`) before treating it as a ruling")
    res["note"] = ("later_granules are leads (amended opinion, reconsideration, order after remand): fetch and grep "
                   "them. An empty list is NOT a clean history - appeals are separate dockets and are not shown.")
    return res


# --------------------------------------------------------------------------- #
# Fetch + text
# --------------------------------------------------------------------------- #
def paths(gid):
    CACHE.mkdir(parents=True, exist_ok=True)
    return CACHE / f"{gid}.pdf", CACHE / f"{gid}.txt"


def kind_of(gid):
    """Which collection an id belongs to. USCOURTS-/USREPORTS- ids are GovInfo;
    OJD- (Oregon appellate opinions, official reports) and WA- (Washington
    slip opinions) are served by scripts/statecourts.py."""
    if gid.startswith("USREPORTS-"):
        return "usreports"
    if gid.startswith("OJD-"):
        return "ojd"
    if gid.startswith("WA-"):
        return "wa"
    return "uscourts"


def meta_of(gid):
    """Sidecar metadata written beside the cached PDF by the state-court fetchers."""
    f = CACHE / f"{gid}.json"
    try:
        return json.loads(f.read_text()) if f.exists() else {}
    except Exception:
        return {}


def package_of(gid):
    if gid.startswith("USREPORTS-"):
        return "-".join(gid.split("-")[:2])
    return gid.rsplit("-", 1)[0]


def is_ocr(pdf):
    """True when the text layer is OCR of page scans rather than born-digital
    text: most pages hold a sheet-shaped image, or an OCR engine produced it."""
    try:
        info = subprocess.run(["pdfinfo", str(pdf)], capture_output=True, text=True).stdout
        if re.search(r"ABBYY|FineReader|Tesseract", info, re.I):
            return True
        m = re.search(r"Pages:\s+(\d+)", info)
        n = int(m.group(1)) if m else 0
        rows = subprocess.run(["pdfimages", "-list", str(pdf)], capture_output=True, text=True).stdout.splitlines()[2:]
        scanned = set()
        for line in rows:
            c = line.split()
            if len(c) > 4 and c[3].isdigit() and c[4].isdigit():
                w, h = int(c[3]), int(c[4])
                if w >= 1000 and 1.2 <= h / w <= 1.6:
                    scanned.add(c[0])
        return n > 0 and len(scanned) >= 0.5 * n
    except Exception:
        return None


def fetch(gid, force=False):
    pdf, txt = paths(gid)
    out = {"granule_id": gid, "cached": txt.exists() and pdf.exists() and not force}
    if not out["cached"]:
        try:
            if kind_of(gid) in ("ojd", "wa"):
                import statecourts                       # same folder; no GovInfo key involved
                data = statecourts.download(gid, CACHE)
            else:
                with _open(f"{API}/packages/{package_of(gid)}/granules/{gid}/pdf", timeout=180) as r:
                    data = r.read()
        except urllib.error.HTTPError as e:
            return {"granule_id": gid, "found": False, "reason": f"HTTP {e.code} fetching PDF"}
        except Exception as e:
            return {"granule_id": gid, "found": False, "reason": f"could not retrieve (network): {_clean(e)}"}
        if not data.startswith(b"%PDF"):
            return {"granule_id": gid, "found": False, "reason": "response was not a PDF"}
        pdf.write_bytes(data)
        try:
            # -layout keeps each printed line intact and the CM/ECF stamp on its
            # own line; raw mode interleaves the stamp into sentences (measured).
            subprocess.run(["pdftotext", "-layout", "-enc", "UTF-8", str(pdf), str(txt)],
                           check=True, capture_output=True)
        except (FileNotFoundError, subprocess.CalledProcessError):
            try:
                from pypdf import PdfReader
                txt.write_text("\f".join((p.extract_text() or "") for p in PdfReader(str(pdf)).pages))
                out["extractor_warning"] = ("pdftotext missing (install poppler-utils); pypdf text used - "
                                            "quote checks are less reliable")
            except Exception as e:
                return {"granule_id": gid, "found": False, "reason": f"no pdftotext and pypdf failed: {e}"}
    text = txt.read_text(errors="replace")
    pages = _split_pages(text)
    chars = len(text.strip())
    out.update(found=True, text_path=str(txt), pdf_path=str(pdf), pages=len(pages), chars=chars,
               opening=re.sub(r"\s+", " ", text[:700]).strip())
    if kind_of(gid) == "uscourts" and caption_recommendation(text):
        out["recommendation_in_caption"] = True
        out["recommendation_note"] = ("the document's opening reads as a magistrate judge's findings/report and "
                                      "recommendation - not a ruling unless adopted; run `docket`")
    if pages and chars / len(pages) < 200:
        out["warning"] = "under 200 characters a page: an image-only PDF with no text layer; treat as unreadable"
    out["source"] = kind_of(gid)
    m = meta_of(gid)
    if m:
        out["meta"] = m
        try:
            import statecourts
            chk = statecourts.identity(gid, text, m)
            if chk:
                out["identity_check"] = chk
        except Exception:
            pass
    out["ocr_layer"] = is_ocr(pdf)
    if out["ocr_layer"] is None:
        out["ocr_layer"] = True                     # could not tell (poppler missing): assume the worse case
        out["ocr_undetermined"] = True
    if out["ocr_layer"]:
        out["ocr_note"] = ("the text layer is OCR of a page scan; misreads are possible ('id' for 'did', ')' for ']'). "
                           "Before quoting, VIEW the PDF page (Read tool with pages=N on pdf_path) and quote what "
                           "the page image shows.")
    return out


def _split_pages(text):
    pages = text.split("\f")
    if pages and not pages[-1].strip():
        pages = pages[:-1]
    return pages


def load_pages(gid):
    r = fetch(gid)
    if not r.get("found"):
        return None, r
    return _split_pages(pathlib.Path(r["text_path"]).read_text(errors="replace")), r


# --------------------------------------------------------------------------- #
# Normalization, page furniture, index
# --------------------------------------------------------------------------- #
_TRANS = {0x2018: "'", 0x2019: "'", 0x201A: "'", 0x201B: "'", 0x2032: "'",
          0x201C: '"', 0x201D: '"', 0x201E: '"', 0x2033: '"',
          0x2013: "-", 0x2014: "-", 0x2212: "-", 0x2010: "-", 0x2011: "-",
          0x00A0: " ", 0xFB01: "fi", 0xFB02: "fl", 0xFB00: "ff", 0xFB03: "ffi", 0xFB04: "ffl"}
_DASH = "\\-\\u2013\\u2014"

STAMP = re.compile(r"^\s*(Case|Appeal|USCA\d*|Appellate Case)[:\s].{0,80}?(Document|Doc\.?|DktEntry)\b.*?"
                   r"(Page|Pg)[:\s]*\d+(\s+of\s+\d+)?.*$", re.I)
FOOT = re.compile(r"^\s*((PAGE\s+)?\d{1,3}\s*[" + _DASH + r"]\s*[A-Z][A-Z ,&'.]{4,70}|[" + _DASH + r"]?\s*\d{1,4}\s*["
                  + _DASH + r"]?|(page|pg\.?)\s*\d+(\s*(of|-)\s*\d+)?)\s*$", re.I)
US_STAMP = re.compile(r"^\s*\S*\d+US\d+\b.*(Unit:|PGT:)|PAGES\s+PGT:", re.I)
US_HEAD = re.compile(r"^\s*(Cite as:.*\d+|\d+\s{2,}\S.*|OCTOBER TERM.*|.*\S\s{2,}\d+\s*U\.\s?S\.?|.*\S\s{2,}\d+)\s*$", re.I)
US_SECTION = re.compile(r"^(Syllabus|Counsel|Per Curiam|Opinion of .{3,40}|Opinion in Chambers|Statement of .{3,40}|"
                        r"Argument for .{3,40}|Appendix to .{3,60}|Decree|Order|"
                        r"[A-Z][\w.' ,]{1,45}J\s*J?\s*\.?\s*,.{0,60}\b(concurring|dissenting)\b.{0,50})$", re.I)
NOT_OPINION_SECTION = re.compile(r"syllabus|counsel|argument for", re.I)


def _us_section(line):
    """The running head's section name, tolerant of the older volumes' layout
    ('64      Opinion of the Court.' / 'Syllabus.      304 U. S.')."""
    t = re.sub(r"^\s*\d+\s{2,}", "", line.strip())
    t = re.sub(r"\s{2,}\d+\s*U\.\s*S\.?\s*$", "", t, flags=re.I).strip().rstrip(".").strip()
    return re.sub(r"\s+", " ", t) if US_SECTION.match(t) else None


RUNHEAD = re.compile(r"^\s*(\d{1,4}\s{2,}[A-Z][A-Z0-9 .,'&\-]{5,80}|[A-Z][A-Z0-9 .,'&\-]{5,80}\s{2,}\d{1,4})\s*$")
PLEADING_NO = re.compile(r"^\s*(\d{1,2})(?=\s{2,}|\s*$)")
SOFT_HYPHEN = re.compile("\u00ad\\s*")
TOKEN = re.compile(r"(\.\s*\.\s*\.\s*\.?|\u2026)")
NEGATION = re.compile(r"\b(not|no|never|nor|neither|none|without|cannot|unless|except|but|however|only|fail\w*|"
                      r"declin\w+|reject\w+|refus\w+|den(y|ies|ied|ial)|rather than|un\w{4,}|in(correct|valid|"
                      r"sufficient|applicable|consistent)\w*)\b|n't", re.I)
ABBREV = re.compile(r"(?:\b(?:v|vs|Inc|Co|Corp|Ltd|No|Nos|Mr|Ms|Mrs|Dr|Jr|Sr|St|Cir|Cal|Wash|Or|App|Supp|Stat|"
                    r"Rev|Ch|Sec|Art|Fed|Civ|Crim|Evid|Proc|id|Id|cf|Cf|e\.g|i\.e|et al|U\.S|U\. S|F|P|S\. Ct|L\. Ed|"
                    r"[A-Z])\.)$")
JUSTICE_OPENER = re.compile(r"(?:Mr\. )?(?:Chief )?Justice ([A-Z][A-Za-z']+)(?:,[^.]{0,200}?)?,? "
                            r"(?:concurring|dissenting)[^.]{0,120}\.", re.I)
COURT_OPENER = re.compile(r"delivered the opinion of the Court|announced the judgment of the Court|"
                          r"(?<![(\w])P(?:er|ER) C(?:uriam|URIAM)\b(?!\))")
_NOT_NAMES = r"(?!(?:AFFIRMED|REVERSED|REMANDED|VACATED|DISMISSED|DENIED|GRANTED|ORDERED|SO|IT|IS|Before|BEFORE)\b)"
_NAME = r"[A-Z\u00c0-\u00dd][A-Za-z\u00c0-\u00ff'\-]+"
_TITLE = (r"(?:(?:Chief |Senior |Presiding )?(?:Circuit |District |Bankruptcy |Magistrate )?(?:Judge|Justice)"
          r"|(?:(?:C|P|S|A\s?\.\s?C)\s?\.\s?)?J\s?[.,](?:\s?P\s?\.\s?T\s?\.|\s+pro tempore)?)")
SEPARATE = re.compile(r"(?<![A-Za-z(\-])(?<!\(opinion of )(" + _NOT_NAMES + _NAME + r"(?:,? (?:JR\.|SR\.|Jr\.|Sr\.|II|III))?"
                      r"(?: " + _NOT_NAMES + r"(?:" + _NAME + r"|[A-Z]\.)){0,3})\s?,\s*" + _TITLE +
                      r"(?:"
                      # federal and Oregon style:  'MILLER, Circuit Judge, concurring in part'  /  'JAMES, J., dissenting.'
                      # (OCR variants 'ARMSTRONG,J., dissenting' and 'ARMSTRONG, P. J ., dissenting' included)
                      r"\s?,\s?(?:[^:.;()]{0,160}?)\b(?:concurring|dissenting)\b(?:\s+(?:in part|in the judgment|in the "
                      r"result|in judgment|and|concurring|dissenting|specially)|,)*(?!\s*\))"
                      # Washington style:  'MONTOYA-LEWIS, J. (dissenting)' / '(dissent in part)' / '(concurrence)'
                      r"|\s?\*?\s*[({]\s*(?i:(?:specially |partially )?(?:concur|dissent))[^)]{0,80}\)"
                      r")")


def separate_headings(disp, lo=0):
    """[(offset, heading)] of separate-opinion headings in display text.

    A match inside an open parenthesis is a citation parenthetical
    ('(De Muniz, C. J., concurring in part)'), not a heading."""
    out = []
    for m in SEPARATE.finditer(disp):
        if m.start() < lo:
            continue
        before = disp[max(0, m.start() - 110):m.start()]
        # '(De Muniz, C. J., concurring ...)' / '(Brennan, J., joined by Marshall, J., dissenting in part)':
        # the last parenthesis before the match is an opening one, with only ordinary citation text after it
        if re.search(r"[(\[][A-Za-z0-9 .,;'&\-]{0,100}$", before):
            continue
        out.append((m.start(), re.sub(r"\s+", " ", m.group(0)).strip(" ,")))
    return out


MAX_GAP = 400          # an ellipsis may skip at most this many characters of the opinion
MIN_SEG = 12           # each part of an elided quote must be at least this long ...
MIN_SEG_WORDS = 3      # ... and at least this many words


def _edge_lines(lines, k=3):
    idx = [i for i, ln in enumerate(lines) if ln.strip()]
    return idx[:k], idx[-k:]


def _strip_page_furniture(page, usreports=False):
    """Drop the CM/ECF stamp, running heads and running footers so they never
    sit inside a sentence. Returns (body, section) - section is the U.S. Reports
    running head ('Syllabus', 'Opinion of the Court', 'Thomas, J., concurring'),
    or None when it could not be read."""
    lines = page.split("\n")
    head, tail = _edge_lines(lines, 6 if usreports else 3)
    drop, section = set(), None
    if usreports:
        # running head = [printer's stamp] + page/title line (+ caption overflow) + section line
        for n, i in enumerate(head):
            if US_STAMP.search(lines[i]):
                drop.add(i)
                continue
            sec = _us_section(lines[i])
            if sec:
                section = sec
                drop.update(j for j in head[:n + 1])      # everything above the section line is running head
                break
        if section is None:
            first = [i for i in head if i not in drop][:1]
            for i in first:
                if US_HEAD.match(lines[i]):
                    drop.add(i)
    else:
        for i in set(head) | set(tail):
            if STAMP.match(lines[i]) or FOOT.match(lines[i]):
                drop.add(i)
        for i in head:                         # '14      BIELSKI V. COINBASE, INC.' (appellate running head)
            if RUNHEAD.match(lines[i]):
                drop.add(i)
        # Line-numbered pleading paper (N.D. Cal., D. Ariz., E.D. Wash. ...):
        # the margin numbers 1..28 would otherwise land inside every sentence.
        expect, numbered = 1, []
        for i, ln in enumerate(lines):
            m = PLEADING_NO.match(ln)
            if m and int(m.group(1)) == expect:
                numbered.append((i, m.end(1)))
                expect += 1
        if len(numbered) >= 10:
            for i, end in numbered:
                lines[i] = " " * end + lines[i][end:]
    return "\n".join(ln for i, ln in enumerate(lines) if i not in drop), section


_PG = r"(\d{1,4}(?:-[a-z])?)"
OJD_HEAD = re.compile(r"^\s*(?:(?:Cite as|Nonprecedential Memo Op:) .{3,40}\(\d{4}\)\s+" + _PG + r"|" + _PG +
                      r"\s{2,}\S.*|.*\S\s{2,}" + _PG + r"|" + _PG + r")\s*$")
WA_NOTE = re.compile(r"^\s*For the current opinion, go to https?://\S+\s*$", re.I)
WA_DOCKET_LINE = re.compile(r"^\s*(?:Nos?\.\s*\d[\d ,\-]{4,12}[\s\-]*[IVX1l]{0,3}|\d[\d ,]{3,8}\s?-\s?\d\s?"
                            r"(?:-\s?[IVX1l]{1,3})?)\s*(?:/\s*(\d{1,3}))?\s*$")
HEADLIKE = re.compile(r"\bNos?\.?\s*\d|\bv\.?\s|\bIn re\b|^\(.*(?:concurr|dissent).*\)$|[\x00-\x1f]")


def _first_int(m):
    v = next((x for x in m.groups() if x), None) if m else None
    return (int(v) if v.isdigit() else v) if v else None


def official_labels(printed, npages, official):
    """How each PDF page of an official-reports document is cited.

    ``printed`` is the page number read from each page's running head (an int,
    a lettered insert page such as '56-a', or None); ``official`` is
    (reporter, first page) from the catalogue record. A printed number is
    trusted only when it continues the sequence of a neighbouring printed
    page; a page whose number was not read gets one only when the confirmed
    pages on both sides (or the only side there is) imply the same number."""
    ints = {i: v for i, v in printed.items() if isinstance(v, int)}
    from_catalogue = False
    if official and 1 not in ints and not isinstance(printed.get(1), str):
        ints[1] = official[1]
        from_catalogue = True

    def lettered(a, b):
        return sum(1 for k in range(a + 1, b) if isinstance(printed.get(k), str))

    order = sorted(ints)
    confirmed = set()
    for a, b in zip(order, order[1:]):
        if ints[b] - ints[a] == (b - a) - lettered(a, b):
            confirmed |= {a, b}
    if official and ints.get(1) == official[1]:
        confirmed.add(1)
    labels = {}
    for i in range(1, npages + 1):
        lab = {"pdf_page": i}
        v = printed.get(i)
        n = None
        if isinstance(v, str):
            n = v
        elif i in ints and not (i == 1 and from_catalogue):
            n = ints[i]
            if i not in confirmed:
                lab["page_number_unconfirmed"] = ("the number read from this page's running head does not continue "
                                                  "the neighbouring pages - view the PDF page before giving a pin")
        else:
            prev = max((k for k in confirmed if k < i), default=None)
            nxt = min((k for k in confirmed if k > i), default=None)
            cand = set()
            if prev is not None:
                cand.add(ints[prev] + (i - prev) - lettered(prev, i))
            if nxt is not None:
                cand.add(ints[nxt] - (nxt - i) + lettered(i, nxt))
            if i == 1 and from_catalogue:
                cand = {official[1]}
            if len(cand) == 1:
                n = cand.pop()
                lab["official_page_inferred"] = True
        if n is not None:
            lab["official_page"] = n
            if official:
                lab["pin"] = f"{official[0]} at {n}"
        else:
            lab["official_page"] = None
            lab["page_note"] = "official page number not read - view the PDF page before giving a pin"
        labels[i] = lab
    return labels


def strip_page(page, kind="uscourts", repeated=None):
    """(body, section, printed page number) for one page of any collection.

    ``repeated`` is the set of lines that recur at the top of several pages of
    the same document (a running head); they are dropped wherever they open a
    page. The printed number is the page number the document itself prints."""
    if kind == "usreports":
        body, section = _strip_page_furniture(page, True)
        return body, section, None
    lines = page.split("\n")
    nb = [i for i, ln in enumerate(lines) if ln.strip()]
    printed = None
    if kind == "ojd":
        # 'Cite as 375 Or 580 (2026)   581'  /  '582      State v. Solano'  /  '580   October 1, 2026   No. 38'
        drop = set()
        if nb:
            m = OJD_HEAD.match(lines[nb[0]])
            if m and len(lines[nb[0]].strip()) <= 110:
                printed = _first_int(m)
                drop.add(nb[0])
        for i in nb[:3]:                        # an OCR scan can break the running head over two lines
            if i in drop:
                continue
            if repeated and re.sub(r"\s+", " ", lines[i]).strip() in repeated:
                drop.add(i)
            else:
                break
        return "\n".join(ln for i, ln in enumerate(lines) if i not in drop), None, printed
    if kind == "wa":
        # running head: the Lexis pointer line, the docket-number line, the short case name,
        # '(Name, J., dissenting)'. Dropped only as an unbroken run from the top of the page.
        drop = set()
        for i in nb[:5]:
            key = re.sub(r"\s+", " ", lines[i]).strip()
            dm = WA_DOCKET_LINE.match(lines[i])
            if WA_NOTE.match(lines[i]) or dm or (repeated and key in repeated):
                drop.add(i)
                if dm and dm.group(1):          # Division I prints the page beside the number: 'No. 79086-2-I/6'
                    printed = int(dm.group(1))
            else:
                break
        if nb and re.fullmatch(r"\s*[" + _DASH + r"]?\s*(\d{1,4})\s*[" + _DASH + r"]?\s*", lines[nb[-1]]):
            printed = int(re.sub(r"\D", "", lines[nb[-1]]))
            drop.add(nb[-1])
        return "\n".join(ln for i, ln in enumerate(lines) if i not in drop), None, printed
    body, section = _strip_page_furniture(page, False)            # federal slip opinions: unchanged
    return body, section, None


def slip_labels(printed, npages, skip=()):
    """Slip-opinion page numbers for a document whose pages print their own
    number (and whose separate opinions restart at 1, their first page usually
    unnumbered). A printed number is used when it continues a neighbouring
    page, or is a '2' directly after an unnumbered page; the page before a
    known page N >= 2 is N-1. Nothing is inferred forwards: an unnumbered
    page after the last page of one opinion is the first page of the next,
    not that opinion's next page."""
    ints = {i: v for i, v in printed.items() if isinstance(v, int) and 0 < v < 1000 and i not in skip}
    known = {i: ints[i] for i in ints if ints.get(i + 1) == ints[i] + 1 or ints.get(i - 1) == ints[i] - 1}
    for i, v in ints.items():
        if v == 2 and i not in known and (i - 1) not in ints and (i - 1) not in skip and i > 1:
            known[i] = 2                       # page 2 of a two-page opinion whose first page is unnumbered
    inferred = set()
    for i in range(npages, 0, -1):             # backwards only
        if i in known or i in skip:
            continue
        nxt = known.get(i + 1)
        if nxt is not None and nxt >= 2 and (i not in ints or ints[i] == nxt - 1):
            known[i] = nxt - 1
            if ints.get(i) != known[i]:
                inferred.add(i)
    labels = {}
    for i in range(1, npages + 1):
        lab = {"pdf_page": i, "slip_page": known.get(i)}
        if i in inferred:
            lab["slip_page_inferred"] = True
        if known.get(i) is None and i not in skip:
            lab["page_note"] = ("page number not read (an unnumbered page is often the first page of an opinion) - "
                                "view the PDF page before giving a pin")
        labels[i] = lab
    return labels


def repeated_heads(pages, k=5, min_pages=3):
    """Lines that open (within the first k non-blank lines) at least min_pages pages."""
    seen = {}
    for p in pages:
        nb = [re.sub(r"\s+", " ", ln).strip() for ln in p.split("\n") if ln.strip()][:k]
        for key in set(nb):
            seen[key] = seen.get(key, 0) + 1
    return {key for key, n in seen.items() if n >= min_pages and len(key) <= 140 and HEADLIKE.search(key)}


AUTHOR_LINE = re.compile(r"^\s*(?:(?:[A-Z\u00c0-\u00dd][A-Za-z\u00c0-\u00ff'\-]*\s?){1,3},\s*(?:(?:C|P|S)\s?\.\s?)?J\s?\.(?:\s*pro tempore)?"
                         r"|PER CURIAM)\s*[.,]?\s*$")
TC_AUTHOR_LINE = re.compile(r"^\s*[A-Z][A-Z .'\-]{4,40},\s+(?:Senior\s+)?(?:Judge|Magistrate)(?:\s+Pro\s+Tempore)?\.\s*$")
CAPTION_SEPARATE = re.compile(r"([A-Z\u00c0-\u00dd][A-Za-z\u00c0-\u00ff'\-]+(?: [A-Z][A-Za-z\u00c0-\u00ff'\-]+)?)\s?,\s*(?:(?:C|P|S)\s?\.\s?)?J\s?\.\s?"
                              r"(?:pro tempore\s?)?,\s*(?:specially\s+)?((?:concurr|dissent)\w*)[^.\n]{0,70}")


def split_front(kind, bodies):
    """Lift the text that precedes the opinion out of the page bodies.

    Oregon official reports: the caption page(s) - parties, counsel, the
    disposition lines and often a staff case summary - end where the
    authoring judge's name stands alone on a line for the SECOND time (it
    appears once in the caption block and once opening the opinion, which
    always begins on a new page). When only one such line is read (an OCR
    scan can garble the other), the text after it decides: a caption's author
    line is followed by a line or two of disposition and the end of the page,
    an opinion's by paragraphs.
    Washington slip opinions: a 'NOTICE: SLIP OPINION' cover sheet.
    Returns (bodies, fronts, how) - how is 'two', 'one-opening', 'one-caption',
    'tax', 'cover', or '' when nothing was recognised."""
    fronts = ["" for _ in bodies]
    if kind == "wa":
        how = ""
        for i, b in enumerate(bodies[:2]):
            if re.search(r"NOTICE:\s*SLIP OPINION", b[:400]):
                fronts[i], bodies[i], how = b, "", "cover"
        return bodies, fronts, how
    if kind != "ojd":
        return bodies, fronts, ""
    hits = []
    for pi, b in enumerate(bodies[:14]):
        for li, ln in enumerate(b.split("\n")):
            if AUTHOR_LINE.match(ln) and sum(1 for c in ln if c.isupper()) >= 3:
                hits.append((pi, li))
    if not hits:
        # Oregon Tax Court: 'HENRY C. BREITHAUPT, Judge.' on its own line, once, and the opinion follows it
        for pi, b in enumerate(bodies[:4]):
            lines = b.split("\n")
            for li, ln in enumerate(lines):
                if TC_AUTHOR_LINE.match(ln):
                    for k in range(pi):
                        fronts[k], bodies[k] = bodies[k], ""
                    fronts[pi], bodies[pi] = "\n".join(lines[:li + 1]), "\n".join(lines[li + 1:])
                    return bodies, fronts, "tax"
        # the opinion's opening was not recognised (an OCR scan can garble the
        # author line): keep the caption page out of the quotable text anyway
        if bodies:
            fronts[0], bodies[0] = bodies[0], ""
        return bodies, fronts, ""

    def cut(pi, li, whole_page):
        for k in range(pi):
            fronts[k], bodies[k] = bodies[k], ""
        lines = bodies[pi].split("\n")
        if whole_page:
            fronts[pi], bodies[pi] = bodies[pi], ""
        else:   # the author line itself ('DUNCAN, J.') goes with the front matter: a heading, not a sentence
            fronts[pi], bodies[pi] = "\n".join(lines[:li + 1]), "\n".join(lines[li + 1:])

    def after_len(pi, li):                     # how much text follows the line on its page
        return len("\n".join(bodies[pi].split("\n")[li + 1:]).strip())

    # The caption's author line is followed by a line or two of disposition; the opinion's by paragraphs.
    openings = [h for h in hits if after_len(*h) >= 1000]
    if openings:
        pi, li = openings[0]
        cut(pi, li, False)
        return bodies, fronts, ("two" if hits[0] != openings[0] else "one-opening")
    if len(hits) >= 2:                         # a short opinion (per curiam): caption line, then the opening
        cut(hits[1][0], hits[1][1], False)
        return bodies, fronts, "two"
    pi, li = hits[0]                           # only the caption's author line was read: the opinion
    cut(pi, li, True)                          # starts on the next page
    return bodies, fronts, "one-caption"


def display(s):
    """The source's own characters, with typographic quotes and dashes
    straightened and whitespace collapsed. A word broken across lines keeps
    its break as 'liti- gating' (soft or hard hyphen alike): only the page
    can say whether the hyphen belongs to the word."""
    s = SOFT_HYPHEN.sub("- ", s)
    s = re.sub(r"\s+", " ", s.translate(_TRANS)).strip()
    return re.sub(r"\u2026|\.\s?\.\s?\.(?!\.)", ". . .", s)        # one spelling for every ellipsis


LINE_BREAK = re.compile(r"(?<=[A-Za-z])- (?=[a-z])")


def tidy(text):
    """(text with line-break hyphens closed up, how many were closed)."""
    out, n = LINE_BREAK.subn("", text)
    return out, n


def matchable(disp, drop_footnote_calls=False, dropped=None):
    """Lower-cased comparison string + a map back into ``disp``.

    Ignored, in the quote and the opinion alike: hyphens between letters (a
    line-end 'pre- printed' and a compound 'cost-sharing' compare equal
    however the PDF broke the line); a space before closing punctuation; and
    the bracket CHARACTERS '[' and ']' (so '[T]he' matches 'The' and the
    court's own 'apply[ing]' matches itself - but the words inside a bracket
    must be in the opinion like any others). Every digit is compared.

    ``drop_footnote_calls`` is applied to the OPINION text only, never to a
    quote, and only as a second attempt: it removes 1-3 digits glued to the end
    of a word ('contracts.2 The'), so a quote may leave a footnote call out but
    can never change a number."""
    out, back, n, i = [], [], len(disp), 0
    while i < n:
        c = disp[i]
        if c in "[]":
            i += 1
            continue
        if c == "-" and out and out[-1].isalpha():
            j = i + 1
            while j < n and disp[j] == " ":
                j += 1
            if j < n and disp[j].isalpha():
                i = j
                continue
        if c == " " and i + 1 < n and disp[i + 1] in ".,;:)]":
            i += 1
            continue
        if drop_footnote_calls and c.isdigit() and out and i > 0 and disp[i - 1] != " " and (
                out[-1].isalpha() or (out[-1] in ".,;:\"')" and len(out) > 1 and out[-2].isalpha())):
            j = i
            while j < n and disp[j].isdigit():
                j += 1
            # 1-3 digits glued to the end of a WORD (not to a number) and followed by a space: a footnote call
            if j - i <= 3 and (j == n or disp[j] == " "):
                if dropped is not None:
                    dropped.append((i, disp[i:j]))
                i = j
                continue
        out.append(c.lower())
        back.append(i)
        i += 1
    return "".join(out), back


def norm(s):
    return matchable(display(s))[0]


class Index:
    """All pages of one granule as a single searchable string with page marks."""

    def __init__(self, pages, gid="", sections=None, footnotes=False, drop_calls=False, labels=None):
        """``pages`` are page BODIES already stripped of running heads (see Doc);
        ``sections`` the U.S. Reports running head per page. ``footnotes`` marks
        the stream that holds only footnote text. ``drop_calls`` builds the
        comparison text with footnote-call digits removed from the opinion."""
        parts_id = gid.split("-")
        self.us = gid.startswith("USREPORTS-")
        self.labels = labels or {}
        self.is_footnotes = footnotes
        self.first_us_page = int(parts_id[2]) if self.us and len(parts_id) > 2 and parts_id[2].isdigit() else None
        parts, self.marks, pos = [], [], 0
        self.sections = dict(sections or {})
        for i, p in enumerate(pages, 1):
            d = display(p)
            self.marks.append((pos, i))
            self.sections.setdefault(i, None)
            parts.append(d + " ")
            pos += len(d) + 1
        self.disp = "".join(parts).rstrip()
        self.starts = {p: o for o, p in self.marks}
        self.dropped = []
        self.text, self.back = matchable(self.disp, drop_calls, self.dropped)
        self.sections_detected = sum(1 for v in self.sections.values() if v)
        # Court-staff summary at the head of Ninth Circuit (and some other)
        # slip opinions: "This summary constitutes no part of the opinion".
        self.summary = None
        m = None if footnotes else re.search(r"summary constitutes no part of the opinion", self.disp, re.I)
        if m:
            start = self.disp.rfind("SUMMARY", 0, m.start())
            end = re.search(r"\sCOUNSEL\s", self.disp[m.end():])
            if start >= 0:
                self.summary = (start, m.end() + (end.start() if end else 0))
        # Separate opinions inside one slip PDF: 'MILLER, Circuit Judge, concurring in part ...'
        self.separate = []
        if not self.us and not footnotes:
            lo = self.summary[1] if self.summary else 0
            self.separate = separate_headings(self.disp, lo)

    def _d(self, off):
        return self.back[min(max(off, 0), len(self.back) - 1)] if self.back else 0

    def page(self, off):                              # off = offset into self.text
        d = self._d(off)
        pg = 1
        for o, p in self.marks:
            if o <= d:
                pg = p
            else:
                break
        return pg

    def label(self, pg):
        """How to cite the page: the official U.S. Reports page, or the slip page."""
        if self.us and self.first_us_page is not None:
            return {"us_page": self.first_us_page + pg - 1, "running_head": self.sections.get(pg)}
        return dict(self.labels.get(pg) or {"slip_page": pg})

    def us_part(self, off):
        """(section the text at ``off`` belongs to, certain?) for a U.S. Reports page.

        The running head names the section that starts or continues on the
        page. Where one section ends and the next begins on the same page,
        text ABOVE the new section's opening line belongs to the previous
        page's section - but only when exactly one recognisable opening line
        is on the page; otherwise the answer is 'not certain' and the caller
        must look at the page."""
        pg = self.page(off)
        sec, prev = self.sections.get(pg), self.sections.get(pg - 1)
        if sec is None:
            return None, False
        lo, hi = self.starts[pg], self.starts.get(pg + 1, len(self.disp))
        openers = list(JUSTICE_OPENER.finditer(self.disp, lo, hi))
        named = [m for m in openers if m.group(1).lower() in sec.lower()]
        other = [m for m in openers if m.group(1).lower() not in sec.lower()]
        if pg == 1 or prev == sec:
            return sec, not other                     # another Justice's opinion also sits on this page
        if prev is None or other:
            return sec, False
        if re.search(r"opinion of the court|per curiam", sec, re.I):
            ms = list(COURT_OPENER.finditer(self.disp, lo, hi))
            m = ms[0] if len(ms) == 1 else None
        else:
            m = named[0] if len(named) == 1 else None
        if not m:
            return sec, False
        return (prev, True) if self._d(off) < m.start() else (sec, True)

    def not_opinion(self, off):
        """Non-empty when the offset lies in material that is no part of the opinion."""
        if self.summary:
            d = self._d(off)
            if self.summary[0] <= d < self.summary[1]:
                return "court-staff SUMMARY"
        if self.us:
            sec = self.us_part(off)[0] or ""
            if NOT_OPINION_SECTION.match(sec):
                return f"'{sec}' pages of the U.S. Reports (the Reporter's syllabus or counsel's argument)"
        return None

    def part(self, off):
        """Whose words these are, as far as the document itself says."""
        if self.us:
            return self.us_part(off)[0]
        d = self._d(off)
        label = None
        for o, text in self.separate:
            if o <= d:
                label = text
        return label

    def lead_in(self, i):
        """The words of the same sentence that precede a quote starting at text
        offset i ('' when the quote starts a sentence)."""
        d = self._d(i)
        before = self.disp[max(0, d - 400):d]
        pos = 0
        for m in re.finditer(r"[.?!][\"')\]]*\s+", before):
            if not ABBREV.search(before[:m.start() + 1]):
                pos = m.end()
        lead = before[pos:].strip()
        if re.fullmatch(r"(?:[IVXLC]{1,6}|[A-Z]|\d{1,2})[.)]?", lead):      # a section heading's 'A.' / 'III.'
            return ""
        if re.fullmatch(r"(?:(?:See|see|Cf\.|But see|See also|See, e\.g\.),? )?(?:Id|Ibid)\.(?: at [^.]{1,30}\.)?", lead):
            return ""                                                       # a bare 'Id.' citation sentence
        return lead if re.sub(r"[\s\"'(\[\]]", "", lead) else ""

    def trail(self, j):
        """The rest of the sentence after a quote ending at text offset j ('' when it ends the sentence)."""
        if j >= len(self.text):
            return ""
        last = self.text[j - 1]
        d = self._d(j - 1) + 1
        after = self.disp[d:d + 220]
        if last in ".?!" and not ABBREV.search(self.disp[max(0, d - 12):d]):
            return ""
        if re.match(r"[\"')\]]*\s*$", after) or re.match(r"[\"')\]]*[.?!][\"')\]]*(\s|$)", after):
            return ""
        m = re.search(r"[.?!][\"')\]]*(?=\s|$)", after)
        return after[:m.end()].strip() if m else after[:160].strip()

    def cautions(self, spans):
        """Things the orchestrator must settle before a verified quote is
        published. Empty list = nothing outstanding."""
        out = []

        def add(c):
            if c and c not in out:
                out.append(c)
        for i, j in spans:
            for off in (i, j - 1):
                if self.us:
                    sec, sure = self.us_part(off)
                    if sec is None:
                        add("section_unknown: the running head on this U.S. Reports page could not be read - view "
                            "the page (Read pdf_path, pages=N) and confirm the passage is in the Court's opinion, "
                            "not the syllabus, counsel's argument, a concurrence or a dissent")
                    elif not sure:
                        add(f"section_boundary: more than one section or opinion sits on this page (running head "
                            f"'{sec}') - view the page (Read pdf_path, pages=N) and confirm whose words these are")
                    elif not re.search(r"opinion of the court|per curiam", sec, re.I):
                        add(f"separate_opinion: this page's running head is '{sec}' - this is not the opinion of "
                            "the Court; attribute the quote to that Justice, and view the page if in any doubt")
                else:
                    p = self.part(off)
                    if p:
                        add(f"separate_opinion: this text follows the heading '{p}' - attribute the quote to that "
                            "judge, not to the court")
            if self.page(i) != self.page(j - 1):
                add("page_break: the quote runs over a page break - view both pages and confirm it reads "
                    "continuously")
        lead = self.lead_in(spans[0][0])
        if lead:
            shown = lead if len(lead) <= 230 else lead[:90] + " [...] " + lead[-130:]
            flag = " (it contains a negation or limitation)" if NEGATION.search(tidy(lead)[0]) else ""
            add(f"lead_in: the quote starts mid-sentence{flag}. The sentence begins: '{tidy(shown)[0]}' - quote the "
                "whole sentence, or confirm the fragment does not misstate it and is the court's own statement "
                "rather than a party's argument or another court's holding")
        rest = self.trail(spans[-1][1])
        if rest:
            add(f"trail_off: the quote stops mid-sentence. The sentence continues: '{tidy(rest)[0][:170]}' - quote "
                "the whole sentence, or confirm nothing after the cut changes the meaning")
        return out

    def source(self, i, j):                           # the source's own characters for text[i:j]
        if not self.back or i >= len(self.back) or j <= i:
            return ""
        return self.disp[self.back[i]: self.back[min(j, len(self.back)) - 1] + 1]

    def sentences(self, i, j):
        """source(i, j) widened towards sentence boundaries - a convenience
        window to requote from; trim it to whole sentences and verify again."""
        if not self.back:
            return ""
        a, b = self._d(i), self._d(max(j, i + 1) - 1) + 1
        lo = max(0, a - 500)
        m = None
        for m in re.finditer(r"(?<![A-Z])(?<!\bv)(?<!\bNo)(?<!\bU\. S)[.?!][\"')\]]*\s+(?=[\"'(\[]*[A-Z])",
                             self.disp[lo:a]):
            pass
        start = lo + m.end() if m else a
        m2 = re.search(r"[.?!][\"')\]]*(?=\s|$)", self.disp[b - 1:b + 500])
        end = b - 1 + m2.end() if m2 else b
        return self.disp[start:end].strip()

    def page_span(self, pg):                          # (start, end) offsets in self.text
        if pg not in self.starts:
            return None
        lo = bisect.bisect_left(self.back, self.starts[pg])
        hi = bisect.bisect_left(self.back, self.starts[pg + 1]) if pg + 1 in self.starts else len(self.text)
        return lo, hi

    def at_word_start(self, i):
        return i <= 0 or not (self.text[i - 1].isalnum() and self.text[i].isalnum())

    def at_word_end(self, j):
        return j >= len(self.text) or not (self.text[j - 1].isalnum() and self.text[j].isalnum())


FN_LINE = re.compile(r"^\s*(\d{1,3})(?:\s*$|\s{1,8}(?![.)\d])\S)")


def split_footnotes(body, expected, restart=None, strict=False):
    """Split one page body into (text above the footnotes, footnote text,
    next expected footnote number[, next restart number]).

    A footnote block starts at a line that begins with the next footnote
    number in the document's running sequence (alone on its line, or followed
    by text) in the lower part of the page; everything from there to the foot
    of the page is footnote text. A page that only CONTINUES a footnote from
    the page before has no number to find and stays in the body - which is
    why a quote across a page break still carries a caution.

    ``strict`` (state documents): the number must also be set like a footnote
    - indented from the left margin, or set off by more blank space than the
    page's lines normally have, or (under double-spaced text) followed
    directly by its next line, or coming straight after a line that ends a
    sentence. A body line that merely begins with a number ('... Section' /
    '2 of the FAA provides') is none of these.
    ``restart`` (state documents): the next number of a second sequence that
    begins again at 1 inside a separate opinion; None = not in use."""
    lines = body.split("\n")
    nonblank = [i for i, ln in enumerate(lines) if ln.strip()]
    indents = sorted(len(lines[i]) - len(lines[i].lstrip()) for i in nonblank)
    margin = indents[len(indents) // 10] if indents else 0        # the left margin, ignoring a stray outlier
    gaps = sorted(b - a - 1 for a, b in zip(nonblank, nonblank[1:]))
    typical = gaps[len(gaps) // 2] if gaps else 0
    double_spaced = typical >= 1
    start, use_restart = None, False
    # the same number can head two lines of a page: first as a superscript CALL that -layout set on a
    # line of its own, then as the footnote itself. Only the last such line can start the block.
    last_line_for = {}
    for i in nonblank:
        m = FN_LINE.match(lines[i])
        if m:
            last_line_for[int(m.group(1))] = i
    for rank, i in enumerate(nonblank):
        m = FN_LINE.match(lines[i])
        if not m:
            continue
        n = int(m.group(1))
        if strict and start is None:
            rest = lines[i].strip()[len(m.group(1)):].lstrip()
            if rest[:1].islower():
                continue                        # '10 days before the commencement ...' continues a sentence
            if last_line_for.get(n, i) != i:
                continue                        # a later line carries this number: this one is the call
        if start is None:
            low = rank >= max(3, int(0.25 * len(nonblank))) and (rank + 1 < len(nonblank))
            ind = len(lines[i]) - len(lines[i].lstrip())
            indented = ind > margin
            if not strict:
                set_off = True
            elif ind - margin > 12:
                set_off = False                 # a superscript call that -layout put on a line of its own, mid-line
            else:
                prev = lines[nonblank[rank - 1]].rstrip() if rank else ""
                set_off = (indented or
                           (rank > 0 and i - nonblank[rank - 1] - 1 > typical) or
                           (double_spaced and rank + 1 < len(nonblank) and nonblank[rank + 1] - i == 1) or
                           bool(re.search(r"[.?!:;][\"'\u201d\u2019)\]]*\s?\d{0,3}$", prev)))
            if strict and indented and rank >= 3 and rank + 1 < len(nonblank):
                low = True                      # a long footnote can begin high on an Oregon Reports page
            window = 4 if (strict and indented) else 2      # an OCR scan can misread a footnote number or two
            if low and set_off and expected <= n <= expected + window:
                start, expected = i, n + 1
            elif low and set_off and restart is not None and restart <= n <= restart + 1:
                start, restart, use_restart = i, n + 1, True
        elif use_restart:
            if n == restart:
                restart = n + 1
        elif n == expected:
            expected = n + 1
    out = (body, "") if start is None else ("\n".join(lines[:start]), "\n".join(lines[start:]))
    if restart is None and not use_restart and not strict:
        return out[0], out[1], expected
    return out[0], out[1], expected, restart


class Doc:
    """One granule: the body text and the footnote text as two searchable
    streams, so a sentence that continues over a page break is matched as the
    continuous text it is, and footnote words are never run into body words."""

    def __init__(self, pages, gid=""):
        us = gid.startswith("USREPORTS-")
        kind = kind_of(gid)
        meta = meta_of(gid) if kind in ("ojd", "wa") else {}
        repeated = repeated_heads(pages) if kind == "wa" else (repeated_heads(pages, k=3) if kind == "ojd" else None)
        stripped, sections, printed = [], {}, {}
        for i, p in enumerate(pages, 1):
            body, section, pr = strip_page(p, kind, repeated)
            stripped.append(body)
            sections[i] = section
            printed[i] = pr
        stripped, fronts, self.front_how = split_front(kind, stripped)
        self.front_found = bool(self.front_how)
        bodies, fns, expected, restart = [], [], 1, None
        state = kind in ("ojd", "wa")
        for body in stripped:
            if state and separate_headings(display(body)):
                restart = 1                    # a separate opinion begins: its footnotes may start again at 1
            if not state:
                b, f, expected = split_footnotes(body, expected)          # federal: unchanged
            else:
                b, f, expected, restart = split_footnotes(body, expected, restart, strict=True)
            bodies.append(b)
            fns.append(f)
        # how each page is cited
        labels = {}
        self.official = None
        m = (re.match(r"\s*(\d+\s+(?:Or(?:\s+App)?|OTR))\s+(\d+)\s*(?:;|$)", meta.get("citation") or "")
             if kind == "ojd" else None)
        if m:
            self.official = (m.group(1), int(m.group(2)))
        if kind == "ojd":
            labels = official_labels(printed, len(pages), self.official)
        elif kind == "wa":
            labels = slip_labels(printed, len(pages), skip={i + 1 for i, f in enumerate(fronts) if f.strip()})
        self.gid, self.us, self.kind, self.meta = gid, us, kind, meta
        self.footnotes_detected = expected - 1
        self.body = Index(bodies, gid, sections, labels=labels)
        self._bodies, self._fns, self._fronts, self._sections, self._labels = bodies, fns, fronts, sections, labels
        self._loose = None
        self.fn = Index(fns, gid, sections, footnotes=True, labels=labels)
        self.front = Index(fronts, gid, sections, footnotes=True, labels=labels)
        self.front_name = ("the slip-opinion cover notice" if kind != "ojd" else
                           "the caption, case summary, counsel listing or disposition lines that precede the opinion"
                           if self.front_found else
                           "the first page, withheld because the opinion's opening could not be recognised (view "
                           "the PDF: it may hold opinion text)")
        notes = [meta[k] for k in ("nonprecedential_note", "not_an_opinion_note", "publication_note",
                                   "superseded_note", "order_note", "unresolved_note") if meta.get(k)]
        # --- separate opinions the heading pattern may have missed -------------------------------------
        self.unlocated = None                  # why a quote's author cannot be taken as 'the court'
        self.page_heads = {}
        self.unpublished_from = None
        if kind == "ojd":
            want = []
            for m in CAPTION_SEPARATE.finditer(display("\n".join(fronts))):
                if m.group(1).split()[-1].lower() not in [w.lower() for w in want]:
                    want.append(m.group(1).split()[-1])
            missing = []
            for name in want:
                if any(name.lower() in t.lower() for _, t in self.body.separate):
                    continue
                m = re.search(r"(?<![A-Za-z(])" + re.escape(name) + r"\s?,\s*(?:(?:C|P|S)\s?\.\s?)?J\s?\.?\s?"
                              r"(?:pro tempore\s?)?,?\s*(?:specially\s+)?(?:concurring|dissenting)\w*"
                              r"(?: in part)?", self.body.disp, re.I)
                if m:
                    self.body.separate.append((m.start(), re.sub(r"\s+", " ", m.group(0)).strip(" ,")))
                    self.body.separate.sort()
                else:
                    missing.append(name)
            if missing:
                self.unlocated = ("the caption lists a separate opinion by " + ", ".join(missing) + " whose "
                                  "heading was not found in the text")
        elif kind == "wa":
            heads = repeated_heads(pages, min_pages=2)
            for i, p in enumerate(pages, 1):
                top = [re.sub(r"\s+", " ", ln).strip() for ln in p.split("\n") if ln.strip()][:5]
                hit = next((t for t in top if t in heads and re.search(r"dissent|concurr", t, re.I)), None)
                if hit:
                    self.page_heads[i] = hit
            parts = [x for x in re.split(r",|\band\b", meta.get("file_contains") or "")
                     if re.search(r"\b(Dis|Con)", x)]
            located = len(self.body.separate)
            if parts and located < len(parts):
                self.unlocated = (f"the court's listing says this file contains '{meta.get('file_contains')}' but "
                                  f"only {located} separate-opinion heading(s) were found in the text")
            m = re.search(r"only the foregoing portion of this opinion will be printed|remainder of this opinion "
                          r"(?:shall|will) be filed for public record|having no precedential value,? shall be filed "
                          r"for public record", self.body.disp, re.I)
            if m:
                self.unpublished_from = m.start()
                notes.append("published in part: the text after the court's statement that only the foregoing "
                             "portion will be printed is UNPUBLISHED - quotes from it carry an `unpublished_part` "
                             "caution")
            elif meta.get("pub_status") == "PAR":
                notes.append("published in part, but the court's dividing statement was not found in the text: "
                             "view the PDF to see whether a passage is in the published part")
        if self.unlocated:
            notes.append(self.unlocated + " - every quote from this document carries a `separate_opinion` caution "
                         "until the page has been viewed")
        # A decision with no majority opinion: a per curiam with a signed 'lead opinion', or a plurality.
        # The first signed opinion in the file is then NOT the court's, whatever the headings say.
        self.fractured = None
        if state:
            m = re.search(r"\b(lead opinion|plurality opinion|the plurality)\b", self.body.disp, re.I)
            if m:
                self.fractured = (f"the text speaks of '{m.group(1).lower()}': this decision may have no majority "
                                  "opinion, and the first opinion in the file may be the view of fewer than a "
                                  "majority (or the phrase may describe another case)")
                notes.append(self.fractured + " - every quote carries a `fractured_decision` caution until the "
                             "pages have been viewed")
        self._extra_separate = list(self.body.separate)
        if kind == "ojd" and self.front_how == "one-caption":
            notes.append("only the caption's author line was recognised; the opinion is taken to begin on the "
                         "next page - view the PDF if the first page of the opinion looks incomplete")
        if kind == "ojd" and not self.front_found:
            notes.append("the opinion's opening (the authoring judge's name on a line of its own) was not recognised; "
                         "page 1 is treated as caption and the staff case summary, if any, may run past it - view "
                         "the PDF before quoting from the first pages")
        if kind == "ojd" and not self.official:
            notes.append("the catalogue record carries no Oregon Reports citation; page labels are the numbers "
                         "printed on the pages, without a reporter")
        if kind == "wa":
            notes.insert(0, "slip opinion, not the official report: cite pages as 'slip op. at N'")
        self.notes = notes

    def header(self):
        """Document-level facts every text command prints for a state-court document."""
        if self.kind not in ("ojd", "wa"):
            return {}
        h = {"source": self.meta.get("source") or self.kind}
        for k in ("case_name", "citation", "case_number", "docket", "date", "court", "document_type", "pub_status",
                  "file_contains"):
            if self.meta.get(k):
                h[k] = self.meta[k]
        if self.notes:
            h["document_notes"] = self.notes
        return h

    @property
    def loose(self):                                   # body with footnote calls removed (second attempt only)
        if self._loose is None:
            self._loose = Index(self._bodies, self.gid, self._sections, drop_calls=True, labels=self._labels)
            if self.kind in ("ojd", "wa"):
                self._loose.separate = list(self._extra_separate)      # same display text, same offsets
        return self._loose

    def _part_at_page_end(self, pg):
        span = self.body.page_span(pg)
        return self.body.part(max(span[0], span[1] - 1)) if span and span[1] > span[0] else None

    def _state_checks(self, r, ix):
        """Cautions only a state document needs, added to a verified result."""
        if self.kind not in ("ojd", "wa") or r.get("grade") != "verified":
            return r
        c = r.setdefault("cautions", [])
        if self.fractured:
            c.append("fractured_decision: " + self.fractured + " - view the opening of each opinion in the PDF, "
                     "say which opinion this passage is from and how many judges joined it, and do not call it "
                     "the court's holding unless a majority did")
        flagged = any(x.startswith("separate_opinion") for x in c)
        if not flagged:
            head = next((self.page_heads[p] for p in r.get("pages", []) if p in self.page_heads), None)
            if head:
                c.append(f"separate_opinion: the running head of this page reads '{head}' - attribute the quote to "
                         "that judge, not to the court")
                r["opinion_part"] = head
            elif self.unlocated:
                c.append("separate_opinion: " + self.unlocated + " - view the page and confirm whose words these "
                         "are before attributing them to the court")
                r["opinion_part"] = "not established (a separate opinion in this document could not be located)"
        if self.unpublished_from is not None and ix is not self.fn:
            if any(ix._d(i) >= self.unpublished_from for i, _ in r.get("_spans", [])):
                c.append("unpublished_part: this passage is in the UNPUBLISHED portion of a part-published opinion "
                         "- say so wherever it is quoted; it is not precedent (GR 14.1)")
        elif self.unpublished_from is not None:
            c.append("unpublished_part: this opinion is published only in part and footnote text cannot be placed "
                     "on either side of the dividing statement - view the page")
        bad = [lab for lab in r.get("cite_pages", []) if lab.get("official_page_inferred") or
               lab.get("slip_page_inferred") or lab.get("page_number_unconfirmed") or
               ("official_page" in lab and lab["official_page"] is None) or
               ("slip_page" in lab and "pdf_page" in lab and lab["slip_page"] is None)]
        if bad:
            c.append("page_label: the page number of PDF page " + ", ".join(str(b["pdf_page"]) for b in bad) +
                     " was not read from the page itself (inferred, unconfirmed or not read) - view the PDF page "
                     "before giving a pin")
        return r

    def verify(self, quote):
        r = verify_quote(self.body, quote)
        if r["grade"] == "verified":
            return self._state_checks(r, self.body)
        r2 = verify_quote(self.loose, quote)
        if r2["grade"] == "verified":
            lo, hi = self.loose._d(0), None
            calls = []
            for (i, j) in r2.get("_spans", []):
                a, b = self.loose._d(i), self.loose._d(j - 1)
                calls += [d for off, d in self.loose.dropped if a <= off <= b]
            r2["footnote_calls_ignored"] = calls
            r2["cautions"].append("footnote_call: the opinion has " + ", ".join(f"'{c}'" for c in calls) +
                                  " glued to a word inside this passage, taken to be a footnote reference and "
                                  "ignored - read source_text and confirm it is not a number that belongs to the "
                                  "sentence")
            return self._state_checks(r2, self.loose)
        r3 = verify_quote(self.fn, quote) if self.fn.text else {"grade": "not_found"}
        if r3["grade"] == "verified":
            r3["in_footnote"] = True
            r3["cautions"].insert(0, "footnote: this passage is footnote text - cite it as a footnote (n.), and "
                                     "view the page to see which footnote and whose opinion it belongs to")
            if not self.us:
                p = self._part_at_page_end(r3["pages"][0])
                span = self.body.page_span(r3["pages"][0])
                p0 = self.body.part(span[0]) if span and span[1] > span[0] else None
                if p and not any(c.startswith("separate_opinion") for c in r3["cautions"]):
                    if p0 == p:                 # the whole page lies inside that judge's opinion
                        r3["opinion_part"] = p
                        r3["cautions"].append(f"separate_opinion: this footnote is on a page of the opinion headed "
                                              f"'{p}' - attribute it to that judge, not to the court")
                    else:
                        r3["cautions"].append(f"separate_opinion: the page this footnote is on carries the heading "
                                              f"'{p}' - the footnote may belong to that judge's opinion")
            return self._state_checks(r3, self.fn)
        if self.front.text:
            segs = _segments(quote) if isinstance(quote, str) else []
            if segs and max(segs, key=len) in self.front.text:
                return {"quote": quote, "grade": "not_found", "not_opinion_text": self.front_name,
                        "note": f"these words appear in {self.front_name} - not in the opinion; do not quote them as "
                                "the court's reasoning"}
        for cand in (r, r2, r3):
            if cand["grade"] == "likely":
                return cand
        return r

    def grep(self, phrase, context=200, limit=20):
        a = grep_text(self.body, phrase, context, limit)
        b = grep_text(self.fn, phrase, context, limit) if self.fn.text else {"match_count": 0, "matches": []}
        for m in b["matches"]:
            m["footnote"] = True
        ms = (a["matches"] + b["matches"])[:limit]
        out = {"query": phrase, "match_count": a["match_count"] + b["match_count"], "shown": len(ms), "matches": ms}
        if self.front.text:
            c = grep_text(self.front, phrase, context, 3)
            if c["match_count"]:
                out["outside_the_opinion"] = {"where": self.front_name, "match_count": c["match_count"],
                                              "first": c["matches"][0]["context"],
                                              "note": "not opinion text; never quote it as the court's words"}
        return out


def grep_text(ix, phrase, context=200, limit=20):
    q = norm(phrase)
    hits, start = [], 0
    while q and len(hits) < limit:
        i = ix.text.find(q, start)
        if i < 0:
            break
        h = {"page": ix.page(i), **ix.label(ix.page(i))}
        no = ix.not_opinion(i)
        if no:
            h["not_opinion_text"] = no
        part = ix.part(i)
        if part:
            h["opinion_part"] = part
        h["context"] = tidy(ix.source(max(0, i - context), min(len(ix.text), i + len(q) + context)))[0]
        hits.append(h)
        start = i + max(len(q), 1)
    return {"query": phrase, "match_count": ix.text.count(q) if q else 0, "shown": len(hits), "matches": hits}


def _word_diff(a, b):
    aw, bw = a.split(), b.split()
    sm = difflib.SequenceMatcher(None, [w.lower() for w in aw], [w.lower() for w in bw], autojunk=False)
    return [{"quote_has": " ".join(aw[i1:i2]), "source_has": " ".join(bw[j1:j2])}
            for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag != "equal"]


def _segments(quote):
    """Split a quote at its ellipses -> list of normalized segments."""
    return [t for t in (matchable(p.strip())[0] for p in TOKEN.split(display(quote))
                        if p and p.strip() and not TOKEN.fullmatch(p.strip())) if t]


def _occurrences(full, sub, lo=0, hi=None):
    hi = len(full) if hi is None else hi
    i = full.find(sub, lo, hi)
    while i >= 0:
        yield i
        i = full.find(sub, i + 1, hi)


def _whole(ix, i, n):
    return ix.at_word_start(i) and ix.at_word_end(i + n)


def _place(ix, segs):
    """Place every segment in the opinion proper, anchored on the longest,
    neighbours within MAX_GAP characters, each at word boundaries.
    Returns (spans, None) or (None, reason)."""
    full = ix.text
    anchor = max(range(len(segs)), key=lambda k: len(segs[k]))
    reason, hit_non_opinion = "absent", None
    for a in _occurrences(full, segs[anchor]):
        if not _whole(ix, a, len(segs[anchor])):
            reason = "mid_word" if reason == "absent" else reason
            continue
        spans = {anchor: (a, a + len(segs[anchor]))}
        ok, cur = True, a
        for k in range(anchor - 1, -1, -1):
            t = segs[k]
            cand = [i for i in _occurrences(full, t, max(0, cur - MAX_GAP - len(t)), cur) if _whole(ix, i, len(t))]
            if not cand:
                ok = False
                break
            spans[k] = (cand[-1], cand[-1] + len(t))
            cur = cand[-1]
        cur = spans[anchor][1]
        for k in range(anchor + 1, len(segs)):
            if not ok:
                break
            t = segs[k]
            cand = [i for i in _occurrences(full, t, cur, cur + MAX_GAP + len(t)) if _whole(ix, i, len(t))]
            if not cand:
                ok = False
                break
            spans[k] = (cand[0], cand[0] + len(t))
            cur = cand[0] + len(t)
        if not ok:
            reason = "segments_apart"
            continue
        ordered = [spans[k] for k in range(len(segs))]
        bad = next((ix.not_opinion(o) for i, j in ordered for o in (i, j - 1) if ix.not_opinion(o)), None)
        if bad:
            hit_non_opinion = bad
            continue
        return ordered, None
    if hit_non_opinion:
        return None, ("not_opinion", hit_non_opinion)
    return None, reason


def verify_quote(ix, quote):
    """Grade one quote against the opinion text.

    verified   the quote is the opinion's own words: each part is in the
               opinion proper, exactly (after the normalization in
               matchable()), at word boundaries, in one opinion; an ellipsis
               is accepted only where the opinion itself has it or nothing
               but punctuation lies between the parts. ``cautions`` lists
               what must still be settled before publication; empty = nothing.
    likely     the words are nearly there but the quote as written is NOT the
               opinion's (a changed, added or missing word; a bracket that adds
               words; an ellipsis that leaves ANY words of the opinion out; a
               quote cut mid-word; a quote running from one opinion into
               another).
    not_found  not in the opinion - or only in a syllabus / staff summary, or
               stitched from passages that are far apart.
    """
    if not isinstance(quote, str):
        return {"quote": quote, "grade": "not_found", "note": "quote must be a string"}
    full = ix.text
    segs = _segments(quote)
    q = " ".join(segs)
    if len(q) < MIN_SEG:
        return {"quote": quote, "grade": "not_found", "note": "quote too short to verify (under 12 characters)"}
    # First, the quote exactly as written, its ellipses taken as the opinion's own
    # (courts quote with ellipses too). Only if that fails are they the quoter's.
    whole = norm(quote)
    spans, why = _place(ix, [whole]) if len(segs) > 1 else (None, None)
    if spans:
        segs = [whole]
    else:
        short = [s for s in segs if len(segs) > 1 and (len(s) < MIN_SEG or len(s.split()) < MIN_SEG_WORDS)]
        spans, why = (None, "short_fragment") if short else _place(ix, segs)
    if spans:
        problems, elided = [], []
        for (a0, a1), (b0, b1) in zip(spans, spans[1:]):
            gap = ix.source(a1, b0).strip() if b0 > a1 else ""
            if not re.search(r"[A-Za-z0-9]", gap):
                continue                                   # the opinion's own ellipsis, or nothing omitted
            elided.append(tidy(gap)[0])
            if ix.page(a1 - 1) != ix.page(b0):
                problems.append("the ellipsis crosses a page break; quote the two passages separately")
            elif NEGATION.search(tidy(gap)[0]):
                problems.append(f"the ellipsis omits words that can change the meaning: '{tidy(gap)[0][:160]}'")
            else:
                # No word list can tell a harmless omission from 'erred when it', 'waived', 'lacked':
                # a quote with words of the opinion left out is never graded verified.
                problems.append(f"the ellipsis omits words of the opinion: '{tidy(gap)[0][:160]}' - quote each "
                                "part on its own, or the passage whole")
        parts = {re.sub(r"\s+", "", str(ix.part(o) or "")).lower() for i, j in spans for o in (i, j - 1)}
        if len(parts) > 1:
            problems.append("the quote runs from one opinion or section into another: " +
                            " / ".join(sorted({str(ix.part(o) or "the court's opinion")
                                               for i, j in spans for o in (i, j - 1)})))
        pg = sorted({p for i, j in spans for p in range(ix.page(i), ix.page(j - 1) + 1)})
        src, joined = zip(*(tidy(ix.source(i, j)) for i, j in spans))
        sent, joined2 = tidy(ix.sentences(spans[0][0], spans[-1][1]))
        base = {"quote": quote, "pages": pg, "cite_pages": [ix.label(p) for p in pg],
                "opinion_part": ix.part(spans[0][0]) or ("the court's opinion (no separate-opinion heading "
                                                         "precedes this text)" if not ix.us else None),
                "source_text": list(src), "source_sentences": sent}
        if sum(joined) or joined2:
            base["joined_line_breaks"] = max(sum(joined), joined2)
            base["line_break_note"] = ("words broken across lines in the PDF are shown joined; a true compound "
                                       "('state-court') may have lost its hyphen - check the page before publishing "
                                       "source_text or source_sentences verbatim")
        if elided:
            base["elided"] = elided
        if problems:
            return dict(base, grade="likely", problems=problems,
                        note="NOT publishable as handed in. Quote the passage plainly, without the alteration, "
                             "verify again, and re-check that the analysis still matches what the opinion says.")
        cautions = ix.cautions(spans)
        if elided:
            cautions.append("elision: the quote omits " + "; ".join(f"'{e[:200]}'" for e in elided) +
                            " - the omitted words must not change the meaning of the quote")
        return dict(base, grade="verified", segments=len(segs), cautions=cautions, _spans=spans,
                    occurrences_of_longest_segment=full.count(max(segs, key=len)))
    if isinstance(why, tuple):
        return {"quote": quote, "grade": "not_found", "not_opinion_text": why[1],
                "note": f"these words appear in the {why[1]}, which is no part of the opinion - do not quote"}
    if why == "short_fragment":
        return {"quote": quote, "grade": "likely", "problems": [
            "a fragment between or beside ellipses is too short to verify (each part of an elided quote needs at "
            f"least {MIN_SEG_WORDS} words): {short}"],
            "note": "NOT publishable as handed in. Quote whole sentences without ellipses and verify again."}
    if why == "segments_apart":
        return {"quote": quote, "grade": "not_found",
                "note": f"each part of the quote may exist, but not within {MAX_GAP} characters of the others in "
                        "this order in the opinion proper: it is stitched from separate passages. Quote each "
                        "passage on its own."}
    # A sentence interrupted by a page break with footnote text between its halves
    if len(segs) == 1:
        w = q.split()
        for cut in range(len(w) - 3, 2, -1):
            head, tail = " ".join(w[:cut]), " ".join(w[cut:])
            if len(head) < MIN_SEG or len(tail) < MIN_SEG:
                continue
            for i in _occurrences(full, head):
                span = ix.page_span(ix.page(i) + 1)
                if span and i + len(head) <= span[0]:
                    j = full.find(tail, span[0], span[0] + len(tail) + 4)
                    if 0 <= j - span[0] <= 3:
                        p1 = ix.page(i)
                        return {"quote": quote, "grade": "likely", "pages": [p1, p1 + 1],
                                "cite_pages": [ix.label(p1), ix.label(p1 + 1)],
                                "source_text": [tidy(ix.source(i, i + len(head)))[0],
                                                tidy(ix.source(j, j + len(tail)))[0]],
                                "problems": ["the two halves are on consecutive pages with other text between them "
                                             "in the PDF (footnotes, or body text): view both pages; quote the part "
                                             "on one page, or each half separately"],
                                "note": "NOT publishable as handed in."}
    # Fuzzy: best window around any 4-word anchor taken from the quote
    words = q.split()
    best = (0.0, 0, 0)
    tried = set()
    for k in range(0, max(len(words) - 3, 1) if len(q) <= 2500 else 0):
        a = " ".join(words[k:k + 4])
        j = full.find(a)
        while j >= 0 and len(tried) < 80:
            lo = max(0, j - len(" ".join(words[:k])) - 15)
            if lo // 40 not in tried:
                tried.add(lo // 40)
                window = full[lo: lo + len(q) + 60]
                blocks = [b for b in difflib.SequenceMatcher(None, q, window, autojunk=False).get_matching_blocks()
                          if b.size]
                if blocks:
                    w0 = max(0, blocks[0].b - blocks[0].a)
                    w1 = min(len(window), blocks[-1].b + blocks[-1].size + (len(q) - blocks[-1].a - blocks[-1].size))
                    ratio = difflib.SequenceMatcher(None, q, window[w0:w1], autojunk=False).ratio()
                    if ratio > best[0]:
                        best = (ratio, lo + w0, lo + w1)
            j = full.find(a, j + 1)
    if why == "mid_word" and best[0] < 0.92:
        i = full.find(max(segs, key=len))
        best = (1.0, i, i + len(max(segs, key=len)))
    if best[0] >= 0.92:
        b0, b1 = best[1], best[2]
        while b0 > 0 and not ix.at_word_start(b0):          # widen to whole words: show a clipped word in full
            b0 -= 1
        while b1 < len(full) and not ix.at_word_end(b1):
            b1 += 1
        src, joined = tidy(ix.source(b0, b1))
        pgs = sorted({ix.page(b0), ix.page(max(b0, b1 - 1))})
        out = {"quote": quote, "grade": "likely", "similarity": round(best[0], 3), "pages": pgs,
               "cite_pages": [ix.label(p) for p in pgs], "source_text": src,
               "source_sentences": tidy(ix.sentences(b0, b1))[0],
               "differences": _word_diff(re.sub(r"[\[\]]", "", display(quote)), re.sub(r"[\[\]]", "", src)),
               "note": "NOT publishable as handed in. Read `differences`: if a word differs, re-read the passage and "
                       "re-check the analysis built on it. Requote whole sentences from the opinion (source_sentences "
                       "is a window to trim, not a finished quote) and verify again, or drop."}
        if why == "mid_word":
            out["problems"] = ["the quote begins or ends in the middle of a word of the opinion "
                               "(for example 'enforceable' cut from 'unenforceable')"]
        if joined:
            out["joined_line_breaks"] = joined
        if ix.not_opinion(b0):
            out["not_opinion_text"] = ix.not_opinion(b0)
        return out
    stems = [" ".join(words[i:i + 5]) for i in range(max(len(words) - 4, 1))]
    stem = max(stems, key=len) if stems else ""
    return {"quote": quote, "grade": "not_found", "best_similarity": round(best[0], 3),
            "absence_check": {"stem": stem, "match_count": full.count(stem) if stem else 0,
                              "all_5_word_stems_absent": all(full.count(x) == 0 for x in stems)},
            "note": "confirmed_absent when all_5_word_stems_absent is true"}


# --------------------------------------------------------------------------- #
# Search
# --------------------------------------------------------------------------- #
def _search(q, n=20, sort="score"):
    body = json.dumps({"query": q, "pageSize": max(1, min(n, 100)), "offsetMark": "*",
                       "sorts": [{"field": sort, "sortOrder": "DESC"}]}).encode()
    with _open(f"{API}/search", data=body) as r:
        d = json.load(r)
    rows = []
    for x in d.get("results", []):
        pkg = x.get("packageId", "")
        m = re.match(r"USCOURTS-([A-Za-z0-9]+)-(.+)$", pkg)
        rows.append({"granule_id": x.get("granuleId"), "package_id": pkg, "title": x.get("title"),
                     "date_issued": x.get("dateIssued"),
                     "court_name": (x.get("governmentAuthor") or [None])[0],
                     "court_code": m.group(1) if m else None,
                     "court_citation_string": court_citation_string(m.group(1)) if m else None,
                     "details_url": (f"https://www.govinfo.gov/app/details/{pkg}/{x.get('granuleId')}"
                                     if x.get("granuleId") else None),
                     "docket_number": m.group(2).replace("_", ":") if m else None})
    return {"query": q, "count": d.get("count"), "returned": len(rows), "rows": rows}


def _filters(court=None, circuit=None, courttype=None, after=None, before=None):
    q, notes = "", []
    if court:
        nm = court_name(court)
        if nm:
            q += f' AND courtname:"{nm}"'
        else:
            raise ValueError(f"no GovInfo court for id '{court}' - use a CourtListener court id such as ord, waed, "
                             "ca9, orb (search was not run)")
    if circuit:
        q += f' AND circuit:"{circuit}"'
    if courttype:
        q += f" AND courttype:{courttype}"
    if after or before:
        q += f" AND publishdate:range({after or '1990-01-01'},{before or '2100-01-01'})"
    return q, notes


def search(terms, court=None, circuit=None, courttype=None, after=None, before=None, n=20, sort="score"):
    f, notes = _filters(court, circuit, courttype, after, before)
    out = _search(f"collection:USCOURTS AND ({terms})" + f, n, sort)
    if court in KNOWN_ABSENT:
        notes.append(f"'{court}' does not publish to GovInfo; an empty result says nothing")
    if notes:
        out["notes"] = notes
    return out


def cites(name=None, cite=None, negative=False, after=None, n=30, context=0):
    """Federal opinions in USCOURTS that mention a case by name or by reporter
    citation - a free, federal-only citing search. NOT a citator: it covers
    only GovInfo's participating federal courts, and a hit containing a
    negative word may be using it about some other case."""
    alts = [f'"{x}"' for x in (name, cite) if x]
    if not alts:
        return {"error": "give --name and/or --cite"}
    q = "collection:USCOURTS AND (" + " OR ".join(alts) + ")"
    if negative:
        q += " AND " + NEGATIVE
    f, _ = _filters(after=after)
    out = _search(q + f, n, "publishdate")
    out["coverage_note"] = ("federal courts participating in GovInfo only; silence here is NOT evidence of good law, "
                            "and state-court treatment is not covered at all")
    if context and (name or cite):
        # look for the full name, then the citation, then the more distinctive party
        generic = re.compile(r"^(united states|u\.s\.|usa|state|people|commonwealth|in re|ex parte)\b", re.I)
        sides = [x.strip() for x in re.split(r"\s+v\.?\s+", name or "") if x.strip()]
        variants = [cite, re.sub(r"\bF\.(\d)", r"F. \1", cite), re.sub(r"\bF\. (\d)", r"F.\1", cite)] if cite else []
        probes = [x for x in [name] + list(dict.fromkeys(variants)) + [x for x in sides if not generic.match(x)]
                  if x]

        def ctx(row):
            pages, r = load_pages(row["granule_id"])
            if pages is None:
                return dict(row, context_error=r.get("reason"))
            doc = Doc(pages, row["granule_id"])
            for probe in probes:
                g = doc.grep(probe, context=350, limit=3)
                if g["match_count"]:
                    return dict(row, matched_on=probe, mentions=g["match_count"],
                                contexts=[m["context"] for m in g["matches"]])
            return dict(row, mentions=0, contexts=[])
        with cf.ThreadPoolExecutor(6) as ex:
            head = list(ex.map(ctx, out["rows"][:context]))
        out["rows"] = head + out["rows"][context:]
    return out


# --------------------------------------------------------------------------- #
# United States Code (USCODE collection, annual editions 1994-present)
# --------------------------------------------------------------------------- #
def usc(title, section, year="mostrecent"):
    """Text of one U.S.C. section from GPO's annual edition, extracted by this
    script (no summarizing model in the path). ``year`` is an edition year for
    a historical question, else the most recent edition GovInfo holds - which
    LAGS the OLRC 'prelim' code; always report the edition line."""
    import html as _html
    link = f"https://www.govinfo.gov/link/uscode/{title}/{section}?type=usc&year={year}&link-type=html"
    try:
        with urllib.request.urlopen(urllib.request.Request(link, headers={"User-Agent": "deep-legal-research"}),
                                    timeout=60) as r:
            raw, final = r.read().decode("utf-8", "replace"), r.geturl()
    except urllib.error.HTTPError as e:
        return {"found": False, "citation": f"{title} U.S.C. § {section}", "year": year,
                "reason": f"HTTP {e.code} - no such section in that edition, or the edition is not held"}
    except Exception as e:
        return {"found": False, "citation": f"{title} U.S.C. § {section}", "reason": f"could not retrieve: {e}"}
    if "/content/pkg/USCODE-" not in final:
        return {"found": False, "citation": f"{title} U.S.C. § {section}", "reason": "link service did not resolve to a U.S. Code page",
                "resolved_to": final}
    body = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", raw)
    body = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</h\d>", "\n", body)
    text = _html.unescape(re.sub(r"<[^>]+>", "", body))
    text = "\n".join(ln.strip() for ln in text.split("\n") if ln.strip())
    ed = re.search(r"United States Code, (\d{4}) Edition[^\n]*", text)
    start = re.search(r"^\u00a7\s*" + re.escape(str(section)) + r"\b.*$", text, re.M)
    return {"found": True, "citation": f"{title} U.S.C. § {section}", "edition": ed.group(0) if ed else None,
            "edition_year": int(ed.group(1)) if ed else None, "url": final, "chars": len(text),
            "heading": start.group(0) if start else None,
            "text": text[start.start():] if start else text,
            "note": "GPO annual edition. Quote only after a second, independent source agrees (statute-sources.md)."}


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("probe")
    p = sub.add_parser("resolve")
    p.add_argument("--court", required=True)
    p.add_argument("--docket")
    p.add_argument("--date")
    p.add_argument("--name")
    p.add_argument("--cite", action="append")
    p = sub.add_parser("resolve-batch")
    p.add_argument("rows")
    p = sub.add_parser("fetch")
    p.add_argument("granule", nargs="+")
    p.add_argument("--force", action="store_true")
    p = sub.add_parser("read")
    p.add_argument("granule")
    p.add_argument("--pages")
    p.add_argument("--raw", action="store_true", help="print the page exactly as extracted, stamps and all")
    p = sub.add_parser("grep")
    p.add_argument("granule")
    p.add_argument("phrase", nargs="+")
    p.add_argument("--context", type=int, default=200)
    p = sub.add_parser("triage")
    p.add_argument("granule", nargs="+")
    p.add_argument("--terms", nargs="+", required=True)
    p = sub.add_parser("verify")
    p.add_argument("granule")
    p.add_argument("quotes")
    p = sub.add_parser("search")
    p.add_argument("terms")
    p.add_argument("--court")
    p.add_argument("--circuit")
    p.add_argument("--courttype")
    p.add_argument("--after")
    p.add_argument("--before")
    p.add_argument("-n", type=int, default=20)
    p.add_argument("--sort", default="score", choices=["score", "publishdate", "lastModified"])
    p = sub.add_parser("docket")
    p.add_argument("granule")
    p = sub.add_parser("usc")
    p.add_argument("--title", required=True)
    p.add_argument("--section", required=True)
    p.add_argument("--year", default="mostrecent")
    p = sub.add_parser("cites")
    p.add_argument("--name")
    p.add_argument("--cite")
    p.add_argument("--negative", action="store_true")
    p.add_argument("--after")
    p.add_argument("-n", type=int, default=30)
    p.add_argument("--context", type=int, default=0)
    a = ap.parse_args()

    def emit(x):
        print(json.dumps(x, indent=1, ensure_ascii=False))

    if a.cmd == "probe":
        try:
            d, h = get_json("/collections")
            c = {x["collectionCode"]: x for x in d["collections"]}
            emit({"ok": True, "uscourts_granules": c.get("USCOURTS", {}).get("granuleCount"),
                  "usreports_granules": c.get("USREPORTS", {}).get("granuleCount"),
                  "ratelimit_limit": h.get("x-ratelimit-limit"), "ratelimit_remaining": h.get("x-ratelimit-remaining"),
                  "pdftotext": subprocess.run(["which", "pdftotext"], capture_output=True).returncode == 0,
                  "cache_dir": str(CACHE)})
        except (Exception, SystemExit) as e:
            emit({"ok": False, "error": _clean(e),
                  "meaning": "GovInfo lane unavailable this run: read federal cases through CourtListener and say so"})
    elif a.cmd == "resolve":
        emit(resolve(a.court, a.docket, a.date, a.name, a.cite))
    elif a.cmd == "resolve-batch":
        rows = json.load(open(a.rows))

        def one(r):
            if not isinstance(r, dict):
                return {"found": False, "reason": "row is not an object", "cluster_id": None, "case_name": None}
            try:
                x = resolve(r.get("court_id") or r.get("court_code") or "",
                            r.get("docketNumber") or r.get("docket_number") or "",
                            r.get("dateFiled") or r.get("date_filed") or r.get("date_issued"),
                            r.get("caseName") or r.get("case_name") or r.get("title"),
                            r.get("citation") or r.get("citation_strings"))
            except Exception as e:
                x = {"found": False, "reason": f"could not check (network): {_clean(e)}"}
            x["cluster_id"] = r.get("cluster_id")
            x["case_name"] = r.get("caseName") or r.get("case_name") or r.get("title")
            return x
        with cf.ThreadPoolExecutor(6) as ex:
            out = list(ex.map(one, rows))
        emit({"resolved": sum(1 for o in out if o["found"]), "of": len(out), "rows": out})
    elif a.cmd == "fetch":
        with cf.ThreadPoolExecutor(6) as ex:
            out = list(ex.map(lambda g: fetch(g, a.force), a.granule))
        emit(out if len(out) > 1 else out[0])
    elif a.cmd == "read":
        pages, r = load_pages(a.granule)
        if pages is None:
            emit(r)
            return
        doc = Doc(pages, a.granule)
        ix = doc.body
        lo, hi = 1, len(pages)
        if a.pages:
            m = re.match(r"(\d+)(?:-(\d+))?$", a.pages)
            if not m:
                emit({"error": "--pages takes N or N-M (for example 3 or 3-7)"})
                return
            lo = int(m.group(1))
            hi = int(m.group(2) or lo)
        if lo > len(pages) or lo < 1:
            emit({"error": f"this document has {len(pages)} pages"})
            return
        for k, v in doc.header().items():
            print(f"### {k}: {v if not isinstance(v, list) else ' | '.join(v)}")
        if r.get("ocr_layer"):
            print("### OCR TEXT LAYER - view the PDF page before quoting: " + r["pdf_path"])
        for i in range(lo, min(hi, len(pages)) + 1):
            lab = ix.label(i)
            if "us_page" in lab:
                tag = f"{a.granule.split('-')[1]} U.S. {lab['us_page']} | {lab.get('running_head') or 'section not detected'}"
            elif "official_page" in lab:            # Oregon official reports
                how = ("official page - INFERRED, not printed on this page" if lab.get("official_page_inferred")
                       else "official page - UNCONFIRMED against neighbouring pages"
                       if lab.get("page_number_unconfirmed") else "official page")
                tag = ((lab.get("pin") or f"page {lab['official_page']}") + f" ({how}"
                       if lab["official_page"] is not None else "official page number NOT READ (view the PDF page")
                tag += f"; PDF page {i} of {len(pages)})"
            elif "pdf_page" in lab:                 # Washington slip opinions
                tag = ((f"slip op. at {lab['slip_page']}" + (" - INFERRED" if lab.get("slip_page_inferred") else ""))
                       if lab.get("slip_page") else "slip page number NOT READ - view the PDF page") + \
                      f" (PDF page {i} of {len(pages)})"
            else:
                tag = f"slip op. page {i} of {len(pages)}"
            if a.raw:
                body = pages[i - 1]
            else:                       # running heads and margin numbers removed, blank lines dropped,
                def clean(t):           # footnote text set apart from the body
                    return "\n".join(ln.strip() for ln in t.split("\n") if ln.strip())
                body = clean(doc._bodies[i - 1])
                if doc._fronts[i - 1].strip():
                    body = ("    ----- " + doc.front_name + " (NOT opinion text) -----\n" + clean(doc._fronts[i - 1]) +
                            "\n    ----- end -----\n" + body)
                if doc._fns[i - 1].strip():
                    body += "\n    ----- footnote text on this page (cite as n.) -----\n" + clean(doc._fns[i - 1])
            print(f"\n===== [{tag}] =====\n{body}")
    elif a.cmd == "grep":
        pages, r = load_pages(a.granule)
        if pages is None:
            emit(r)
            return
        doc = Doc(pages, a.granule)
        emit({"granule_id": a.granule, **doc.header(), "chars": r["chars"], "pages": r["pages"],
              "ocr_layer": r.get("ocr_layer"), "results": [doc.grep(ph, a.context) for ph in a.phrase]})
    elif a.cmd == "triage":
        def one(g):
            pages, r = load_pages(g)
            if pages is None:
                return r
            doc = Doc(pages, g)
            hits = {}
            for t in a.terms:
                x = doc.grep(t, context=160, limit=1)
                hits[t] = {"count": x["match_count"], "first": x["matches"][0]["context"] if x["matches"] else None}
                if x["matches"] and x["matches"][0].get("not_opinion_text"):
                    hits[t]["first_is_not_opinion_text"] = x["matches"][0]["not_opinion_text"]
            return {"granule_id": g, **doc.header(), "pages": r["pages"], "chars": r["chars"],
                    "ocr_layer": r.get("ocr_layer"), "opening": r["opening"][:300], "terms": hits}
        with cf.ThreadPoolExecutor(6) as ex:
            emit(list(ex.map(one, a.granule)))
    elif a.cmd == "verify":
        pages, r = load_pages(a.granule)
        if pages is None:
            emit(r)
            return
        doc = Doc(pages, a.granule)
        ix = doc.body
        quotes = json.load(open(a.quotes))
        if not isinstance(quotes, list):
            emit({"error": "the quotes file must be a JSON array of strings (or of objects with a `quote` field)"})
            return
        res = [doc.verify(q.get("quote", "") if isinstance(q, dict) else q) for q in quotes]
        for x in res:
            x.pop("_spans", None)
        tally = {g: sum(1 for x in res if x["grade"] == g) for g in ("verified", "likely", "not_found")}
        emit({"granule_id": a.granule, **doc.header(), "ocr_layer": r.get("ocr_layer"),
              "sections_detected": (f"{ix.sections_detected} of {len(pages)} pages" if ix.us else None),
              "separate_opinions": [t for _, t in ix.separate] or None,
              "footnotes_detected": doc.footnotes_detected,
              "tally": tally, "with_cautions": sum(1 for x in res if x.get("cautions")), "results": res})
    elif a.cmd == "search":
        emit(search(a.terms, a.court, a.circuit, a.courttype, a.after, a.before, a.n, a.sort))
    elif a.cmd == "docket":
        emit(docket(a.granule))
    elif a.cmd == "usc":
        emit(usc(a.title, a.section, a.year))
    elif a.cmd == "cites":
        emit(cites(a.name, a.cite, a.negative, a.after, a.n, a.context))


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except urllib.error.HTTPError as e:
        print(json.dumps({"found": False, "ok": False, "error": f"GovInfo answered HTTP {e.code}",
                          "meaning": "request refused or failed; not evidence that the document does not exist"},
                         indent=1))
    except Exception as e:           # never a traceback, never the key
        print(json.dumps({"found": False, "ok": False, "error": _clean(f"{type(e).__name__}: {e}")}, indent=1))
