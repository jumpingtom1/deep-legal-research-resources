#!/usr/bin/env python3
"""Retrieve ONE provision from a bundled corpus.

The point of this script is token economy: Python reads the whole corpus, the
model sees only the provision it asked for. Never `Read` the .jsonl files
directly — a full ORCP is ~110k tokens and reading it defeats the purpose.

Usage:
    or_lookup.py "ORCP 47"            # one rule
    or_lookup.py "ORCP 47 C"          # one subdivision, if it can be isolated
    or_lookup.py "UTCR 5.100"
    or_lookup.py --search "ex parte"  # phrase search across all corpora
    or_lookup.py --search "ex parte" --corpus manual
    or_lookup.py --list               # what is bundled, and as of when

Exit codes: 0 found, 1 not found, 2 usage/corpus error.
"""
import argparse
import datetime
import json
import pathlib
import re
import sys

CORPUS_DIR = pathlib.Path(__file__).resolve().parent.parent / "references" / "or-corpus"


def load(corpus: str):
    p = CORPUS_DIR / f"{corpus}.jsonl"
    if not p.exists():
        return None
    return [json.loads(l) for l in p.open() if l.strip()]


def available():
    return sorted(p.stem for p in CORPUS_DIR.glob("*.jsonl"))


def meta(corpus: str):
    p = CORPUS_DIR / f"{corpus}.meta.json"
    return json.loads(p.read_text()) if p.exists() else {}


def parse_cite(s: str):
    """'ORCP 47 C' -> ('orcp', '47', 'C'); 'UTCR 5.100' -> ('utcr','5.100',None)"""
    m = re.match(r"^\s*([A-Za-z]+)\s+([0-9]+(?:\.[0-9]+)?[A-Za-z]?)\s*([A-Z](?:\(\d+\))?)?\s*$", s)
    if not m:
        return None, None, None
    return m.group(1).lower(), m.group(2), m.group(3)


def isolate_subdivision(text: str, sub: str):
    """Best-effort slice of e.g. subdivision 'C'. Returns None rather than guessing."""
    start = re.search(rf"^\s*{re.escape(sub)}\.?\s", text, re.M)
    if not start:
        return None
    nxt = re.search(r"^\s*[A-Z]\.?\s", text[start.end():], re.M)
    return text[start.start(): start.end() + nxt.start()].strip() if nxt else text[start.start():].strip()


# Oregon court rules are amended on a biennial cycle, so a year-old copy is
# plausibly current and a two-year-old copy plausibly is not.
STALE_WARN_DAYS = 365
STALE_ALERT_DAYS = 730


def age_status(captured: str):
    """-> (age_days|None, level, message). Never guesses if the date is unparseable."""
    try:
        cap = datetime.date.fromisoformat(captured)
    except (ValueError, TypeError):
        return None, "UNKNOWN", "capture date missing or unparseable — treat as unverified"
    days = (datetime.date.today() - cap).days
    if days < 0:
        return days, "UNKNOWN", "capture date is in the future — the manifest is wrong"
    if days >= STALE_ALERT_DAYS:
        return days, "EXPIRED", (
            f"EXPIRED — captured {days} days ago (>{STALE_ALERT_DAYS}). "
            "Do NOT quote this as current. Re-ingest, or verify against a live "
            "source before use, and say in the report that you did.")
    if days >= STALE_WARN_DAYS:
        return days, "STALE", (
            f"STALE — captured {days} days ago (>{STALE_WARN_DAYS}). Oregon rules "
            "are amended biennially; verify before quoting as current.")
    return days, "OK", f"captured {days} days ago"


def banner(rec, m):
    cap = rec.get("captured") or m.get("captured") or ""
    url = rec.get("source_url") or m.get("source_url") or ""
    days, level, msg = age_status(cap)
    head = f"[bundled corpus — captured {cap or 'unknown'}"
    if url:
        head += f" from {url}"
    head += "]"
    lines = [head]
    if level in ("EXPIRED", "UNKNOWN"):
        lines.append(f"[!! {msg}]")
    elif level == "STALE":
        lines.append(f"[! {msg}]")
    lines.append("[STATE THIS CAPTURE DATE IN THE REPORT]")
    return "\n".join(lines)


def cmd_list():
    if not available():
        print("No corpora bundled yet.")
        print(f"Expected in: {CORPUS_DIR}")
        print("Build one with: scripts/or_corpus_build.py SOURCE --corpus orcp "
              "--pattern orcp --captured YYYY-MM-DD")
        return 1
    worst = 0
    for c in available():
        m = meta(c)
        days, level, msg = age_status(m.get("captured", ""))
        flag = {"OK": "ok", "STALE": "STALE", "EXPIRED": "EXPIRED", "UNKNOWN": "UNKNOWN"}[level]
        print(f"{c:10s} {m.get('provisions','?'):>5} provisions   "
              f"captured {m.get('captured','?')}   [{flag}] {msg}")
        worst = max(worst, {"OK": 0, "STALE": 1, "UNKNOWN": 2, "EXPIRED": 2}[level])
    if worst:
        print("\nRe-ingest stale corpora with scripts/or_corpus_build.py before relying on them.")
    return 0


def cmd_search(term, corpus):
    corpora = [corpus] if corpus else available()
    hits = 0
    for c in corpora:
        recs = load(c)
        if recs is None:
            print(f"ERROR: no such corpus '{c}'. Available: {', '.join(available()) or 'none'}",
                  file=sys.stderr)
            return 2
        m = meta(c)
        for r in recs:
            for mo in re.finditer(re.escape(term), r["text"], re.I):
                s = max(0, mo.start() - 220)
                e = min(len(r["text"]), mo.end() + 220)
                print(f"\n=== {r['citation']} — {r['title']} ===")
                print(banner(r, m))
                print("..." + r["text"][s:e].strip() + "...")
                hits += 1
                break  # one excerpt per provision keeps output small
    if not hits:
        print(f'NOT FOUND — no provision contains "{term}"'
              f'{" in corpus " + corpus if corpus else ""}.')
        print("This is a valid result. Do not infer content that is not here.")
        return 1
    print(f"\n({hits} provision(s) matched. Re-run with a citation to get full text.)")
    return 0


def cmd_cite(query):
    corpus, num, sub = parse_cite(query)
    if not corpus:
        print(f'Could not parse "{query}" as a citation. Try: "ORCP 47", "UTCR 5.100", '
              f'or use --search.', file=sys.stderr)
        return 2
    recs = load(corpus)
    if recs is None:
        print(f"ERROR: no bundled corpus '{corpus}'. Available: {', '.join(available()) or 'none'}",
              file=sys.stderr)
        return 2

    m = meta(corpus)
    key = f"{corpus} {num.lower()}"
    rec = next((r for r in recs if r["key"] == key), None)

    if rec is None:
        near = [r["citation"] for r in recs if r["key"].startswith(f"{corpus} {num.split('.')[0]}")][:8]
        print(f"NOT FOUND — {query.upper()} is not in the bundled {corpus.upper()} corpus.")
        print("This is a valid result. Do not reconstruct the provision from its number or title.")
        if near:
            print(f"Nearby provisions that ARE present: {', '.join(near)}")
        return 1

    print(f"=== {rec['citation']} — {rec['title']} ===")
    print(banner(rec, m))
    if sub:
        piece = isolate_subdivision(rec["text"], sub)
        if piece:
            print(f"\n[subdivision {sub} isolated from the full rule]\n")
            print(piece)
            return 0
        print(f"\n[subdivision {sub} could not be isolated — printing the full provision]\n")
    print()
    print(rec["text"])
    return 0


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("citation", nargs="?", help='e.g. "ORCP 47" or "UTCR 5.100"')
    ap.add_argument("--search", help="phrase search instead of citation lookup")
    ap.add_argument("--corpus", help="restrict --search to one corpus")
    ap.add_argument("--list", action="store_true", help="show bundled corpora and capture dates")
    a = ap.parse_args()

    if a.list:
        return cmd_list()
    if a.search:
        return cmd_search(a.search, a.corpus)
    if a.citation:
        return cmd_cite(a.citation)
    ap.print_help()
    return 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            sys.exit(0)
