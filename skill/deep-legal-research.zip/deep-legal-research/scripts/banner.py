#!/usr/bin/env python3
"""Assemble the deep-legal-research console banner (v10.0, state lanes added 2026-10-05).

The banner is *assembled*, never hand-drawn: the version line comes from
``VERSION``; every statute/rule Data Sources line comes from a row of
``references/source-status.md``; the GovInfo, Oregon and Washington text
lines come from this run's probes (--govinfo, --oregon, --washington); the
two "[-]" lines are fixed. Run it once, at Phase 1, before the first
CourtListener call, and paste its output verbatim into a fenced code block.

Usage
-----
    python scripts/banner.py --need "Federal statutes" --need "Federal rules"
    python scripts/banner.py --need RCW --need "Washington court" --need "review disp" \
        --hourly-used 12 --daily-used 40 --daily-reset 22:26Z   # values from get_api_usage
    python scripts/banner.py --need "Federal statutes" --govinfo ok   # result of `govinfo.py probe`
    python scripts/banner.py --need Oregon --govinfo ok --oregon ok --washington off   # `statecourts.py probe`
    python scripts/banner.py --need "New York Official"                # lights the nycourts.gov page-check row
    python scripts/banner.py --state-repo ok --states de,ri            # [v10.5] `state_repo.py setup` + `route`
    python scripts/banner.py --no-federal          # user excluded federal courts
    python scripts/banner.py --list                # show the families it knows

``--need`` takes a case-insensitive substring of a family label; every family
that matches is printed with its verification mark, every other family prints
as ``[ ]`` (available, not needed). Families are grouped, so ``--need Oregon``
lights up every Oregon row. Nothing here touches CourtListener.

Marks
-----
    [x]  newest matching row is OK and <= 90 days old        (date printed;
         365 days for the bundled Oregon corpora)
    [!]  row is FAIL or older than that                       (date printed;
         a working tier-2 fallback is named on the next line)
    [ ]  available, not needed for this query
    [-]  the fixed 'not available' / 'blocked to automation' lines only
"""
import argparse
import datetime as dt
import pathlib
import re
import sys

W = 78
HERE = pathlib.Path(__file__).resolve().parent.parent
VERSION = HERE / "VERSION"
STATUS = HERE / "references" / "source-status.md"

# Banner families -> (label, [substrings that match a source-status row]).
# Order is the print order after the fixed CourtListener line.
FAMILIES = [
    ("Federal statutes (U.S.C.) OLRC/Cornell/GovInfo", ["U.S.C.) via OLRC", "U.S.C.) via Cornell",
                                                        "U.S.C.) via GovInfo"]),
    ("Federal rules (FRCP/FRE) via Cornell LII", ["Federal rules via Cornell"]),
    ("Washington statutes (RCW) via leg.wa.gov", ["Washington statutes (RCW)"]),
    ("Washington court rules via courts.wa.gov", ["Washington court rules"]),
    ("WA Supreme Court review dispositions", ["Washington Supreme Court review"]),
    ("Oregon statutes (ORS) via oregonlegislature.gov", ["Oregon statutes (ORS) via oregonlegislature"]),
    ("Oregon ORS archived editions 1953-2023 (PDF)", ["Oregon ORS archived editions"]),
    ("Oregon ORCP / UTCR bundled corpus", ["Oregon ORCP bundled", "Oregon UTCR bundled"]),
    ("Oregon OAR via sos.state.or.us", ["Oregon OAR via sos"]),
    ("Oregon ORAP via courts.oregon.gov", ["Oregon ORAP"]),
    ("Oregon Sup. Ct. petitions for review", ["Oregon Supreme Court petitions"]),
    ("New York Official Reports pages (nycourts.gov)", ["New York Official Reports pages"]),
]
# [v10.5] Every other state and D.C. (Delaware and the public.law states included) comes from
# the state-sources repo: --state-repo / --states, not a FAMILIES row.
FALLBACKS = {  # tier-1 family -> tier-2 row substring
    "Oregon statutes (ORS) via oregonlegislature.gov": "Oregon ORS via public.law",
    "Oregon OAR via sos.state.or.us": "Oregon OAR via public.law",
}
FRESH_DAYS = {"Oregon ORCP / UTCR bundled corpus": 365}   # a bundled corpus is re-ingested yearly, not quarterly
MONTHS = ["Jan.", "Feb.", "Mar.", "Apr.", "May", "June", "July", "Aug.", "Sept.", "Oct.", "Nov.", "Dec."]


def rule(title=None):
    if title is None:
        return "-" * W
    t = f" {title} "
    n = W - len(t)
    return "-" * (n // 2) + t + "-" * (n - n // 2)


def row(label, status, dotcol=48):
    s = "  " + label + " "
    if len(s) < dotcol:
        s += "." * (dotcol - len(s))
    pad = max(1, W - len(s) - len(status))
    return s + " " * pad + status


def note(text):
    """A right-aligned continuation line under a row, never wider than W."""
    text = "-> " + text
    return " " * max(2, W - len(text)) + text


def read_version():
    v = {}
    for line in VERSION.read_text().splitlines():
        if ":" in line:
            k, _, val = line.partition(":")
            v[k.strip()] = val.strip()
    d = dt.date.fromisoformat(v["last_modified"])
    return v["version"], f"{MONTHS[d.month - 1]} {d.day}, {d.year}", v.get("author", "")


def read_status():
    """Return list of (label, date, result) from the source-status table."""
    rows = []
    for line in STATUS.read_text().splitlines():
        if not line.startswith("|") or line.startswith("|---") or "Banner label" in line:
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 5:
            continue
        label, date_cell, result = cells[0], cells[3], cells[4]
        m = re.search(r"(\d{4}-\d{2}-\d{2})", date_cell)
        rows.append((label, m.group(1) if m else None, result))
    return rows


def family_status(matches, rows, today, fresh_days=90):
    """(date, ok, failed_labels) across the rows a family maps to.

    The family is verified when, among its most recently probed rows, at least
    one is OK and <= 90 days old. Rows of the family that FAILED on that date
    are returned so the banner can name them instead of hiding them (v10.0:
    a three-source family must not print [!] because one source is down, nor
    print a clean [x] without saying which one is)."""
    hits = [(date, result.upper().startswith("OK"), label) for label, date, result in rows
            if any(m.lower() in label.lower() for m in matches)]
    if not hits:
        return None, False, []
    newest = max((d or "") for d, _, _ in hits)
    latest = [h for h in hits if (h[0] or "") == newest]
    ok = any(h[1] for h in latest)
    failed = [h[2] for h in latest if not h[1]]
    fresh = bool(newest) and (today - dt.date.fromisoformat(newest)).days <= fresh_days
    return (newest or None), ok and fresh, failed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--need", action="append", default=[], help="family label substring relevant to this query")
    ap.add_argument("--hourly-used", type=int, default=None, help="50/hour 'used' from get_api_usage")
    ap.add_argument("--daily-used", type=int, default=None, help="125/day 'used' from get_api_usage")
    ap.add_argument("--daily-reset", default=None, help="125/day 'reset_at' from get_api_usage, e.g. 22:26Z")
    ap.add_argument("--govinfo", choices=["ok", "off"], default=None,
                    help="result of `python3 scripts/govinfo.py probe` (ok true -> ok, anything else -> off)")
    ap.add_argument("--oregon", choices=["ok", "off"], default=None,
                    help="`oregon.ok` from `python3 scripts/statecourts.py probe` (omit when Oregon is not in scope)")
    ap.add_argument("--washington", choices=["ok", "off"], default=None,
                    help="`washington.ok` from the same probe (omit when Washington is not in scope)")
    ap.add_argument("--no-federal", action="store_true", help="user excluded federal courts")
    ap.add_argument("--state-repo", choices=["ok", "off"], default=None,
                    help="[v10.5] result of `state_repo.py setup` (omit when no other state is in scope)")
    ap.add_argument("--states", default="", help="[v10.5] jurisdictions picked by `state_repo.py route`, e.g. de,ri")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for label, _ in FAMILIES:
            print(label)
        return
    version, modified, author = read_version()
    rows = read_status()
    today = dt.date.today()

    out = [rule("Claude Legal Research Skill"),
           f"v{version} - last modified {modified}",
           f"Created by {author}",
           "Generates legal research memo based on statutes and case law. All quotations",
           "and citations are checked against source text before publication.",
           "",
           "Data Sources:",
           "  CourtListener case-law API ......... connector loaded [x]  (status confirmed",
           " " * 39 + "on first call)"]
    if a.no_federal:
        out.append(row("GovInfo federal opinion text (court PDFs)", "not needed for query [ ]"))
        out.append(row("Federal decisions", "excluded at your request [-]"))
    elif a.govinfo == "ok":
        out.append(row("GovInfo federal opinion text (court PDFs)", "probe ok, 0 units [x]"))
    elif a.govinfo == "off":
        out.append(row("GovInfo federal opinion text (court PDFs)", "unreachable this run [!]"))
        out.append(note("federal opinions read via CourtListener"))
    else:
        out.append(row("GovInfo federal opinion text (court PDFs)", "not probed [!]"))
    for flag, label, off in ((a.oregon, "Oregon official reports text (OJD)", "Oregon"),
                             (a.washington, "Washington slip opinions (courts.wa.gov)", "Washington")):
        if flag == "ok":
            out.append(row(label, "probe ok, 0 units [x]"))
        elif flag == "off":
            out.append(row(label, "unreachable this run [!]"))
            out.append(note(f"{off} opinions read via CourtListener"))
        else:
            out.append(row(label, "not needed for query [ ]"))
    picked = [x.strip().upper() for x in a.states.split(",") if x.strip()]
    if a.state_repo == "ok":
        out.append(row("Other states via state-sources repo", f"{' '.join(picked) or 'repo'} ok [x]"))
    elif a.state_repo == "off":
        out.append(row("Other states via state-sources repo", "unreachable this run [!]"))
        out.append(note(f"{' '.join(picked) or 'state'} authorities cited by number only"))
    else:
        out.append(row("Other states via state-sources repo", "not needed for query [ ]"))
    needed = [f for f in FAMILIES if any(n.lower() in f[0].lower() or any(n.lower() in m.lower() for m in f[1])
                                         for n in a.need)]
    rest = [f for f in FAMILIES if f not in needed]
    for label, matches in needed:
        date, ok, failed = family_status(matches, rows, today, FRESH_DAYS.get(label, 90))
        if date is None:
            out.append(row(label, "no approved source [!]"))
        elif ok:
            out.append(row(label, f"verified {date} [x]"))
            for f in failed:
                out.append(note(f"{f[:54]} FAILED {date}"))
        else:
            out.append(row(label, f"stale/failed {date} [!]"))
            fb = FALLBACKS.get(label)
            if fb:
                fdate, fok, _ = family_status([fb], rows, today)
                if fok:
                    out.append(note(f"via public.law (secondary), {fdate}"))
    for label, _ in rest:
        out.append(row(label, "not needed for query [ ]"))
    out.append(row("Westlaw/Lexis citator, headnotes, secondary", "not available [-]"))
    out.append(row("NY (Westlaw) / WA (Lexis) official reports", "blocked to automation [-]"))
    if a.hourly_used is None and a.daily_used is None:
        budget = "Budget:  50/hour + 125/day (rolling 24h).  get_api_usage not read [!]"
    else:
        h = "?" if a.hourly_used is None else a.hourly_used
        d = "?" if a.daily_used is None else a.daily_used
        budget = f"Budget:  hourly {h}/50, daily {d}/125 used (live)"
        if a.daily_reset:
            budget += f"; daily pool reopens {a.daily_reset}"
    out += ["", budget, "Stages:"]
    for s in ["Phase 1  parse & banner", "Phase 2  anchor citators",
              "Phase 3  search (CourtListener, GovInfo, Oregon collection) & triage",
              "Phase 4  resolve ids, assign text lanes, screen history",
              "Phase 5  deep analysis", "Phase 6  sufficiency & refinement",
              "Phase 7  verify quotes, history, statutes", "Phase 8  report & memo"]:
        out.append("  " + s)
    out.append(rule())
    bad = [l for l in out if len(l) > W]
    if bad:
        print("WARNING: line(s) exceed 78 columns:", *bad, sep="\n  ", file=sys.stderr)
    print("\n".join(out))


if __name__ == "__main__":
    main()
