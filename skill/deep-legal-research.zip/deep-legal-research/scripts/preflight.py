#!/usr/bin/env python3
"""preflight.py — can this chat reach the sources the skill reads?

    python3 scripts/preflight.py [--json]

Run once at the start of every research run, beside update_check.py. It
opens one small page (robots.txt) on a representative host for each source
the skill reads outside CourtListener, in parallel, and reports:

    READY       every source host is reachable
    LIMITED     some are not (typically: network egress set to "package
                managers only", or to specific domains that leave some out)
    NO-NETWORK  nothing outside is reachable (network egress off)

followed by the lanes that are off and a ready-to-show USER_MESSAGE with the
exact setting to change. It never blocks the run and always exits 0. The
CourtListener connector is not tested here: it does not go through this
sandbox's network.

If this script cannot run at all, code execution is off — see SKILL.md
§ Setup check. Stdlib only; about 10 requests, one per host.
"""
import argparse
import concurrent.futures as cf
import json
import sys
import urllib.error
import urllib.request

sys.dont_write_bytecode = True

UA = "deep-legal-research-preflight/1.0"
# lane -> (what it gives the user, [hosts]); a lane is up if every host answers.
LANES = {
    "github": ("update check and the state-sources repo (48 states and D.C.)",
               ["raw.githubusercontent.com"]),
    "govinfo": ("federal opinion text and the U.S. Code from GovInfo",
                ["api.govinfo.gov", "www.govinfo.gov"]),
    "oregon": ("Oregon official reports and petitions for review",
               ["ojd.contentdm.oclc.org"]),
    "oregon-statutes": ("Oregon statutes (ORS) from the Legislature",
                        ["www.oregonlegislature.gov"]),
    "washington": ("Washington slip opinions and RCW",
                   ["www.courts.wa.gov", "app.leg.wa.gov"]),
    "federal-rules": ("federal rules and U.S. Code from Cornell LII",
                      ["www.law.cornell.edu"]),
    "state-sites": ("live official pages for the other states (sample)",
                    ["webserver.rilegislature.gov", "delcode.delaware.gov"]),
}
BASELINE = "pypi.org"          # reachable under "package managers only"
DENY_MARKERS = ("not in allowlist", "allowlist", "egress", "not allowed by", "blocked by policy",
                "x-deny-reason", "proxy denied", "domain is not allowed")


def probe(host):
    """True if the host itself answered (any HTTP status from the host)."""
    url = f"https://{host}/robots.txt"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            r.read(2048)
            return True
    except urllib.error.HTTPError as e:
        if e.code in (403, 407):
            hdrs = " ".join(f"{k}: {v}" for k, v in (e.headers or {}).items()).lower()
            try:
                body = e.read(2048).decode("utf-8", "replace").lower()
            except Exception:  # noqa: BLE001
                body = ""
            if e.code == 407 or any(m in hdrs or m in body for m in DENY_MARKERS):
                return False        # the sandbox proxy refused it, not the site
        return True                 # the site answered (404, 401, 503 … all mean reachable)
    except Exception:  # noqa: BLE001 — DNS failure, refused connection, timeout, TLS to a proxy
        return False


MSG_ALL = (
    "Some of this skill's sources can't be reached from this chat, so this run will use fewer of them "
    "({off}). To give it full access:\n"
    "- Free, Pro or Max plan: open Settings > Capabilities, make sure \"Code execution and file creation\" "
    "is on, turn on \"Allow network egress\", and if a list of domains is offered choose All domains.\n"
    "- Team or Enterprise plan: ask your Claude organization owner to set Organization settings > "
    "Capabilities > network egress to \"All domains\" (or add the domains listed in the skill's "
    "state-sources repo, hosts.json).\n"
    "Then start a new chat. I'll carry on now with the sources that are available.")
MSG_NONE = (
    "Network access is turned off for this chat, so the skill can't run its own lookups: no GovInfo "
    "text, no state-sources repo, no exact-text quote checks against official pages, and no update "
    "check. It will fall back to the CourtListener connector and the web-fetch tool. To turn it on:\n"
    "- Free, Pro or Max plan: Settings > Capabilities > turn on \"Allow network egress\" (choose All "
    "domains if offered); \"Code execution and file creation\" must also be on.\n"
    "- Team or Enterprise plan: ask your Claude organization owner to set Organization settings > "
    "Capabilities > network egress to \"All domains\".\n"
    "Then start a new chat. I'll carry on now with what is available.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    hosts = sorted({h for _, hs in LANES.values() for h in hs} | {BASELINE})
    with cf.ThreadPoolExecutor(max_workers=len(hosts)) as ex:
        up = dict(zip(hosts, ex.map(probe, hosts)))
    lanes = {k: all(up[h] for h in hs) for k, (_, hs) in LANES.items()}
    off = [k for k, ok in lanes.items() if not ok]
    if not any(up.values()):
        status, msg = "NO-NETWORK", MSG_NONE
    elif off:
        status = "LIMITED"
        msg = MSG_ALL.format(off="; ".join(LANES[k][0] for k in off))
    else:
        status, msg = "READY", ""
    out = {"status": status, "lanes": lanes,
           "lanes_off": [{"lane": k, "gives": LANES[k][0], "hosts": [h for h in LANES[k][1] if not up[h]]}
                         for k in off],
           "package_managers_reachable": up[BASELINE],
           "user_message": msg}
    if a.json:
        print(json.dumps(out, indent=1))
        return
    print(status)
    for k, ok in lanes.items():
        print(f"  {'ok ' if ok else 'OFF'} {k:16} {LANES[k][0]}")
    if msg:
        print("USER_MESSAGE:")
        print(msg)


if __name__ == "__main__":
    main()
