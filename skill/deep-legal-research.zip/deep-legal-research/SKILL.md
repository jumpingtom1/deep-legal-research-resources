---
name: deep-legal-research
description: Comprehensive US case-law research using the CourtListener connector, the GovInfo API, the Oregon courts' official reports, Washington court slip opinions, verified official sources for every other state and D.C., and parallel subagents. Use for any legal research question — "find cases about…", "is X good law?", elements of a claim or defense, precedent in a jurisdiction, questions citing statutes, constitutions, court rules or regulations of any US jurisdiction (RCW, ORS, USC, FRCP, Cal. Civ. Code, Del. C., N.Y. CPLR…). Produces a structured, numbered research report in chat with API-sourced Bluebook citations and verbatim-verified quotes, plus a companion Word memo delivered as a file — both without further prompting.
---

# Deep Legal Research

Run an eight-phase research session against **CourtListener** (search in
every court, every reporter citation, the citator), **GovInfo** (the federal
courts' own opinion PDFs, read and quote-checked off the CourtListener
budget; `references/govinfo.md`) and, since the 2026-10-05 rebuild, the
**state courts' own publishers** (`references/state-sources.md`): the
Oregon Judicial Department's official Oregon Reports pages, Washington
Courts slip opinions, and — for an official-page check only — the New York
Law Reporting Bureau. Deliver TWO things, in order, without being asked for
either: (1) a numbered markdown
report in this chat, then (2) a companion Word memo built from that report per
`references/memo-format.md`, sent as a `.docx`. The full pipeline runs for
**every** query; depth scales through the complexity profile chosen in
Phase 1 and through Phase 6, where a second round of searching is built
from what the first round's cases said.

## Hard rules — never violate, regardless of query

1. **Citations are API-sourced, never composed.** Reporter citations come only
   from CourtListener API responses, copied verbatim through every step. If
   the API returned none, render the case name and link with no reporter
   citation — never "recall" one. `[v10.0]` GovInfo supplies text, not
   reporter citations. A decision found only in GovInfo is cited in
   slip-opinion form built from GovInfo API fields (`references/govinfo.md`
   § 4). A page number read from a GovInfo slip opinion is written `slip op.
   at N` and is never presented as a pin cite to a reporter. **State
   sources** `[v10.0]`: an Oregon page the verifier returns from the Oregon
   Judicial Department collection *is* an official Oregon Reports page and
   may be used as a pin; a Washington page is a slip page (`slip op. at N`)
   and may not. **Only when CourtListener's row holds no
   official-reporter citation** may the Oregon catalogue's `citation` field
   — or a New York official citation that two fetches of the Law Reporting
   Bureau page agree on — supply one: added, never substituted for a
   citation the API gave, re-abbreviated mechanically by the table in
   `references/state-sources.md`, and disclosed in the About table. An
   Oregon decision found only in the Oregon collection is cited from its
   catalogue fields (`state-sources.md` § 6), as a GovInfo-only decision is
   from GovInfo's. Nothing else may supply a citation, and never memory.
2. **Quotes only from fetched opinion text**, verified verbatim against the
   opinion before publication (Phase 7) — `[v10.0]` **against the same
   source the analyzer read**: CourtListener text for a CourtListener-lane
   case, the GovInfo court PDF for a GovInfo-lane case, the Oregon Reports
   page or the Washington slip opinion for a state-lane case, never one
   checked against another. Unverifiable quotes are dropped or flagged, never
   silently kept. On the GovInfo and state lanes only quotes graded
   `verified` **with no outstanding `cautions`** are published; a `likely` grade means the
   quote as written is not the opinion's — requote whole sentences from the
   opinion, check again, and re-check the analysis built on it — not "close
   enough."
3. **Statute text only from allowlisted sources, only when two fetches
   agree.** `references/statute-sources.md` defines the tiers: bundled corpora
   (tier 0 — ORCP and UTCR, queried with `scripts/or_lookup.py`, never by
   reading the corpus files), official publishers (tier 1, always tried first),
   Public.Law (tier 2, only for the collections verified there, disclosed with
   its currency date). `[v10.5]` **Every other state and D.C.** comes from
   the state-sources repo through `scripts/state_repo.py`; its rows are that
   state's allowlist, tier-2 Justia / Cornell LII rows included, and an
   exact match from `state_repo.py doc verify` or `corpus verify` is the
   second fetch (`statute-sources.md` § "Every other state and D.C.").
   No other aggregator, for any purpose. Never guess a
   URL. Never quote statute text from memory. A truncated chapter page is a
   fetch failure, not an absent statute. **A question about what a statute
   said in an earlier year is answered from an archived edition, never from
   the current page or from an opinion's paraphrase** — see § Historical
   statute text below.
4. **Absence of a subsequent-history flag means "not flagged," never
   "confirmed good law."** Say so in those words.
5. **No legal advice framing.** The report is research; it opens with the AI
   notice line and never omits it.
6. **CourtListener does not index state supreme court review dispositions.**
   Any state appellate decision under ~3 years old that reaches Leading
   Authorities is checked against the state's official source (Phase 7B). A
   clean citator is not evidence review was never sought. `[v10.0]` For
   Oregon the check is a free script call (`statecourts.py or-history`), so
   it is run for **every** Oregon Court of Appeals decision in Leading
   Authorities, whatever its age.
7. **"Not found" is always an available answer.** No subagent, and not you, is
   ever required to produce content. Every field of every contract accepts
   `null`; a stated gap is a usable result. A plausible reconstruction is the
   worst outcome this skill can produce, because it is indistinguishable from
   research. Every prompt gives the agent an explicit, easy way to report
   nothing.
8. **The skill ships whole, or not at all.** Every release, revision, or
   "recreate the skill" request delivers a `.zip` of the **entire** folder —
   `SKILL.md`, `VERSION`, `CHANGELOG.md`, every file under `references/`
   (including the bundled `or-corpus/`, `govinfo.md` and
   `state-sources.md`), and every file under `scripts/` (including
   `govinfo.py`, `govinfo.key` and `statecourts.py`) — and
   the delivery message lists the manifest. Never deliver `SKILL.md` alone,
   and **never use the `propose_skills` / "propose new skill" tool** for this
   skill: it saves only `SKILL.md`, which silently discards the reference
   files the pipeline depends on. That is how the v9.5 sync lost
   `pipeline.md`, `subagent-briefing.md`, `courtlistener-mcp.md`,
   `known-corrections.md`, `report-format.md`, `memo-format.md`, both
   Oregon scripts and the corpora. See § Packaging and release.

9. **GovInfo is a text source for the federal courts it holds, and nothing
   more.** `[v10.0]` It has no state courts, it is not a citator, and it
   never clears a case's history. A case CourtListener found is read from
   GovInfo only when `scripts/govinfo.py resolve-batch` matched it on
   **docket number, decision date and case name** (for the Supreme Court:
   `U.S.` citation and case name); a miss on any of them is the
   CourtListener lane, not a reason to try harder. A decision GovInfo's own
   `search` found is read from the granule the search returned, after the
   opening-text identity check and a `docket` call. A magistrate judge's
   findings and recommendation is not a ruling: it is authority only as
   adopted by an order the docket shows. GovInfo text is fetched
   only with the script — never with WebFetch, which summarizes. From an
   OCR-layer PDF, no quote is published until the page image has been
   viewed. Words from a staff summary or a syllabus are never quoted as the
   court's, and words from a concurrence or dissent are never quoted
   without saying whose they are.

10. **State court sources are used for exactly what each allows, and a
    blocked publisher stays blocked.** `[v10.0]`
    `references/state-sources.md` is the rule; in brief:
    - **Oregon** (Oregon Judicial Department collection): a text lane, a
      free full-text search, and the Supreme Court's review dispositions.
      A case CourtListener found is on it only when `scripts/statecourts.py
      resolve-batch` matched **citation or case number, decision date and a
      distinctive party name**; a decision the collection's own `or-search`
      found is read from the item the search returned, after the identity
      check. The caption page and the staff case summary ("*Held:* …") are
      not the opinion and are never quoted as the court's reasoning (the
      caption's history line and the catalogue's disposition note are
      reported as history, attributed to their source). A nonprecedential
      memorandum opinion is called that wherever it is cited, whichever
      lane it was read in.
    - **Washington** (courts.wa.gov): a **slip-opinion** text lane, matched
      on **docket number, file date and a distinctive party name**. Never
      presented as the official report: pages are `slip op. at N`, a slip
      the court has marked superseded says so beside every quote,
      unpublished status is stated, and a quote from the unpublished part
      of a part-published opinion says so.
    - **New York** (nycourts.gov Law Reporting Bureau): an official-page
      check through WebFetch, two agreeing fetches, for the official
      citation, court, date, corrected-through date and publication status
      only. Never a text lane; New York opinions are
      read and verified through CourtListener.
    - The Westlaw-hosted New York Official Reports and the LexisNexis-hosted
      Washington official reports refuse automated access. **They are never
      fetched — not by WebFetch, not by a script, not through a mirror, an
      archive or a cache — and no other refused page is either.** A source
      that refuses is reported as unavailable, the run uses the lane it
      has, and no "fallback" route to the same host is tried.
    - None of these is a citator. A near miss in `resolve-batch` (a
      different date, an amended opinion, a name that does not match) is
      the CourtListener lane, never a reason to force the match. An empty
      Oregon review-history result is "no disposition located", never
      "review was not sought"; an incomplete one is "not checked".
    - A separate opinion is never quoted as the court's: on these lanes a
      `separate_opinion` caution can also mean "this document has a dissent
      the script could not place" — view the page before attributing. A
      `fractured_decision` caution means the decision may have no majority
      opinion: a lead or plurality opinion is attributed as such, with its
      vote, and its disposition is never reported as the court's.
11. **Users do not edit this skill; they send suggestions.** `[v10.5]` The
    skill is maintained centrally and every upgrade replaces the whole
    folder, so a local edit is lost at the next upgrade and, until then,
    makes this copy differ from what everyone else runs. If a user asks to
    change, extend, "fix" or re-package this skill — any file, any
    instruction, through any tool, `skill-creator` included — **do not
    make the change and do not produce an edited copy.** Instead:
    - say in one or two sentences that the skill is maintained centrally
      and changes made locally would be overwritten at the next upgrade;
    - write the user's suggestion up as a short note — what they want,
      why, and an example query where it matters — and give it to them in
      chat, addressed to the maintainer (the `author` e-mail in `VERSION`,
      or the `feedback` contact `update_check.py` prints);
    - carry on with any research they asked for, on the installed version.
    This does not apply to the maintainer releasing a new version through
    § Packaging and release.

## Prerequisites

- The **CourtListener connector** (`search`, `read_document`,
  `search_document`, `analyze_citations`, …), signed in to **the user's own
  CourtListener account**. If its tools cannot be found or return
  authentication errors, do not start the research: run § First-run setup
  below, then resume the question the user asked. Never improvise from
  memory or web search.
- **GovInfo**, through `scripts/govinfo.py` — needs Bash, outbound HTTPS to
  `api.govinfo.gov` and `www.govinfo.gov`, the key in `scripts/govinfo.key`
  (or `$GOVINFO_API_KEY`) and `pdftotext`. **Optional, never blocking:** run
  `python3 scripts/govinfo.py probe` at Phase 1. `"ok": false` means federal opinions
  are read through CourtListener exactly as in v9.6 (a state lane, if on,
  is unaffected); print the `GOV` line and carry on. Never stop a run because GovInfo is unreachable, and never
  substitute WebFetch or memory for it.
- **State court sources**, through `scripts/statecourts.py` — needs Bash,
  outbound HTTPS to `ojd.contentdm.oclc.org` and `www.courts.wa.gov`, and
  `pdftotext`; no key. **Optional, never blocking:** when Oregon or Washington
  is in scope run `python3 scripts/statecourts.py probe` at Phase 1. A
  source that is not `ok` is the CourtListener lane for the run; print the
  `ST` line and carry on. New York has no probe: its page check needs only
  WebFetch, at Phase 7.
- **Other states and D.C.**, through `scripts/state_repo.py` `[v10.5]` —
  needs Bash and outbound HTTPS to `raw.githubusercontent.com` for the
  repo; reading a live official page also needs that page's host (the
  repo's `hosts.json`; on Team/Enterprise an owner allows them under
  Organization settings → Capabilities). **Optional, never blocking:**
  `setup` failing means those states' authorities are cited by number
  only (banner `--state-repo off`); a host that is not reachable sends the
  read to the row's fetch-tool route.
- **Parallel subagents** do the heavy work. If they cannot reach the
  connector, make the calls yourself and pass fetched text to analyzers.

## First-run setup — the CourtListener connector `[v10.1]`

This skill is shared between colleagues, and it carries **no CourtListener
credential**: the connection lives in each person's Claude account, and each
person signs in with their own free CourtListener account. A colleague who
has just installed the skill will usually not have the connector yet. The
check costs nothing and runs at the start of every run — there is no
"already set up" flag to keep.

**Detect.** Phase 1 calls `get_api_usage` anyway. Before concluding the
connector is absent, look for its tools properly (in a session that loads
tools on demand, search for `CourtListener`). Then:

- `get_api_usage` answers → the connector is set up. Say nothing about
  setup; carry on with Phase 1.
- No CourtListener tools exist, or the call returns an authentication or
  authorization error → run the walkthrough. Any other error (a timeout, a
  5xx) is an outage, not a setup problem: say so and offer to retry.

**Walkthrough.** Tell the user in one or two sentences why this is needed:
the skill reads case law through CourtListener (Free Law Project), the
account is free, it takes about three minutes, and it is needed once. Then
give the steps **one at a time**, waiting for the user to say each is done:

1. **Create a CourtListener account** at
   `https://www.courtlistener.com/register/` and confirm the email address
   (the confirmation message must be clicked before sign-in works). Skip
   this step if they already have an account.
2. **Add the connector in Claude.** Click the **+** below the prompt box →
   **Connectors** → **Add connectors** → **Browse connectors** → search for
   **CourtListener** → add it.
3. **Sign in when prompted**, with the CourtListener account from step 1,
   and approve the access request.
4. **Make sure it is switched on for this chat** — CourtListener should
   appear, enabled, in the **+** → **Connectors** list — then reply "done".

**Confirm.** When the user says it is done, look for the tools again and
call `get_api_usage`. If it answers, tell the user the connection works,
state their allowance in plain words (their own pool: 5 calls a minute, 50
an hour, 125 a day — about four research runs a day, not shared with
whoever gave them the skill), and **go straight on to the research question
they originally asked** — do not make them ask again. If the tools still
cannot be found, the connector was probably added after this chat loaded
its tools: ask the user to start a new chat and repeat the question there.

**If it does not go to plan:**

- *CourtListener does not appear in Browse connectors.* On a Team or
  Enterprise plan an organization owner may have to allow the connector
  first; tell the user to ask their Claude administrator, and stop.
- *Sign-in fails.* The usual cause is an unconfirmed email address; have
  them check for the confirmation message, or reset the password at
  courtlistener.com, and try step 3 again.
- *The menu labels differ* from step 2 (the app changes): the same list is
  under Settings → Connectors.

**Never** ask for, accept or store a CourtListener password or API token in
the chat — the connector's own sign-in page is the only place credentials
go. If the user pastes one, tell them not to, and do not repeat it. Never
edit or re-package this skill as part of setup: nothing in the skill changes
per user.

The GovInfo key in `scripts/govinfo.key` is different: it is a shared
api.data.gov key, deliberately bundled, and needs no setup by anyone.

## Budget

**One pool per CourtListener account (each colleague has their own), three caps: 5/min, 50/hour, 125/day** — the last a
rolling 24-hour window and the real ceiling (about four runs a day). Every
metered call costs 1 unit — **a `search` costs 1 unit per 20 rows it returns**
(`num_results: 40` with 40 hits is 2 units, 100 is 5; measured v10.0, M29) —
and document reads cost 1 unit per document on first
fetch and are free forever after, across sessions, against **all three** caps.
Full detail, allocation and concurrency rules: `references/pipeline.md`
§ Budget. Every figure there was measured; the methods and the open questions
are in `references/measurements.md` — read it before redesigning anything
that depends on API behaviour, or before spending a window on a test it shows
has already been run.

### The counters are live — read them, do not keep a ledger `[v9.6]`

The connector exposes **`get_api_usage`**. It is free, never draws on the
`user` quota, and answers even while every other call is throttled. It
returns, per cap, `used` / `remaining` / `reset_at`, plus the last 14 days of
daily totals. **Nothing in this skill counts calls by hand any more.** The
earlier ledger (`calls_metered` summed across agents) is retired: it
undercounted, it was recomputed from memory, and the API now says exactly
what has been spent. Call `get_api_usage`:

1. **Before the banner** — its `used`/`reset_at` values feed
   `scripts/banner.py --hourly-used N --daily-used N --daily-reset HH:MMZ`.
   If `remaining` on the daily cap is below the ~13-unit spine, say so and
   stop before spending anything — offering, when the question is federal,
   the GovInfo-only run in `references/govinfo.md` § 7 (never started
   unasked).
2. **Before every metered wave** (Phase 3 dispatch, the Phase 4 screen,
   Phase 5 dispatch, each Phase 6 round). Dispatch only what `remaining` on the hourly cap covers,
   less a 6-unit reserve.
3. **After any 429**, to read which cap fired and when it reopens — the body
   says the same thing, but the tool also shows the other two caps.
4. **At close**, for the About table, the memo's Skill line and the `DONE`
   line. Every figure there comes from this call, never from recollection.

Subagents may call it too; it costs them nothing. They still report
`rate_limited` / `limit_hit` so the orchestrator can act on a refusal, but
they no longer return `calls_metered`.

### GovInfo reads are outside the pool `[v10.0]`

GovInfo allows 36,000 requests an hour and has no daily cap; nothing done
through `scripts/govinfo.py` touches the CourtListener counters. Every
selected case that `resolve-batch` places on the GovInfo lane is read,
triaged and quote-checked for **zero units**, so the wave gate counts only
CourtListener-lane reads: `wave_cost = CourtListener-lane unread opinions`.
Assign lanes (pipeline Phase 4) *before* computing a wave. The saving is the
number of analyzed cases on the GovInfo lane — for a federal question most
of the reading budget, for a state-court question the federal cases
applying that state's law. State courts, W.D. Wash., unpublished Ninth
Circuit dispositions and pre-2004 decisions are never on the GovInfo lane
(`references/govinfo.md` § 1). Spend what GovInfo frees on the things only
CourtListener can do: searches, citators, and reading the state authority
that has no lane of its own.

### State lanes are outside the pool too `[v10.0]`

Nothing done through `scripts/statecourts.py`, and no text command run on
an `OJD-…` or `WA-…` id, touches the CourtListener counters. Oregon
appellate opinions since 1998 and Washington slip opinions since 2013 that
`statecourts.py resolve-batch` matches are read, triaged and quote-checked
for zero units; Oregon candidates can also be *found* for zero units
(`or-search`), and Oregon review dispositions checked for zero
(`or-history`). The courts' servers are asked for one request a second —
the script enforces it across all agents — so a state lane is slower than
GovInfo, never metered. Older decisions, date mismatches and every New York
opinion remain CourtListener reads.

Two principles still govern spending:

- **Plan the run from the live counters, not from a guess.** The tool
  replaces the old "plan as if the window is full" heuristic: if
  `get_api_usage` shows 30 of 50 hourly units already spent by an earlier
  run, plan a 20-unit run (or wait for `reset_at`), and say so in the report.
- **Pay for the spine first.** Candidates, the history screen, and the
  CourtListener-lane reads (~13 units when nothing is on the GovInfo or a
  state lane, as few as ~6 when everything selected is) are what the report cannot be
  published without; everything
  above that is enhancement and is what gets cut. Never publish a report
  whose spine is incomplete without the banner naming what is missing.

### Read the 429 body — three caps, three responses

| Body says | Response |
|---|---|
| `5/min` | Sleep the **stated N + 5 s** (floor 5, ceiling 90), retry once. Do not count the rejection — it consumed no quota |
| `50/hour` | **Do not wait.** Stop, report `limit_hit: "hourly"`. Recoverable this hour |
| `125/day` | **Do not wait.** Stop, report `limit_hit: "daily"`, print the `DAY` line, tell the user. Nothing recovers this today |

Never report a daily refusal as hourly; the orchestrator's next move depends
on which fired. A subagent that gets a second 429 after its one retry stops
and reports rather than spinning.

## Subagent briefing — mandatory

`references/subagent-briefing.md` holds a canonical block: the rate-limit
model, forty-three known CourtListener quirks, the GovInfo-lane rules and the state-lane rules. **Every subagent receives it
verbatim** — pasted, or written once to a scratch file that each agent is told
to `cat` first. Every entry was learned by burning calls or by an agent
silently analyzing the wrong case. When a subagent reports a `new_quirk`, add
it.

## Corrections that must survive the run

`references/known-corrections.md` records verified findings about what
specific opinions are miscited for and what they actually hold, each with the
method that established it. Read it at Phase 3 triage; paste the entry into
the analyzer prompt for any listed case. The skill has no memory — a
correction survives only by being written in and reinstalled, and earning a
new one is a release.

## Historical statute text — archived editions `[added v9.5]`

"When did ORS X first say Y?" is a statutory-history question and is
answered from **official archived editions**, not from the current chapter
page (which shows only the latest text plus a source-law bracket) and not
from an opinion's recitation alone (which may be paraphrased, OCR-damaged,
or quoting the session law rather than the codified text). Both Oregon
archives are allowlisted tier-1 sources; the patterns, probe records and OCR
cautions are in `references/statute-sources.md` § "Archived ORS editions".

```
1953–1997  https://archives.oregonlegislature.gov/ORS_Archives/<YEAR>-Chapter-<NNN>.PDF
1999–2023  https://www.oregonlegislature.gov/bills_laws/Archive/<YEAR>ors<NNN>.pdf
```

`<NNN>` is the chapter zero-padded to three digits; the 1953–1997 extension
is upper-case `.PDF`. **Neither pattern is linked from the archive landing
page** (`bills_laws/Pages/ORSarchive.aspx`) — that page renders its document
library client-side and three WebFetch passes against it returned no
year-specific href. Go straight to the pattern. Oregon Laws session-law text
is online only from 1999 (`bills_laws/lawsstatutes/<YEAR>orLaw<CCCC>ses.html`);
for earlier acts the ORS edition and its source-law bracket carry the dating.

Method, which is the long-page protocol with two additions:

1. **Bracket the change first, then bisect.** Read the current bracket, list
   the amending acts, fetch the edition just after the earliest candidate and
   the edition just before the latest, and narrow. Five editions dated a
   1985→1987→1991→1993 sequence in this skill's first use of the route.
2. **One provision per fetch, `NOT PRESENT` escape, two agreeing fetches
   before quoting** — exactly as for the current page. Defeat the 15-minute
   cache by appending a throwaway query string (`?v=2`) to the second URL.
3. **These are page scans.** OCR renders `(b)` as `(h)`, `1991` as `1891`,
   `c.762` as `c.62`/`c.662`; a fetch can return only the first sentence of a
   subsection. Ask the second fetch for a specific sentence ("the SECOND
   sentence of the subsection beginning …") and for the exact form of any
   cross-reference in dispute ("paragraph (b) of subsection (1)" versus
   "subsection (1)(b)"). Report the edition year as printed on the volume,
   not as OCR'd.
4. **Report the edition year, the subsection number as printed in that
   edition, and the bracket** for every edition read. Subsection numbers move
   when a subsection is inserted above; a cross-reference can be restyled by
   Legislative Counsel without a substantive change. Where the question is
   "first contained this text," give both dates when they differ — the
   edition where the substance first appears and the edition where the exact
   wording first appears — and say which change accounts for the gap.

The console banner lights the `Oregon ORS archived editions` family with
`--need "archived"`; add the archive line to the report's Data Sources block
with a `[+]` mark if it becomes relevant only mid-run.

## Workflow

Follow `references/pipeline.md` exactly. In brief:

1. **Parse** — decompose the query; resolve court IDs yourself; existence
   framings ("are there any cases…") set `deep`; `get_api_usage`
   (if the connector is missing or not signed in, § First-run setup, then
   resume), `govinfo.py probe` and — when Oregon or Washington is in scope —
   `statecourts.py probe`; print the banner.
2. **Anchor** — for any user-named case: one batched resolution, one raw
   citator, one topic-filtered citator. The citing set is candidates, a
   doctrinal map; the anchor itself is screened in Phase 4 with the rest.
3. **Search** — strategies that fill the anchor set's gaps, **one of them a
   plain-language semantic question**: unwindowed first for current law,
   then narrow (≤ 5-year) windows aimed at the eras the other rows date
   (semantic ranking favours recent cases inside any window), the rest
   keyword; ≤2 agents
   concurrent, 3–4 queries each; **when federal courts are in scope, the
   same strategies run on GovInfo for free, and when Oregon appellate courts
   are, on the Oregon collection (`or-search`)**; merge, dedupe;
   `resolve-batch` (both scripts) and `triage` the candidates that resolve;
   score, select.
4. **Select** — resolve every id centrally (rows already carry them; known
   cases, including ones you recall, in ONE batched call under the four
   guardrails); **assign each selected case its text lane** (GovInfo,
   state, or CourtListener); then **the mandatory one-call history screen**, before
   any opinion is read.
5. **Analyze** — one analyzer per case, fanned wide, reading the full
   opinion once in its lane; only CourtListener-lane analyzers are staggered
   and metered.
6. **Refine** — write the lead ledger from the analyses (authorities the
   cases point to, the courts' own vocabulary, statutes, splits, eras,
   gaps, and the question's own premise); sufficiency test against the target and every sub-question; a
   budgeted round if short, if `deep`, **or if a fruitful lead is open** —
   never on a `quick` request. Every refinement query is written from a
   named finding of the round before, not from the original question.
7. **Verify** — history confirmation against cached opinions (plus free
   GovInfo docket history and citing search), state review dispositions
   (Oregon by script), the New York official-page check, statutes, and
   every quote, each in the lane it was read in.
8. **Report** — the report, then the memo.

Query syntax, the citator recipe, ID resolution and citation construction
are in `references/courtlistener-mcp.md`. Coverage, the lane rule, the
script's commands, GovInfo-only authorities and the GovInfo quirks are in
`references/govinfo.md` — read it before Phase 3 of any run whose
jurisdiction includes a federal court. The Oregon, Washington and New York
sources, their ids, what each text is and is not, and quirks S1–S30 are in
`references/state-sources.md` — read it before Phase 3 of any run touching
one of those states.

## Update check — first thing in every run `[v10.4, notes and local-change check v10.5]`

Before the banner, run **once**:

```
python3 scripts/update_check.py
```

It does two things and never blocks the run:
- **Local check (no network).** It compares this installation with the
  `MANIFEST.sha256` it shipped with and lists any file that was changed,
  removed or added since release (`local_changes`).
- **Release check.** It compares `VERSION` with the release manifest
  published at `github.com/jumpingtom1/deep-legal-research-resources`
  (`skill/latest.json`) — one small request.

| First line | Do |
|---|---|
| `UP-TO-DATE` | Nothing, unless `local_changes` is printed (below). |
| `UNREACHABLE` / `INVALID` | One `UPD` exception line: `update check unavailable — running v<X.Y>`. Carry on. |
| `UPDATE` | Deliver the file the script names with `SendUserFile`, captioned `deep-legal-research v<new> — upgrade available`. In chat: first **What's new** — every release under `whats_new`, newest first, as `v<X.Y> (<date>)` followed by its bullets, word for word; then the `upgrade_steps` as a numbered list; then the `organization` and `notes` lines, word for word. Print one `UPD` line: `v<new> available (running v<X.Y>) — zip delivered`. Then **carry on with the research on the installed version.** Do not stop, and do not ask first. |

**`local_changes` printed** (any status): give the user the
`local_changes_note` line word for word, and print one `UPD` line:
`local copy differs from release in <n> file(s)`. Do not list file contents,
do not try to restore or "repair" the files, and carry on. (A v10.4 or older
installation has no `MANIFEST.sha256`; the check is skipped silently.)

The script checks the zip's sha256 against the manifest and its layout (one
`deep-legal-research/` folder with `SKILL.md`). It then copies
`scripts/govinfo.key` from this installation into the zip, because the public
release never contains it (§ Packaging and release). Never fetch the release
any other way, never unpack it over this installation, and never upload it
on the user's behalf. Upgrading is the user's action.

## Console output — one banner, then exceptions only

Everything the user sees before the report is a single fixed-width banner and
then **only exception lines** — no progress, no methodology, no preview.

**Banner** — assembled by `python scripts/banner.py --need "<family>" …
[--hourly-used N --daily-used N --daily-reset HH:MMZ] [--govinfo ok|off]
[--oregon ok|off] [--washington ok|off] [--no-federal]` from `VERSION`,
`references/source-status.md`, one `get_api_usage` call, one `govinfo.py
probe` and, when a state source is in scope, one `statecourts.py probe`,
pasted verbatim inside a fenced code block before the first call. Name the
state families the query needs — `--need "petitions"` for an Oregon
question, `--need "New York Official"` for a New York one. Do not
hand-edit it except to fix the underlying table. Its Data Sources lines are
reproduced in the report and memo. Never spend a call to confirm the
connector.

**Exception lines** — fenced, tag padded to 5, message ≤ 60 characters
(`DONE` alone may run longer):

| Tag | When | Content |
|---|---|---|
| `UPD`  | update check says UPDATE, UNREACHABLE or INVALID, or prints `local_changes` (§ Update check) | `v10.6 available (running v10.5) — zip delivered` — or `update check unavailable — running v10.5` — or `local copy differs from release in 2 file(s)` |
| `API`  | first metered call | `CourtListener API: status confirmed` — or `FAILED — <error>` and the run stops |
| `GOV`  | after lanes are assigned (Phase 4) — or at Phase 1 if `probe` fails | `GovInfo lane: <g> of <n> selected cases (0 units)` — or `GovInfo unreachable — federal cases via CourtListener` |
| `ST`   | after lanes are assigned, when any Oregon, Washington or New York case was selected — or at Phase 1 if a state probe fails | `State lanes: <o> OR, <w> WA of <n> selected (0 units)` — or `<Oregon collection\|WA listing> unreachable — CourtListener lane` |
| `WAIT` | a per-minute 429 | `429 — window reopens in Ns` |
| `DAY`  | a `125/day` 429, including on the first probe | `daily cap reached — pool refills from <HH:MM>Z`; the run stops or finishes short |
| `NOTE` | `get_api_usage` shows hourly `remaining` ≤ 20 | `hourly 30/50 used — remaining work is mostly cached reads` |
| `CUT`  | planned metered work dropped for budget | `<what> — <n> of <m> cases unscreened` |
| `FIX`  | an analyzer returns `id_mismatch` or corrects its premise | `<case>: <one clause>` |
| `DONE` | after the memo is delivered | `<cases> cases (<g> via GovInfo, <s> via state sources) · <quotes> quotes verified · <calls> calls (<n>/125 daily) · <agents> agents · <wall-clock>` — the call figures from a closing `get_api_usage` |

No timestamps, no budget meter, no phase-transition lines. A clean run prints
the banner, `API`, `GOV`, `ST` when a state source was used, and `DONE`.

## Session model

One chat per research matter. A follow-up in this thread — including weeks
later — is a scoped Phase 6 round with the affected sections re-rendered and
the memo regenerated, not a full rerun. A genuinely new question belongs in a
new chat. A follow-up starts with `get_api_usage`, not with a remembered
count — the pool is shared with whatever else ran in the meantime.

## Packaging and release — the whole skill, always `[v9.6, manifest v10.0]`

The skill is one folder of interdependent files. `SKILL.md` is the entry
point, not the skill: the pipeline, the briefing block, the query recipes,
the corrections, the report and memo formats, the source tables, the GovInfo
and state-source references, the two bundled corpora and the five scripts are all load-bearing, and a copy that
lacks any of them fails silently (the v9.5 orchestrator ran without a
briefing to give its subagents and had to reconstruct the citator recipe from
the changelog).

Therefore, for every release and for every request to "update", "fix",
"recreate" or "bump" this skill:

1. Start from the **most recent complete copy** — a `.zip` the user supplies,
   or the synced folder only if `ls -R` shows every file below. If files are
   missing, ask for the last full `.zip` before editing anything.
2. Make the edits in a scratch copy of the whole tree.
3. Run the release checklist in `CHANGELOG.md` (probe, `VERSION`, changelog,
   measurements).
4. **Package the entire tree as `deep-legal-research-v<X.Y>.zip`** and deliver
   the zip. Exclude `__pycache__` (the scripts set `dont_write_bytecode`,
   but check: `find . -name __pycache__` must print nothing). Print the manifest (`unzip -l`) in the delivery message and check
   it against this list:

   ```
   SKILL.md  VERSION  CHANGELOG.md
   references/pipeline.md  references/subagent-briefing.md
   references/courtlistener-mcp.md  references/known-corrections.md
   references/report-format.md  references/memo-format.md
   references/statute-sources.md  references/source-status.md
   references/measurements.md  references/govinfo.md
   references/state-sources.md
   references/or-corpus/{MANIFEST.md, orcp.jsonl, orcp.meta.json,
                          utcr.jsonl, utcr.meta.json}
   scripts/banner.py  scripts/or_lookup.py  scripts/or_corpus_build.py
   scripts/govinfo.py  scripts/govinfo.key  scripts/statecourts.py
   scripts/update_check.py  scripts/state_repo.py
   references/state-repo.lock.json
   MANIFEST.sha256          (written by release_skill.py — never by hand)
   ```

   Twenty-nine files at v10.5: `scripts/state_repo.py` and
   `references/state-repo.lock.json` (the other states, read from the
   state-sources repo at a pinned commit) and `MANIFEST.sha256` (the
   sha256 of every other file, which `update_check.py` uses to spot local
   edits).
   Twenty-six at v10.4 (`scripts/update_check.py` added); twenty-five at v10.3, unchanged since v10.0 (2026-10-05 rebuild; twenty-three on
   2026-10-04). `scripts/statecourts.py` imports `scripts/govinfo.py` and
   the reverse: neither works without the other in the same folder. `scripts/govinfo.key` holds an
   api.data.gov key in plain text, **bundled on purpose and shared by
   everyone who has the skill** `[v10.1]`: the zip may be passed to
   colleagues, not posted publicly — say so in the delivery message, and
   never paste the key into a report, a memo, a subagent's returned JSON or
   a chat message. The zip contains no CourtListener credential and must
   never gain one (§ First-run setup).
   **Publishing a release** `[v10.4, v10.5]`. The public release lives in the
   deep-legal-research-resources repo and is what `update_check.py` offers
   users. Publish only with that repo's script:
   `python3 scripts/release_skill.py <folder> --notes NOTES.md --private-out <dir outside the repo>`
   - `--notes` is required: 1–8 user-facing bullets (≤ 200 characters
     each) saying what upgrading gets the user. Write them for a lawyer,
     not a developer — "Rhode Island court rules can now be quoted", not
     "ri.json fix pass". They become this release's entry in the
     manifest's `history`, which every older installation shows as
     **What's new**.
   - It writes `MANIFEST.sha256` into the zip.
   - It leaves `scripts/govinfo.key` (and any `*.key`, `*.pem` or `.env`
     file) out of the public zip, and lists it under `preserve_local`;
     it refuses to write if a remaining file looks like a credential.
   - `--private-out` also writes `deep-legal-research-v<X.Y>-with-key.zip`:
     the same release **with** the key, for colleagues installing for the
     first time. Never commit or post it.
   The maintainer does not run any of this: he asks Claude for a release,
   in a session that has the repo attached. Claude runs the checklist and
   the script, commits and pushes, and then **delivers the `-with-key` zip
   to the maintainer with `SendUserFile`**, captioned "for new colleagues —
   send privately". When the maintainer writes no release notes, Claude
   drafts the bullets from the changelog entry and shows them before
   publishing.
5. **Never use `propose_skills`** (the "propose new skill" review card) for
   this skill, in any version. It writes `SKILL.md` only. A user who saves
   that card gets a skill with no references and no scripts.

## Versioning and release

`VERSION` holds the number, date and author the banner prints. **Any change
to any file is a release**: run the checklist at the top of `CHANGELOG.md` —
re-probe `references/source-status.md`, update `references/measurements.md`,
bump `VERSION`, add the changelog entry, and ship the whole tree as a `.zip`
(§ Packaging and release).

---

*v10.5 — 2026-10-18, every other state and D.C. through the pinned state-sources repo; release notes and local-change check in the update check (see `VERSION`). Change history, the evidence behind each
rule, the release checklist and the load-bearing rules are in `CHANGELOG.md`.
Read it before editing this skill.*
