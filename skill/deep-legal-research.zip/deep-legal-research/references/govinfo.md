# GovInfo — the second source `[added v10.0]`

GovInfo (`api.govinfo.gov`) is the Government Publishing Office's repository.
Since v10.0 the skill uses it beside CourtListener, through one script,
`scripts/govinfo.py`. Every figure in this file was measured on 2026-10-03;
the methods are in `measurements.md` (M13–M32).

**The division of labour, in one paragraph.** CourtListener finds cases in
every court, supplies every reporter citation, and is the only citator.
GovInfo supplies the *text* of federal opinions it holds — to read, to triage
and to check quotes against — and a second, free full-text search of federal
courts. CourtListener allows 125 calls a day; GovInfo allows 36,000 an hour.
Every opinion read through GovInfo is a CourtListener unit not spent.

## 1. What GovInfo holds — and what it does not

| Collection | Holds | Does NOT hold |
|---|---|---|
| `USCOURTS` | The courts' own PDFs of opinions and orders designated as opinions by **participating** federal appellate, district and bankruptcy courts, generally 2004 → present. One *package* per docket; one *granule* per filing. 4.64 million granules | **Any state court.** The Supreme Court. Reporter citations. Anything before ~2004. Non-participating courts |
| `USREPORTS` | The bound United States Reports, **volumes 1–586** (through early 2019), one granule per case, with official page numbers and the running head naming the section | Supreme Court decisions after vol. 586; anything known only by an `S. Ct.` citation |
| `USCODE` | The U.S. Code, annual editions 1994 → 2024, one page per section (see `statute-sources.md`) | Laws enacted after the latest annual edition |

### Coverage of the courts this skill uses most `[measured]`

| Court | CourtListener id | In GovInfo? | Note |
|---|---|---|---|
| D. Or. | `ord` | **Yes** — 48,098 granules, ~2,000 a year, 2005 → 2026 | 8 of 8 post-2004 CourtListener rows resolved |
| E.D. Wash. | `waed` | **Yes** — 49,667 | |
| **W.D. Wash.** | `wawd` | **No** — zero district granules (its bankruptcy court `wawb` has 282) | Always the CourtListener lane |
| 9th Cir. | `ca9` | **Published opinions only** — 400–750 a year | 15 of 17 published rows resolved; **0 of 21** unpublished memorandum dispositions |
| Bankr. D. Or. | `orb` | Yes — 766 | |
| D. Idaho / D. Mont. / D. Alaska | `idd` `mtd` `akd` | Yes | |
| N.D. Cal. | `cand` | Yes — 441,141 | Docket strings often lack the office digit; the script tries each office and demands a date **and** name match |
| S.D.N.Y., C.D. Cal. | `nysd` `cacd` | **No** district granules | |
| 2d Cir. | `ca2` | Partial — 8 of 12 resolved | |
| 4th, 5th, 7th, 10th, 11th, D.C. Cir. | `ca4` … `cadc` | Yes — 35 of 35 resolved | D.C. Circuit's GovInfo code is `caDC`; Federal Circuit's is `ca13` (the script maps both) |
| Supreme Court | `scotus` | Via `USREPORTS`, by `U.S.` citation, vols. 1–586 | 5 of 5 pre-2019 cases resolved; 2019+ and `S. Ct.`-only cases miss |
| Every state court | `or` `orctapp` `wash` `washctapp` … | **No** | Not GovInfo's. Oregon appellate courts (1998 →) and Washington slip opinions (2013 →) have their own text lane — `state-sources.md`; every other state court is the CourtListener lane |

An absent court is not an error and not a reason to search harder: it is the
CourtListener lane, exactly as in v9.6 — or, for Oregon and Washington
appellate decisions, the `state` lane of `state-sources.md`.

## 2. The lane rule — one source per case

Every case selected for analysis is assigned a **text lane** before the
analysis wave, and keeps it to the end of the run:

- **`state`** `[2026-10-05]` — an Oregon or Washington appellate decision
  that `scripts/statecourts.py` matched; read and verified with the same
  text commands on its `OJD-…` / `WA-…` id (`state-sources.md` § 1).
- **`govinfo`** — `govinfo.py resolve-batch` returned `found: true`. The analyzer reads
  the GovInfo text, and Phase 7 verifies its quotes against **the same
  granule**. Zero CourtListener units.
- **`courtlistener`** — everything else. Read and verified exactly as in
  v9.6: `read_document` / `search_document`, one unit on first fetch.

**Never read a case in one lane and verify it in the other.** The two texts
are different artifacts: CourtListener often holds the *reporter's* text (OCR
of the bound volume), GovInfo holds the *court's slip opinion*. Measured on
*Willis v. Nationwide Debt Settlement Group*, 878 F. Supp. 2d 1208: of 40
sentences sampled from the CourtListener text, 26 matched the GovInfo text
exactly, 11 differed in typography or OCR (`(# 22)` vs `(#22)`,
`Or.App.` vs `Or. App.`, CourtListener's `áre` and `.require`), 3 did not
match. Neither is "wrong"; they are not interchangeable. A cross-lane check
manufactures false `not_found` grades and invites a hand-repaired quote.

## 3. The script

```
python3 scripts/govinfo.py probe
python3 scripts/govinfo.py resolve-batch rows.json
python3 scripts/govinfo.py fetch   GRANULE [GRANULE …]
python3 scripts/govinfo.py triage  GRANULE [GRANULE …] --terms "illusory" "unilateral"
python3 scripts/govinfo.py read    GRANULE [--pages 3-7] [--raw]
python3 scripts/govinfo.py grep    GRANULE "phrase" ["phrase" …]
python3 scripts/govinfo.py verify  GRANULE quotes.json
python3 scripts/govinfo.py docket  GRANULE
python3 scripts/govinfo.py search  'arbitration AND unconscionab*' --court ord [-n 50]
python3 scripts/govinfo.py cites   --name "Bielski v. Coinbase" --cite "87 F.4th 1003" [--negative] [--context 5]
python3 scripts/govinfo.py usc     --title 15 --section 1692k [--year 2008]
```

Every command except `read` prints JSON, including on failure (`"found":
false` / `"ok": false` with a `reason` or `error` — never a traceback, and
never the API key). `"found": false` with a `reason` is a normal, complete
answer. The API key is read from `$GOVINFO_API_KEY`, else from
`scripts/govinfo.key`. PDFs and extracted text are cached under
`$GOVINFO_CACHE` (default `~/.cache/govinfo`); set it to one scratch
directory at Phase 1 and give the same path to every subagent, so a granule
is downloaded once per run.

**The text commands serve the state lanes too** `[2026-10-05]`. `fetch`,
`triage`, `read`, `grep` and `verify` accept an `OJD-…` (Oregon official
reports) or `WA-…` (Washington slip opinion) id from
`scripts/statecourts.py` exactly as they accept a granule id; no key is
involved for those. Their output then opens with the document's own record
(`source`, `case_name`, `citation`, `document_notes`) and the page labels
differ — `official_page` / `pin` for Oregon, `slip_page` / `pdf_page` for
Washington, the PDF page (`slip_page`) for GovInfo slip opinions as before.
Everything below about grades, cautions and normalization is the same for
all three. `resolve-batch`, `docket`, `search`, `cites` and `usc` remain
GovInfo-only. See `state-sources.md`.

**Use the script, never WebFetch, for GovInfo text.** WebFetch passes the page
through a summarizing model; the script returns the document's own
characters. (WebFetch remains correct for the statute sources that have no
script.)

### `probe` — once, at Phase 1

Costs nothing and takes a second. `{"ok": true, …, "pdftotext": true}` turns
the GovInfo lane on for the run. `"ok": false` — the host is not reachable
from this environment (an egress allowlist that omits `api.govinfo.gov` and
`www.govinfo.gov`), or the key was rejected — turns it **off**: the run is a
v9.6 run for federal cases — every one on the CourtListener lane (a state lane, if on, is unaffected) — and the banner says so. Never
stop a run because GovInfo is unavailable. `"pdftotext": false` means
poppler-utils is missing: try `apt-get install -y poppler-utils`; if that
fails the script falls back to pypdf and says so, and quotes from that run
are held to the OCR rule in § 5 (view the page).

### `resolve-batch` — CourtListener rows → granules

Input: a JSON array of CourtListener search rows carrying `court_id`,
`docketNumber`, `dateFiled`, `caseName` and `citation`. Those are why
`court_id` joined the standard `fields` list in v10.0. **All of court id,
docket number, date and case name are required**: a row missing any of them
is `found: false`, by design. (`court_id` must be the id — `ord` — not the
court's name.) The script:

1. builds the package id from the court code and docket number
   (`ord` + `3:20-cv-01695` → `USCOURTS-ord-3_20-cv-01695`; `ca9` + `22-15566`
   → `USCOURTS-ca9-22-15566`); for `scotus` it builds
   `USREPORTS-<vol>-<page>` from the `U.S.` string in the `citation` array;
2. asks GovInfo whether it exists;
3. requires a granule whose `dateIssued` **equals** `dateFiled`;
4. requires the package title to share the case name's distinctive words;
5. returns the granule, the `docket_text` of that filing, and every other
   granule in the docket.

It never guesses. A miss at any step is `found: false`:

| `reason` begins | Meaning | What to do |
|---|---|---|
| `court '…' does not publish` | known-absent court | CourtListener lane |
| `docket number not in a constructible form` | no number the script can parse | CourtListener lane |
| `no GovInfo package for this docket` | court did not publish it (9th Cir. memoranda; most pre-2004, including old-style numbers such as `CIV.02-592-ST`) | CourtListener lane |
| `no case name supplied` / `no decision date` / `court must be a CourtListener court id` | the row is incomplete | fix the row or CourtListener lane — never retry without the missing field |
| `package exists but no granule is dated …` | **the docket has filings on other dates** — commonly an amended opinion that replaced the one CourtListener indexed. `granule_dates` lists them | CourtListener lane for the text, **and treat the later date as a history lead** (Phase 7A) |
| `…title does not match the case name` | a consolidated or related docket (`In re Uber Text Messaging` for *Manning v. Uber*) | CourtListener lane |

Three fields of a `found: true` row need reading, every time:

- **`ambiguous: true`** — more than one filing on that date. `granule_id` is
  only the first. Read `docket_text` for each and choose the one described
  as the opinion; if that is not plain from the docket text, give the
  analyzer **every** same-date granule and have it report which is the
  decision. Never take the first by default.
- **`adoption_hint`** — the dated filing is an order adopting a magistrate
  judge's findings and recommendation. The reasoning is in an **earlier**
  granule. Measured on *Meunier v. Northwestern Mutual*, 51 F. Supp. 3d 1023:
  the date-matched granule is a 2-page adopting order (2,027 characters);
  CourtListener's reporter text for the same citation is 64,590 characters
  because West printed the F&R beneath it. Pass both granule ids to the
  analyzer and require each quote to name its granule; the report attributes
  a quote from the F&R to the magistrate judge, "adopted" by the district
  judge.
- **`recommendation_hint`** — the filing itself is a magistrate judge's
  findings and recommendation. It is not a ruling. Run `docket` and read
  `adopting_orders` (G15).
- **`history_hint`** — the docket text says this filing was vacated,
  withdrawn or amended (`VACATED pursuant to Court's Order entered 05/04/23.
  Amended Opinion filed.`). Read `other_granules`; the later filing is the
  one to analyze, and the earlier one is a Subsequent History entry.

### `fetch`, `read`, `grep`, `triage`

`fetch` downloads the PDF and extracts text with `pdftotext -layout`; it
prints `pages`, `chars`, the `opening` (for the identity check),
`ocr_layer` (with `ocr_undetermined` when poppler could not say — treated
as OCR) and `recommendation_in_caption` when the document's own caption is
a findings/report and recommendation. Twenty-five District of Oregon opinions fetch, extract and
triage in under five seconds.

`read` prints the opinion page by page with the stamp, running heads and
pleading-paper line numbers removed, and **each page's footnote text set
apart** under a `----- footnote text on this page -----` line (footnotes
are found by their running number sequence at the foot of a page; the
detector's count is `footnotes_detected` in `verify` output). Page markers are the citation unit:
`[slip op. page 12 of 34]` for `USCOURTS`; `[563 U.S. 344 | Opinion of the
Court]` for `USREPORTS`, where the second part is the bound volume's own
running head.

`triage` is the pre-read: for each granule, the count of each term and one
snippet. It is what CourtListener's search cannot give (briefing quirk 1: no
snippets) and it is free. Use it at Phase 3 to score federal candidates on
what they say rather than on their names.

### `docket` — the same-case history of any USCOURTS granule

`docket GRANULE` returns the filing's own `docket_text` and hints,
`is_recommendation`, `adopting_orders` (with `adopting_orders_note`),
`possible_recommendation`, `same_date_granules`, `earlier_granules`, and
every **later** filing in that docket (`later_granules`) with its docket
text. Use it (a) on every
GovInfo-found candidate before it is selected (§ 4) and (b) in Phase 7A for
every GovInfo-lane case. Later filings are leads to fetch and grep. An empty
list is not a clean history — an appeal lives in another docket.

### `verify` — the Phase 7D check for the GovInfo lane

Input: a JSON array of quotes. For each, one grade:

| Grade | Means | Publication rule |
|---|---|---|
| `verified` | the quote is the opinion's own words: each part is in the opinion proper — exactly (after the normalization below), at word boundaries, inside one opinion. An ellipsis in the quote is accepted only where the opinion itself has that ellipsis, or where nothing but punctuation lies between the parts `[2026-10-05]`. `cautions` lists anything still to settle | publish with the page from `cite_pages` **only when `cautions` is empty or every caution has been settled** (pipeline Phase 7D) |
| `likely` | the words are nearly there but the quote as written is not the opinion's: a changed, added or missing word (≥ 92 % similar); words in a bracket that the opinion does not have at that point; **an ellipsis of the quoter's that omits any words of the opinion** `[2026-10-05: previously only a negation — review 4 produced "the trial court . . . denied" for "erred when it denied"]` or crosses a page; a fragment beside an ellipsis shorter than three words; a quote cut mid-word; a quote running from one opinion into another; a sentence whose halves lie on two pages with other text between. `differences` / `problems` say which; `source_sentences` is a window of the opinion's own text to requote from | **not publishable as handed in.** If a word differs, re-read the passage and re-check the analysis. Requote plainly, `verify` again, publish only on `verified` |
| `not_found` | not in the opinion; or only in a staff summary or syllabus — or, on a state lane, only in the caption / case summary / cover sheet that precedes the opinion (`not_opinion_text`); or stitched from passages more than 400 characters apart. `absence_check` reports stem counts | drop, or report the absence as a finding |

There is no "≈ close match" label on the GovInfo lane: everything published
from it is `verified` with its cautions settled. The check is deterministic
— the same quote and granule always give the same grade.

**Normalization — what is ignored, in the quote and the opinion alike:**
curly vs straight quotation marks and dashes; runs of whitespace and line
breaks; a hyphen between letters (so a word broken across lines matches);
a space before closing punctuation; and the bracket *characters* `[` `]`.
Nothing else: **every word and every digit is compared.** In particular
the words inside a bracket are compared like any other words — `[T]he`
matches the opinion's `The`, and the court's own `apply[ing]` matches
itself, but `[in]correctly`, `[do not]` and `[Coinbase]` in place of
another name do not verify. Punctuation is compared: `it.` against the
opinion's `it;` is `likely`.

**Body and footnotes are separate streams.** A quote is matched against the
body text with footnote blocks lifted out — so a sentence that continues
over a page break matches as the continuous text it is — and, failing that,
against the footnote text. Where a footnote block is recognised, body words
are not run into footnote words; a block the splitter misses (an OCR scan
that misreads the number, a PDF whose text order puts the footnote's first
line above its number — seen on the state lanes, review 5) stays in the
body, where a quote from it verifies without a `footnote` caution or fails
across the page break. If
a quote fails only because the opinion has a footnote call glued to a word
(`contracts.2 The`), a second attempt ignores such calls **in the opinion
only** and the result carries `footnote_call`; a quote can leave a footnote
number out but can never change a number (550 of 550 single-digit changes
were refused in M21).

**What `verified` does and does not mean.** It means those words are in
that document at that place. It does not mean the court said them (see
`opinion_part` and the `separate_opinion` caution), that the fragment is
fair to its sentence (see `lead_in` and `elided`), or that the analysis
around it is right. Three rounds of independent adversarial review of the
v10.0 builds (M31) produced false `verified` grades — a quote cut from
inside "unenforceable"; `[S]ufficient` for "insufficient"; an ellipsis
hiding "do not"; `[in]correctly`; a trailing `[with prejudice]`; passages
seventeen pages apart joined by an ellipsis; a dissent with no heading
detected; and, in the third round, numbers changed after a comma
(`$31,999` for `$31,000`) and fragments following "nothing in" — and every
one of those inputs now grades `likely` or `not_found`, or carries a
caution. The rule that came out of it: **quote
whole sentences, plainly.** Each ellipsis or bracket is something more to
settle.

| Caution | Raised when | Settle by |
|---|---|---|
| `lead_in` | the quote starts mid-sentence — always, whatever the words are; the caution prints how the sentence begins ("We think that nothing contained in …", "Plaintiffs oppose … on the following grounds: …", "in *Solis* the court held that …") | quoting the whole sentence, or confirming the fragment does not misstate it; a party's argument or another court's rule is never presented as this court's holding |
| `trail_off` | the quote stops mid-sentence; the caution prints how the sentence continues ("… not suffice.") | quoting the whole sentence, or confirming nothing after the cut changes the meaning |
| `footnote` | the words are footnote text | citing it as a footnote (`slip op. at 5 n.2`); viewing the page for the number and whose opinion it belongs to |
| `footnote_call` | the opinion has digits glued to a word inside the passage, taken to be a footnote reference and ignored (`footnote_calls_ignored` lists them) | reading `source_text` to confirm the digits are not part of the sentence |
| `elision` | *(retired 2026-10-05)* a quoter's ellipsis that omits words of the opinion now grades **`likely`**, with the omitted words in `problems` and `elided` — it is no longer a caution on a verified quote. An ellipsis that is the opinion's own still verifies | quoting each part on its own, or the passage whole |
| `page_label` *(state lanes)* | the page number in `cite_pages` was inferred, unconfirmed against its neighbours, or not read from the page | viewing the PDF page before giving any pin |
| `fractured_decision` *(state lanes)* | the document's text uses "lead opinion" or "plurality": the decision may have no majority opinion, and the first opinion in the file may be the view of fewer than a majority | viewing the opening of each opinion in the PDF; saying which opinion the passage is from and how many judges joined; never calling it the court's holding unless a majority did |
| `unpublished_part` *(Washington)* | the passage lies after the court's statement that only the foregoing portion of the opinion will be printed | labelling the quote "unpublished portion"; never resting a holding on it as precedent |
| `separate_opinion` | the text follows a heading such as `MILLER, Circuit Judge, concurring in part`, or the U.S. Reports running head is a concurrence, dissent or individual Justice's opinion; on the state lanes also when the page's running head names a dissent, or when the document is known to contain a separate opinion (Oregon caption, Washington listing) that the script could not place — then on **every** quote from the document | attributing the quote; never using it as the court's holding; for "could not be located", viewing the page first |
| `section_unknown` / `section_boundary` | a U.S. Reports page whose running head could not be read, or on which more than one section or opinion sits and the opening line could not be placed with certainty | viewing the page (`Read` the `pdf_path`, `pages` = N) |
| `page_break` | the quote runs over a page break (a footnote *continued* from the previous page carries no number and can sit undetected in the body there) | viewing both pages |

Tested adversarially on the final script (M21), 21 opinions: 1,371 strings
sampled from the extracted body and footnote text. The 54 lying in a
syllabus or staff summary were all refused. Ten that the sampler had cut
across a footnote or section boundary were refused, correctly. The other
1,307 all graded `verified` — 640 with no caution; the rest carrying
`separate_opinion` (211), `footnote` (109), `page_break` (104),
`section_boundary` (31) or, because the sampler splits at abbreviations,
`lead_in` / `trail_off`. The same 1,307 with one word inserted: all refused.
550 of 550 single-digit changes: refused. 84 of 84 invented holdings:
`not_found`.

**What no string check can see** — and a third review round confirmed
(M31): a whole sentence that is the court's summary of a party's argument,
or a block quotation of another court, verifies cleanly, because those are
the opinion's words. A dissent under a heading the detector does not
recognize verifies without `separate_opinion`. A footnote continued from
the previous page looks like body text. These are the analyzer's and the
orchestrator's to catch by reading; the checker narrows the field, it does
not replace the reading.

`source_text` and `source_sentences` show words that were broken across
lines joined up, and report how many (`joined_line_breaks`): a true compound
such as `state-court` can lose its hyphen that way, so check the page before
publishing either field verbatim. `source_sentences` is a window to trim to
whole sentences, not a finished quote.

### `search` — a free second discovery channel for federal courts

Same boolean style as CourtListener keyword search: `AND`, `OR`, quoted
phrases, trailing `*`, parentheses. **Proximity (`"a b"~10`) is not
supported** — it returned the same single hit as the bare phrase and zero for
the reversed order. Filters: `--court <CourtListener id>` (one court),
`--circuit 9th`, `--courttype appellate|district|bankruptcy`, `--after`,
`--before`. Rows carry `granule_id`, `title`, `date_issued`, `court_code`,
`docket_number`, `court_citation_string` and `details_url`.

It finds decisions CourtListener's search does not return. Measured: the
query `arbitration AND (unilateral OR illusory) AND unconscionab*` in the
District of Oregon returned **9** rows from CourtListener and **25** from
GovInfo; all 8 of CourtListener's post-2004 rows were among the 25. Of the
other 17: nine were district judges' opinions on dockets CourtListener does
not hold; **eight were magistrate judges' findings and recommendations**,
each adopted by a later order in the same docket, and CourtListener held
the adopting order for three of them (§ 4).

Rows can be orders, opinions **or recommendations**, and one docket can
contribute many granules. Triage before scoring, and `docket` before
selecting.

### `cites` — federal opinions that mention a case

`cites --name "<Party v. Party>" --cite "<vol reporter page>"` lists
USCOURTS opinions containing either string, newest first; `--negative` adds
the treatment words; `--context N` fetches the first N citers and returns the
passages around the case's name. It is free, and unlike the CourtListener
screen it says which case each citer is talking about.

**It is not a citator.** It sees only GovInfo's participating federal
courts, no state court, and a hit containing "overruled" may be overruling
something else. It adds leads to Phase 7A; it never clears a case. Hard
rule 4 is unchanged.

## 4. Decisions found only in GovInfo

A `search` row with no CourtListener counterpart is a real decision that
CourtListener does not hold, or holds under another date.

0. **`docket <granule_id>` first, free.** If `is_recommendation` is true
   the filing is a magistrate judge's recommendation (G15): it is authority
   only as adopted. Read `adopting_orders`; analyze the F&R together with
   the adopting order; the decision's date and citation are the adopting
   order's. No adopting order in the docket → not selected, listed as an
   unadopted recommendation.
1. **One batched CourtListener call per court** for the rows that survive
   triage: `q='docketNumber:("3:10-cv-00649" OR "3:22-cv-00060" …)'`,
   `court=["ord"]`, the three `stat_*` flags, the standard `fields`. One
   unit resolves many dockets (quirk 41). A returned row counts **only if its
   `dateFiled` equals the granule's `date_issued` or the date of the order
   adopting it** — the same docket holds other orders. A match brings the `citation` array, `cluster_id`,
   `opinion_id` and `absolute_url`, and the case becomes an ordinary
   candidate with a GovInfo text lane.
2. **No match → a GovInfo-only authority.** It may be analyzed and cited, on
   these terms:
   - Citation in slip-opinion form, built only from GovInfo API fields:
     `*<title>*, No. <docket_number> (<court_citation_string> <full date>)`.
     Trim `et al` from the title; change nothing else.
   - The case name links to its `details_url`.
   - Marked *(GovInfo court PDF — not in CourtListener; not citator-covered)*.
   - It cannot enter the Phase 4 screen (no opinion id). Its history check is
     `docket` (the later filings in its own docket) plus one `cites
     --negative --context 5`. The Subsequent History section says so, in the
     words report-format gives.
   - It counts toward sufficiency like any other analyzed case.
3. **Never search CourtListener for a reporter citation to dress it up.** If
   CourtListener does not return the row, there is no reporter citation in
   this report.

## 5. GovInfo quirks — G1 to G18

Tags as in the CourtListener quirk list.

G1. `[measured]` **USCOURTS has no state courts, no Supreme Court, and only
    participating federal courts.** W.D. Wash., S.D.N.Y. and C.D. Cal. are
    absent at the district level. An empty GovInfo result for an absent
    court says nothing. State opinions are never looked for here: Oregon and
    Washington have `scripts/statecourts.py`.

G2. `[measured]` **The Ninth Circuit publishes only its precedential
    opinions to GovInfo.** Memorandum dispositions (0 of 21) are
    CourtListener-lane.

G3. `[measured]` **A granule is a filing, not a case.** One docket holds
    many; orders are mixed with opinions. Identity = docket + date + name,
    then the opening text.

G4. `[verified]` **A date-matched granule can be a two-page adopting
    order** whose reasoning is in an earlier granule (`adoption_hint`). The
    reporter version prints both.

G5. `[verified]` **An amended opinion replaces the original.** For the
    Ninth Circuit, GovInfo held only the amended *Olson v. FCA* (2026-05-21),
    not the original CourtListener also indexes (2026-04-07). A date miss
    with `granule_dates` is a history lead.

G6. `[verified]` **`docketText` is free same-case history** — "VACATED
    pursuant to Court's Order", "Amended Opinion filed", "ADOPT the F&R".
    But "VACATED and REMANDED" in a circuit entry is the disposition of the
    judgment *below*, not the fate of the opinion.

G7. `[measured]` **Some PDFs are page scans with an OCR text layer**
    (`ocr_layer: true`; 6 of 25 District of Oregon opinions in one sample,
    dated 2010 to 2020, and the older U.S. Reports volumes). The
    layer misreads: `id` for `did`, `contract)` for `contract]`, `V.` for
    `v.`. **Before quoting from an OCR-layer granule, view the page** —
    `Read` the cached `pdf_path` with `pages` — and quote only words the
    page image shows. If the misread is inside the passage, pick another
    passage or trim. Never repair a quote by hand.

G8. `[verified]` **Ninth Circuit slip opinions open with a staff
    `SUMMARY`** that "constitutes no part of the opinion of the court".
    `verify` grades words found only there `not_found`; `grep` marks them
    `not_opinion_text`.

G9. `[verified; corrected after review]` **U.S. Reports cases open with the
    Reporter's `Syllabus`** and, in older volumes, counsel's argument; the
    running head names the section on each page, including `…, J.,
    concurring` and `dissenting`. Three layouts are read (a printer's stamp
    line above the head in vols. ~514–556; a two-line caption; the older
    `64   Opinion of the Court.` form). In the second review's sample of
    fifteen granules, vols. 304–570, thirteen gave a section on every page
    and two missed one page each. Where a head cannot be read the quote
    carries `section_unknown`. On a page where one section ends and the next
    begins (the last lines of the Court's opinion above "Justice Stevens …
    dissenting."), text above the opening line is assigned to the earlier
    section **only when exactly one recognizable opening line is on the
    page**; otherwise — two short opinions on one page, an OCR-mangled
    "Justi ce Bren nan" — the quote carries `section_boundary` and the page
    must be viewed. In volumes before ~1990 the first page of a granule can
    begin with the last lines of the preceding case.

G10. `[measured]` **Page numbers are slip-opinion pages** for USCOURTS and
    official pages for USREPORTS. Write `slip op. at 12` and `563 U.S. at
    344`. Never convert a slip page to a reporter page, and never present a
    slip page as a pin cite to the reporter citation.

G11. `[verified]` **Court codes differ in two places:** D.C. Circuit is
    `caDC` (case-sensitive) and the Federal Circuit `ca13`. Pass the
    CourtListener id; the script maps it.

G12. `[verified]` **`courtname:` must be the exact indexed phrase**
    ("United States District Court District of Oregon"; "Western District
    of Washington" matches only the bankruptcy court). Use `--court`; a
    hand-written name that is slightly off returns 0 silently.

G13. `[reported]` **Search does not support proximity operators**, and a
    `circuit:"District of Columbia"` filter returned HTTP 500. Use
    `--court cadc`.

G14. `[verified]` **Line-numbered pleading paper** (N.D. Cal., D. Ariz.)
    puts margin numbers 1–28 in the text layer. The script strips them from
    `read`, `grep` and `verify`; `read --raw` shows them.

G15. `[measured]` **A findings/report and recommendation is not a ruling.**
    Eight of seventeen GovInfo-found District of Oregon filings were
    magistrate judges' F&Rs (and CourtListener's own search returned one as
    a decision). Two detectors flag them: the docket text (`docket`:
    `is_recommendation`; `resolve`: `recommendation_hint`) and the
    document's own caption (`fetch`: `recommendation_in_caption`), across
    the titles districts use — Findings and Recommendation, Report and
    Recommendation, Memorandum and Recommendation, R&R. `adopting_orders`
    lists later orders that adopt *a* recommendation: match the document
    number or date the order names, and read "adopted in part" or "as
    modified" orders in full. `possible_recommendation` appears when later
    orders adopt something and this filing's docket text does not say what
    it is. Cite and date the adopting order; attribute the reasoning to the
    recommendation "as adopted"; one the docket does not show as adopted is
    not authority. CourtListener, when it has the case, usually indexes it
    under the adopting order's date.

G16. `[verified]` **One slip PDF usually holds every opinion in the case.** A
    circuit concurrence or dissent follows the majority in the same granule
    under a heading like `MILLER, Circuit Judge, concurring in part and
    concurring in the judgment:` (or the Tenth Circuit's `EID, J.,
    dissenting.`). `verify` and `grep` report it as `opinion_part` and
    raise `separate_opinion`. The second review surveyed 78 circuit granules
    with separate opinions: 73 headings were detected and the five misses
    were two styles since added. **The detector is a backstop, not a
    guarantee** — the analyzer reads the whole document and is responsible
    for attribution. In the **Second Circuit** a concurrence or dissent can
    be a separate same-date granule (`ambiguous: true`): read each one's
    opening.

G17. `[verified]` **The text layer breaks words across lines.** Extraction
    shows `liti- gating`; matching ignores the break; output fields close
    it up and count it (`joined_line_breaks`). A real hyphenated compound
    broken at its hyphen comes out unhyphenated. Check the page before
    publishing script output verbatim; a quote the analyzer typed and
    `verify` accepted is unaffected.

G18. `[verified]` **Footnotes sit at the foot of each page in the text
    layer.** The script lifts them into a separate stream by their running
    numbers (17 found in one District of Oregon opinion, 47 in a Third
    Circuit one). A footnote that *continues* onto the next page has no
    number there and stays in the body; symbol footnotes (`*`, `†`) are not
    detected. Hence `page_break`.

## 6. What GovInfo changes in the budget

| | v9.6 | v10.0, federal-heavy question | v10.0, state-court question |
|---|---|---|---|
| Searches | 8–16 units | 8–16, plus unlimited GovInfo searches | 8–16 |
| History screen | 1–5 (booked as 1) | 1–5 | 1–5 |
| Reading 12–18 cases | 12–18 | **CourtListener-lane cases only** — often 2–6 | 10–16 (federal cases applying state law are free) |
| Quote verification | 0 (cached) | 0 | 0 |
| Typical run | ≈ 32–40 | ≈ 15–25 | ≈ 28–38 |

The saving is exactly the number of analyzed cases on the GovInfo lane.
Report it in the About table; never estimate it. `[2026-10-05]` For an
Oregon- or Washington-law question the state lanes add to it: Oregon
appellate opinions since 1998 and Washington slip opinions since 2013 are
read for zero units too (`state-sources.md` § 8), so the third column's
"10–16" falls to the CourtListener-lane remainder — typically the pre-1998
Oregon and pre-2013 Washington authorities.

## 7. GovInfo-only mode — offered, never assumed

When `get_api_usage` shows the daily pool below the spine, the run still
prints the `DAY` line and stops, as in v9.6. **Add one sentence offering a
GovInfo-only run** if the question is federal: federal courts in § 1 only,
slip-opinion citations only (official `U.S.` citations for Supreme Court
cases through vol. 586), no CourtListener citator screen, no state courts.
Run it only if the user says yes, and open that report with:

`> ⚠️ **GovInfo-only run** — the CourtListener daily pool was exhausted.
Federal slip opinions only; no reporter citations; no citator screen; state
courts not searched. Re-run after <reset_at>Z for full coverage.`
