# Report Format

Order is fixed; **empty sections drop out and numbering stays contiguous.**

## Fixed opening (always, in this order)

1. Notice line, always first, exactly:

   > *AI-generated legal research (CourtListener database; federal opinion
   > text from GovInfo where marked). Not reviewed by an attorney — verify
   > every citation and holding against the full opinion before relying on
   > it.*

   Drop the parenthetical's second clause when no analyzed case was on the
   GovInfo lane. `[v10.0]` When any analyzed case was on a state lane, the
   parenthetical names it too, in the same clause form: `; Oregon opinion
   text from the Oregon Judicial Department's official reports where
   marked` and/or `; Washington opinion text from the courts' slip opinions
   where marked`. A GovInfo-only run (`govinfo.md` § 7) replaces the
   parenthetical with `(GovInfo federal opinions only)` and carries its
   banner.

2. Optional banners (only when set):
   - Partial results: `> ⚠️ **Partial results** — some searches failed
     (CourtListener API degradation); coverage may be incomplete.`
   - Budget-limited: `> ⚠️ **Coverage note** — the CourtListener hourly call
     limit was reached; some planned searches were not run.`
   - GovInfo unavailable (only when federal courts were in scope): `> ℹ️
     **Source note** — GovInfo was unreachable this run; federal opinions
     were read through CourtListener.`
   - A state source unavailable (only when that state's courts were in
     scope): `> ℹ️ **Source note** — the <Oregon Judicial Department
     collection | Washington Courts opinion listing> was unreachable this
     run; <Oregon | Washington> opinions were read through CourtListener.`
   - Research exhausted: `> ⚠️ **Depth note** — refinement stopped
     (<reason>) before the sufficiency target was met. Treat this as a
     starting point, not exhaustive coverage.`

3. `# <headline>` — the primary legal question as interpreted in Phase 1,
   trailing `?`/`.` stripped, ≤110 chars; fallback: the original query
   truncated to 110 chars + `…`.

4. The original query in italics on its own line (omit if identical to the
   headline).

5. Read-as line:
   `Read as: **<query_type>** question · jurisdiction **<jurisdiction>** ·
   complexity **<estimated_complexity>**` (append ` · dates <after>–<before>`
   only if a date range was parsed; omit any element not parsed).

6. **Data Sources** — the banner's `Data Sources:` lines (only those lines),
   reproduced verbatim inside a fenced code block so they stay monospace.
   They were already printed in the console banner before the first search;
   they appear here again so the report is self-contained. **Late additions are appended and marked, never
   back-edited.** A source family that becomes relevant only after Phase 1 —
   an analyzer surfaces a statute nobody anticipated — is appended to *this*
   block with a `[+]` mark and the date it was probed:

   ```
     Delaware Code via delcode.delaware.gov ....  probed in run 2026-09-06 [+]
   ```

   The printed banner is never retro-edited: it is a record of what was known
   before the first search. Without this rule the choice is between an
   inaccurate Data Sources block and a bent "verbatim" requirement, and the
   v9.2 run took the second.

## Numbered sections

### N. Short Answer

About three paragraphs of prose directly answering the question. Every
sentence must be supported by a specific analyzed case or resolved statute;
weave full Bluebook citations inline with the case name linked to
CourtListener: `[*Smith v. Jones*](https://www.courtlistener.com<absolute_url>),
500 F.3d 123, 130 (9th Cir. 2020)`. Statutes cited by their citation string
(linked to the resolved official URL). End with a short limitations sentence
if material (e.g., split of authority, thin coverage, an unresolved question
the case law has not reached).

Where a distinction materially changes how a practitioner would use the
authority — for example, a famous passage that is a statutory holding rather
than a constitutional one — lead with that distinction rather than burying it.

### N. Rules & Statutes

Only if provisions resolved. One line each:
`**[RCW 4.16.080](<official url>)** — <one-sentence gist>. > "<short quote
from the FETCHED text only>"` (quote optional; link-only families get no
quote). U.S.C. text taken from GovInfo's annual edition names the edition:
`*(text: United States Code, 2024 Edition, via GovInfo)*`.

A provision may be **quoted** only if two independent fetches agreed on its
text (see `references/statute-sources.md`). A provision resolved by a single
fetch may be cited and linked, but not quoted. An official page and a
Public.Law page agreeing is the strongest form of that check.

**Text taken from Public.Law (tier 2) must say so, inline.** Append the source
and its stated currency date to the provision line:

`**[ORS 527.770](<official chapter url>)** — <gist>. > "<quote>" *(text via
[Public.Law](<public.law url>) — the official chapter page truncates before
this section; Public.Law currency: through early 2026)*`

Link the official page where one exists, since that is the authority; the
Public.Law link is the retrieval receipt. For the six state collections that
have no tier-1 entry (CA, CO, FL, NV, NY, TX), Public.Law *is* the source —
link it directly and give its currency date.

Unresolved provisions the user explicitly named go at the end, and **the
reason must distinguish the two cases**:

- `ORS 527.770 — could not be resolved from official sources.` (no
  allowlisted URL pattern, or the fetch failed outright)
- `ORS 527.770 — the official chapter page truncates before this section; text
  not retrieved. [link]` (the page loaded but the body text was absent)

The second phrasing matters: it tells the reader the statute exists and where
to look, rather than implying it could not be found at all. Never let a
truncation read as an absence.

### N. Leading Authorities

The top analyzed cases by `relevance_ranking` (max 10), after any Guard-2
re-scoring — **with up to two slots reserved for the best-scored authority on
the other side of the question**, whatever its number. A
strict top-10 by score once filled every slot with unenforceability holdings
and pushed the two current enforcement-side circuit decisions (and the
leading assent case) into Also Reviewed; a reader skimming Leading
Authorities would have seen a one-sided line that the Short Answer itself
described as split. When the question has sides, the section must show both.
Mark the reserved entries *(contrary authority)* after the relevance score so
the ordering is not mistaken for a scoring error. Per case:

```
**1. [*Case Name*](https://www.courtlistener.com<absolute_url>)**, <citation
without case name> (<court> <year>) — relevance <relevance_ranking>/5

<holding + relevance_summary, one tight paragraph>

*Facts:* <factual_background — include this line only for fact/mixed
query types>

> "<verified quote>" ✓ verified
> *(quote label: ✓ verified | ≈ close match | ⚠ unverified)*
> *(GovInfo-lane quotes add the page and the source: `✓ verified · slip op.
> at 12 · [court PDF](<link>)` or `✓ verified · 563 U.S. at 344 ·
> [U.S. Reports](<link>)` — `<link>` is the `pdf_url` that `resolve-batch`
> or `docket` returned, else the granule's `details_url`)*
> *(state-lane quotes likewise: `✓ verified · 326 Or. App. at 118 ·
> [Oregon Reports page](<public_url>)` for Oregon — an official page, so it
> may also be the pin in the citation; `✓ verified (slip opinion) · slip op.
> at 5 · [court PDF](<pdf_url>)` for Washington, with `; official report may
> differ in wording` added inside the parenthesis when the row carried
> `superseded_note`)*

*Treatment:* <treatment_of_other_cases / subsequent-history one-liner, if any>
```

Quote verification labels map from the Phase 7 states: `verified` → ✓
verified, `likely` → ≈ close match, `not_found` → ⚠ unverified (or the quote
is dropped). `[v10.0]` **GovInfo-lane quotes are published only as ✓
verified**, with the page `govinfo.py verify` returned: a `likely` quote
was replaced by the opinion's own words and re-verified, or dropped, before
this point, and a `not_found` one is never shown. The page is a
**slip-opinion page** — write `slip op. at N`, never append it to the
reporter citation as a pin cite. `[v10.0]` **State-lane quotes follow the
same rule — ✓ verified only.** An Oregon page from the verifier is an
*official* Oregon Reports page and may be used as a pin; a Washington page
is a slip page and may not. An Oregon **nonprecedential memorandum
opinion**, a Washington **unpublished** or **published-in-part** opinion and
a New York **unreported (U)** disposition each carry that label in italics
after the citation every time they are cited — *(nonprecedential memorandum
opinion)*, *(unpublished)*, *(published in part)*, *(unreported
disposition)* — whichever lane they were read in, and are never the sole
support for a sentence in the Short Answer without saying so. A quote from
the unpublished portion of a part-published Washington opinion adds
*(unpublished portion)* to its label. A quote from a lead or plurality
opinion says so and gives the count — *(lead opinion of Whitener, J.,
joined by two justices)* — and the holding line gives the **court's**
disposition, not that opinion's. A quote from a U.S. Reports page whose
running head is a concurrence or dissent says so: *(Thomas, J.,
concurring)*; so does one from a separate opinion inside a circuit slip
PDF: *(Miller, J., concurring in part)*. A quote from a magistrate judge's
findings adopted by the district judge says so: *(F&R of Jelderks, M.J.,
adopted)*. **No quote reaches the report with an unsettled `cautions`
entry** (pipeline Phase 7D). On the GovInfo and state lanes a quote never
carries an ellipsis of the quoter's — one that omits words of the opinion
does not verify; an ellipsis shown is the opinion's own. Where a quote is the court quoting a third source (a treatise,
another opinion), say so in an italic parenthetical after the label — the
attribution matters to anyone who reuses the quote.

The citation after the linked name is `bluebook_citation` with any leading
`Case Name,` prefix stripped (the name is already rendered). If the API
provided no reporter citation but did provide a docket number, use the
slip-opinion form — `No. <docket_number> (<court abbrev.> <full date>)` —
built entirely from API fields; otherwise show the linked name + court/year
only. Mark RECAP-sourced authorities (no `cluster_id`) with *(PACER order —
not citator-covered)* after the citation. `[v10.0]` Mark a **GovInfo-only
authority** — found by GovInfo search, no same-date CourtListener row — with
*(GovInfo court PDF — not in CourtListener; not citator-covered)*; its name
links to the GovInfo `details_url` and its citation is the slip form built
from GovInfo fields. Never give it a reporter citation.

The analyzer's `dicta` and `treatment_of_other_cases` fields are working
material for the Short Answer prose and the *Treatment:* line — they are not
rendered as separate report elements.

### N. Subsequent History

Rendered if any case was flagged, **or** if a flag candidate was run down and
cleared. A same-name or higher-court citer that the screen
surfaced and the orchestrator chased to a conclusion is worth reporting even
when the conclusion is "not negative treatment" — it tells the reader work was
done that would otherwise be invisible, and it distinguishes a checked-clean
case from an unchecked one. Render a cleared candidate as:

`> **<Case Name>** — checked, **not** negative treatment (<confidence>):
<what the citer actually did>. *Source:* <citing case, court, date>.`

Do not render the section merely to say nothing was found; a run with no flags
and no chased candidates omits it, as before.

For flagged cases: Per flagged case, a callout:
`> **<Case Name>** — <precedential_status> (<confidence> confidence):
<detail> *Flagged by:* <reversing_case name, court, date>.`

`[v10.0]` For Oregon the source is `statecourts.py or-history`; name the
record it came from — *Source: Oregon Supreme Court, Petitions for review,
November 17, 2023, 371 Or 535 (Oregon Judicial Department collection)* — and
give the list entry's disposition heading and date, nothing inferred. A
disposition found (review denied, allowed, dismissed) is rendered in this
section even when it is the only entry. Where the check returned nothing,
the sentence *no review disposition located in the Oregon Supreme Court's
published lists through <newest_list_in_collection>* goes in that case's
*Treatment:* line in Leading Authorities — not here; this section is still
not rendered merely to say nothing was found. Where the check was
incomplete, the *Treatment:* line says *review history not checked:
<what>*. A
Supreme Court opinion on review is rendered as an ordinary flag
(`reversed` / `affirmed` / `vacated`) with the Supreme Court's citation.

Where a state-court review disposition was found outside CourtListener, use:
`> **<Case Name>** — <disposition> (<confidence> confidence): <detail>
*Source:* <official state judiciary source> — **CourtListener does not index
state supreme court review dispositions**, so a clean citator result here is
not evidence that review was never sought.`

Close the section with: *Cases not listed here were checked but not flagged;
that is not a certification of good law.* If any leading authority is a
RECAP/PACER document (not citator-covered), add: *PACER orders cannot be
checked for subsequent history via the citator.* If any is a GovInfo-only
authority, add: *Decisions marked "GovInfo court PDF" are not in the
CourtListener citator; their history check was limited to later filings in
the same docket and a search of federal opinions in GovInfo.* A lead from
`govinfo.py cites` or from a docket's later granules is rendered like any
other flag or cleared candidate, with *Source:* naming the GovInfo granule;
"no negative federal citer found in GovInfo" is never rendered as a
clearance. If any is an Oregon-collection-only authority, add: *Decisions
marked "Oregon Judicial Department collection" are not in the CourtListener
citator; their history check was limited to the Oregon Supreme Court's
review lists and opinions.*

### N. Also Reviewed

Only if analyzed cases remain beyond Leading Authorities. One line each:
`*Case Name*, <citation> — <relevance_ranking>/5, <one-clause reason>.`

If a refinement round surfaced cases that were scored but not read in full,
they may be listed at the end of this section under an explicit label —
*Surfaced but not read in full* — with links. Never imply they were analyzed.

### N. About this Research

A markdown table:

| | |
|---|---|
| **Rounds** | <n> of max 4 — <round 2+ run because: results were short of the target / breadth was asked for / the first round's cases opened <k> lead(s)> — stopped: <stop reason / "initial results were sufficient; no open leads"> |
| **Leads** | <f> fruitful lead(s) from the cases read — <w> followed (<one clause each: what was searched and what it produced>) · <u> not followed: <each named, with the reason — budget / round cap> <; or: "none open"> · premise checked: <the mechanism the question assumed, and what the search for it found / "not applicable"> <; omit the row on a `quick` run> |
| **Semantic** | <n> semantic queries: <court, window, rows on point / 20 — one item each> · unique finds: <cases only a semantic query surfaced, or "none"> |
| **Searches** | <total> metered CourtListener calls this run (closing `get_api_usage` minus opening) — <s> searches, <f> first document fetches, <c> free cached re-reads; <r> requests rejected by rate limits |
| **Text sources** | <g> of <analyzed> analyzed opinions read from GovInfo court PDFs (0 CourtListener units; <o> from OCR-layer scans, page images viewed) · <so> from the Oregon Judicial Department's official reports · <sw> from Washington Courts slip opinions (<ws> marked superseded by the official report) · <c> read through CourtListener · <x> GovInfo-only and <xo> Oregon-collection-only authorities (not in CourtListener) · GovInfo searches run: <n> · Oregon collection searches run: <m> · citations taken from the Oregon catalogue or a New York Law Reporting Bureau page rather than CourtListener: <list, or "none"> |
| **Pool at close** | hourly <used> of 50 (reopens <reset_at>Z) · daily <used> of 125 (reopens <reset_at>Z) — read from `get_api_usage`, not computed <; or: "daily cap reached at call <n>"> |
| **Cases** | <screened> unique candidates screened (<rows> candidate rows, <dupes> duplicates) · <analyzed> analyzed in depth · <recalled> of the analyzed set entered via orchestrator-recalled citations, <found> via search discovery |
| **Quotes** | <v> of <t> verified verbatim · <l> close matches · <nf> not found |
| **History** | reversal/overruling check on <n> analyzed cases — <f> flag(s)<, plus state review dispositions checked for <s> decision(s) (Oregon: every Court of Appeals leading authority, by script; other states: decisions under ~3 years old)> |
| **Rules** | <comma-separated resolved citations / "none cited in this query"> — <q> quoted with two-fetch agreement, <u> unresolved (page truncated) |
| **Agents** | <total subagents dispatched> across <waves> parallel waves |

**Every number in this table is computed, not recalled.**
`screened` is the cardinality of the deduped candidate union; the call figures
are the difference between the closing and opening `get_api_usage` readings
(the search/fetch split from the orchestrator's own dispatch record);
`recalled` vs `found` comes from which authorities entered through the
Phase 4 batch; the **Text sources** figures come from the Phase 4 lane table
and the analyzers' `text_source` fields (omit the row when every lane but
CourtListener was off and say so in the Searches row; omit any clause whose
count is zero). In the 2026-09-06 run a screened-candidate figure was carried
over from the *previous* run's report and published in both the chat report
and the Word memo before anyone recomputed it. A narrated number is a defect
waiting to happen and is invisible to the reader.

The **Pool at close** row exists so that a reader deciding whether to start
a second run today has the live figures and the reopen times in front of
them. Since v9.6 they come from `get_api_usage` (briefing quirk 37), which is
free; never estimate them.

Footer line, small: `Generated <YYYY-MM-DD> · deep-legal-research skill
(Claude + CourtListener + GovInfo)` — drop `+ GovInfo` when no analyzed
case and no search used it; append `+ Oregon Judicial Department` when a
case was read, a search run or a review history checked there, and
`+ Washington Courts` when a case was read on that lane.

## Rules

- Never renumber-skip: if Rules & Statutes is empty, Leading Authorities
  becomes section 2.
- Bluebook format throughout: *Case Name*, Vol Reporter Page (Court Year).
  For state cases, official state reporter first with the regional parallel
  cite, both copied verbatim from the API `citation` array.
- Every case-name mention links to its CourtListener `absolute_url`; a
  GovInfo-only authority links to its GovInfo `details_url`. A GovInfo-lane
  case that CourtListener also holds keeps the CourtListener link on its
  name and carries the court-PDF link on its quotes.
- An Oregon state-lane case links its name to CourtListener's
  `absolute_url` and its quotes to the collection's `public_url`; an
  Oregon-collection-only authority links its name to `public_url`.
- A slip-opinion page is never written as a reporter pin cite. The pin page
  in the Short Answer example above (`500 F.3d 123, 130`) is available only
  for a CourtListener-lane case whose text carries star pagination; a
  GovInfo-lane case is cited without a pin, and the page travels with the
  quote (`slip op. at 12`). An Oregon state-lane case **can** be cited with
  a pin — the verifier's `official_page` — because its text is the official
  reporter's page; a Washington state-lane case cannot.
- No invented citations, no unverified quotes without the ⚠ label.

## After the report: the companion memo

Rendering this report in chat is not the end of Phase 8. Immediately after,
build and deliver the Word memo per `references/memo-format.md` — without
waiting for the user to ask. The memo re-presents this report's verified
content only.
