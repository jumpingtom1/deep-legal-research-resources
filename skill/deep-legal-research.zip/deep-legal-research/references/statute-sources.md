# Statute, Rule & Court-History Sources (hard allowlist)

Every statute/rule URL must match a pattern below, constructed from the parsed
citation. **Never guess a URL. Never quote statute text from memory.** A
citation that doesn't parse into a pattern is reported as unresolved. Cap: 12
provisions per session, deduped case-insensitively (strip subsection suffixes
before deduping).

**Every row in this file has a verification record in
`references/source-status.md`.** That file — not this one — is what the
console banner reads, and the release checklist in `CHANGELOG.md` re-probes
every row of it before any version ships. When you change a pattern here,
update its row there in the same edit.

**Three tiers of source, in strict order.**

- **Tier 0 — bundled corpora.** Complete offline copies shipped with this
  skill, queried with `scripts/or_lookup.py`. Use these FIRST where they exist
  (currently ORCP and UTCR): they are complete, exact, and cost no network
  call. They are frozen at their capture date, which the tool prints on every
  result and which the report must state.
- **Tier 1 — official government publisher**, listed in the table below. Use
  where no bundled corpus exists. Always the citation target and link.
- **Tier 2 — Public.Law**, only for the collections verified in the
  § "Public.Law (tier 2)" table, and only when tiers 0 and 1 fail. Text from
  tier 2 **must be labelled as such in the report**.

No other aggregator is permitted for any purpose.

## Tier 0 — bundled Oregon corpora

```
scripts/or_lookup.py --list             # what is bundled, and how stale
scripts/or_lookup.py "ORCP 47"          # one rule
scripts/or_lookup.py "ORCP 47 C"        # one subdivision
scripts/or_lookup.py "UTCR 5.100"
scripts/or_lookup.py --search "ex parte" --corpus utcr
```

**Never `Read` the files in `references/or-corpus/`.** They hold ~800k
characters; reading one would consume more context than the entire rest of a
research run. The script reads them and returns a single provision.

The tool prints a capture-date banner on every result and flags a corpus
**STALE** after 365 days and **EXPIRED** after 730 (Oregon rules are amended on
a biennial cycle). On EXPIRED, do not quote as current — re-ingest with
`scripts/or_corpus_build.py`, or verify against tier 1/2 and say in the report
that you did. `references/or-corpus/MANIFEST.md` is regenerated on every
ingest, so it cannot drift from what is actually bundled.

A citation that is absent from a bundled corpus returns `NOT FOUND` with
nearby provisions listed — that is a real answer. Do not reconstruct a rule
from its number or title.

All fetches here use `WebFetch` and cost **zero CourtListener budget** — so
never trade one of these away to save time.

## Statutes and rules

| Family | Citation example | URL pattern | Text? |
|---|---|---|---|
| RCW | `RCW 4.16.080` | `https://app.leg.wa.gov/rcw/default.aspx?cite=4.16.080` | fetch & quote |
| WA court rules (CR, CrR, RAP, ER, GR, RPC) | `CR 56` | `https://www.courts.wa.gov/court_rules/?fa=court_rules.display&group=sup&set=CR&ruleid=supcr56` — group by set: CR/CrR→`sup`, RAP→`app`, ER/GR/RPC→`ga`; `ruleid` = group + set lowercased + rule number | link-only (PDF) |
| ORS | `ORS 12.110` | `https://www.oregonlegislature.gov/bills_laws/ors/ors012.html` (chapter zero-padded to 3 digits + optional letter, e.g. `ors646a.html`) | **fetch via the long-page protocol below — these pages truncate** |
| ORS, archived edition (1953–1997) | `ORS 59.115 (1987 ed.)` | `https://archives.oregonlegislature.gov/ORS_Archives/<YEAR>-Chapter-<NNN>.PDF` — chapter zero-padded to 3 digits, extension upper-case `.PDF`. `[added v9.5]` Odd years; 1985/1987/1989/1991/1993 ch. 59 all verified 2026-09-15 | fetch & quote via § "Archived ORS editions" below |
| ORS, archived edition (1999–2023) | `ORS 59.115 (2001 ed.)` | `https://www.oregonlegislature.gov/bills_laws/Archive/<YEAR>ors<NNN>.pdf` — chapter zero-padded to 3 digits (`archive/` lower-case also serves). `[added v9.5]` Odd years; 1999/2001 ch. 59 verified 2026-09-15; `1997ors059.pdf` is a 404 — 1997 belongs to the other library | fetch & quote via § "Archived ORS editions" below |
| ORCP | `ORCP 47` | **TIER 0 — use `scripts/or_lookup.py "ORCP 47"`.** Official page `https://www.oregonlegislature.gov/bills_laws/SiteAssets/ORCP.html` truncates mid-Rule 9 of 85 and is usable only for Rule 8 and below | bundled: all 79 rules |
| OAR | `OAR 137-050-0710` | `https://secure.sos.state.or.us/oard/view.action?ruleNumber=137-050-0710` — **INTERMITTENT.** FAIL 2026-09-05 (robots.txt, twice), OK 2026-09-06, OK 2026-09-07 (confirmed on two independent URLs on the host, so not a cache artifact). Try tier 1 first every time; fall back to the Public.Law OAR pattern below, disclosed as tier 2, only on an actual failure | fetch & quote (tier 1 first, tier 2 on failure) |
| UTCR | `UTCR 5.100` | **TIER 0 — use `scripts/or_lookup.py "UTCR 5.100"`.** Official index: `https://www.courts.oregon.gov/programs/utcr/pages/currentrules.aspx` | bundled: all 242 rules |
| ORAP | `ORAP 5.45` | link `https://www.courts.oregon.gov/courts/appellate/rules/pages/orap.aspx` — reachable, and names "Current" and "Previous" ORAP, but `[probed 2026-09-07]` it states **no edition date** and the rule documents are injected client-side, so **no ORAP text and no ORAP PDF is retrievable via WebFetch** | link-only — and no edition date may be stated in a report |
| U.S.C. | `15 U.S.C. § 1692k` | Official (OLRC): `https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title15-section1692k&num=0&edition=prelim` (pattern `granuleid:USC-prelim-title{T}-section{S}`; verified 2026-08-08 against § 1404 — text and source credit matched Cornell exactly). Cornell mirror: `https://www.law.cornell.edu/uscode/text/15/1692k` | fetch & quote — **use BOTH for the two-fetch check** (see note below) |
| U.S.C. via GovInfo (GPO annual edition; any edition year 1994–2024) | `15 U.S.C. § 1692k` · `15 U.S.C. § 1692k (2008 ed.)` | `python3 scripts/govinfo.py usc --title 15 --section 1692k [--year 2008]` — resolves GovInfo's link service (`https://www.govinfo.gov/link/uscode/{T}/{S}?type=usc&year={Y\|mostrecent}&link-type=html`) to the section page `…/content/pkg/USCODE-<YEAR>-title<T>/html/…-sec<S>.htm` and returns the section's text, extracted by the script (no summarizing model). `[added v10.0; verified 2026-10-03]` `mostrecent` = **2024 Edition** on that date; 1994, 2000, 2008 and 2024 editions of the probe sections served; 1993 and 2025 return HTTP 400 | fetch & quote — **counts as one of the two sources**; the other is OLRC or Cornell. See § "U.S.C. via GovInfo" below |
| Federal rules | `Fed. R. Civ. P. 12` | `https://www.law.cornell.edu/rules/frcp/rule_12` — keys: FRCP→`frcp`, FRE→`fre`, FRAP→`frap`, Fed. R. Crim. P.→`frcrmp` | fetch & quote |
| Delaware Code | `6 Del. C. § 18-101` | Chapter index `https://delcode.delaware.gov/title6/c018/index.html` is **navigation only** (verified 2026-09-05 — no section text on it); fetch it, follow its subchapter link (e.g. `…/c018/sc01/index.html`, which holds § 18-101), then fetch that page. Hyphenated section `18-101` → chapter 18; a non-hyphenated section resolves only with an explicit `ch. N` in the citation | fetch & quote **from the subchapter page** |

## Public.Law (tier 2) — verified coverage only

Public.Law publishes per-section pages, which sidesteps the chapter-page
truncation described below entirely. It is permitted **only** for the
collections verified here, **only** after the tier-1 official source has been
tried, and **only** with disclosure in the report.

### Constructible patterns — verified, use directly

| Collection | Per-section URL pattern | Verified |
|---|---|---|
| ORS | `https://oregon.public.law/statutes/ors_527.770` — `ors_` + section number | 2026-07-29 ✓ |
| OAR | `https://oregon.public.law/rules/oar_137-050-0710` — `oar_` + rule number | 2026-07-29 ✓ |

### Index-anchored collections — navigate, never construct

For everything below, the per-section URL is **not** derivable from the
citation: slugs embed code names and rule titles, and the hierarchy runs
several levels deep. The index URLs are verified; the section URLs are not.
**Fetch the index, follow the real link down to the section, then fetch that.**
Constructing one of these yourself is guessing a URL, which this file forbids.

| Collection | Verified index | Intermediate form observed |
|---|---|---|
| ORCP | `https://oregon.public.law/rules-of-civil-procedure/` | `.../orcp-47-summary-judgment/` ✓ verified |
| California Codes | `https://california.public.law/codes` | `/codes/civil_code` |
| Colorado C.R.S. | `https://colorado.public.law/statutes` | `/statutes/crs_title_18` |
| Florida Statutes | `https://florida.public.law/statutes` | `/statutes/fla._stat._title_i` |
| Nevada NRS | `https://nevada.public.law/statutes` | `/statutes/nrs_chapter_11` |
| New York Laws | `https://newyork.public.law/laws` | `/laws/n.y._business_corporation_law` |
| Texas Statutes | `https://texas.public.law/statutes` | `/statutes/tex._agric._code` |
| Rome Statute | `https://www.public.law/world/rome_statute` | — |
| International Dictionary | `https://www.public.law/dictionary` | — |

The last two are outside this skill's usual US case-law scope; they are
permitted but rarely relevant.

**None of the six state collections above has a tier-1 entry in this file.**
They extend the skill's reach into new jurisdictions rather than backstopping
an existing official source — so for those, Public.Law *is* the source, and the
report must say so. If you need an official tier-1 source for one of these
states, find and verify it, then add a row to the main table above.

**ORCP currency caution:** the ORCP 47 page reported a last-modified date of
2018. Treat Public.Law's ORCP as potentially stale, state the date it reports,
and prefer the official page only for **Rule 8 and below**, which is all it
fully reaches — its body text stops partway through Rule 9.

**What Public.Law does NOT cover.** Verified absent as of 2026-07-29 — do not
attempt these, and do not assume a `<state>.public.law` host exists just
because the pattern looks regular:

- **Washington (RCW)** — `washington.public.law` does not resolve at all (DNS
  failure, not a 404).
- **U.S.C.**, **federal rules** (FRCP/FRE/FRAP/FRCrmP), **Delaware Code**,
  **WA court rules**, **UTCR**, **ORAP** — not published.

For those families the tier-1 source is already per-section (RCW via
app.leg.wa.gov, U.S.C. and federal rules via Cornell), so the truncation
problem does not arise and no fallback is needed. The six Public.Law state
collections in the index-anchored table above (California, Colorado, Florida,
Nevada, New York, Texas) **are** permitted — as tier 2 only, index-navigated,
and disclosed with their currency date; they have no tier-1 entry, so for
them Public.Law *is* the source. A state that appears nowhere in this file
(Idaho, Arizona, …) has **no approved statutory source at all**: the Phase 1
"Data Sources" lines of the console banner must say so, and the report cites
such sections by number only. Adding a state requires verifying its pattern first
and recording the date here.

**Currency is not assumed.** Every Public.Law page states a currency date.
Report it. If it is materially older than the current edition, say so next to
the quote rather than presenting the text as current.

## Long-page truncation — the ORS/ORCP failure mode

**Oregon publishes statutes as whole-chapter pages, and `WebFetch` silently
truncates them.** The fetched markdown ends with `[Content truncated due to
length...]`. Critically, the **table of contents at the top survives**, so
section numbers and headings for the *entire* chapter remain visible while the
body text of later sections is simply gone.

That combination is what makes this dangerous. A naive "quote ORS 527.770"
prompt sees the heading in the surviving ToC, has no sanctioned way to report
absence, and **invents statutory text** — in testing, complete with a
fabricated bracketed source-law citation. It does not error. It does not warn.

Measured boundaries (2026-07-29, `WebFetch`; re-measure if these look wrong,
they will drift as chapters grow):

| Page | Body text ends at | Consequence |
|---|---|---|
| `ors012.html` | complete | ORS 12.080 retrievable |
| `ors030.html` | ~ORS 30.275 (mid-citation) | 30.300 and everything above is **unreachable**; 30.265 and 30.275 are fine |
| `ors527.html` | ~ORS 527.710 | 527.755, 527.765, 527.770, 527.990 **unreachable** |
| `ORCP.html` | **mid-Rule 9** (of 85) | Rules 9–85 **unreachable**, incl. 21, 36–46, 47, 68 — ~90% of the document |

Chapter PDFs are **not** a workaround — the archived chapter PDF
(`.../Archive/2017ors527.pdf`) truncated at ORS 527.755. There is no
per-section official URL for ORS.

### Mandatory retrieval protocol for ORS, ORCP, and any chapter-level page

1. **One provision per fetch.** Never ask for two sections in a single prompt.
   Batching is what produced the fabricated ORS 30.300 text *and* its fake
   citation bracket; the same section requested alone, with an escape hatch,
   correctly returned "not present."
2. **Use this prompt shape**, which leads with the warning, demands
   proof-of-body, and supplies an exact escape string:

   > CRITICAL: do not infer or reconstruct text from a heading. This page may
   > be truncated, and its table of contents lists sections whose body text is
   > absent. For `<CITE>` ONLY, reproduce (a) the heading, (b) the complete
   > body text, and (c) the bracketed source-law citation history that closes
   > the section, e.g. `[1991 c.919 §21; 2003 c.749 §12]`. The bracket appears
   > ONLY in body text, never in the table of contents. If you cannot actually
   > see (c), answer exactly: "NOT PRESENT — table-of-contents entry only",
   > and supply nothing for (b).

3. **The bracket is proof-of-body, not proof-of-truth.** It can itself be
   fabricated. So: **any statute text that will be quoted in the report must be
   fetched twice**, with differently worded prompts, and the bracketed citation
   history must match *exactly* across both. A mismatch means unresolved.
   These are `WebFetch` calls and cost zero CourtListener budget — there is no
   reason to skip this.
4. **On "NOT PRESENT", the provision is unresolved.** Link the chapter page,
   state that the official page truncates before that section, and **quote
   nothing**. Do not substitute an aggregator; do not reconstruct from the
   heading; do not quote from memory. "Could not be retrieved from the official
   source" is a correct and publishable result.

### Rules for statutes

- **Fetch early, and fetch both times at once.** WebFetch has its own session
  quota, independent of CourtListener; in the 2026-09-05 run it ran out
  before the second confirming fetches, leaving two provisions cite-only. Do
  both fetches of every provision early — Phase 2 or 3 — or in the first rate-limit
  cooldown, never in the finishing wave. For RCW, alternate the URL casing
  (`/rcw/default.aspx` and `/RCW/default.aspx`) so the second fetch is not
  the 15-minute cache serving the first.
- Extract only the cited section/rule from multi-section pages; quote at most
  a short, directly relevant passage.
- Link-only families: render the official link with a one-line description;
  quote nothing.
- Fetch failure after one retry → provision treated as unresolved (naming the
  attempted official source), never substituted from another site. In the
  report, only provisions the user explicitly named are surfaced as
  unresolved; unresolved opinion-cited provisions are simply omitted.
- **A truncated page is a fetch failure, not an absent statute.** If the
  protocol above returns "NOT PRESENT", the provision is unresolved *because
  the official page was cut off* — say that, rather than implying the section
  does not exist or that its text is unknown. The distinction matters to a
  reader deciding whether to look it up themselves.
- **Never report a provision as quoted-and-verified unless two independent
  fetches agreed.** One fetch is enough to *locate* a provision; two are
  required to *quote* it.
- **Make the two fetches genuinely independent.** `WebFetch` caches a URL for
  ~15 minutes, so two prompts against the SAME URL within that window read
  the same cached page — that validates extraction, not retrieval. Where the
  family has two or more allowlisted sources (U.S.C.: OLRC, Cornell, and —
  since v10.0 — GovInfo's annual edition through `scripts/govinfo.py usc`),
  fetch from two of them and require the text and source-credit/bracket
  history to match.
  Where only one source exists, the same-URL double-fetch is still required
  (it catches extraction fabrication — see the v5 evidence) but note that it
  cannot catch a corrupted page.
- **`[added v9.3]` Opinion corroboration is a permitted second source for
  single-source families.** Some collections have a tier-1 source and no
  permitted tier-2 at all — the Delaware Code, the federal rules, ORAP. For
  those, the second confirmation may be **the same statutory language quoted
  verbatim inside an opinion you fetched this session and verified against
  that opinion's text**. A court reproducing the provision is genuinely
  independent of the publisher's page, which is the property the two-fetch
  rule is actually after. Disclose it on the provision line, e.g. *(text
  confirmed against the official page and against the same language quoted in
  Smith v. Jones, 361 F. Supp. 2d 237, 247)*. Two constraints: the opinion
  must have been read this session, not recalled; and quote only the run of
  text that appears in both. Without this rule the fallback gets invented
  mid-run, which is what happened to 5 Del. C. § 952(a) on 2026-09-06.
- Statutes are cited by their citation string linked to the resolved URL —
  they never get `[C1]`-style case treatment.

## Archived ORS editions — historical statute text `[added v9.5]`

A statutory-history question ("what year did ORS 59.115 first say …?") is
answered from official archived editions. Two libraries, two patterns, both
tier 1:

```
1953–1997  https://archives.oregonlegislature.gov/ORS_Archives/<YEAR>-Chapter-<NNN>.PDF
1999–2023  https://www.oregonlegislature.gov/bills_laws/Archive/<YEAR>ors<NNN>.pdf
```

**How this was found, so nobody re-burns the time.** The Legislature's
archive landing page (`bills_laws/Pages/ORSarchive.aspx`, any casing) names
both libraries but renders them client-side; three WebFetch passes on
2026-09-15 returned no year-specific href and one returned a dead
`/PAGES/NONE` link. `archives.oregonlegislature.gov/Pages/ORS-Archives.aspx`
is only a redirect notice back to that page. The `ORS_Archives/Chapters%20020-061.pdf`
file the landing page does link is the 1953 "prior legislative history"
table, not statute text. The working pattern surfaced from a web-search hit
on `1953-Chapter-087.PDF`; constructing `1987-Chapter-059.PDF` from it worked
first time. The 1999–2023 pattern surfaced the same way (`2001ors012.pdf`).
Never navigate the landing page; go straight to the pattern.

**What is NOT available.** Oregon Laws session-law text before 1999.
`bills_laws/lawsstatutes/<YEAR>orLaw<CCCC>ses.html` works from 1999
(`2003orLaw0631ses.html` verified) and 404s for 1993.
`bills_laws/lawsstatutes/<YEAR>.pdf` exists for earlier years (1987, 1993
verified) but is only the Chap./Sec.→ORS cross-reference table, and WebFetch
reads it unreliably — on 2026-09-15 it found `1987 c.158 §10 → 59.115` and
missed `1987 c.603 §6 → 59.115`, which the ORS bracket lists. Do not use it
to confirm or deny an amendment. The State of Oregon Law Library holds the
bound volumes.

**Method — the long-page protocol plus four rules:**

1. **Bracket, then bisect.** The current chapter page's source-law bracket
   lists every amending act. Fetch the edition immediately after the earliest
   candidate act and the edition immediately before the latest, then narrow.
   Each edition is one WebFetch; five editions settled a 1985→1987→1991→1993
   sequence on the first use.
2. **One provision per fetch, `NOT PRESENT` escape, two agreeing fetches
   before quoting** — unchanged. These PDFs can also return *partial*
   sections: the 1989 edition returned ORS 59.115 only through subsection (3)
   on the first prompt and (4)–(5) on a reworded second prompt. Treat a
   partial return as a fetch to repeat, not as absence.
3. **Defeat the cache with a query string.** `WebFetch` caches a URL ~15
   minutes; the second, differently-worded fetch goes to `…PDF?v=2`. The
   server ignores the query and serves the same file.
4. **They are scans — budget for OCR.** Observed on 2026-09-15: `(b)` → `(h)`;
   `1991 EDITION` → `1891 EDITION`; `c.762` → `c.62`, `c.662`, `062`;
   `§28]` → `§281`; a subsection returned as its first sentence only. So the
   second fetch asks for a *specific* sentence ("the SECOND sentence of the
   subsection beginning 'Except as otherwise provided'") and for the exact
   printed form of any cross-reference in dispute. An OCR'd year that is
   impossible (1891 for a statute enacted 1967) is read as the obvious
   correction and the correction is disclosed in the report.

**What the report states for each edition read:** edition year as printed,
the subsection number as printed *in that edition*, the operative text, and
the closing bracket. Subsection numbers shift when a subsection is inserted
above (ORS 59.115's limitations provision was (5) through 1989 and (6) from
1991); Legislative Counsel restyles cross-references without substantive
change ("paragraph (b) of subsection (1)" became "subsection (1)(b)" in the
1993 edition). When the question is "first contained this text," give both
the edition where the substance first appears and the edition where the
exact wording first appears, and name the change that accounts for the gap.

**Banner:** `python scripts/banner.py --need "archived"` lights the family.
If the need arises only mid-run, append the line to the report's Data
Sources block with a `[+]` mark and the probe date, per `report-format.md`.

## U.S.C. via GovInfo — current and historical editions `[added v10.0]`

GovInfo's `USCODE` collection is the Government Publishing Office's annual
edition of the United States Code, one page per section, for every edition
year from 1994 through 2024. `scripts/govinfo.py usc --title T --section S
[--year YYYY]` returns the section's text as the script extracted it — the
page's own characters, with no model between the page and the caller, which
is the property the two-fetch rule exists to approximate for WebFetch.

Rules:

1. **It is one source, not two.** Quote U.S.C. text only when the GovInfo
   text and a second allowlisted source (OLRC `prelim`, or Cornell) agree on
   the operative words. On 2026-10-03 the OLRC site served a maintenance
   notice on two separate fetches; GovInfo + Cornell was the working pair
   that day.
2. **Report the edition.** The JSON's `edition` line (`United States Code,
   2024 Edition`) goes in the report beside the quote. The annual edition
   **lags** the OLRC `prelim` code: a section amended since the edition
   closed will differ, legitimately. When GovInfo and OLRC/Cornell disagree,
   do not quote; say which sources were compared and that an amendment after
   the edition year is the likely cause, and link both.
3. **Historical federal text** — "what did 15 U.S.C. § 1692k say in 2008?" —
   is answered from the edition for that year (`--year 2008`), exactly as
   archived ORS editions answer the Oregon version of the question, and
   never from an opinion's paraphrase. Say "2008 Edition" and nothing more
   precise: the section page states the edition and gives no "as of" date,
   so none may be stated in a report. The second source for a historical quote is an opinion that
   quotes the same words (the v9.3 opinion-corroboration fallback). An
   adjacent edition year is **not** a second source — it is the same
   publisher's same file a year on. Without corroboration the provision is
   cited, linked and described with its edition named, but not quoted.
4. A section that the link service cannot resolve returns `found: false`
   (HTTP 400). That is "not retrieved from GovInfo," not "no such statute."
5. `USCODE` is not the Statutes at Large and not the session laws; the
   source credit at the foot of the section (`Pub. L. …, Stat. …`) is the
   pointer to those.

## State-court review dispositions

**CourtListener does not index state supreme court review dispositions** —
petitions allowed, denied, or dismissed are absent from the database
entirely. A clean `cites:()` result is therefore **not** evidence that review
was never sought.

**When this check is mandatory:** any state appellate decision less than
about three years old that will appear in Leading Authorities — and, since
the Oregon check became a free script call in v10.0, **every** Oregon Court
of Appeals decision in Leading Authorities whatever its age. In a prior run
this check was the only way to learn that a February 2025 Court of Appeals
decision had review allowed in September 2025 and dismissed in October 2025 —
history the report would otherwise have presented as clean.

### Procedure

1. Start from the state judiciary's own domain. Never use a commercial
   citator, a court-watcher blog, or an aggregator for this.
2. Locate the official periodical that publishes review dispositions. Most
   states publish these as an advance-sheet list, an orders bulletin, or a
   docket search on the supreme court's site.
3. **Verify the page actually names the case and states a disposition and
   date** before reporting it. If you cannot find an authoritative statement,
   report "no review disposition located in the official source" — do not
   infer from silence, and do not fill the gap from memory.
4. In the report, name the official source you used and note the
   CourtListener gap, so the reader knows why the citator looked clean.

### Verified entry points

| State | Entry point | Notes |
|---|---|---|
| Oregon | **`[v10.0]` Scripted — use `python3 scripts/statecourts.py or-history <OJD id \| A-number> [--cite "326 Or App 117"]`** (`state-sources.md` § 3). It searches every petitions-for-review list since August 1997 for the case number, reads the list PDF itself (not a summary of it), returns the disposition heading, date and entry verbatim, and adds any Supreme Court opinion on review and the history printed in the opinion's own caption. The WebFetch route that follows is the **fallback** for a run in which `statecourts.py probe` reports Oregon off **because of a network failure** — never after a refusal (`automated access refused`): it is the same host. **Use the OJD contentdm JSON API — the site-navigation route is dead.** `[corrected 2026-09-07]` Search: `https://ojd.contentdm.oclc.org/digital/api/search/collection/p17027coll3/searchterm/petitions!<year>/field/title!date/mode/all!all/conn/and!and/maxRecords/10/order/date/ad/desc` ; item: `https://ojd.contentdm.oclc.org/digital/api/collections/p17027coll3/items/<id>/false` ; collection list: `https://ojd.contentdm.oclc.org/digital/api/collections` | **Verified in use**, and re-probed 2026-09-07: most recent list "Petitions for review, August 27, 2026"; item content carries explicit ALLOWED and DENIED sections with paired Court of Appeals / Supreme Court case numbers. Three corrections to the old entry: (a) `courts.oregon.gov` → Appellate Courts has **no** "Petitions for Review" link anywhere in ~130 link titles, and several plausible supreme-court URLs are hard 404s; (b) the media-release route renders navigation only (client-side), so it is unusable under WebFetch; (c) there is **no** dedicated advance-sheet collection — the lists live inside `p17027coll3`, titled "Opinions -- Oregon Supreme Court". Titles follow the stable form `Petitions for review, <date>`, so resolve the current issue by **title search on p17027coll3**, never by site navigation or a stored deep link. The contentdm HTML UI is Javascript-only and returns nothing useful; the JSON API reads fine. |
| Washington | `https://www.courts.wa.gov/appellate_trial_courts/supremecourt/` | Supreme Court orders and rulings on petitions for review. Confirm the specific case and date on the page before relying on it. `[probed 2026-09-07]` Three things a run needs to know: (a) the **PETITIONS FOR REVIEW link is an intermediate page**, not a list — it names no cases, numbers, dispositions or dates, and offers three onward links; one more hop is **always** required, and a run that stops there and reports "no disposition located" is wrong; (b) the ORDERS page is the dated one (most recent entry "Filed September 3, 2026" at probe time) and the ACCEPTED CASES PDF carries its own "Last updated" line; (c) **never construct a courts.wa.gov query URL** (the one exception is inside `scripts/statecourts.py`, which requests the court's own by-year opinion listing — never build even that by hand) — a guessed `?fa=atc_supreme.disp` returned a ColdFusion error *inside normal page chrome*, which reads like an empty result rather than a failure. Follow the real hrefs. Both `/supremecourt/` and `/SupremeCourt/` resolve, which gives a cache-independent second fetch. |

For any state not listed, follow the Procedure above, confirm the source is on
the state judiciary's own domain, and **add the verified entry point to this
table** so the next run does not repeat the search.
