# Pipeline

Eight phases, run in order for **every** query. Depth is set only by the
complexity profile — never skip a phase because a question looks easy.

The reasons behind each rule are in `CHANGELOG.md`; the empirical facts the
budget rests on are in `references/measurements.md`. This file is the
procedure. `[v10.0]` Three kinds of source now feed it: CourtListener
(metered); GovInfo (`references/govinfo.md`, unmetered, federal courts
only); and the state publishers in `references/state-sources.md`
(unmetered — Oregon official reports, Washington slip opinions, and a New
York official-page check). Wherever a step says "GovInfo lane," the
commands are `scripts/govinfo.py`; wherever it says "state lane," the id
comes from `scripts/statecourts.py` and the text commands are the same
`govinfo.py fetch / triage / read / grep / verify`. Either way the
CourtListener cost is zero.

## Depth constants

| Complexity | Strategies | Candidates fetched | Analyzed round 1 | New analyses per refinement round | High-relevance target |
|---|---|---|---|---|---|
| simple | 3 | 10 | 6 | 5 | 2 |
| standard | 4 | 18 | 12 | 8 | 3 |
| complex | 5 | 20 | 15 | 8 | 4 |

Round cap: 4 total (initial + up to 3 refinement rounds).

## Budget

**One account-wide pool, three caps: 5/min, 50/hour, 125/day.** The daily cap
is a rolling 24-hour window — units return one at a time, 24 hours after the
call that spent them. It is the real ceiling: about four full runs a day.

**Costs.** Every `call_endpoint`, `get_endpoint_item`, `get_choices`,
`analyze_citations`, `extract_citations` and `get_more_results` call: 1
unit. **`search`: 1 unit per page of 20 rows actually returned** `[measured
v10.0, M29]` — the connector fetches CourtListener's 20-row pages one by one
to fill `num_results`. A query that returns 9 rows costs 1 whatever was
asked for; `num_results: 40` with 40+ hits costs 2; `100` costs 5. **Default
`num_results` to 20.** Ask for more only when the extra rows are worth a
unit per 20, and count them into the wave. `read_document` / `search_document`: 1 unit per document on its
**first** fetch, then free forever — against all three caps, inside an
exhausted window and across sessions (measurements M4, M11). A batched
document call costs one unit **per document**. `get_api_usage` is free and
has its own separate throttle (10/min, 120/hour). **Every `scripts/govinfo.py`
command costs nothing against any of these** — GovInfo is a different service
with a 36,000-an-hour limit (M13); a GovInfo-lane read never appears in
`get_api_usage`. The same is true of every `scripts/statecourts.py` command
and of every text command run on an `OJD-…` or `WA-…` id: those requests go
to the Oregon and Washington courts' own servers, one a second.

### Spending from live counters `[v9.6]`

The connector exposes `get_api_usage` (measurement M10). It never spends the
`user` quota and answers while other calls are throttled. It reports, per
cap, `used`, `remaining`, `reset_at` and `blocked`, plus daily totals for the
last 14 days. **There is no ledger.** Read the counters instead:

1. **Before the banner.** One call. Its values go to `banner.py`
   (`--hourly-used`, `--daily-used`, `--daily-reset`) and set the plan: the
   run's hourly budget is `remaining − 6` (reserve), its daily budget is the
   daily `remaining`. If the daily `remaining` is below the ~13-unit spine,
   print the `DAY` line with `reset_at` and stop before spending anything.
2. **Before every metered wave** — Phase 3 dispatch, the Phase 4 screen,
   Phase 5 dispatch, each Phase 6 round. `wave_cost <= hourly remaining − 6`,
   else split or cut, and cut from the top of the allocation table down.
3. **After any 429**, to see which cap fired and when it reopens; the 429
   body names the cap, the tool shows all three.
4. **At close**, for the About table, the memo's Skill line and the `DONE`
   line. Those numbers are read from the tool, never recalled or summed.

A run that finds the hourly counter already high (an earlier run this hour)
plans a smaller run or waits for `reset_at`, and says which in the report.

### The spine

A run that completes these is publishable; everything else is enhancement and
is what gets cut when a cap fires:

| Spine item | Cost |
|---|---|
| Enough searches to surface candidates | ~4 |
| The negative-treatment screen (Phase 4) | 1–5 (one per 20 rows returned; usually 1–3) |
| Reading the selected cases | ~8 minimum, **less one for every case on the GovInfo lane or a state lane** |

**Minimum viable run ≈ 13 units** with nothing on the GovInfo lane, ≈ 6 with
everything on it. The Phase 1 stop rule does not move: lanes are unknown at
Phase 1, so a daily `remaining` below 13 still stops the run there (with the
GovInfo-only offer for a federal question). What changes is the wave gate
*after* Phase 4, which counts only CourtListener-lane reads. A cap that fires above the spine shortens
the report; state what was cut and for how many cases in the coverage banner.
A cap that fires below it means the run aborts and says so.

### Allocation

| Phase | Units | Notes |
|---|---|---|
| 2 Anchor | 3–4 per anchor | ONE batched resolution for all anchors + 1 raw citator (40 rows = 2 units) + 1 topic-filtered citator (20 rows) each. The anchor's negative-treatment screen is the Phase 4 screen, not the raw citator |
| 3 Search | 8–16 | 3–4 queries per strategy **at 20 rows each**; ≤2 agents concurrent (3 at 40 s spacing); plus 1 for the known-case batch. GovInfo searches: 0 |
| 4 Select | 1–5, +1 per court | The screen: up to 100 rows, one unit per 20 actually returned (usually 1–3). Plus 1 per court if GovInfo-found or `or-search`-found candidates are resolved. Ids come free on search rows |
| 5 Analyze | 12–18, **minus GovInfo- and state-lane cases** | One unit per CourtListener-lane opinion, minus any already cached. GovInfo-lane and state-lane opinions: 0 |
| 6 Refine | 4–8 per round | 1–3 searches or citators, each written from a lead-ledger row + first reads of new cases |
| 7 Verify | ~0 | WebFetch + cached greps + `govinfo.py verify` / `cites` + `statecourts.py or-history` |
| Reserve | ≥6 | Retries and 429s |

Without refinement ≈ 32 + reserve; with one round ≈ 40 + reserve. Both fit
the hour. With *g* analyzed cases on the GovInfo lane, subtract *g* — a
federal-heavy run is ≈ 15–25. Do not spend the difference automatically:
spend it where the sufficiency test says the report is thin (another
strategy, a citator on a pivotal case, a state-court read), or leave it in
the daily pool for the next run.

### Counters and concurrency

- Subagents no longer count calls. They report `rate_limited` and
  `limit_hit` (with the verbatim 429 body) so the orchestrator can react; the
  orchestrator reads the true spend from `get_api_usage` after each wave.
  Rejected requests cost nothing (M5) and cached reads cost nothing (M11).
- `wave_cost` counts **CourtListener-lane** first fetches only. GovInfo-lane
  analyzers and verifiers are not part of any wave's cost, need no start
  offsets and have no concurrency limit. State-lane analyzers likewise cost
  nothing and may all be dispatched at once: the script itself spaces
  requests to each court's server a second apart, across processes.
- Before dispatching a wave: `wave_cost <= hourly remaining − 6`. If it does
  not fit, split it. When hourly `remaining` ≤ 6, stop dispatching metered
  work and finish from what you have with the budget-limited banner. Never
  idle for a reset — spend any wait on zero-cost work (statute WebFetch,
  cached verification, drafting) — unless `reset_at` is only minutes away
  and the remaining work is the spine.
- Waves that issue `search`: **max 2 concurrent at 25–30 s spacing, or 3 at
  40 s**; agents issue calls one at a time. `[v10.3, M44]` The 5/min window
  counts **pages**, as the hourly and daily caps do: a 100-row request that
  returns 26 rows takes two of the five slots. Space by pages, not calls. Analysis waves fan out wide with
  start offsets ~13 s apart. The orchestrator's own calls: one per message,
  ≥15 s apart. Verification against cached documents has no concurrency limit.
- On a 429, take the branch the body names (SKILL.md § "Read the 429 body").

## Phase 1 — Parse

Produce the parsed query:

- `query_type`: `fact` / `law` / `mixed`
- `estimated_complexity`: `simple` / `standard` / `complex`
- `depth_preference`: `quick` / `deep` / `unspecified`. `deep` when the user
  asks for breadth in any words — and **an interrogative existence framing is
  a breadth request**: "are there any cases where…", "has any court…", "is
  there authority for…", "do any courts hold…". Apply mechanically.
  `quick` → skip Phase 6; `deep` → at least one Phase 6 round;
  `unspecified` → a Phase 6 round whenever the sufficiency test fails **or
  the lead ledger holds a fruitful lead** (Phase 6) `[v10.2]`.
- `jurisdiction`(s), with **court IDs resolved by you now** from
  `courtlistener-mcp.md` § "Court IDs" — never a metered `get_choices`.
- `federal_excluded`: `true` only when the user expressly limited to state
  courts. Default `false`.
- key concepts; date range if stated
- `statutory_authorities[]`: provisions the user explicitly named
- `anchor_cases[]`: cases the user named as a starting point
- the **sub-questions** the answer must cover — these gate sufficiency.
  `[v10.3]` Write each at **the granularity of the user's facts**, not of
  the doctrine: "does the saving statute apply to a dismissal for lack of
  *personal* jurisdiction?", not "does Oregon have a saving statute?". A
  sub-question pitched at the doctrine is satisfied by any case on the
  doctrine, the Gap row in Phase 6 can never fire, and the fact-specific
  case the user needs is never looked for (M43, ORS 12.220 run).
- the **premise**: what the question assumes about how the law works
  ("the limitations period stops and starts running again"). One line. It
  feeds the Premise row of the Phase 6 ledger

State the interpretation in one line (it becomes the report's "Read as:").

**Probe GovInfo** `[v10.0]` unless `federal_excluded` is true: `export
GOVINFO_CACHE=<scratch>/govinfo-cache` (one directory for the whole run;
give the same path to every subagent) and run `python3 scripts/govinfo.py
probe`. `"ok": true` → the GovInfo lane is on. `"ok": false` → it is off for
this run: every federal case is CourtListener-lane, the banner prints the GovInfo
line as unavailable, and the `GOV` exception line says so. Export
`GOVINFO_CACHE` even when `federal_excluded` — the state lanes use the same
cache directory. Either way the
run proceeds.

**Probe the state sources** `[v10.0]` when the jurisdiction includes Oregon
or Washington (a federal court applying that state's law counts):
`python3 scripts/statecourts.py probe`, with the same `GOVINFO_CACHE`. It
reports `oregon.ok` and `washington.ok` separately; a source that is not
`true` is off for the run (its cases are CourtListener-lane) and gets one
`ST` line. If the probe's error is a **refusal** (`automated access
refused`) nothing on that host is fetched for the rest of the run by any
tool. New York has no probe: its official-page check is WebFetch, done in
Phase 7. Read `references/state-sources.md` before Phase 3 of any run
touching Oregon, Washington or New York.

Then **print the banner** — the run's first output, before any metered call
— by calling `get_api_usage` (free), then `python scripts/banner.py --need
"<family>" … --hourly-used <used> --daily-used <used> --daily-reset <HH:MMZ>
--govinfo <ok|off> [--oregon <ok|off>] [--washington <ok|off>] [--no-federal]`
and pasting the output verbatim. Pass `--oregon` / `--washington` only when
the state probe was run; add `--need "petitions"` for an Oregon question
and `--need "New York Official"` for a New York one. `--need` names each
statute/rule family the query makes relevant; the three usage flags carry the
live counters so the banner's Budget line is true. Never spend a metered call
confirming the connector; `get_api_usage` succeeding is the check, and the
first metered call confirms the `user` quota. If the connector's tools are
missing or `get_api_usage` returns an authentication error, run SKILL.md
§ First-run setup before anything else, then resume here `[v10.1]`. Console rules are in SKILL.md.

## Phase 2 — Anchor

Only if `anchor_cases[]` is non-empty (max 3). The forward citator on a named
case is the single highest-yield action available.

1. **Resolve all anchors in ONE call:** `citation:("<A>" OR "<B>" …)`. Each
   row carries `opinion_id`, the verbatim `citation` array and
   `cluster_opinions`. Confirm each returned `citation` array contains the
   string you asked for (quirk 23).
2. **Per anchor, ONE raw citator:** `cites:(<ids>)`, `order_by="citeCount
   desc"`, `num_results` 40 (2 units — the top 40 by cite count; `count`
   says how many there are in all, and 100 rows would cost 5),
   OR-joining every sub-opinion id and any duplicate cluster's ids (quirks 9,
   28).
3. **Per anchor, ONE topic-filtered citator:** `cites:(<ids>) AND (<3–5
   phrases from the key concepts>)`. Search returns no snippets, so this is
   the only precision tool. Its rows go to the front of Phase 5 selection.

The citing set is now candidates for Phase 3 triage and a doctrinal map for
strategy design. `[v10.0]` It is **not** the anchor's negative-treatment
screen: at 40 rows by cite count it shows the most-cited citers, and an
overruling decision is usually recent and little-cited. Every anchor id goes
into the Phase 4 screen with the selected cases. (Under v9.6 the 100-row raw
citator was treated as the anchor's screen; it had the same blind spot for
any anchor with more than 100 citers, at five units.)

## Phase 3 — Search

**Design** the profile's number of strategies to fill the gaps the anchor
citing set left open. Vary the angle (doctrine name, fact pattern, remedy,
procedural posture) **and the mode** `[v10.2]`: semantic search finds
opinions that discuss the issue in words the question did not use; keyword
search finds a known phrase, a citation or a statute section, runs the
citator, and is the only mode that ranks by citation count.

**At least one strategy is semantic, and it opens the search** — the
connector's own guidance for an open-ended question is one plain-language
semantic query before any keyword variations, then keyword to narrow. Write
the query as the question a lawyer would ask, one sentence, no operators
(`courtlistener-mcp.md` § "Semantic search"). `[v10.3, M42]` Semantic search
ranks by similarity **weighted toward recent decisions**, so every page
packs against its upper date bound: a 1985–2017 window returned only
2013–2016; a 1985–1990 window returned the two leading 1988–89 cases first.
**A window reaches about 3–5 years of a busy court and 5–10 of a quiet one,
and within that span its ranking is good.** So the semantic strategy is not
a sweep backward through time; it is:

1. **unwindowed, per court** — current law. Run it first.
2. **2–3 narrow windows (≤ 5 years each) aimed at eras the evidence points
   to** — never stepped back blindly from the oldest date on the page (in
   D. Utah three stepped windows reached only 1999 and found none of the
   four authorities the question turned on). Take the eras from, in order:
   an anchor case's date; the decision dates of the strongest keyword or
   GovInfo/Oregon-collection rows (the cluster of years where on-point
   cases sit); the year the statute in question was enacted or rewritten;
   the dates of cases that triage snippets show being cited. Window each
   era as `filed_after` = its first year, `filed_before` = its last + 1.
3. If round 1 gives no dated evidence yet, run only query 1 here and carry
   the windows into Phase 6 as Era rows.

So the semantic strategy's windows are written **after** the keyword and
free-source rows are in (they are what date the eras); its unwindowed query
is the one that runs first. Skip the windows only when the question is
confined to recent law (a statute or rule enacted inside query 1's span).
For a `fact` query, add a second semantic strategy that describes the fact
pattern rather than the legal issue.

**Where semantic earns its units** (M42, M43): questions framed as a
doctrine or a standard with no distinctive term ("equitable indemnity",
"when do the tort-claims caps not apply") — a narrow window put three
leading cases in its top eleven. Where the question carries a distinctive
string — a statute section, a rule number, a term of art — keyword search
on that string is stronger: `"12.220" AND (dismiss* OR "personal
jurisdiction")` returned five of the eight scored authorities in one call,
and the run's four semantic queries found nothing it did not. There the
semantic strategy is held to query 1 plus one era window, and the units go
to keyword and citator work.

Case names the semantic rows surface go to Phase 4's batch, and the doctrine
names those captions and courts suggest are used in the keyword queries.
Constraints:

- Pattern `[Core Concept] AND ([Variant1] OR [Variant2])`; never 5+ AND'd
  concepts; never 4+ OR-groups with a `court` filter (quirk 4).
- **Exactly one court ID per call** (quirk 12). Cover two court levels with
  two calls.
- A semantic query is never run **only** unwindowed when older authority
  matters (quirk 11) — add narrow era windows as above, never one wide
  window (it collapses to its last few years). A semantic row is a candidate
  like any other: its relevance is unknown until triage or the analyzer says
  so, and its `count` means nothing.
- Every opinion search carries the three `stat_*` flags and the `fields` list.
- **3–4 queries per strategy**, stated as a budget, issued one at a time.
- Dedupe identical query strings across strategies.
- Never spend a query on a case already known by citation (Phase 4 batches
  those) or on a case named in an opinion already read (grep it first —
  quirks 13, 21).
- For federal procedural questions decided mostly by district-court order,
  make one strategy the RECAP search (`courtlistener-mcp.md`).
- **GovInfo strategies** `[v10.0]` — when the GovInfo lane is on and a
  federal court that GovInfo holds is in scope (`govinfo.md` § 1), run each
  strategy's queries on GovInfo as well, yourself, before dispatching the
  CourtListener agents: `python3 scripts/govinfo.py search '<terms>' --court
  <id> -n 50`, one court per call (`ord`, then `ca9`, then `orb` …). They are
  free and return in a second; there is no query budget, but keep the same
  discipline — `[Core] AND ([Variant] OR [Variant])`, no proximity operator
  (G13). GovInfo has **no state courts and no W.D. Wash.**: these searches
  add federal candidates, they never replace a CourtListener strategy.
- **Oregon strategies** `[v10.0]` — when the Oregon lane is on and Oregon
  appellate courts are in scope, run each strategy's key phrases through the
  Judicial Department's own full-text index as well, yourself: `python3
  scripts/statecourts.py or-search "<exact phrase>" <word> … [--court
  orctapp] [--after YYYY-MM-DD] -n 40`. Free; newest first, unranked, no
  proximity (`state-sources.md` § 3). Use two or three distinctive phrases
  per strategy rather than one broad word. These add Oregon candidates —
  each still needs its CourtListener row in Phase 4 — and never replace a
  CourtListener strategy: only CourtListener ranks by citation count and
  covers decisions before 1998. Washington and New York have no free search.

**Dispatch** search subagents two at a time. Each prompt carries: the
research question; its strategy, queries and court IDs; its query budget and
the spacing rule; the **verbatim briefing block** (pasted, or `cat` from a
scratch file); and this contract:

> Return ONLY JSON: `{"candidates": [{cluster_id, opinion_id, case_name,
> court, court_id, court_citation_string, date_filed, cite_count, absolute_url,
> citation_strings[], status, docket_number}], "queries_run": [],
> "rate_limited": bool, "limit_hit": null|"per_minute"|"hourly"|"daily",
> "limit_body": null|"<verbatim 429 body>", "new_quirk": null}`. Copy `opinion_id` from every row —
> it is present even when not in `fields` (quirk 18) and is NOT the
> `cluster_id`. `citation_strings` copied EXACTLY from the API `citation`
> array. Do not request `snippet`. RECAP rows set `cluster_id: null`.
> **An empty `candidates` array is a valid, useful result.** Never pad it.

**Triage**, yourself: merge every array plus the anchor citing set, the
GovInfo rows and the `or-search` rows; dedupe by `cluster_id`, by case name +
date, and — across sources — by court + docket number + date (a CourtListener
row and a GovInfo row for the same docket and date are one decision: keep the
CourtListener row, attach the `granule_id`; a CourtListener row and an
`or-search` row with the same Oregon citation or case number and date are one
decision likewise). CourtListener holds duplicate clusters of recent Oregon
opinions — same docket, same date, one with an empty `citation` array (S8):
keep the row that has the citation.

**Pre-read the federal candidates, free** `[v10.0]`. Write the merged
CourtListener rows to a JSON file and run `govinfo.py resolve-batch` on it;
then `govinfo.py triage <every granule found, plus every GovInfo-only
granule> --terms "<3–5 key concepts>"`. For those candidates you now hold
term counts and a snippet from the opinion itself, where CourtListener gives
only a name, a date and a cite count (quirk 1). Use them: a federal candidate
whose text never mentions the core concept scores 1–2 whatever its name
suggests, and one that discusses it at length earns its 4 before a unit is
spent. Candidates with no granule are scored as before.

**Pre-read the Oregon and Washington candidates, free** `[v10.0]`. Run
`statecourts.py resolve-batch` on the same rows file (300-second timeout, or
slices of ≤ 25 rows — it makes one request a second), then `govinfo.py
triage <every OJD-/WA- id found, plus every or-search opinion id> --terms …`
— at most ~20 uncached state ids a call, or with a 300-second timeout (the
first fetch of each is two throttled requests). The
same scoring rule applies. Note `nonprecedential`, `pub_status` and
`superseded_slip` on each row now: a nonprecedential Oregon memorandum
opinion or an unpublished Washington opinion is scored on what it says but
can never be presented as binding authority.

Score every candidate 1–5 on the Phase 5 rubric; select the top *Analyzed
round 1* by score, cite count as tiebreaker. A GovInfo-only candidate
competes on its triage evidence — it has no cite count. *Candidates fetched* is an effort guide, not an eligibility gate.
Consult `references/known-corrections.md` — a listed case carries its
correction into scoring. Then call `get_api_usage` and note the hourly
`remaining` before planning Phase 4–5.

## Phase 4 — Select

**Resolve ids.** Search rows already carry `opinion_id` and
`cluster_opinions`, so search-surfaced candidates cost nothing here. Cases
known only by citation — user-named, harvested from a cached opinion,
returned by `analyze_citations`, or **recalled by you** — resolve together in
ONE `citation:("<A>" OR "<B>" …)` call. Before that call, grep any cached
opinion that names the case: a linked citation span carries the id (quirk 13);
a `citation no-link` span means CourtListener does not hold it and no search
will find it (quirk 21).

Recalled citations are governed by four rules: they are search **inputs**,
never outputs; a row counts only if its `citation` array literally contains
the string requested; a citation that returns no row is unresolved and never
reaches the report in any form; and the About table reports how many analyzed
authorities entered by recall versus discovery.

Every id is a hypothesis until the analyzer's identity check confirms it. A
cluster id passed **as** an `opinion_id` returns an unrelated case silently
(quirk 2); the dedicated `cluster_id` parameter is safe. Spend a metered
`get_endpoint_item(clusters, fields=["sub_opinions"])` only when an analyzer
returns `id_mismatch` and the batched query cannot re-resolve.

**Resolve GovInfo-only candidates** `[v10.0]` — only those selected for
analysis. ONE call per court: `q='docketNumber:("<d1>" OR "<d2>" …)'` with
that court's id, the `stat_*` flags and the standard `fields` (quirk 41). A
returned row counts only if its `dateFiled` equals the granule's
`date_issued` — **or the date of the order that adopted it**; it then
supplies the `citation` array, `cluster_id`, `opinion_id` and
`absolute_url`, and the case is an ordinary candidate with a GovInfo lane.
No such row → a **GovInfo-only authority**: slip citation from GovInfo
fields, `details_url` link, not citator-covered (`govinfo.md` § 4). Never
hunt for a reporter citation for it.

Before that call, run `python3 scripts/govinfo.py docket <granule_id>` on
each GovInfo-found candidate (free). It says whether the filing is a
magistrate judge's **findings and recommendation** (`is_recommendation`) and
lists the `adopting_orders`. Eight of seventeen GovInfo-found District of
Oregon decisions in the measuring run were F&Rs (M20). An F&R is authority
only as adopted: cite the adopting order's date, read both granules,
attribute the reasoning to the F&R "as adopted", and if the docket shows no
adopting order, do not select it — list it under *Surfaced but not read in
full* as an unadopted recommendation.

**Resolve `or-search`-only candidates** `[v10.0]` — only those selected for
analysis. ONE call per court, by **case number** (the `A…` / `S…` number in
the catalogue title — a recent Oregon cluster can have an empty `citation`
array, so a `citation:` query would miss a case CourtListener holds, S8):
`q='docketNumber:("A184664" OR "A181475" …)'` with `court: ["orctapp"]`
(a second call with `["or"]` for S-numbers; one court id per call, quirk
12), the `stat_*` flags and the standard `fields`. A returned row counts
only if its `dateFiled` equals the catalogue date **and** its case name
agrees — confirm by running `statecourts.py or-resolve` on the row; it then
supplies `cluster_id`, `opinion_id`, the parallel `P.3d` citation and
`absolute_url`, and the case is an ordinary candidate with a state lane. A
row with the same number and a **different date** is another decision in
the same case, not this one. No matching row → an
**Oregon-collection-only authority** (`state-sources.md` § 6): catalogue
citation, `public_url` link, not citator-covered.

**Assign text lanes** `[v10.0]` — for every selected case, from the
`resolve-batch` output of **both** scripts already in hand:

| `resolve-batch` says | Lane |
|---|---|
| `govinfo.py`: `found: true` | **GovInfo.** Record `granule_id`, `ocr_layer` (from `fetch`), and any `adoption_hint`, `history_hint`, `ambiguous` (several filings that day: decide from `docket_text` which is the opinion; if that is not plain, give the analyzer every same-date granule and have it report which one is the decision) |
| `statecourts.py`: `found: true` with an `OJD-…` or `WA-…` `granule_id` | **State.** Record the id, `ocr_layer` (from `fetch`), and every note on the row: `nonprecedential_note`, `pub_status` / `publication_note`, `superseded_note`, `order_note`, `citation_differs`. `ambiguous` (several items or files share the key and date): `fetch` each listed id, read its opening, use the one that is the opinion for this case — if that is not plain, CourtListener lane |
| `statecourts.py`: a New York state-court row (`found: false`, `lane: "CourtListener"`) | **CourtListener** for text; keep `official_page_url`, when present, for the Phase 7 official-page check |
| `found: false`, any reason — including a state near miss with a `candidate` | **CourtListener** — as in v9.6. Never re-run with the candidate's date |
| `found: false` with `granule_dates` | CourtListener, **and** a Phase 7A lead: the docket holds a later filing |
| GovInfo lane off, or `federal_excluded` | CourtListener for every federal case |
| A state source off (probe not `ok`) | CourtListener for that state's cases |

A case has one lane at a time: the analyzer reads in it and Phase 7D
verifies in it (hard rule 2). The only way a lane changes is a GovInfo- or
state-lane analyzer returning `id_mismatch` or `text_unavailable`; the case
is then re-dispatched, read **and** verified on the CourtListener lane, and
nothing from the abandoned read is used. Print the `GOV` line, and the `ST`
line when any Oregon, Washington or New York case was selected. Then compute the analysis wave's
cost from the CourtListener-lane cases alone.

**Screen history — mandatory, before the analysis wave** (one call; more only to page a long result). It needs
only the selected ids and it is the spine item most easily lost if deferred:

```
search(type="o", order_by="citeCount desc", num_results=100,
       stat_Published=true, stat_Unpublished=true, stat_Unknown=true,
       fields=[<standard list>],
       q='cites:(<id1> OR <id2> …) AND (overrul* OR abrogat* OR disavow*
          OR "no longer good law" OR "declined to follow" OR "superseded by")')
```

`[v10.0]` The screen asks for 100 rows, as in v9.6, and its true cost is one
unit per 20 rows **returned** (M29) — 1 when it returns ≤ 20, 5 at 100.
Budget it at 3 and read `get_api_usage` after it. If `count` exceeds the
rows returned, the screen is **incomplete**: fetch further pages with
`get_more_results` (one unit each) until `count` is exhausted, or — if the
budget cannot carry that — print the `CUT` line and state in Subsequent
History how many citing rows went unread. Never treat a truncated screen as
a complete one. Include every Phase 2 anchor id.

Drop `vacat*` where the subject matter is arbitration, awards, injunctions or
stays — it is ubiquitous there and buries the signal. Order by `citeCount
desc`, not `dateFiled desc` (quirk 34). (No id is "already screened" by Phase 2 — see there.)

Screen the rows locally, free: flag any citer with the **same case name**, any
**higher court in the same jurisdiction**, and any citer postdating a known
doctrinal shift. A flagged case may be dropped from the analysis wave before
it is paid for, or kept with its treatment noted. Confirmation happens in
Phase 7 against cached opinions. Record which ids were screened.

## Phase 5 — Analyze

Dispatch **one analyzer per selected case in a single message**, up to 15,
after the wave-size check. CourtListener-lane analyzers get start offsets
~13 s apart; GovInfo-lane and state-lane analyzers need none and cost
nothing, so dispatch them all at once. Order the wave so
each sub-question's top case is in the first half — a truncated wave still
covers every prong. This wave costs one unit per opinion not already cached,
and it front-loads the cache for everything after.

Each prompt carries: the parsed query and sub-questions; the case's
`text_source` (`"courtlistener"`, `"govinfo"` or `"state"`); its resolved `opinion_id`,
`cluster_id`, `absolute_url`, name, date and `bluebook_citation` (built per
`courtlistener-mcp.md`); for a GovInfo-lane case its `granule_id` (all of
them, if `ambiguous` or `adoption_hint`), the hints verbatim, the absolute
path of `scripts/govinfo.py` and the run's `GOVINFO_CACHE`; for a state-lane
case its `OJD-…` / `WA-…` id (quoted), every note recorded at lane
assignment, the same script path and cache, and — never — a nycourts.gov
URL as something to read; the verbatim
briefing block; any `known-corrections.md` entry for the case; the rubric
below; and this contract (the GovInfo-lane wording is in the briefing's
"GovInfo lane" section — the fields are the same):

> Read the FULL opinion. FIRST confirm the opening text names your assigned
> case; if not, stop and return `{"id_mismatch": true, "found_instead":
> "<name>"}`. Fetch ONCE by `opinion_id` — the first fetch is metered, every
> later grep is free — never re-fetch under `cluster_id`, never batch
> `search_document` across unread ids. Then return ONLY JSON:
> `{cluster_id, opinion_id, bluebook_citation (copied EXACTLY),
> relevance_ranking (1–5), scale_confirmation, answers_the_question (bool),
> relevance_summary, factual_background (fact/mixed only), holding,
> key_quotes: [{quote, context}], dicta, treatment_of_other_cases,
> pivotal_case, follow_up: {citations_to_trace[], search_terms[],
> statutes_cited[] (max 3, verbatim)}, rate_limited, limit_hit,
> limit_body, extra_fetch_explanation (required whenever the agent fetched
> any document other than the one assigned)}`. A GovInfo-lane analyzer adds
> `text_source: "govinfo"`, `granule_ids_read[]`, `ocr_layer`, and per quote
> `{granule_id, grade, page_label, opinion_part (who wrote it: the court, a
> named concurring or dissenting judge, a magistrate judge), cautions[],
> viewed_page_image, requoted_from_source}` — it runs `govinfo.py verify` on its own
> quotes before returning — and returns `text_unavailable: true` with the
> reason if `fetch` fails, rather than turning to CourtListener. A
> state-lane analyzer returns the same additions with `text_source:
> "state"`, the id in `granule_ids_read[]`, `page_label` copied from
> `cite_pages` (`official_page` for Oregon, `slip_page` for Washington), and
> `document_notes[]` copied from the verify output; a quote graded
> `not_found` with `not_opinion_text` (caption, case summary, cover sheet)
> is dropped, never reworded.
> `follow_up` is what the next round of searching is built from, so fill it
> from the opinion, not from the question: `search_terms[]` are **the
> court's own words for this issue where they differ from the question's** —
> the name of the doctrine or test, the statutory phrase, the label the
> court gives the argument; `citations_to_trace[]` are the authorities the
> opinion treats as controlling, as the origin of the rule, or as the
> contrary line, each copied verbatim with a word saying which. Nothing new
> to report is `[]`.
> Quotes verbatim from the fetched text. **Every field accepts `null` or an
> empty array**: no dicta means `dicta: null`, two good quotes beat five
> padded ones, and a wrong premise is reported in `relevance_summary` rather
> than answered as though it held.

A GovInfo- or state-lane analyzer that returns `id_mismatch` or `text_unavailable`
is re-dispatched on the CourtListener lane if the wave budget allows (one
unit), and the case's lane is changed in your records; otherwise the case is
listed as surfaced-but-not-read.

### Rubric — anchored, and echoed back

| Score | Meaning |
|---|---|
| **5** | Squarely answers the question. Holding directly on point, target jurisdiction |
| **4** | Applies or materially informs the governing rule; on point but resolves on adjacent grounds, or is the leading framework case |
| **3** | Same doctrinal area; useful framework, contrast or context; does not answer the question |
| **2** | Framework or standard of review only; facts and posture distant |
| **1** | Tangential — keyword match, different issue |

The analyzer returns the literal string `"5=squarely on point,
1=tangential"` as `scale_confirmation`. If it is absent or altered, or
`relevance_ranking <= 2` while `answers_the_question` is true, **re-score the
case yourself** from the summary and holding. Bare scales get inverted.

## Phase 6 — Refine

Legal research is iterative: what the first round read decides what the
second round searches for. Two things can call for another round — the
answer is thin, or the cases in hand point somewhere that has not been
looked at — and the second is tested as deliberately as the first `[v10.2]`.

**Lead ledger — every run except `quick`; free.** When the Phase 5 analyses
are in, and before the sufficiency test, write one table from all of them
(`follow_up`, `pivotal_case`, `treatment_of_other_cases`, `holding`) and from
every `queries_run` so far. One row per lead, with the case(s) it came from:

| Kind | What it is | Fruitful when |
|---|---|---|
| **Authority** | A case the analyzed opinions name as controlling, as the origin of the rule, or as the contrary line — **on the question's issue** | It is not in the analyzed set, **and** either a case scoring ≥4 names it in one of those three roles, or any case scoring ≥3 says it decided **the question's own fact or posture** (the personal-jurisdiction dismissal, the out-of-state statute). `[v10.3]` A case cited only for background, a general canon or a neighbouring point is not fruitful however many analyzers cite it (*Tikka*: named by two, read, 2/5). Not fruitful if it is already in the candidate pool and its own text was triaged at ≤2 |
| **Vocabulary** | The courts' own term for the issue — a doctrine or test name, a statutory phrase, the label given to the argument | A case scoring ≥4 uses it and no query run so far contained it |
| **Statute or rule** | A provision the cases treat as governing | Two analyzed cases cite it (or one scoring ≥4 calls it governing), and it was neither in `statutory_authorities[]` nor in any query |
| **Split** | A contrary line, a later limiting case, a majority and minority rule | The other side has no case in the analyzed set |
| **Era or court** | Where the doctrine was made — a leading case from a period or a court no round-1 query or semantic window reached | Always, once identified. Worked first with a **narrow semantic window (≤ 5 years) around that period** in that court (M42), then keyword if the window returns nothing on point |
| **Premise** `[v10.3]` | The mechanism the user's question assumes (Phase 1 *premise*), when the cases read correct it — "it does not restart; a saving statute gives a new window" | The mechanism the user described may still exist somewhere the round did not look (a tolling statute beside the saving statute; another forum's rule) and no query has looked for it. One row, worked with one keyword query and one semantic query phrased in the user's terms. Closed "nothing found" is a result the Short Answer states (ORS 12.220 run: the report corrected the premise and never checked ORS 12.150 tolling, which the earlier run had) |
| **Gap** | A Phase 1 sub-question with no case scoring ≥4 | Always |

A lead that comes only from a case scored ≤2 is not fruitful unless a better
case repeats it. Check each Authority row against the cached opinions before
counting it (grep for the name — quirks 13, 21: a `citation no-link` span
means CourtListener does not hold it, and it is recorded as *not held*, not
as fruitful). **An empty ledger is a valid result** (hard rule 7): do not
promote a weak lead to justify a round, and do not skip writing the ledger
because round 1 looked sufficient — that is the case this step exists for.

**Sufficiency test.** Count analyzed cases scoring ≥4 after Guard-2
correction. Sufficient when the count meets the profile target, or is one
short with a controlling authority present (a 5, or a `pivotal_case` named by
an analyzer) — **and** every sub-question from Phase 1 has at least one case
scoring ≥4. For `fact`/`mixed` queries, additionally require ≥3-scoring
cases ≥ target. Record round stats.

**Whether to refine.**

| `depth_preference` | Sufficient? | Fruitful leads? | Rounds |
|---|---|---|---|
| `quick` | — | — | None. The ledger is not written |
| any other | no | — | Up to three, until sufficient or a stop condition |
| `deep` | yes | — | At least one |
| `unspecified` | yes | **yes** | **One, scoped to the fruitful rows.** A second only if that round's new cases include one scoring ≥4 that itself opens a fruitful row |
| `unspecified` | yes | no | None — "initial results were sufficient; no open leads" |

**Each round:**

1. **Plan from the ledger, and only from the ledger.** Every search and
   citator in the round is written from a named row and records
   `derived_from` (the row and its source case). **A query that could have
   been written before round 1 was read is not a refinement query** —
   rewrite it from a finding or drop it. Fruitful rows first, in this order:
   Gap, Authority, Split, Vocabulary, Statute, Era. How each becomes work:
   - *Authority* — resolve every named case in ONE `citation:("…" OR "…")`
     call (Phase 4 rules) and read the best; for one that looks pivotal, a
     topic-filtered citator `cites:(<ids>) AND (<the courts' terms>)`, and,
     free, `govinfo.py cites` for a federal case.
   - *Vocabulary* — a keyword query built on the courts' phrase, quoted:
     `"<court's term>" AND (<variant> OR <variant>)`; and one semantic query
     that restates the question **in the courts' words rather than the
     user's**, windowed as in Phase 3. `related:<opinion_id>` on the best
     case in hand when the vocabulary is thin.
   - *Statute or rule* — a keyword query on the section string in the form
     the opinions print it, with the issue's core term.
   - *Split* — the citator on the contrary case; a keyword or semantic query
     phrased from the contrary line's holding.
   - *Era or court* — a semantic query with a ≤ 5-year window around the
     period, in that court; then round 1's best-performing keyword query
     with the same window if the semantic page has nothing on point.
   - *Premise* — one keyword query and one semantic query for the
     mechanism as the user described it.
   - *Gap* — a new strategy for that sub-question, written with every term
     the ledger now holds for it.
   Carry the negative results too: a query form that returned nothing or
   noise in round 1 is not re-run in other words, and a term the analyzers
   showed to belong to a different doctrine is excluded (`-term`).
2. ONE wave of ≤3 concurrent subagents: citators on pivotal cases, batched
   `analyze_citations`, the new searches (and, free, the same new searches on
   GovInfo plus `govinfo.py cites` on a pivotal federal case, and on the
   Oregon collection with `statecourts.py or-search` when Oregon is in
   scope); the `opinions-cited` endpoint when leads are thin. Each prompt
   carries the ledger rows it is working and the names of the cases already
   analyzed, so the agent returns what is new. Cases resolved by
   `analyze_citations` need a backfill search for `absolute_url` and
   `court_citation_string` before scoring.
3. Score as Phase 3 (with both scripts' `resolve-batch` + `triage` on the
   new federal, Oregon and Washington candidates); assign lanes; analyze up to *New analyses per round* as
   Phase 5, as `get_api_usage` permits — GovInfo-lane and state-lane analyses do not count
   against that permission. Add their ids to a second screen only if
   budget remains; otherwise the report says which cases were unscreened.
4. **Close the rows.** Mark each row worked with what it produced (a new
   case and its score, "nothing new", "not held"); add the rows the new
   analyses open; re-run the sufficiency test.

A case brought in by a lead is read **in full** like any other before it
reaches Leading Authorities; a partial read is disclosed and the case stays
out of Leading Authorities until the rest is read (*Wallace*, the find of
the ORS 12.220 run, reached Leading Authorities with its jurisdiction
analysis unread).

A fruitful row left unworked — for budget, or because the round cap was
reached — is not dropped: it is listed in the report (About table, *Leads*
row) so the reader can ask for it as a follow-up.

`deep` means the refinement round *is* the breadth — no ad-hoc sweep in
Phase 7.

**Stop conditions, in order:** no planned work (sufficient, and no fruitful
row open) · sufficient and the leads-only round is done (and not `deep`, or
one deep round done) · zero new high-relevance cases this round · ≥60% of
results already seen · leads exhausted · round cap · **hourly `remaining`
≤ 6 per `get_api_usage`**. If the
loop ends still insufficient, set `research_exhausted` with a one-line
reason; the report carries the banner.

## Phase 7 — Verify

Dispatch in one message:

**A. History confirmation** (≤3 subagents, 4–5 cases each, cached documents,
free). For each flag candidate from the Phase 4 screen, `search_document` the
**citing** opinion for the cited case's name and the treatment verbs
(`disavow*` included — partial disavowal is the commonest state-supreme-court
form). Free if that citer was already read; metered if it is a first fetch, so
prefer citers already in the analyzed set. Escalate to a metered keyword
citator only if the document is inconclusive. If budget runs out, say so in
the report. Return only flagged cases: `{cluster_id, opinion_id,
precedential_status (reversed|overruled|vacated|abrogated|superseded|
disavowed|questioned), detail, confidence (high|medium|uncertain),
reversing_case: {case_name, court, date_filed}, rate_limited, limit_hit}`.
A same-name or higher-court candidate chased and cleared is also reported, as cleared.

`[v10.0]` **Free federal additions to A — leads, never clearances:**

- For every GovInfo-lane case and every GovInfo-only authority, run
  `python3 scripts/govinfo.py docket <granule_id>`: this filing's
  `docket_text` and hints, and every `later_granules` entry with its docket
  text. A later filing in the same docket (amended opinion, order on
  reconsideration, order rejecting an F&R, order after remand) is fetched
  and grepped free. A CourtListener-lane case whose resolve miss carried
  `granule_dates` gets the same look through `fetch` on the later granule.
  An empty `later_granules` is not a clean history: an appeal is a separate
  docket.
- For each Leading Authority decided by a federal court — and every
  GovInfo-only authority, which the Phase 4 screen could not cover — run
  `govinfo.py cites --name "<short name>" --cite "<first citation>"
  --negative --context 5`. Read the returned passages: a hit counts only if
  the negative word is about *this* case.
- These searches see GovInfo's participating federal courts and nothing
  else. A clean result is reported as "no negative federal citer found in
  GovInfo," never as cleared, and hard rule 4's sentence still closes the
  section.

**B. State-court review dispositions** (no CourtListener budget). For every
state appellate decision under ~3 years old headed for Leading Authorities,
check the official source. CourtListener does not index these; a clean
citator says nothing. Name the source used.

- **Oregon** `[v10.0]` — scripted: `python3 scripts/statecourts.py
  or-history <OJD id>` (or `<A-number> --cite "326 Or. App. 117"` — always
  give the citation with a bare number). Run it for **every** Oregon Court
  of Appeals decision headed for Leading Authorities — it is free, so the
  three-year limit does not apply to Oregon — and for every
  Oregon-collection-only authority. Report only entries whose `relates_to`
  begins "this decision"; an "unconfirmed" entry is reported only after you
  have compared its citation and date with the decision; an entry with
  `view_the_list` only after viewing the list page. `complete: false` is
  "not checked: <what>", never an empty result. `found_any: false` with
  `complete: true` is "no review disposition located in the Oregon Supreme
  Court's published lists through <newest_list_in_collection>" — for a
  decision before about 2012 add that those lists are scans the search may
  not match (`state-sources.md` § 3). A
  `supreme_court_opinion_on_review` entry dated after the decision is a
  subsequent-history flag, not a footnote: fetch that opinion on the state
  lane (its `id` is in the entry), read what the Supreme Court did, and
  report it in Subsequent History with the Supreme Court's citation and its
  disposition as the opinion itself states it (the catalogue's note is a
  pointer, not the quotation). If the Oregon source is off because of a
  network failure, fall back to the WebFetch route in `statute-sources.md`;
  if it **refused** access, do not — report the check as not made.
- **Washington and every other state** — the WebFetch route in
  `statute-sources.md` § "State-court review dispositions", unchanged.

**B2. New York official-page check** `[v10.0]` (WebFetch, no CourtListener
budget). For every New York decision headed for Leading Authorities whose
row carried an `NY Slip Op` citation: `statecourts.py ny-url`, then the
two-fetch check in `state-sources.md` § 5. It can supply or confirm the
official citation, the corrected-through date and the publication status —
nothing else. The opinion is not read or quoted from that page.

**C. Statutes** (WebFetch, no CourtListener budget). Collect
`statutory_authorities[]` plus all `follow_up.statutes_cited[]`, dedupe, cap at
12, resolve per `statute-sources.md` — one provision per fetch, two-fetch
agreement before quoting, both fetches run early. Tally like quotes.

**D. Quote verification** (fan out as wide as you like — cached, free), **in
the lane the case was read in** (hard rule 2). No sampling, in any lane.

*GovInfo lane and state lanes* `[v10.0]` — you, not a subagent: write each
case's quotes to a JSON array and run `python3 scripts/govinfo.py verify
<granule_id | OJD-… | WA-…> quotes.json`, even though the analyzer already
ran it — the orchestrator's run is the one of record. On a state lane read
the output's `document_notes` first and carry each into the report
(nonprecedential; slip opinion; superseded slip; unpublished or published
in part; unresolved file; a separate opinion that could not be located),
and take the pin from `cite_pages`: Oregon `official_page` (a reporter pin,
attached only to the official-reporter citation), Washington `slip_page`
written `slip op. at N` and, when `opinion_part` names a judge, `slip op.
at N (Name, J., dissenting)`. Four cautions exist only on these lanes and
are settled like the others: **`fractured_decision`** — the text speaks of
a "lead opinion" or "plurality": view the opening of each opinion in the
PDF, establish which opinion the passage is from and how many judges
joined it, attribute it so, and correct the analyzer's `holding` if it
took a lead opinion's disposition for the court's; **`page_label`** — the page number was
inferred, unconfirmed or not read: view the PDF page before giving any pin;
**`unpublished_part`** — the passage is in the unpublished portion of a
part-published Washington opinion: label it so, and do not rest a holding
on it as precedent; **`separate_opinion`** in its two extra forms — "the
running head of this page reads …" (attribute to that judge) and "a
separate opinion in this document could not be located" (view the page and
establish whose words these are; until then the quote is not the court's).
Then, per quote:

- **`verified`, `cautions` empty** → publish, with the page from
  `cite_pages`.
- **`verified`, `cautions` not empty** → not yet publishable. Settle each:
  `lead_in` / `trail_off` — the quote starts or stops mid-sentence; the
  caution prints the rest of the sentence ("We think that nothing contained
  in…", "Mr. Bielski argues that…", "… not suffice."). Quote the whole
  sentence instead, or drop it; never present a party's argument or another
  court's rule as this court's holding. `footnote` — cite it as a footnote
  and view the page. `footnote_call` — read `source_text` and confirm the
  ignored digits are a footnote reference. `elision` — no longer arises on a verified quote:
  since the 2026-10-05 rebuild an ellipsis that omits **any** words of the
  opinion grades `likely` (below), because no word list can tell a harmless
  omission from "erred when it". `separate_opinion` — attribute the quote to the named judge or
  Justice in the report, and check that the analyzer's `holding` does not
  rest on it as the court's. `section_unknown` / `section_boundary` /
  `page_break` — view the page(s) (`Read` the cached PDF, `pages` = N) and
  confirm whose words they are and that they read continuously.
- **`likely`** → the quote as written is not the opinion's. Read
  `differences` and `problems`. **If a word differs** — not merely
  punctuation or spacing — the analyzer may have misread the passage:
  `grep` it, read the sentence in context, and correct `holding` /
  `relevance_summary` if they leaned on the wrong word. Then requote **whole
  sentences, with no ellipsis and no bracket beyond a capital letter**,
  trimming `source_sentences` (a window, not a finished quote; mind
  `joined_line_breaks`), run `verify` on the new quote, and publish only on
  `verified` with its cautions settled.
  Passing that second check proves the words are the opinion's; it does not
  prove the analysis is right — that is what the re-read is for.
- **`not_found`** → drop (a `not_opinion_text` note means the words were in
  a syllabus or staff summary; a "stitched" note means two separate
  passages were run together).

For an `ocr_layer` granule (or `ocr_undetermined`), a quote is publishable
only if the analyzer reported `viewed_page_image: true` for it; otherwise
view the page yourself or drop the quote — and a `likely` quote on an OCR
granule is requoted from the **page image**, not from `source_sentences`,
which is the OCR layer's text. A quote from an adopted F&R is attributed to
the magistrate judge.

*CourtListener lane* — as before. Every `key_quotes` entry headed for the
report: `search_document` the opinion for the exact text; grade `verified` /
`likely` / `not_found` with the retry rule in quirk 7. Have verifiers **return corrected verbatim text**
where the opinion differs from the quote handed them, and **run an absence
check** (match counts on a short distinctive stem) on any quote not sourced
from fetched text this session. `not_found` quotes are dropped or shown with
⚠. A quote from a case never read in full costs a metered first fetch —
budget it or drop it.

## Phase 8 — Report

Render per `references/report-format.md`, as markdown in chat. Then, without
waiting to be asked, build and deliver the Word memo per
`references/memo-format.md`. The memo re-presents the verified report; it
never adds authorities, quotes or research. Every About-table number is
computed from the run's own records — the call and pool figures from a
closing `get_api_usage`, the case and quote counts from the triage and
verification tables, the lane counts from the Phase 4 lane table — never
recalled.

## Follow-ups in this chat

"Go deeper on X" / "check the Ninth Circuit" is ONE scoped Phase 6 round:
plan → wave → analyze → re-run only the affected Phase 7 checks → re-render
only the affected report sections and the About row → regenerate the memo.
Never rerun the whole pipeline. Start the follow-up with `get_api_usage`; a
follow-up in the same hour shares the pool with whatever else ran. A
GovInfo- or state-lane case from the earlier round is re-read free (re-`fetch` if the
cache directory is gone); keep its lane.
