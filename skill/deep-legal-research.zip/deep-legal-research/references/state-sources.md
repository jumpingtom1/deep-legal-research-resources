# State court sources — Oregon, Washington, New York `[added v10.0, 2026-10-05 rebuild]`

GovInfo holds no state court (`govinfo.md` § 1), so until this rebuild every
Oregon, Washington and New York opinion cost one CourtListener unit to read.
Three state publishers were examined on 2026-10-05. They are not alike, and
the skill treats each according to what it actually allows. Every figure
here was measured that day; the methods are in `measurements.md` (M33–M40).

| Requested collection | What happened | What the skill uses |
|---|---|---|
| **Oregon** — Oregon Judicial Department digital collection, `ojd.contentdm.oclc.org` (CONTENTdm) | **Available.** A JSON API with no key; `robots.txt` asks only for `Crawl-Delay: 1` | **A full text lane** — the official Oregon Reports pages, with official page numbers — plus full-text search and the Supreme Court's review dispositions. `scripts/statecourts.py` |
| **Washington** — the official reports the courts.wa.gov "Lexis overview" page points to (`lexisnexis.com/clients/wareports`) | **Not available to automation.** LexisNexis's `robots.txt` disallows it; never fetched, by any route | **A slip-opinion text lane** from courts.wa.gov itself (2013 →; Court of Appeals published opinions from 2012), found through the court's own year listings. Slip text, *not* the official report — labelled as such everywhere |
| **New York** — the Official Reports on `govt.westlaw.com/nyofficial` | **Not available.** Westlaw blocks automated access; never fetched, by any route | **No text lane.** The Law Reporting Bureau's own page for a decision on `nycourts.gov` is reachable through WebFetch only (scripts are stopped by a browser check, which is not worked around). It is used for an **official-page check**: official citation, court, date, corrected-through date, publication status. New York opinions are still read and quote-verified through CourtListener |

**The division of labour does not change.** CourtListener finds cases in
every court, supplies reporter citations and is the only citator. These
sources supply *text* (Oregon, Washington), a second free discovery channel
(Oregon), one piece of subsequent history CourtListener lacks entirely
(Oregon review dispositions), and an official-page cross-check (New York).

## 1. The lane rule, extended

Every analyzed case has exactly one **text lane**, assigned in Phase 4 and
kept to the end of the run:

| Lane | Assigned when | Read with | Quotes verified with |
|---|---|---|---|
| `govinfo` | `govinfo.py resolve-batch` → `found: true` | `govinfo.py read` | `govinfo.py verify` |
| `state` | `statecourts.py resolve-batch` (or `or-resolve` / `wa-resolve`) → `found: true` with a `granule_id` beginning `OJD-` or `WA-`; or an Oregon-collection-only authority under § 6 | `govinfo.py read <id>` | `govinfo.py verify <id>` |
| `courtlistener` | everything else — including every New York case | `read_document` | `search_document` |

**Never read a case in one lane and verify it in the other** (hard rule 2).
The CourtListener text of an Oregon case and the Oregon Reports PDF are
different artifacts, exactly as CourtListener and GovInfo are for a federal
one. The text commands are the same script and the same verifier for all
three scripted lanes: `fetch`, `read`, `grep`, `triage` and `verify` take an
`OJD-…` or `WA-…` id exactly as they take a GovInfo granule id, and every
grade, caution and rule in `govinfo.md` § 3 (`verify`) applies unchanged.

A state lane is **optional and never blocking**. `statecourts.py probe` at
Phase 1 says which sources answer (it makes a live request to each; the
item counts it prints are of catalogue records titled "Opinion", not the
collection totals in § 3); a source that does not is the CourtListener lane
for the whole run, with one `ST` line (SKILL.md § Console output). A row
that does not resolve is the CourtListener lane for that case. Neither is a
reason to search harder, guess a file name, or fetch a page by another
route. **If a source answers with a refusal** (`automated access refused`,
HTTP 401/403/451) it is off for the run and nothing on that host is fetched
by any other tool either — including the WebFetch fallbacks elsewhere in
this skill that point at the same host.

## 2. The script

```
python3 scripts/statecourts.py probe
python3 scripts/statecourts.py resolve-batch rows.json        # same rows file as govinfo.py resolve-batch
python3 scripts/statecourts.py or-resolve --court orctapp --cite "326 Or. App. 117" --docket A176132 \
        --date 2023-05-17 --name "Garza v. Recology Oregon Recovery, Inc."
python3 scripts/statecourts.py or-search "procedurally and substantively unconscionable" arbitration \
        [--court or|orctapp|ortc|all] [--any] [--after 2015-01-01] [--before …] [-n 20]
python3 scripts/statecourts.py or-history OJD-p17027coll5-35851        # or a case number: A176132
python3 scripts/statecourts.py wa-resolve --court washctapp --docket 32978-0-III --date 2015-11-03 --name "…"
python3 scripts/statecourts.py wa-list --year 2024 --court wash [--status PUB|UNP|PAR] [--grep Barlow]
python3 scripts/statecourts.py ny-url "2023 NY Slip Op 04822"

python3 scripts/govinfo.py fetch|read|grep|triage|verify <OJD-… | WA-…>   # the text commands
```

No key. Needs Bash, outbound HTTPS to `ojd.contentdm.oclc.org` and
`www.courts.wa.gov`, and `pdftotext`. Requests to each host are spaced at
least 1.1 seconds apart **across every process sharing the cache directory**
(a lock file in the cache), so parallel analyzers cannot exceed the
publisher's crawl delay. Consequences: `resolve-batch` is sequential — about
3 seconds per Oregon row and, the first time a Washington year is touched, a
few seconds per listing page (cached for the day). **Run `resolve-batch` with
a 300-second timeout or in slices of ≤ 25 rows** (52 rows took 3 min 25 s,
M34). The same arithmetic governs the text commands the first time a state
document is fetched (two requests each): **`fetch` / `triage` at most ~20
uncached state ids per call, or with a 300-second timeout**; once cached
they are instant. The "twenty-five granules in five seconds" figure in
`govinfo.md` is GovInfo's, not these servers'.

Ids:

- `OJD-<collection>-<item>` — e.g. `OJD-p17027coll5-35851`. Collections:
  `p17027coll3` Supreme Court, `p17027coll5` Court of Appeals,
  `p17027coll6` Tax Court.
- `WA-<pdf file name, percent-encoded, without .pdf>` — e.g. `WA-1010451`,
  `WA-329780.pub`, `WA-D2%2044209-4-II%20%20Part-Published%20Opinion`.
  **Quote the id in the shell.** Never construct one. An id is a reading
  source only when it came from `resolve-batch` / `wa-resolve` (which
  checked docket, date and title); an id seen in `wa-list` must be passed
  through `wa-resolve` first — a file fetched without that carries
  `unresolved_note`.

### `resolve-batch` — CourtListener rows → state ids

Give it the same JSON array of search rows `govinfo.py resolve-batch` takes
(`caseName`, `citation`, `court_id`, `dateFiled`, `docketNumber`,
`cluster_id`). It handles rows whose `court_id` is `or`, `orctapp`, `ortc`,
`wash` or `washctapp`; for a New York **state** court row (`ny`,
`nyappdiv`, `nyappterm`, `nysupct` … — not the federal `nysd`, `nyed`,
`nynd`, `nywd` or their bankruptcy courts) it returns `found: false` with an
`official_page_url` for the § 5 check; every other row is "not served"
(those are `govinfo.py`'s, or nobody's). Run both scripts
on the same file; each ignores the other's rows.

**It never guesses.** A row is `found: true` only when all three agree:

| Source | Key | and | and |
|---|---|---|---|
| Oregon | the official citation of the row's own court (`326 Or. App. 117` → the catalogue's `326 Or App 117`; `21 Or. Tax 260` → `21 OTR 260`), **or**, failing that, the appellate case number in the docket string (`A176132`, `S071185`, `TC 5171`) | decision date equal | the case names agree on a **distinctive** party word |
| Washington | an appellate docket number in the docket string (`101,045-1` = `101045-1` = `No. 44209-4-II`; each number of a consolidated string is tried) in the court's listing for that year | file date equal | the case titles agree on a **distinctive** party word |

"Distinctive" excludes the words that say nothing about which case it is —
*State*, *Oregon*, *Washington*, *Dept.*, *Human Services*, *Board of
Parole*, *In re Marriage of* and the like. `State v. Momeni` does not match
`State v. Marshall` although both begin "State" (the first build accepted
that; review 4). **Each side of the caption is compared**: `SAIF v. Smith`
is not `SAIF v. Jones`, and `State v. Michael Smith` is not `State v.
Michael Jones` (the sides may be swapped — a listing can print the
appellant first). Words must be identical: `Johnson` is not `Johnston`, so
a name the court's own listing misspells is refused too (one of the twenty
Washington test rows — the CourtListener lane, not a reason to force it).
A name with nothing distinctive in it (initials only, as in juvenile cases)
must be the same once the generic words are removed: `… v. T. R. S.` is not
`… v. T. R. M.` (review 5).

For Oregon there is a fourth check when the match was by citation: **if the
row's docket string carries an appellate case number, it must be the
item's.** A row whose citation points at one case and whose number names
another is refused, with both shown.

A miss returns `found: false` with the reason and, where one exists, the
near-miss `candidate` — most often "the court lists this docket number with
a file date of 2021-05-03, not 2021-01-25": an amended or substituted
opinion, or a CourtListener date a day off. **A near miss is the
CourtListener lane.** Do not re-run with the candidate's date to force a
match; the two texts may differ.

Measured on real CourtListener rows (M34, final rules): Oregon Court of
Appeals **19 of 19** in-coverage rows resolved (the twentieth, a 1986
decision, predates the collection and was reported as such); Washington
Court of Appeals **16 of 20** (three date mismatches and one name the
court's listing misspells, all refused); New York 10 of 12 rows yielded a
URL (two 2013 rows carried no slip-opinion citation).

Fields worth reading on a found row: `document_type` and
`nonprecedential` / `nonprecedential_note` (Oregon); `pub_status`,
`publication_note`, `superseded_slip` / `superseded_note` and `order_note`
(Washington); `citation_differs`; `ambiguous`. The same sentences reappear
as **`document_notes`** at the top of every `read`, `grep`, `triage` and
`verify` output for the document — that list, not the individual keys, is
what the text commands print.

`ambiguous: true` (with `other_items_same_date` / `other_files_same_date`)
means several catalogue items or files share the key and the date. `fetch`
each id and read its opening: use the one that is the opinion for the row's
case; if that is not plain, the case is the CourtListener lane.

## 3. Oregon — the official reports

**What the collection holds** (catalogue counts 2026-10-05):

| Collection | Holds | From | Items |
|---|---|---|---|
| Supreme Court `p17027coll3` | Opinions as printed in the Oregon Reports; **the petitions-for-review lists** (641 of them) | 326 Or 1 (Aug. 21, 1997) → current week. A handful of stray older volumes | 3,162 |
| Court of Appeals `p17027coll5` | Opinions as printed in the Oregon Reports, Court of Appeals; nonprecedential memorandum opinions (2,447) | 152 Or App (Jan. 7, 1998) → current week | 19,480 |
| Tax Court `p17027coll6` | Regular Division opinions with `OTR` citations; Magistrate Division decisions (no citation) | 1 OTR (1962) → current | 8,285 |

Older decisions, and anything the catalogue does not carry, are the
CourtListener lane.

**What the text is.** The PDF is the page as published in the official
reports: the running head carries the official page number (`Cite as 375 Or
580 (2026)   581`), so **a pin cite to the official reporter can be given
and checked** — something CourtListener's text does not support. Every page
label `read` and `verify` print looks like

```
{"pdf_page": 2, "official_page": 118, "pin": "326 Or App at 118"}
```

(that is the `cite_pages` entry in `verify` and `grep` output; `read`
prints the same thing as a page heading, `[326 Or App at 118 (official
page; PDF page 2 of 5)]`). Use `official_page` for the pin. A label can
also carry `page_number_unconfirmed` (the number read does not continue its
neighbours) or `official_page_inferred` (not printed on that page; implied
by confirmed neighbours), or have `official_page: null` with a `page_note`.
In all three cases `verify` adds a **`page_label` caution** to the quote and
`read` says so in the heading (`INFERRED`, `UNCONFIRMED`, `NOT READ`):
**view the PDF page before giving a pin.** Scanned volumes have lettered
insert pages (`56-a`, `56-b`); they are labelled as printed.

**What is not the opinion.** Each document opens with a caption page —
parties, case numbers, counsel, the panel, the disposition line — and
often a **staff-written case summary** ("… *Held:* …"; present in every
sampled Supreme Court and Court of Appeals opinion dated 2011–2021 and in
the Tax Court sample, absent from those dated 2023 →). None of it is the
court's reasoning, whether or not a summary is there. The engine lifts everything before the opinion's opening out of the
quotable text. The opening is the authoring judge's name standing alone on a
line and followed by the opinion's paragraphs (the same name stands once
before, in the caption block, followed only by the disposition); in the Tax
Court, the `NAME, Judge.` line:

- `read` prints it inside a `----- … (NOT opinion text) -----` block;
- `grep` reports hits there under `outside_the_opinion`;
- `verify` grades a quote found only there `not_found` with
  `not_opinion_text` — the same refusal as a Supreme Court syllabus.

If the opening is not recognised (an OCR scan can garble the author line; a
Tax Court Magistrate Division decision has a different layout), page 1 is
still withheld and the document carries a `document_notes` entry saying so:
view the PDF before quoting from the first pages. Measured (M36): 551
sentences sampled from front matter in 97 documents — 528 refused, and the
23 that verified are sentences the opinion itself repeats (a disposition
line, a sentence the summary copied), verified at their page in the opinion.

"Never quoted" means never quoted **as the court's reasoning**. The
caption's own history line ("petition for review denied …") and the
catalogue's disposition note are reported as *history*, attributed to the
caption or the catalogue — see `or-history` below.

**Separate opinions.** Headings of the form `JAMES, J., dissenting.` /
`EGAN, C. J., dissenting.` / `X, J. pro tempore, concurring` are detected,
including the OCR forms `ARMSTRONG,J., dissenting` and `ARMSTRONG, P. J .,
dissenting`. As a cross-check the engine reads the caption, which lists
every separate opinion (`Kamins, J., dissenting.`): a judge named there
whose heading it cannot find in the text makes **every** quote from the
document carry a `separate_opinion` caution until the page is viewed. A
separate opinion's footnotes restart at 1; they are followed as a second
sequence, and a footnote on a page wholly inside a dissent is attributed to
that judge.

**Decisions with no majority opinion.** A file can hold a per curiam
followed by a signed "lead opinion" of fewer than a majority, or a
plurality; the first signed opinion in the file is then not the court's,
and its disposition can differ from the court's (review 5: a Washington
per curiam affirming, followed by a three-justice lead opinion that would
vacate, was labelled "the court's opinion"). No heading says so. When the
text of an Oregon or Washington document uses the words "lead opinion" or
"plurality", every quote from it carries a **`fractured_decision`** caution
and `document_notes` says why. The phrase may be describing another case —
that is what viewing the pages settles: say which opinion the passage is
from and how many judges joined it, and never call it the court's holding
unless a majority did.

**Footnotes — what the splitter can miss.** Footnote text is separated from
the body by its number: the next number in sequence, set like a footnote
(indented, set off, or after a sentence end), not followed by a lowercase
word, and — when the same number heads two lines of a page — the later of
the two (the earlier is a superscript call that the text extraction put on
a line of its own). An OCR scan that misreads a footnote number, or a PDF
whose text order puts a footnote's first line above its number, defeats
this: **the footnote then reads as body text and a quote from it verifies
with no `footnote` caution** (correct page, missing "n."), or does not
verify at all. So: when a quote sits low on a page of a document that has
footnotes — above all in a scan — view the page before citing it as text.

**Nonprecedential memorandum opinions.** Since 2022 the Court of Appeals
issues these under ORAP 10.30; they have Oregon Reports citations and look
like any other opinion in a search result. The catalogue marks them
(`document_type: "Nonprecedential opinion"`), and `resolve-batch` carries `nonprecedential_note`, and `read`,
`triage`, `grep` and `verify` print the same sentence in `document_notes`. **Say
"nonprecedential memorandum opinion" wherever one is cited**, and do not
present one as binding authority. The label follows the *decision*, not the
lane: an Oregon Court of Appeals row from 2022 on that is read through
CourtListener (source off, or a near miss) is checked for the same thing —
its text opens "This is a nonprecedential memorandum opinion pursuant to
ORAP 10.30" — and labelled the same way.

**OCR.** The older items are page scans (`ocr_layer: true` on every
sampled opinion dated 2001–2011; born-digital from 2012 in the sample).
The OCR rule of hard rule 9 applies: view the PDF page (Read tool,
`pages=N` on `pdf_path`) before publishing a quote.

**Identity check.** `fetch` reports `identity_check`: whether the
catalogue's case number and citation appear in the document's opening
pages. Both `false` (with a `warning`) means confirm the caption before
relying on the text.

### `or-search` — a free second discovery channel for Oregon

Full-text search of the collection, zero CourtListener units. A multi-word
argument is an exact phrase; the arguments are ANDed (`--any` ORs them); `*`
is a wildcard; `--after` / `--before` filter by decision date (a
`truncated` entry in the output means paging stopped before `-n` was
filled: narrow the terms or the dates). Results are
**newest first — not relevance-ranked — with no proximity operator and no
citation counts.** Measured against CourtListener on the same court and
period (M35): `unconscionable` in the Court of Appeals since 1998 —
CourtListener 91 rows (which include duplicate clusters of recent opinions),
OJD 66 distinct opinions; the phrase "procedurally and substantively
unconscionable" — CourtListener 3, OJD 4 (the same three plus a
nonprecedential opinion CourtListener holds but did not return for the
phrase). Treat it as a strong
discovery aid, **not** a completeness guarantee, and never as a citator.

`or-search` also returns things that are not opinions — the
petitions-for-review lists, and Tax Court Magistrate Division decisions
(title `TC-MD …, Unpublished`, no citation). A result whose `title` does not
end in "Opinion" is not a candidate **for Leading Authorities**; `fetch`
flags one with `not_an_opinion_note`. `[v10.3]` It may still be read as a
**lead source**: the cases and phrases it cites can enter the Phase 6
ledger like any analyzed case's (scored at most 3, labelled as what it is).
In the ORS 12.220 run an unpublished Tax Court order was the only route to
*Wallace v. Holden*, the one personal-jurisdiction decision found;
`resolve-batch` returns `found: true` for such items, which is not a
licence to cite them as opinions.

Every `or-search` candidate that survives triage still needs its
CourtListener row (Phase 4, one batched call per court, by case number —
`pipeline.md` Phase 4) for the `cluster_id`, the parallel `P.3d` citation
and the history screen. A candidate CourtListener does not have is handled
as § 6 below.

### `or-history` — review dispositions, scripted

CourtListener does not index state supreme court review dispositions (hard
rule 6). For Oregon the check is one command, off the budget; the WebFetch
route in `statute-sources.md` remains only as a fallback for a network
failure (never after a refusal — § 1):

```
python3 scripts/statecourts.py or-history OJD-p17027coll5-35851     # or: or-history A176132 --cite "326 Or. App. 117"
```

**Give it the decision, not just the case number.** With an `OJD-` id the
citation and date are known; with a bare number pass `--cite` (either
`326 Or App 117` or `326 Or. App. 117`). It reads up to three official
records and reports each separately:

1. **`caption_of_the_opinion`** (Court of Appeals decisions the collection
   holds) — bound-volume pages print later history in the caption
   ("petition for review denied May 14, 2015 (357 Or 299)"). Recent items
   are advance-sheet pages and cannot; silence there is not evidence.
2. **`supreme_court_opinion_on_review`** — Supreme Court opinions whose
   record names this Court of Appeals case number, with citation, date and
   the catalogue's disposition note. One dated after the decision checked
   is a subsequent-history flag: read that opinion on the state lane and
   report what it did in the court's own words.
3. **`petitions_for_review_lists`** — entries in the Supreme Court's
   published lists (641 lists, Aug. 1997 →) **whose own citation block names
   this case number**, with the heading the entry sits under (`ALLOWED`,
   `DENIED`, `DISMISSED`, `WITHDRAWN` …), the date, the entry verbatim, and
   the list's own citation (`371 Or 535`). An entry about another case that
   merely mentions this one is listed apart, under
   `mentioned_in_other_entries`, and is never a disposition of this case.

**Every entry carries `relates_to`** — read it before reporting anything:

| `relates_to` begins | Means | Do |
|---|---|---|
| `this decision (… is printed in the entry's own citation)` | the entry prints the citation checked | report it |
| `a DIFFERENT decision in the same case number` | the entry prints another citation: one case number can have several decisions (*State Treasurer v. Marsh & McLennan*, A139453: 241 Or App 107 in 2011, review allowed, reversed 353 Or 1; then 269 Or App 31 in 2015, review denied 357 Or 299) | do **not** report it as this decision's history; mention as prior history only where it matters |
| `unconfirmed: …` | no citation was given, or the entry prints none | compare the entry's citation and date with the decision yourself; report only if they match, and say how it was matched |
| `this Supreme Court case: …` | the target was an S-number: the petition that brought the case up | history of the case below, not of the Supreme Court opinion |
| `an EARLIER Supreme Court decision …` / `decided after …` | a Supreme Court opinion's place in time | earlier = prior history; later = read it |

An entry with **`view_the_list`** was matched in the OCR text of a scanned
list (lists before about 2012), sometimes through a misread character
(`(Al40553)` for A140553): **open the list PDF page (`Read` the cached file)
and confirm the heading, the case and the date** before reporting it.

Reading the result as a whole:

- **`complete: false`** — some record could not be read; `not_checked` says
  which. That is "not checked", **not** an empty result: say what was not
  checked.
- **`found_any: false` with `complete: true`** — no list or opinion found
  names this case. A petition may be pending, may postdate
  `newest_list_in_collection`, may sit under a consolidated number
  (`A180517-19`), or — for a decision before about 2012 — may be printed in
  a scan in a form the search did not match (the script tries the usual OCR
  misreadings of the number, the citation and the first party's name, and
  can still miss). Report "no review disposition located in the Oregon
  Supreme Court's published lists through <newest list>" — never "review
  was not sought."
- **`several_decisions_under_this_number`** — a bare case number named more
  than one decision and no `--cite` was given: run it again with the
  citation.
- **`decision_not_in_catalogue`** — the citation given is not the one the
  catalogue holds under that number (a decision without opinion, or a wrong
  citation or number). The caption check is then skipped or marked "a
  DIFFERENT decision"; only list entries printing the citation given count.

### Citing an Oregon case read on this lane

- **Reporter citation** — CourtListener's `citation` array, verbatim (hard
  rule 1). **Only when that array holds no official-reporter citation**
  (`Or.` / `Or. App.` / `Or. Tax`) — it is empty, or holds only a `P.3d` —
  may the catalogue's `citation` field supply the official one, converted
  mechanically to Bluebook abbreviation (`326 Or App 117` → `326 Or. App.
  117`; `375 Or 580` → `375 Or. 580`; `21 OTR 260` → `21 Or. Tax 260`) and
  marked in the About table as taken from the Oregon Judicial Department
  catalogue. It is **added**, never substituted for a citation the API
  gave. If the two disagree (`citation_differs`), use neither silently:
  report both.
- **Pin** — the `official_page` of the page the verified quote is on,
  attached **only to the official-reporter citation**: `326 Or. App. 117,
  118 (2023)`. Never attach it to a `P.3d` citation. For a footnote, add
  `n.<number>` only after viewing the page (the verifier says a passage is
  footnote text, not which footnote).
- **Link** — the case name still links to CourtListener's `absolute_url`
  when the case has a row; add the collection's `public_url` as the source
  of the text in the memo's source list.

## 4. Washington — slip opinions

**What courts.wa.gov holds.** The opinions as filed, by year: Supreme Court
2013 →, Court of Appeals published 2012 →, unpublished and
published-in-part 2013 →. (The script accepts rows from 2012 on; a 2012 row
resolves only if it is a published Court of Appeals opinion.) The script finds an opinion only through the
court's own listing for the year, court level and publication status —
`wa-list` shows a listing; `wa-resolve` / `resolve-batch` match a
CourtListener row against it. **The site's search form is JavaScript-driven
and is not used. Never construct any other courts.wa.gov query URL** — a
guessed one returns an error inside normal page chrome (statute-sources.md,
Washington row).

**What the text is — and is not.** It is the **slip opinion**. The official
text is the bound report (Wn.2d; Wn. App. and Wn. App. 2d — the court's
own notice says "Washington Appellate Reports"), reachable only on the
LexisNexis site that disallows automated access. Therefore:

- **Cite pages as `slip op. at N`**, never as a reporter pin. The reporter
  citation itself still comes from CourtListener (hard rule 1).
- The court marks a slip opinion that the official report has since
  replaced with a red asterisk in its listing and a cover sheet in the PDF.
  The script carries that as `superseded_slip: true` and a
  `superseded_note`; the cover sheet is withheld from the quotable text.
  **A quote verified on this lane is verified against the slip opinion.**
  Where the opinion is marked superseded, say so beside the quote —
  `✓ verified (slip opinion; official report may differ in wording)` —
  because pre-publication edits "for style, grammar, citation, format,
  punctuation" are made before the bound volume (the court's own notice).
- `file_contains` says what the PDF holds ("Maj., Dis., and Con/Dis
  Opinions", "Order and Opinion"). An `order_note` means an order changed,
  withdrew or accompanies the opinion: read the order first.
- `pub_status`: `PUB`, `UNP` (unpublished — nonbinding, GR 14.1 limits
  citation; say "unpublished" wherever cited), `PAR` (published in part).
  `document_notes` carries the sentence. In a part-published opinion the
  court marks the divide ("only the foregoing portion of this opinion will
  be printed in the Washington Appellate Reports"); a quote from text after
  it carries an **`unpublished_part` caution** and is labelled "unpublished
  portion" in the report. If the dividing statement is not found, the note
  says so: view the PDF.

**Page labels.** `{"pdf_page": 6, "slip_page": 5}` — the number printed on
the page. **Each separate opinion restarts at 1**, and its first page is
usually unnumbered, so a `slip_page` is only meaningful with the opinion it
belongs to: when `verify` reports `opinion_part` other than the court's
opinion, the pin is written `slip op. at 3 (Montoya-Lewis, J.,
dissenting)`. `slip_page: null` (with `page_note`) or `slip_page_inferred`
puts a **`page_label` caution** on the quote → view the PDF page.

**Separate opinions** are detected three ways, because the first build
missed three dissents on its heading pattern alone (review 4): the heading
(`MONTOYA-LEWIS, J. (dissenting)`, `(dissent in part)`, `(concurrence)`,
`( dissenting in part, concurring in part)`, `(Concur in part, Dissent in
part)`, `(specially concurring)`, `YU, J.* (concurring)`, `J.P.T.`); the page's running
head (`(Montoya-Lewis, J., dissenting)`, `State v. Gonzalez - Dissent`); and
the court's listing (`file_contains`: "Maj., and Dis. Opinions"). If the
listing promises more separate opinions than headings were found, **every**
quote from the file carries a `separate_opinion` caution until the page is
viewed. The count is a floor, not a guarantee — "Con/Dis Opinions" in the
listing can be two opinions — and the `fractured_decision` caution (§ 3)
applies to Washington files as well. **The analyzer's own reading remains
the first control**: it reads every page, and a heading the script missed
is still a heading.

**OCR.** Court of Appeals opinions were scans in every sampled file dated
2013–2019 (born-digital from 2020 in the sample);
`ocr_layer: true` and the view-the-page rule apply.

**Washington review dispositions** are unchanged from v9.6: the WebFetch
route in `statute-sources.md` (the Supreme Court's ORDERS page). Nothing
here scripts them.

## 5. New York — the official-page check

There is no scripted access to New York text and none is attempted. What is
available is one page per decision on the Law Reporting Bureau's own site,
through **WebFetch only**:

```
python3 scripts/statecourts.py ny-url "2023 NY Slip Op 04822"
→ https://www.nycourts.gov/reporter/3dseries/2023/2023_04822.htm
```

The address is *built* from the slip-opinion number in CourtListener's
`citation` array (years 2003 →; the number is zero-padded to five digits;
unreported `(U)` dispositions use the same form); `resolve-batch` returns it
as `official_page_url` on New York state-court rows. A row with no
`NY Slip Op` citation yields nothing — say so and move on. A page that does not name the
same case is a **miss**, not a correction.

**The check** (Phase 7, for every New York case headed to Leading
Authorities; zero CourtListener units):

1. WebFetch the URL, asking only for: the case-name line; the citation in
   square brackets at the top; the slip-opinion line; the decision date; the
   court; any "As corrected through …" line; any statement that the opinion
   is uncorrected or will not be published in the printed Official Reports.
2. WebFetch it a second time (append `?v=2` to defeat the cache) with the
   same request. **Use a fact only if both fetches return it identically** —
   the two-fetch rule that governs statutes (hard rule 3) governs this page
   too, because WebFetch summarizes.
3. Confirm the case name, court and date match the CourtListener row. If
   they do not: report "official page not confirmed" and use nothing from it.
4. What may be used:
   - the **official citation** in brackets (`[219 AD3d 1251]`) — **added**
     when CourtListener's row holds no official-reporter citation, or noted
     as confirming the one it has. It never replaces a citation the API
     gave; if the two disagree, report both. Re-abbreviate mechanically and
     only by this table — `AD3d` → `A.D.3d`, `AD2d` → `A.D.2d`, `NY3d` →
     `N.Y.3d`, `NY2d` → `N.Y.2d`, `Misc 3d` → `Misc. 3d`, `Misc 2d` →
     `Misc. 2d`; any other form is copied as printed. Mark it in the About
     table as read from the Law Reporting Bureau page;
   - the **court and decision date** — as confirmation of the row (step 3);
   - the **"As corrected through"** date — reported in the *Treatment* line
     when later than the decision date;
   - **publication status** — an unreported `(U)` disposition is labelled
     "unreported disposition — not published in the printed Official
     Reports" wherever it is cited.
5. What may **not** be done: quote the opinion from this page, read the
   opinion from it, or treat it as the lane. WebFetch returns a model's
   rendering, not the text; quotes are verified in the CourtListener lane
   (hard rule 2). An analyzer never receives this URL as a reading source.

Tested 2026-10-05 (M38): three pages fetched — *Mejia v Linares*, 2023 NY
Slip Op 04822, `[219 AD3d 1251]`, "As corrected through Wednesday, November
8, 2023"; *Patel v Macys Inc.*, 2019 NY Slip Op 00684, `[168 AD3d 632]`;
*People v Bowman*, 2024 NY Slip Op 50001(U), `[81 Misc 3d 1223(A)]`, "will
not be published in the printed Official Reports." Each matched its
CourtListener row.

## 6. An Oregon decision found only by `or-search`

If the one batched Phase 4 call returns no CourtListener row for an
`or-search` candidate, it may still be analyzed on the `state` lane, under
the same conditions as a GovInfo-only authority (`govinfo.md` § 4):

- only an item whose catalogue `document_type` is an opinion with an
  official citation — not a petitions list, and not a Tax Court Magistrate
  Division decision (those have no citation; list one under *Surfaced but
  not read in full* with its `TC-MD` number and `public_url` if it matters);
- its id came from `or-search` and its identity is confirmed the same way
  as any other: `fetch` it and check `identity_check` and the opening;
- cited from catalogue fields only: `*<case_name>*, <citation converted to
  Bluebook abbreviation> (<year>)` — the reporter identifies the court, so
  no court parenthetical — pin from `official_page`, linked to `public_url`;
- marked *(Oregon Judicial Department collection — not citator-covered)*;
- no CourtListener citator can be run on it, so its subsequent history is
  whatever `or-history` returns plus the caption — say exactly that, and
  hard rule 4's sentence still closes the section.

## 7. Quirks — S1 to S30

Every entry was met while building or testing this lane.

| # | Quirk | Rule |
|---|---|---|
| S1 | An OJD item can be a *compound object*: the item JSON answers with its first page and a one-page download | The script takes the parent's metadata and `downloadParentUri`. Never build a download URL by hand |
| S2 | The caption page and the staff case summary read like the court's words | § 3: withheld, `not_opinion_text`. Never quote a "*Held:*" sentence |
| S3 | Nonprecedential memorandum opinions carry official citations | § 3: `nonprecedential_note`; say so wherever cited |
| S4 | Lettered insert pages (`56-a`) and OCR-misread page numbers in scanned volumes | Use the label; `page_number_unconfirmed` / `null` → view the page |
| S5 | Only bound-volume pages print subsequent history in the caption | Silence in a recent caption is not evidence |
| S6 | One case number, several decisions | `or-history` `relates_to`; report only entries for the decision cited |
| S7 | Consolidated numbers are printed as ranges (`A180517-19`) | `or-history` on `A180518` finds nothing: run it on the lead number, and say which number was checked |
| S8 | CourtListener holds duplicate clusters of recent Oregon opinions, one with an empty `citation` array | Dedupe candidates on docket + date; resolve either row — both reach the same OJD item (the second by case number) |
| S9 | `or-search` is newest-first, unranked, no proximity, and returns petitions lists and Magistrate decisions beside opinions | § 3: discovery aid; triage decides relevance; a title not ending in "Opinion" is not a candidate |
| S10 | The collection occasionally answers a download with a web page | The script retries once; a second failure is `found: false` → CourtListener lane |
| S11 | One request a second | `resolve-batch` with a 300 s timeout or ≤ 25 rows a slice; first `fetch` / `triage` of ≤ 20 uncached state ids a call; never parallelize around the lock |
| S12 | A date field can hold two dates (`1997-08-12 ; 1997-08-20`) | The script matches either |
| S13 | Washington: amended or substituted opinions, and CourtListener dates a day off, fail the date test | § 2: a near miss is the CourtListener lane |
| S14 | Washington: red-asterisk slips are no longer the official opinion | § 4: `superseded_note`; label the quote |
| S15 | Washington: each separate opinion restarts page numbering | § 4: pin names the opinion |
| S16 | Washington: running heads, the Lexis pointer line and a garbled-glyph copy of it sit at the top of every page (Division I prints `No. 79086-2-I/6`, number and page together) | Stripped only as an unbroken run from the top of the page and only if header-like; a stray OCR variant left in place makes a page-spanning quote grade `likely` — requote within one page |
| S17 | Washington file names contain spaces and vary (`1010451`, `329780.pub`, `314995.unp`, `D2 44209-4-II  Part-Published Opinion`) | Ids are percent-encoded; quote them; never construct one |
| S18 | Washington: a PDF fetched by file name without `wa-resolve` has no listing metadata | The document carries `unresolved_note`; resolve first |
| S19 | New York: nycourts.gov stops scripts with a browser check | WebFetch only. Never curl, never a script, never a mirror or archive |
| S20 | New York: `(U)` pages show a `Misc 3d …(A)` table citation and "will not be published" | § 5: label as unreported |
| S21 | `govt.westlaw.com/nyofficial` and `lexisnexis.com/clients/wareports` refuse automated access | Never fetched. If a user asks for text from them, say they are not reachable and offer the lane above |
| S22 | Review lists before about 2012 are scans: `(Al40553)` for A140553, `}` for `)` | `or-history` retries the usual misreadings, the citation and the party name, and marks such an entry `view_the_list`; an empty result for a pre-2012 decision is weaker evidence than for a recent one — say so |
| S23 | Decisions affirmed without opinion share one page of the reports, so dozens of cases share one citation (`236 Or App 269`) | A citation alone never identifies a list entry; the case number must be in the entry's own citation block |
| S24 | A list entry's commentary can name another case ("held in abeyance until the court has decided *Barrett* … (A177883)") | Only the leading name-and-parentheses block identifies the entry's case; mentions are reported apart |
| S25 | Footnote calls can sit on a line of their own, or glue to a word (`of30 years`) in an OCR scan | A lone number far from the left margin is not a footnote start; a `footnote_call` caution means read `source_text` — the digits may belong to the sentence |
| S26 | A body line can begin with a number (`Section` / `2 of the FAA provides`; a block-quote line `10 days before …`) | In state documents a footnote must be set like one (indented, set off, or after a sentence end), must not continue in lowercase, and must be the last line on the page carrying its number; the first build moved half a page of opinion into the footnote stream |
| S27 | A footnote can still be missed (OCR misreads its number; the PDF's text order puts its first line above the number) | § 3: it then verifies as body text with no `footnote` caution, or not at all — view the page for a quote low on a footnoted page, above all in a scan |
| S28 | A per curiam with a signed lead opinion, or a plurality, has no majority opinion; no heading says so | § 3: `fractured_decision` on every quote when the text says "lead opinion" or "plurality"; view the pages and say whose opinion it is |
| S29 | The court's own listing can misspell a party (`Sailvi` for Saili); captions share generic words and initials | § 2: names must agree word for word on each side; a refusal is the CourtListener lane |
| S30 | A catalogue number can hold a decision the catalogue does not carry under the citation given (affirmed without opinion) | `or-history` says `decision_not_in_catalogue` and does not borrow another decision's caption |

## 8. What this changes in the budget

Every analyzed case on a `state` lane is one CourtListener unit not spent —
the same arithmetic as the GovInfo lane (`govinfo.md` § 6):
`wave_cost = CourtListener-lane unread opinions`. For an Oregon-law question
the saving is now most of the reading budget: Oregon appellate opinions since
1998 and the District of Oregon / Ninth Circuit decisions applying them are
all off the pool. Oregon review dispositions cost nothing and no longer need
WebFetch. What still costs units: the searches, the citators, the Phase 4
batch, and reading anything older than the collections, any New York case,
and any Washington opinion before 2013 or with a date mismatch.

## 9. What was measured (summary; detail in `measurements.md`)

- Crosswalk (M34, final rules): Oregon 19/19 in coverage; Washington
  16/20; New York URL for 10/12. Rows built to be mismatched — "State v. …"
  against another "State v. …", initials-only juvenile captions one letter
  apart, a citation paired with another case's number — were all refused.
- Verifier on state documents (M36, final engine): 97 opinions (69 Oregon —
  Supreme Court, Court of Appeals including scans and nonprecedential, Tax
  Court; 28 Washington — Supreme Court and Court of Appeals including
  scans, unpublished and part-published) — 5,358 sentences sampled; 5,300
  verified, 58 graded `likely` (sampled across a footnote or page
  boundary), 0 not found; 5,300 of 5,300 one-word alterations refused;
  2,088 of 2,088 changed digits refused; 388 of 388 fabricated holdings
  `not_found`; 551 front-matter sentences sampled, 528 refused, the 23 that
  verified being sentences the opinion repeats.
- Two rounds of independent adversarial review (M39). Round 4 reproduced
  sixteen defects in the first build of these lanes — three dissents graded
  as the court's opinion, a review disposition attributed to the wrong
  case, a name test that "State" alone satisfied, caption text read as
  opinion, body text read as footnote, an ellipsis hiding "erred when it".
  Round 5 confirmed all sixteen fixed and reproduced seven more — a
  three-justice lead opinion labelled the court's, one judge's separate
  opinion attributed to another, initials-only captions matched, a
  caption's history borrowed for another decision, two footnote-splitting
  errors, a caption cross-check that never fired for Supreme Court
  opinions. Each was fixed and re-tested on the reviewers' own files. Round
  5's own counts on the round-4 build: 0 false `verified` in about 4,500
  alterations; 34 page labels checked against page images, 0 wrong; 90
  review-list entries checked, 0 wrong.
- Federal regression (M37): the engine changes for these lanes left the
  federal results identical — 68 GovInfo documents, the released engine's
  and this engine's output the same line for line, after every round of
  fixes.
- **Not measured:** no full Phase 1 → 8 run has been made with the state
  lanes (O12); the Washington official-report wording has never been
  compared with a slip opinion, because the official text is not reachable
  (O13); the round-5 fixes have not themselves been independently reviewed,
  and footnote detection in scans is known to be incomplete (O14).
