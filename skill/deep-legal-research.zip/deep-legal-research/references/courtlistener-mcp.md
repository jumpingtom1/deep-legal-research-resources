# CourtListener MCP — recipes

Connector tools: `search`, `get_more_results`, `read_document`,
`search_document`, `analyze_citations`, `extract_citations`, `call_endpoint`,
`get_endpoint_schema`, `get_endpoint_item`, `get_choices`.

The rate-limit model and the known-quirk list are in
`references/subagent-briefing.md`, which every subagent receives verbatim.
This file is the query construction and the specific recipes. Budget rules
and per-phase allocation are in `pipeline.md` § Budget.

`[v10.0]` CourtListener is one of several sources. It remains the only one
for most state courts, for searching by relevance and citation count, for
reporter citations and for the citator. For the federal opinions GovInfo
holds, the **text** is read and quote-checked through `scripts/govinfo.py`
instead (`govinfo.md`); for Oregon appellate opinions since 1998 and
Washington slip opinions since 2013, through the same text commands on an id
from `scripts/statecourts.py` (`state-sources.md`). Both cost nothing here. The
sections "Reading opinions" and "Quote verification" below govern
**CourtListener-lane** cases only.

## Searching case law

- `search` with `type: "o"`. Always pass the `fields` list and the three
  `stat_*` flags from the briefing. Every row also carries `opinion_id` and
  `cluster_opinions` even when not in `fields` (quirks 18, 20) — carry them
  through; `opinion_id` is what `read_document` and `cites:()` need.
- Pattern `[Core Concept] AND ([Variant1] OR [Variant2])`. Never AND 5+
  concepts; never stack 4+ OR-groups on a `court` filter (quirk 4). To cover
  two court levels, run the query once per court ID.
- **One court ID per call** (quirk 12). Never spend a call on `get_choices`
  — the orchestrator resolves IDs from the table below and passes them down.
- Two modes. **Keyword** (default) for a known phrase, a name, a citation,
  a statute section, every `cites:` query, and any query ordered by
  `citeCount`. **Semantic** (`semantic: true`) for the issue itself, stated
  in plain language — see § "Semantic search" below. A research plan uses
  both; the semantic strategy is designed first (pipeline Phase 3).
- Operators: phrase `"…"`; proximity `"a b"~50`; wildcards `immigra*`,
  `disavow*`; fielded `caseName:`, `judge:`, `docketNumber:`, `citation:`,
  `citeCount:[50 TO *]`; grouping `()`; exclusion `-term`;
  `related:<opinion_id>`.
- Structured filters: `judge`, `citation`, `docket_number`, `cited_gt`,
  `filed_after` / `filed_before`; `order_by: "citeCount desc"` for a
  leading-authority strategy. Prefer `citeCount desc` over `dateFiled desc`,
  which returns mostly RECAP trial-court documents (quirk 34).
- **`num_results` is not free** `[measured v10.0, M29 — supersedes "one call
  beats two"; re-confirmed v10.3, M44]`: a search costs one unit per 20 rows
  it actually returns, minimum one (a zero-row search costs 1; a 100-row
  request returning 26 rows costs 2; a semantic search costs 1). The 5/min
  window counts the same pages. Use
  20 for sweeps (1 unit), 40 for a raw citator (2 units), and 100 only for
  the Phase 4 history screen, where completeness is the point (1 unit per
  20 rows actually returned — usually 1–3). A query
  with few hits costs 1 whatever was requested, so a tight query is the
  cheap one. `get_more_results` is the same price per page — fetch a second
  page only when `count` and the first page say it is worth it.

## Semantic search `[v10.2; measured 2026-10-10, M41]`

```
search(type="o", semantic=true, court=["orctapp"],
       q="When is an arbitration clause in an employment contract
          unconscionable because the employer can unilaterally modify it?",
       filed_after="2005-01-01", filed_before="2009-01-01",
       stat_Published=true, stat_Unpublished=true, stat_Unknown=true,
       num_results=20, fields=[<standard list>])
```

- **`q` is a question, not a query.** One plain-language sentence stating
  the issue (or, for a fact search, the fact pattern). No `AND`/`OR`,
  quotes, wildcards or field prefixes — those are keyword syntax and their
  effect in this mode is untested (O15).
- **The index is not limited to recent opinions.** With a date filter it
  returned Oregon Court of Appeals decisions from 1988–1994 and U.S. Supreme
  Court decisions from 1981–1984. The v9-era rule that semantic search
  "reaches only the last 24 months" was a wrong inference from a real
  observation, which is the next point.
- **Unwindowed, it returns only the newest few years the court has.** Every
  page measured sat just under its upper date bound: no filter → 2016–2025
  (Or.) and 2014–2026 (U.S.); `filed_before` 2015 → 2007–2014;
  `filed_before` 1995 → 1988–1994; `filed_before` 1985 → 1981–1984. *Riley
  v. California* (2014), the case that answers the cell-phone question
  asked, was row 11 behind ten newer and less apt decisions; *Chimel*
  (1969) did not appear under a 1985 bound. The consequence is fixed: **a
  semantic query reaches older authority only through `filed_before` /
  `filed_after`.**
- **Why, and what follows** `[v10.3, M42]`. The rows are not date-sorted, so
  this is not a newest-first listing: the score is similarity **weighted
  toward recent decisions**, and the weighting is applied inside whatever
  window is given. A wide window therefore collapses to its last few years
  — 1985–2017 returned 2013–2016; 1998–2015 returned 2012–2014 — while a
  narrow one is ranked well: Oregon Court of Appeals 1999–2003 put *Moore
  Excavating*, *Maurmann* and *Safeco v. Russell* at rows 2, 3 and 11 for an
  equitable-indemnity question; Oregon Supreme Court 1985–1990 put *Hale v.
  Port of Portland* and *Rogers v. Saylor* at rows 1 and 2 for a tort-caps
  question. One window reaches roughly 3–5 years of a busy court (D. Utah:
  2021–2025, then 2019–2021, then 1999–2004 when stepped back) and 5–10 of a
  quiet one.
- **So window it narrowly, and aim the windows.** Run the question
  unwindowed for current law; then use windows of **5 years or less**
  placed on eras the evidence points to — an anchor's date, the year-cluster
  of the strongest keyword rows, the statute's enactment or rewrite, the
  dates of cases the opinions cite. Never step back blindly from the oldest
  date on the page: in a busy court it spends a unit per three years and in
  the measured D. Utah run reached none of the four authorities the question
  turned on. Never use one wide window. One unit per window at 20 rows.
- **Precision is top-heavy.** The first handful of rows in a well-placed
  window are on point; the rest of the page drifts to neighbours (labor
  arbitration for an unconscionability question). Triage decides — never
  score a semantic row on its rank.
- **`count` is meaningless** in this mode (301–554 for every query run,
  whatever the topic or filter). Do not report it or page on it; a second
  page of a semantic query is rarely worth a unit — move the window instead.
- `court` (one id), `filed_after`, `filed_before` and the `stat_*` flags
  work. `order_by: "score desc"` is the default and returned the identical
  page. `[v10.3, M42]` `order_by: "citeCount desc"` **is honoured** and
  spans every era (1949–2016 on one page), but it re-ranks a loose pool of
  about 500 topical neighbours, so the page fills with famous general cases
  (*Norwest*, *Smothers*, *Hall v. May*): one of eight tort-caps authorities
  and none of ten indemnity authorities. Not a standard strategy; for "the
  most-cited cases on X" use keyword search ordered by `citeCount`.
- Duplicate clusters of the same decision appear in semantic pages as they
  do in keyword pages (three rows for one 2025 Oregon decision). Dedupe as
  usual.

## Resolving GovInfo-found dockets — ONE call per court `[v10.0]`

```
search(type="o", court=["ord"],
       q='docketNumber:("3:10-cv-00649" OR "3:22-cv-00060" OR "3:18-cv-01651")',
       stat_Published=true, stat_Unpublished=true, stat_Unknown=true,
       num_results=40, fields=[<standard list>])
```

Seventeen dockets resolved in one unit (quirk 41). A docket returns a row
per indexed filing; keep a row only when its `dateFiled` equals the GovInfo
granule's `date_issued` **or the date of the order adopting it** (from
`govinfo.py docket`). In the measuring run, 17 District of Oregon filings
found by GovInfo produced five CourtListener rows on three dockets: none on
a granule's own date, three on the date of the order adopting a magistrate
judge's F&R. The other fourteen dockets were not in CourtListener at all —
GovInfo-only authorities (`govinfo.md` § 4), not cases to keep hunting for.

## Court IDs — do not spend a call confirming these

Verified in use: `scotus`, `ca9`, `ca10`, `wash` (Washington Supreme Court),
`washctapp` (Washington Court of Appeals), `wawd`, `waed`, `or`, `orctapp`,
`ord`, `jpml` (see quirk 17). Resolve any other ID once with
`get_choices(endpoint_id="search", field_name="court")` in the orchestrator
and add it here.

## Resolving known cases — ONE batched call

```
search(type="o",
       q='citation:("148 Wash. App. 52" OR "116 Wash. 2d 563" OR "180 Wash. 2d 102")',
       stat_Published=true, stat_Unpublished=true, stat_Unknown=true,
       num_results=<count + a few>, fields=[<standard list>])
```

Returns every case in one unit per 20 rows returned (a batch of up to 20
known cases is 1), each row with `opinion_id`, the verbatim
`citation` array and `cluster_opinions`. Use it for every case known by
citation — user-named, harvested, returned by `analyze_citations`, or
recalled by the orchestrator (under the four guardrails in `pipeline.md`
Phase 4). Confirm each returned `citation` array contains the string you asked
for (quirk 23). Never one search per case.

## Harvest before you search — the cached corpus is free

Before spending a search to resolve a case named inside an opinion already
read this session, `search_document` that opinion for the case name. The
markup answers for free:

- `<span class="citation" data-id="4713078"><a href="/opinion/4908387/…">` —
  resolved; `data-id` is the opinion id, the href segment the cluster id
  (quirk 13).
- `<span class="citation no-link">196 Wn.2d 38</span>` — CourtListener has no
  record of the case; no search will find it (quirk 21).

## RECAP / PACER search

For federal procedural or discovery questions decided mostly by
district-court order, run one strategy as `search` with `type: "rd"`: `q`
matching the issue in `plain_text` plus `description:(order OR opinion)`;
`available_only: true`; a court filter; `fields`: `caseName, court,
docketNumber, entry_date_filed, description, absolute_url, docket_id, id`.
Docket-level filters when the facts suggest them: `party_name`,
`nature_of_suit`, `atty_name` (types `r`/`d`). RECAP documents have no
`cluster_id` and no cite count — score on relevance alone, cite in
slip-opinion form from API fields, and note in the report that `cites:()` does
not cover them.

## The citator — ONE call, two jobs (and the screen is a separate call)

A single `cites:()` call returns a citing set that serves candidate discovery
and relatedness context. `[v10.0]` It is no longer counted as the cited
case's negative-treatment screen: ordered by cite count and capped, it shows
the most-cited citers, and negative treatment usually arrives in a recent,
little-cited decision. The screen is the keyword-filtered call below
("Screen many cases at once"), which every anchor now joins.

1. **Ids are free.** The case's search row carries `opinion_id` and
   `cluster_opinions`; OR every sub-opinion id, and both ids where duplicate
   clusters exist (quirks 9, 28).
2. **Pull the citing set:**
   ```
   search(type="o", q="cites:(<id> OR <id>)", order_by="citeCount desc",
          num_results=40, stat_*=true, fields=[<standard list>])
   ```
   40 rows cost 2 units; 100 would cost 5 (M29). The top 40 by cite count
   are the leading citers; `count` reports the total. This call finds
   candidates. It is **not** a negative-treatment screen — a recent
   overruling decision has few citations and sorts last. Paginate only if `count` exceeds
   what came back.
3. **Filter by topic, one more call:** `cites:(<ids>) AND ("phrase one" OR
   "phrase two" OR stem*)`, `order_by="citeCount desc"`, `num_results` 20.
   Search returns no snippets, so this is the only precision tool; its rows go
   to the front of selection.
4. **Screen locally, free.** Flag candidates: a citer with the same case
   name; a higher court in the same jurisdiction; a citer postdating a known
   doctrinal shift; `count` greater than rows returned.
5. **Confirm against the citing opinion's text.**
   `search_document(opinion_id=<CITING id>, query="<cited short name>")` and
   `query="disavow"`. Free if the citer was already read; one unit if not —
   prefer citers already in the analyzed set. Escalate to a metered keyword
   citator only if the text is inconclusive.

**Screen many cases at once** — the Phase 4 recipe: `cites:(a OR b OR … h)
AND (overrul* OR abrogat* OR disavow* OR "no longer good law" OR "declined to
follow" OR "superseded by")`, `num_results=100`, one unit per 20 rows
returned for the whole selected set (usually 1–3). If `count` exceeds the
rows returned the screen is incomplete: page with `get_more_results` until
it is exhausted, or print `CUT` and say so in the report. Drop
`vacat*` in arbitration, award, injunction and stay questions, where it is
ubiquitous. Rows do not say which joined case each citer cites; that is what
local screening and step 5 are for.

**Backward direction** (what a case relies on): the analyzer's reading is
primary and free. `call_endpoint` on `opinions-cited` filtered by
`citing_opinion=<id>` (with `depth`) only when a ranked upstream list is
needed.

## State-court review dispositions — CourtListener does not have them

Petitions allowed, denied or dismissed are absent from the database. For any
state appellate decision under ~3 years old headed for Leading Authorities,
check the state's official source — zero CourtListener budget. **Oregon:**
`python3 scripts/statecourts.py or-history <id | A-number>` reads the
Supreme Court's own petitions-for-review lists and opinions on review
(`state-sources.md` § 3); run it for every Oregon Court of Appeals decision
in Leading Authorities, whatever its age. **Every other state:** the
WebFetch route in `statute-sources.md` § "State-court review dispositions".

## Building the Bluebook citation (orchestrator only)

Built once from API data, passed to analyzers, copied verbatim downstream.

- Federal / general: `*Case Name*, <first citation string>
  (<court_citation_string> <year of dateFiled>)`.
- `[v10.0]` GovInfo-only authority (no CourtListener row): `*<title>*, No.
  <docket_number> (<court_citation_string> <full date_issued>)`, every part
  from the `govinfo.py search` row. Supreme Court via U.S. Reports: the
  CourtListener `citation` array still supplies the citation; the granule's
  `title` (`AT&T Mobility LLC v. Concepcion, 563 U.S. 333 (2011)`) is a
  cross-check, and a disagreement between the two is reported, not resolved
  by choosing one.
- Page references from a GovInfo text are `slip op. at N` (USCOURTS) or
  `<vol> U.S. at N` (USREPORTS) — never a reporter pin cite built from a
  slip page.
- State with an official reporter: official reporter first, regional parallel
  second, both from the API `citation` array; omit the court parenthetical
  where the reporter identifies the court.
- `[v10.0]` **Oregon, state lane.** The reporter citation is still the API
  `citation` array's. The **pin** is the `official_page` the verifier
  returned for the quoted passage, attached only to the official-reporter
  citation: `326 Or. App. 117, 118 (2023)` — never to a `P.3d` citation.
  Only when the CourtListener row's array holds **no official-reporter
  citation** (it is empty, S8, or holds only a `P.3d`) may the Oregon
  Judicial Department catalogue's `citation` be **added**, re-abbreviated
  mechanically — `326 Or App 117` → `326 Or. App. 117`, `375 Or 580` →
  `375 Or. 580`, `21 OTR 260` → `21 Or. Tax 260` — and recorded in the
  About table as catalogue-sourced. It never replaces a citation the API
  gave. A disagreement between the two (`citation_differs`) is reported,
  not resolved by choosing one. An Oregon-collection-only
  authority is cited the same way from catalogue fields and marked *(Oregon
  Judicial Department collection — not citator-covered)*.
- `[v10.0]` **Washington, state lane.** Reporter citation from the API
  array; page references are `slip op. at N`, with the judge named for a
  separate opinion — never a `Wn.2d` / `Wn. App.` / `Wn. App. 2d` pin built
  from a slip page.
- `[v10.0]` **New York.** Reporter citation from the API array. An official
  citation read in brackets on the Law Reporting Bureau page may be
  **added** — never substituted — and only when the API array holds no
  official-reporter citation, after the two-fetch check in
  `state-sources.md` § 5, re-abbreviated by the table there (`219 AD3d
  1251` → `219 A.D.3d 1251`; a form not in the table is copied as printed)
  and recorded in the About table as read from that page.
- No API citation but a docket number: `*Case Name*, No. <docketNumber>
  (<court_citation_string> <full dateFiled>)`.
- Neither: linked case name and court/year only.

Never fill a gap from memory.

## Reading opinions (CourtListener-lane analyzers — metered once, then free)

- `read_document(opinion_id=…)` for text, `search_document` to grep. Never
  fetch text fields through `call_endpoint`.
- The dedicated `cluster_id` parameter is safe and lists every sub-opinion;
  a cluster id passed *as* `opinion_id` returns an unrelated case (quirk 2).
  Verify the opening text names your case before analyzing (quirks 2, 15).
- Long opinions: read chunk 0, grep for the key concepts, read surrounding
  chunks; request 2 chunks per call. A full read that spills to a local file
  is a success — parse the file (quirk 35).
- Read more rather than less once inside a document: depth is free after the
  first fetch; touching many documents shallowly is what costs.

## Citation lookup from free text

`analyze_citations` / `extract_citations` on text returns verified case name,
date, citeCount, cluster id, parallel cites and a hallucination WARNING on a
case-name mismatch — treat a WARNING as unresolved. Metered; batch the text.
The response carries no `absolute_url` or `court_citation_string`, so resolved
cases need a backfill search before scoring. For citations you already hold,
the batched `citation:(…)` search above is cheaper.

## Quote verification — CourtListener lane — free on read opinions, verify everything

GovInfo-lane and state-lane quotes are verified with `govinfo.py verify`
against the same granule or `OJD-…` / `WA-…` document the analyzer read
(`govinfo.md` § 3, `state-sources.md` § 1). Never grade a quote read on one
of those lanes with `search_document`, or the reverse: the reporter text and the slip
opinion differ in typography and OCR, and a cross-lane check turns true
quotes into `not_found`.


`search_document` for the exact quote → `verified`. No hit → retry with a
fragment that fits one printed line (quirk 7) → `likely` if it matches and the
snippet shows the full quote. Still nothing → `not_found`. Verifiers return
corrected verbatim text where the opinion differs from the quote, and run an
absence check (match counts on a short stem; `confirmed_absent` is a
publishable finding) on any quote not sourced from fetched text this session.
