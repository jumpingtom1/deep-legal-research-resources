# Source status — verification log

**This file is the single source of truth for the console banner's
"Data Sources" lines and for the release checklist in `CHANGELOG.md`.** Every
time any part of the skill is changed, every row below is re-probed and its
date updated *before* the version ships. The banner prints the date from this
table; a row older than 90 days, or with a FAIL result, prints as `[!]`.

Probe = one WebFetch (or one `or_lookup.py` call) asking only "does this page
contain the body text of the probe citation?" — never a CourtListener call.
CourtListener itself is **not** probed here; it is confirmed at runtime by the
first metered call of each run (SKILL.md § Console output). GovInfo, by
contrast, **is** probed — at release here and at Phase 1 of every run with
`scripts/govinfo.py probe` — because its probe is free; so are the Oregon
and Washington court sources, with `scripts/statecourts.py probe`.

| Banner label | Source | Probe | Last verified | Result | Notes |
|---|---|---|---|---|---|
| Other states via state-sources repo | `scripts/state_repo.py` → raw.githubusercontent.com (pinned commit) | `state_repo.py probe` | 2026-10-18 | OK | `[added v10.5]` Pinned 18ad416 (2026-10-18): 49 jurisdictions (every state but OR and WA, plus D.C.), 801 sources, 601 independently verified. `probe`: route '6 Del. C. § 18-101' → Delaware Code; rows de 17 sources, data sha256 verified; corpus resolve Del. Super. Ct. Crim. R. 5.2 OK. Each row's own verification date and status are in the repo record, printed by `rows`. |
| CourtListener case-law API | MCP connector | first metered call of the run | 2026-10-05 (M28–M30) | OK | `[2026-10-05]` Counters read 2026-10-05: 5/min, 50/hour, 125/day unchanged. Five units spent on state-source measurements (M34, M35), none on this checklist. `[v10.0]` Still the only source for most state courts, relevance-ranked search, reporter citations and the citator (Oregon and Washington appellate text now has its own rows below); federal opinion TEXT now comes from GovInfo where held (next rows). Counters read 2026-10-03: 5/min, 50/hour, 125/day unchanged. Never spend a call to ping it. `[measured 2026-09-07]` Three caps: 5/min, 50/hour, **125/day** (rolling 24h). `search` costs **1** unit per 20 rows returned (M29, 2026-10-03, qualifying M3) — 46 consecutive one-row searches drew no hourly 429. Cached document reads are free and persist across sessions (against all three caps — M11, 2026-09-16). `[corrected 2026-09-16]` The connector **does** expose the usage API as `get_api_usage`: free, live, usable while throttled (M10). Read it at Phase 1, before every metered wave, and at close. |
| GovInfo federal opinions (USCOURTS) | `scripts/govinfo.py` → api.govinfo.gov | `govinfo.py probe`, then `resolve --court ord --docket 3:20-cv-01695 --date 2021-08-12 --name "Escobar v. National Maintenance Contractors, LLC"` | 2026-10-18 | OK | `[2026-10-18]` `probe` ok: 4,649,658 granules, limit 36,000/hour; `resolve` on the probe docket → USCOURTS-ord-3_20-cv-01695, name overlap 1.0. `[2026-10-05]` `probe` ok: 4,640,979 granules, limit 36,000/hour. `resolve` on the probe docket returned `USCOURTS-ord-3_20-cv-01695-0` with the right name and refused it with a wrong one. `[added v10.0]` 36,000 requests/hour (header `x-ratelimit-limit`), no daily cap. 4,640,478 granules. **Federal only; participating courts only; ~2004 onward; no state courts.** D. Or. and E.D. Wash. present; **W.D. Wash., S.D.N.Y., C.D. Cal. district courts absent**; 9th Cir. published opinions only. Text is the court's PDF, extracted with `pdftotext -layout`. Probed at run time by `govinfo.py probe` — free, so unlike CourtListener it IS pinged at Phase 1. Coverage table and quirks G1–G18: `govinfo.md`. |
| GovInfo U.S. Reports (USREPORTS) | `scripts/govinfo.py` → api.govinfo.gov | `resolve --court scotus --cite "563 U.S. 333" --name "AT&T Mobility LLC v. Concepcion"` | 2026-10-18 | OK | `[2026-10-18]` `resolve --court scotus --cite "563 U.S. 333"` → USREPORTS-563-333; 37,051 granules. `[2026-10-05]` `resolve --court scotus --cite "563 U.S. 333" --name "AT&T Mobility LLC v. Concepcion"` → `USREPORTS-563-333`; 37,051 granules. `[added v10.0]` Bound volumes **1–586** (through early 2019), one granule per case addressed `USREPORTS-<vol>-<page>`; official page numbers; running head names Syllabus / Opinion of the Court / concurrence / dissent. Vol. 587+ and `S. Ct.`-only citations miss → CourtListener lane. Older volumes are OCR scans. |
| Washington statutes (RCW) via leg.wa.gov | tier 1 | RCW 4.16.080 | 2026-10-18 | OK | `[2026-10-18]` YES: 'The following actions shall be commenced within three years: (1) An action for waste'; no currency statement; credit 2011 c 336 s 83. `[2026-10-05]` Unchanged: 4.16.080 body text present on the lower-case `/rcw/` URL; no currency statement. `[2026-10-03]` Body text of 4.16.080 present ("The following actions shall be commenced within three years:"); only the lower-case `/rcw/` casing probed this time. Two URL casings (`/rcw/`, `/RCW/`) both serve identical body text, no redirect — the two-fetch independence trick still works. No currency statement on the page; only the legislative credit, most recently [2011 c 336 s 83]. |
| Washington court rules via courts.wa.gov | tier 1, link-only | CR 56 | 2026-10-18 | OK | `[2026-10-18]` Link-only as expected: no rule text; PDF href court_rules/pdf/CR/SUP_CR_56_00_00.pdf; only '(c) Copyright 2026' footer, no date. `[2026-10-05]` Unchanged: HTML page carries no rule text; PDF href `court_rules/pdf/CR/SUP_CR_56_00_00.pdf`; footer copyright 2026 only. Link-only. `[2026-10-03]` HTML page still carries no rule text and no date; PDF href `court_rules/pdf/CR/SUP_CR_56_00_00.pdf`. PDF link; not quoted. `[probed 2026-09-07]` The HTML display page carries **no date of any kind** (footer is only a copyright); the adoption/amendment history lives exclusively in the linked PDF. To date a WA rule you must fetch the PDF. |
| Oregon ORCP bundled corpus | tier 0 | `or_lookup.py --list` | 2026-10-18 | OK (81 days on 2026-10-18) | `[2026-10-18]` `or_lookup.py --list`: 79 provisions, captured 2026-07-29. Re-ingest at 365 days. |
| Oregon UTCR bundled corpus | tier 0 | `or_lookup.py --list` | 2026-10-18 | OK (88 days on 2026-10-18) | `[2026-10-18]` `or_lookup.py --list`: 242 provisions, captured 2026-07-22. Re-ingest at 365 days. |
| Oregon statutes (ORS) via oregonlegislature.gov | tier 1 | ORS 12.110 (chapter page) | 2026-10-18 | OK | `[2026-10-18]` YES: 'An action for assault, battery, false imprisonment, or for any'; bracket ends '1987 c.705 s.4]'; '2025 EDITION'. `[2026-10-05]` Unchanged: 2025 EDITION; 12.110 body text and bracket present; the fetch again ended at 12.282 with no truncation notice. `[2026-10-03]` 2025 EDITION; 12.110 body text present; this fetch again ended at 12.282 with no truncation notice (the same point as the first 2026-09-16 fetch) — the long-page protocol stays in force. 2025 EDITION shown. Body text of 12.110 present. `[2026-09-16]` Two fetches of the same page disagreed on where body text ends (first: 12.282; second, cache-busted with `?v=2`: complete to 12.480, no truncation notice) — an extraction inconsistency, which is precisely why the two-fetch rule exists. Chapter 59 (long) served 59.115 in full on two fetches the same day, bracket identical. **Not evidence the truncation problem is fixed**; the long-page protocol stays in force for larger chapters. |
| Oregon ORS archived editions 1953-1997 via archives.oregonlegislature.gov | tier 1 | ORS 59.115 in `1987-Chapter-059.PDF` | 2026-10-18 | OK | `[2026-10-18]` YES: 'A person who sells a security is liable as provided'; edition printed '1987 REPLACEMENT PART'. `[2026-10-05]` `1987-Chapter-059.PDF` served 59.115; edition string came back as "1987 REPLACEMENT PART" and the bracket with OCR noise — report the edition year as printed on the volume. `[2026-10-03]` `1987-Chapter-059.PDF` served 59.115 ("A person who sells a security is liable as …") with its bracket. `[added v9.5]` Pattern `ORS_Archives/<YEAR>-Chapter-<NNN>.PDF`, upper-case extension. 1985, 1987, 1989, 1991, 1993 ch. 59 all served; each quoted subsection agreed on two differently-worded fetches (second via `?v=2`). Page scans: OCR errors observed (`(b)`→`(h)`, `1991`→`1891`, `c.762`→`c.62`). **Not linked from any landing page** — construct the URL. |
| Oregon ORS archived editions 1999-2023 via oregonlegislature.gov | tier 1 | ORS 59.115 in `1999ors059.pdf` | 2026-10-18 | OK | `[2026-10-18]` YES: 'A person who sells a security is liable as provided in'; '1999 EDITION'. `[2026-10-05]` Unchanged: "1999 EDITION", 59.115 body text and the full bracket through 1997 c.772 s.9. `[2026-10-03]` `1999ors059.pdf` served 59.115 and, this time, the full bracket from 1967 c.537 through 1997 c.772 s.9. `[added v9.5]` Pattern `bills_laws/Archive/<YEAR>ors<NNN>.pdf`; 1999 and 2001 ch. 59 served, body text and bracket present (2026-09-16 re-probe of 1999 returned only the final act of the bracket, `[1997 c.772 s.9]` — partial OCR extraction, the same hazard the section documents). `1997ors059.pdf` 404 — 1997 is in the other library. Same truncation caution as the live chapter pages. |
| Oregon ORS via public.law | tier 2 | ORS 527.770 | 2026-10-18 | OK | `[2026-10-18]` YES: 'A forest operator conducting, or in good faith proposing to conduct'; 'Current through early 2026'. `[2026-10-05]` Unchanged: body text and bracket of 527.770; "Current through early 2026". `[2026-10-03]` "Current through early 2026" unchanged. "Current through early 2026." Constructible per-section pattern (`ors_<section>`) resolves directly; no index navigation needed. |
| Oregon OAR via sos.state.or.us | tier 1 | OAR 137-050-0710 | 2026-10-18 | OK | `[2026-10-18]` YES (built URL refused, refetched via public.law link): '(1) To calculate the guideline support amount: (a) Determine each parent's income'; title Calculating Child Support; history DOJ 19-2023. `[2026-10-05]` **FAIL, third consecutive day** — `ROBOTS_DISALLOWED … Failed to fetch or parse robots.txt` (wording differs from the 10-03/10-04 `ConnectTimeout`; same class). Not retried. Tier 2 remains the fallback. `[2026-10-03]` **FAIL twice the same evening** — `ROBOTS_DISALLOWED … robots.txt fetch failed: ConnectTimeout` on both the release probe and a retry. Ends the run of four OK probes (09-06, 09-07, 09-16 ×2). Use the tier-2 row this release; try tier 1 first on every run regardless. FAIL 2026-09-05 (robots.txt) -> OK 2026-09-06 -> OK 2026-09-07 -> OK 2026-09-16 (body text, title "Calculating Child Support", history DOJ 19-2023). Four OK probes in a row now; still treat as **intermittently available** until a full month passes without a FAIL. Body text present, history to DOJ 19-2023. Keep the tier-2 fallback documented. |
| Oregon OAR via public.law | tier 2 | OAR 137-050-0710 | 2026-10-18 | OK | `[2026-10-18]` YES: 'To calculate the guideline support amount: (a) Determine each parent's income'; access dates only (May 26, 2025; May 10, 2025), no currency. `[2026-10-05]` Unchanged: body text present ("To calculate the guideline support amount:"); dates are still access dates, not currency. `[2026-10-03]` Body text present; dates still access dates ("accessed May 26, 2025"; "last accessed May 10, 2025"); title still "Calculating Support". **Changed:** the page now shows dates, but they are **ACCESS dates, not currency** ("May 26, 2025"; source credit "last accessed May 10, 2025" — earlier than the page date). Nothing states which OAR edition or Oregon Bulletin the text is current through. Report the literal string as an access date; never present it as currency. Also: tier 2 titles the rule "Calculating Support" where the official page says "Calculating Child Support" — a heading discrepancy, body text agrees. |
| Oregon ORAP via courts.oregon.gov | tier 1, link-only | ORAP index | 2026-10-18 | OK | `[2026-10-18]` Link-only (built URL refused; casing variant from search): no ORAP rule text, no edition date; titled 'Current Oregon Rules of Appellate Procedure'; only an agency-record instructions PDF linked. `[2026-10-05]` Unchanged in substance: no ORAP text, no document link, no edition date. Headings returned this time as "Current Oregon Rules of Appellate Procedure" and "View Prior Rules". `[2026-10-03]` Unchanged: no ORAP text, no edition date. Names "Current" and "Previous" ORAP but **no edition date**, and the rule documents are injected client-side — no ORAP text and no ORAP PDF is retrievable via WebFetch. Supports a link and nothing more; no edition date may be stated in a report. |
| Federal statutes (U.S.C.) via OLRC | tier 1 | 15 U.S.C. § 1692k | 2026-10-18 | **FAIL** (maintenance) | `[2026-10-18]` GATED (fetch tool); script FAIL: deep link serves 'temporary format' notice, no 1692k text; 'current through Public Law 119-120 (October 7, 2026)'. `[2026-10-05]` **FAIL, third consecutive day** — the same house.gov notice ("The site you requested is currently unavailable…"). Not retried. Cornell and GovInfo rows OK, so the two-source rule is still satisfiable. `[2026-10-03]` **FAIL twice the same evening**: the URL returned a house.gov notice, "The site you requested is currently unavailable," with no statute text. Presumed temporary. Until a probe succeeds, the U.S.C. two-source check is Cornell + GovInfo (rows below). Body text + source credit present. 9 U.S.C. § 2 also fetched in the v9.2 live run; matched Cornell exactly. |
| Federal statutes (U.S.C.) via Cornell LII | tier 1 (second source) | 15 U.S.C. § 1692k | 2026-10-18 | OK | `[2026-10-18]` YES (via search result): 'Except as otherwise provided by this section, any debt collector who'; no currency date, only 'How current is this?' link. `[2026-10-05]` Unchanged: § 1692k body text present; source credit still omits the 2010 amendment line; no currency statement. `[2026-10-03]` Body text present ("Except as otherwise provided by this section, any debt …"). Body text present; source credit omits the 2010 amendment line that OLRC shows, so compare operative text, not credit length. |
| Federal statutes (U.S.C.) via GovInfo | tier 1 (GPO annual edition) | 15 U.S.C. § 1692k via `govinfo.py usc` | 2026-10-18 | OK | `[2026-10-18]` `usc --title 15 --section 1692k` → "United States Code, 2024 Edition", 3,896 characters. `[2026-10-05]` `usc --title 15 --section 1692k` → "United States Code, 2024 Edition", 3,896 characters. `[added v10.0]` "United States Code, 2024 Edition" for `mostrecent`; 2008, 2000 and 1994 editions also served; 1993 and 2025 → HTTP 400. Script-extracted text (no summarizing model). **Lags the OLRC prelim code** — always print the edition. One source of the two required to quote. |
| Federal rules via Cornell LII | tier 1 | FRCP 12 | 2026-10-18 | OK | `[2026-10-18]` YES (via link on /rules/frcp index): 'Unless another time is specified by a federal statute, the'; amended Apr. 2, 2024, eff. Dec. 1, 2024. `[2026-10-05]` Unchanged: FRCP 12 body text; history through Apr. 2, 2024, eff. Dec. 1, 2024. `[2026-10-03]` Unchanged; history through Apr. 2, 2024, eff. Dec. 1, 2024. Amendment history through Apr. 2, 2024, eff. Dec. 1, 2024. Unchanged. |
| Delaware Code via delcode.delaware.gov | tier 1 | 6 Del. C. § 18-101 | 2026-10-18 | OK | `[2026-10-18]` YES (chapter index refused; subchapter via search): 'As used in this chapter unless the context otherwise requires'; no currency statement; history through 85 Del. Laws c. 280. `[2026-10-05]` Unchanged: subchapter page served § 18-101 ("As used in this chapter unless the context otherwise requires:"); no currency statement. `[2026-10-03]` Subchapter page served § 18-101 ("As used in this chapter unless the context otherwise requires:"). Chapter index page is navigation-only; text is on the subchapter page (`…/c018/sc01/index.html`). `[added v9.3]` Non-hyphenated sections resolve the same way: 5 Del. C. § 952 is on `title5/c009/sc02/index.html` (Subchapter II, Bank Revolving Credit) — the chapter index does not say which subchapter holds a section, so fetch the index, then the subchapter. No tier-2 exists for this collection; use the opinion-corroboration fallback in statute-sources.md to quote. |
| California codes via public.law | tier 2 | codes index | 2026-10-18 | OK | `[2026-10-18]` Index with per-code links; CHANGED: 'Updated October 12, 2026' (was September 28, 2026). `[2026-10-05]` Unchanged since 10-03: "Updated September 28, 2026". `[2026-10-03]` Now **"Updated September 28, 2026"** (was September 14). "Updated September 14, 2026." Per-section navigation present. |
| Colorado C.R.S. via public.law | tier 2 | statutes index | 2026-10-18 | OK | `[2026-10-18]` Index with per-title links; 'Colorado Revised Statutes Current through Fall 2025'; currency 'Current through Fall 2025' unchanged. `[2026-10-05]` "Current through Fall 2025" unchanged; the fetch also returned a body sentence, "This online publication of the C.R.S. is up to date through Fall 2025." `[2026-10-03]` "Current through Fall 2025" unchanged. **Wording changed** to "Current through Fall 2025" (was "Up to date through Fall 2025"); same coverage period. Confirmed on a second independent fetch. These strings are printed verbatim in reports, so quote the new one. |
| Florida Statutes via public.law | tier 2 | statutes index | 2026-10-18 | OK | `[2026-10-18]` Index with per-title links; 'The Florida Statutes contain all the laws of the state.'; 'Current Through Fall 2025' unchanged. `[2026-10-05]` Unchanged: "Current Through Fall 2025" (title-cased form). `[2026-10-03]` "Current Through Fall 2025" (title-cased form seen) unchanged. "Current through Fall 2025." (One fetch rendered it title-cased from the page `<title>`; the body string is lowercase "through".) |
| Nevada NRS via public.law | tier 2 | statutes index | 2026-10-18 | OK | `[2026-10-18]` Index (59 titles, title-level links); 'The Nevada Revised Statutes (NRS) contains all the laws'; still 'Updated May 26, 2025' (stale). `[2026-10-05]` Still "Updated May 26, 2025" — about 16 months behind. `[2026-10-03]` Still "Updated May 26, 2025" — about 16 months behind. "Updated May 26, 2025" — has not moved; ~16 months behind, the stalest of the six alongside Texas, whose date is **identical**. Treat NV+TX as one stalled ingest, not two coincidences. Neither has a tier-1 fallback here. Always report the date. |
| New York laws via public.law | tier 2 | laws index | 2026-10-18 | OK | `[2026-10-18]` Index with per-law links; 'Laws of New York Updated September 26, 2026'; unchanged. `[2026-10-05]` Unchanged since 10-03: "Updated September 26, 2026". `[2026-10-03]` Now **"Updated September 26, 2026"** (was August 15). "Updated August 15, 2026." Per-section navigation present. |
| Texas statutes via public.law | tier 2 | statutes index | 2026-10-18 | OK | `[2026-10-18]` Index with per-code links; 'The Texas Statutes represent a comprehensive compilation of legal provisions'; still 'Updated May 26, 2025' (stale). `[2026-10-05]` Still "Updated May 26, 2025", identical to Nevada. `[2026-10-03]` Still "Updated May 26, 2025", identical to Nevada. "Updated May 26, 2025" — identical to Nevada's; see that row. ~16 months behind, spanning multiple legislative sessions. Always report the date. |
| Washington Supreme Court review dispositions | courts.wa.gov | entry page | 2026-10-18 | OK | `[2026-10-18]` ORDERS newest 'Filed September 3, 2026', Aug 20, Aug 12. Petitions hop: currentPetitions heading 'October 6, 2026' but no entries extracted. `[2026-10-05]` Unchanged: entry page links ACCEPTED CASES, ORDERS and PETITIONS FOR REVIEW; ORDERS page most recent entry still "Filed September 3, 2026" (32 days), then August 20 and August 12. `[2026-10-03]` ORDERS page most recent entry still September 3, 2026 (30 days); then August 20 and August 12. Links ORDERS, PETITIONS FOR REVIEW and an ACCEPTED CASES PDF. ORDERS page most recent entry "Filed September 3, 2026" at the 2026-09-16 probe (13 days). **The PETITIONS FOR REVIEW link is an intermediate page — one more hop is always required.** Never construct a query URL: a guessed one returned a ColdFusion error inside normal page chrome, which reads like an empty result. See statute-sources.md. |
| Oregon Supreme Court petitions for review | OJD contentdm JSON API | entry point | 2026-10-18 | OK | `[2026-10-18]` `or-history A176132 --cite "326 Or App 117"` → DENIED, November 17, 2023, list citation 371 Or 535 (expected); newest list "Petitions for review, October 8, 2026". A first attempt during an OCLC outage (HTTP 502) returned complete:false with every source under not_checked, as designed. `[2026-10-05]` **Now scripted** (`statecourts.py or-history`, `state-sources.md` § 3). Newest list in the collection: "Petitions for review, September 24, 2026" (item 18898, 375 Or 579); 641 lists from August 1997. Tested on A176132 (review denied Nov. 17, 2023, 371 Or 535), A139453 (two decisions, two dispositions, correctly separated) and A177959 (review allowed Sept. 19, 2024; Supreme Court opinion 375 Or 580). The WebFetch route below is kept as the fallback. `[2026-10-03]` Most recent list returned: "Petitions for review, September 24, 2026" (item 18898). The API reported 17 results, returned 10, **not in date order** despite the `order/date/ad/desc` segment — read every returned title before naming the latest. The site-navigation route is **dead** — no "Petitions for Review" link exists on the appellate page, and several supreme-court URLs are hard 404s. Working route is the contentdm **JSON API**, collection `p17027coll3`, title search `Petitions for review, <date>`; the HTML UI is Javascript-only. Most recent list at probe: September 10, 2026 (item 18530); ten dated lists returned for 2026. Full URLs in statute-sources.md. |
| Oregon appellate opinions (OJD official reports) | `scripts/statecourts.py` → ojd.contentdm.oclc.org (CONTENTdm JSON API) | `statecourts.py probe`, then `or-resolve --court orctapp --cite "326 Or. App. 117" --date 2023-05-17 --name "Garza v. Recology Oregon Recovery, Inc."` | 2026-10-18 | OK | `[2026-10-18]` First attempts 21:15–21:25 PT: HTTP 502 'Proxy Error' from the CONTENTdm host's own reverse proxy (robots.txt served 200 — an OCLC-side outage); `or-history` correctly returned complete:false with every source under not_checked. Retried ~21:40: `or-resolve` 326 Or. App. 117 → OJD-p17027coll5-35851 (Garza), name overlap 1.0. `[added v10.0, 2026-10-05]` No key. `robots.txt`: `Crawl-Delay: 1`, honoured by a cross-process lock (1.1 s). Supreme Court 3,162 items from 326 Or 1 (Aug. 21, 1997), newest 375 Or 580 (Oct. 1, 2026); Court of Appeals 19,480 from 152 Or App (Jan. 7, 1998), newest 353 Or App 397 (Sept. 30, 2026), 2,447 catalogued "Nonprecedential opinion"; Tax Court 8,285 from 1 OTR (1962). PDFs are the official Oregon Reports pages (running head carries the official page). Probe citation resolved to `OJD-p17027coll5-35851`; identity check true/true. Scans (OCR) through 2011 in the sample. A text lane, a full-text search and the review lists — never a citator. |
| Washington slip opinions (courts.wa.gov) | `scripts/statecourts.py` → www.courts.wa.gov year listings | `statecourts.py probe`, then `wa-resolve --court wash --docket 101045-1 --date 2024-01-04 --name "Barlow v. State"` | 2026-10-18 | OK | `[2026-10-18]` `probe` ok (2026 listing, 47 Supreme Court opinions, newest 2026-10-15 In re Recall of Weyrich); `wa-resolve` 101045-1 → WA-1010451 Barlow v. State. `[added v10.0, 2026-10-05]` `robots.txt` does not disallow `/opinions/`. Listings by year: Supreme Court 2013 →, Court of Appeals published 2012 →, unpublished and part-published 2013 → (the script accepts 2012 on); 44 Supreme Court opinions listed for 2026, newest Oct. 1, 2026. **Slip opinions, not the official reports**; red-asterisk rows are slips the official report has replaced (carried as `superseded_slip`). Probe resolved to `WA-1010451` (57 pages, majority + two separate opinions detected; after review 4, separate opinions are cross-checked against the page running heads and the listing's "File Contains"). The site's search form is JavaScript-driven and is not used. |
| New York Official Reports pages (nycourts.gov) | Law Reporting Bureau, `nycourts.gov/reporter/3dseries/<year>/<year>_<nnnnn>.htm` — **WebFetch only** | `statecourts.py ny-url "2023 NY Slip Op 04822"`, then one WebFetch of the URL | 2026-10-18 | OK | `[2026-10-18]` Mejia v Linares, App Div 1st Dept, Sept 28, 2023; '[219 AD3d 1251]'; 'As corrected through Wednesday, November 8, 2023'. `[added v10.0, 2026-10-05]` Scripts are stopped by a browser check on nycourts.gov, which is not worked around; WebFetch reads the page. Three pages fetched: 2023 NY Slip Op 04822 (`[219 AD3d 1251]`, "As corrected through Wednesday, November 8, 2023"), 2019 NY Slip Op 00684 (`[168 AD3d 632]`), 2024 NY Slip Op 50001(U) ("will not be published in the printed Official Reports"). Used for official citation, court, date, corrected-through date and publication status under the two-fetch rule — **never as a text lane**; New York opinions are read and verified through CourtListener. |
| New York Official Reports (govt.westlaw.com/nyofficial) | Westlaw-hosted | one WebFetch of the collection index | 2026-10-18 | BLOCKED (re-confirmed) | `[2026-10-18]` SITE_BLOCKED: 'Access to this website has been blocked'. `[added v10.0, 2026-10-05]` The user asked for this collection. WebFetch returned `SITE_BLOCKED` ("Access to this website has been blocked"); it was not fetched by any other route and must not be. The nycourts.gov row above is the official alternative for a page check; there is no official New York text lane. |
| Washington official reports (lexisnexis.com/clients/wareports) | LexisNexis-hosted | one WebFetch of the collection address | 2026-10-18 | BLOCKED (re-confirmed) | `[2026-10-18]` ROBOTS_DISALLOWED. `[added v10.0, 2026-10-05]` The courts.wa.gov "Lexis overview" page the user named points here for the official Wn.2d / Wn. App. 2d text. WebFetch returned `ROBOTS_DISALLOWED` ("URL is disallowed by robots.txt rules"); not fetched by any other route and must not be. The courts.wa.gov slip-opinion row above is what the skill uses, labelled as slip text. |
| Westlaw / Lexis citator flags, headnotes, secondary sources | — | — | — | not available | Always printed as `[-]`. |

## Probe coverage for the v10.0 rebuild (2026-10-05)

`[added 2026-10-05]` The user asked for v10.0 to be re-created with three
state court collections. Every row was re-probed that day: 21 WebFetch calls
by a probe subagent (20 rows plus the Washington ORDERS hop), `or_lookup.py`
three ways, the three GovInfo rows through `scripts/govinfo.py`, the Oregon
petitions row through `scripts/statecourts.py or-history`, and the five new
rows as described in their notes. No CourtListener budget was spent on the
checklist (five units were spent that day on the state-source measurements,
M34–M35).

**No row changed between OK and FAIL.** Oregon OAR tier 1 and U.S.C. via
OLRC FAILED for the third consecutive day (one fetch each, not retried);
their fallbacks are OK. The corpora are one day older (68 and 75 days).

**Five rows added:** Oregon appellate opinions (OK), Washington slip
opinions (OK), New York Official Reports pages on nycourts.gov (OK, page
check only), and two rows that record what was asked for and is **not**
reachable — the Westlaw-hosted New York Official Reports and the
LexisNexis-hosted Washington official reports. They are in the table so
that no later run rediscovers them, tries another route, or reports their
absence as a gap in the research.

**One correction to an existing row:** the GovInfo USCOURTS and USREPORTS
probe commands now carry `--name`. Since the v10.0 review fixes, `resolve`
refuses to choose a granule without a case-name match, so the probe as
written on 2026-10-04 would have reported `found: false`.

## Probe coverage for the v10.0 release (2026-10-03 and 2026-10-04)

`[added v10.0]` **Every row was probed twice**: on 2026-10-03 (22 WebFetch
calls by a probe subagent, two retries by the orchestrator) and again on
the ship date, 2026-10-04 (24 WebFetch calls: 21 rows, the Washington
ORDERS hop and two retries), with `or_lookup.py --list` and the three
GovInfo rows through `scripts/govinfo.py` both days. The notes above are
tagged `[2026-10-03]` because that is when their detail was recorded; the
2026-10-04 pass found **no change to any row** (corpora one day older: 67
and 74 days). No CourtListener budget was spent on the checklist.

**Two rows FAILED on both days, each retried once per day:**

1. **Oregon OAR, tier 1** — `robots.txt fetch failed: ConnectTimeout`. The
   row was already marked intermittent; the tier-2 row is OK and is the
   fallback, disclosed as tier 2.
2. **U.S.C. via OLRC** — a house.gov maintenance notice in place of the
   statute. Cornell is OK and the new GovInfo `USCODE` row is OK, so the
   two-source rule for U.S.C. is still satisfiable (Cornell + GovInfo).
   Re-probe OLRC at the next release; do not remove the row.

Changes recorded above: California public.law → "Updated September 28,
2026"; New York public.law → "Updated September 26, 2026"; Oregon
petitions-for-review list → September 24, 2026 (and the contentdm API's
results came back out of date order); ORCP/UTCR corpora 66 and 73 days old;
the 1999 archived ORS edition returned its full bracket this time; Nevada
and Texas public.law still stalled at May 26, 2025. Three rows added:
GovInfo USCOURTS, GovInfo USREPORTS, U.S.C. via GovInfo.

## Probe coverage for the v9.6 release (2026-09-16)

`[added v9.6]` **Every row re-probed on 2026-09-16** — 21 WebFetch calls plus
`or_lookup.py --list`, no CourtListener budget. No row FAILED. Changes
recorded above: California public.law moved to "Updated September 14, 2026";
Oregon petitions-for-review list moved to September 10, 2026; WA ORDERS page
most recent entry September 3, 2026; OAR tier 1 a fourth consecutive OK; ORS
chapter 12 gave two different truncation points on two fetches (recorded as
an extraction hazard, not a source failure); Nevada and Texas public.law
still stalled at May 26, 2025. The CourtListener row is corrected: the
usage API is exposed as `get_api_usage` (M10). This clears the two-day
overrun recorded for v9.5.

## Probe coverage for the v9.5 release (2026-09-16)

`[added v9.5]` **Documentation release plus two new tier-1 rows.** The two
archived-ORS rows were probed live on 2026-09-15 in the run that discovered
them (nine WebFetch calls across seven edition PDFs, every quoted passage
fetched twice). All other rows carry forward the full 2026-09-07 probe under
the 7-day documentation-release allowance in `CHANGELOG.md` — 9 days at
ship, which exceeds the allowance by two; the next release must re-probe
every row in full. No source pattern, URL or protocol for any existing row
changed.

## Probe coverage for the v9.3 release (2026-09-07)

`[added v9.3]` **Every row in this table was re-probed on 2026-09-07** —
the full checklist, not a subset — plus both bundled Oregon corpora via
`scripts/or_lookup.py --list` (ORCP 40 days, UTCR 47 days, both OK) and both
review-disposition entry points.

**No row FAILED.** Five changed materially and are reflected above:

1. **Oregon OAR (tier 1)** has now flipped FAIL → OK → OK on three
   consecutive days. Marked **intermittent**, not restored — try tier 1 first
   every run, keep the tier-2 fallback.
2. **Oregon OAR (tier 2)** now shows dates, but they are **access** dates, not
   currency. Never report them as currency.
3. **Oregon petitions for review**: the documented site-navigation route is
   **dead**. Replaced with the OJD contentdm JSON API route, which works.
4. **Colorado public.law** changed its wording to "Current through Fall 2025".
   These strings are printed verbatim in reports, so the stored value matters.
5. **Washington petitions for review** is an intermediate page — one more hop
   is always required, and a run that stops there reports a false negative.

Two standing cautions worth re-reading before any statute work: **Nevada and
Texas public.law share an identical "Updated May 26, 2025"** — one stalled
ingest covering two states, ~15.5 months behind, with no tier-1 fallback in
this file; and **ORAP cannot be quoted from its official page at all** (no
edition date, rule documents injected client-side), which is exactly the case
the v9.3 opinion-corroboration fallback exists for.

## How the banner uses this table

- A family relevant to the parsed query prints with `[x]` and its date when
  the newest matching row is OK and ≤ 90 days old (≤ 365 days for the
  bundled ORCP/UTCR corpora, which are re-ingested yearly); `[!]` when FAIL
  or older than that (and the banner names the fallback row if one is OK);
  `[ ]` when available but not needed for this query.
- Three text lines — GovInfo, Oregon official reports, Washington slip
  opinions — are **not** read from this table: they print the result of
  this run's probes (`--govinfo`, `--oregon`, `--washington`). Their rows
  above are the release record.
- Two `[-]` lines are fixed: "Westlaw/Lexis citator, headnotes, secondary —
  not available" and "NY (Westlaw) / WA (Lexis) official reports — blocked
  to automation". The two BLOCKED rows above are their record.
- Where a tier-1 row has FAILED and a tier-2 row for the same family is OK,
  the banner prints the tier-2 row and says "via public.law (secondary)".
