# Known corrections — verified findings that must survive across runs

**Why this file exists.** The skill has no memory between runs. A correction
one run pays for — a metered read, an absence check, an analyzer catching a
miscitation — is gone at the next invocation unless it is written down here
and shipped. The v9.1 run established that *Hooters v. Phillips* is widely
miscited for an illusoriness holding it does not contain; the v9.2 run, on the
identical query, lost that finding entirely because it never happened to read
*Hooters*. This file is the fix.

**How it is used.**

- The orchestrator reads this file during **Phase 3 triage**. A candidate
  listed here carries its correction into scoring.
- If a listed case is selected for analysis, its entry is **pasted into that
  analyzer's prompt** so the analyzer starts from the corrected premise rather
  than re-deriving it (or failing to).
- If a listed case is cited in the report *without* having been analyzed —
  e.g. it appears only inside another opinion's string cite — the report must
  not repeat the miscitation, and should note the correction if the point is
  load-bearing.

**Bar for entry.** An entry must be (a) verified against fetched text, not
recalled; (b) durable — a fact about what an opinion says, not about what a
search returned; and (c) worth a manual release. Record *how* it was verified
so a later editor can trust it without re-deriving it. Entries do not expire,
but a later run that contradicts one should be believed and the entry fixed.

**This file is not a research shortcut.** Nothing here substitutes for reading
the opinion. An entry tells an analyzer what *not* to assume; it never tells
the report what to conclude.

---

## Entries

### *Sanders v. Francis*, 277 Or 593, 561 P.2d 1003 (1977)

**Common misrecall:** offered (by the orchestrator's own memory, v9.6 run of
2026-09-16) as an Oregon Securities Law decision on omissions under ORS
59.115(1)(b), alongside *Foelker v. Kwake* and *Adams v. American Western
Securities*. It is nothing of the kind.

**What it actually is:** an Unlawful Trade Practices Act case (ORS 646.605
et seq.) about a used-car dealer's advertised price — bait advertising,
"failure to disclose" as a representation, and whether reliance is an
element of a private UTPA action. The words "security" and "59.115" do not
appear in it.

**Verified:** full `read_document` of opinion 1433676 on 2026-09-16; the
opinion was dropped from the run with a `FIX` line.

**Use:** never cite *Sanders v. Francis* for securities law. Its reliance
discussion is UTPA-specific. (The securities case with a similar name that
the Oregon cases do cite is *Sanders v. John Nuveen & Co.*, 619 F.2d 1222
(7th Cir. 1980), a § 12(2) decision.)

---

### *Marsh & McLennan* (Oregon), three decisions, one citation string each

**Common confusion:** "*Marsh*" on the scienter question refers to the
**Court of Appeals on remand**, *State ex rel. Oregon State Treasurer v. Marsh
& McLennan Cos.*, 269 Or App 31, 346 P3d 504 (2015) (*Marsh III*), which
holds that ORS 59.137 requires scienter and, in footnote 6, expressly limits
that holding to ORS 59.137. The Supreme Court decision, 353 Or 1 (2012)
(*Marsh II*), decides only fraud-on-the-market reliance and remands the
scienter question; the first Court of Appeals decision, 241 Or App 107
(2011) (*Marsh I*), was reversed by *Marsh II*. The official Legislative
Counsel annotations page renders the 59.137 scienter annotation with a
citation string that two WebFetch passes reported inconsistently — do not
copy a *Marsh* citation from that page.

**Verified:** full read of opinion 8127678 (269 Or App 31) and targeted
searches of 834773 (353 Or 1) on 2026-09-16. CourtListener holds no citing
opinions for 269 Or App 31 and does not index the Supreme Court's review
disposition; the disposition remains unconfirmed.

**Use:** cite 269 Or App 31 for the ORS 59.137 scienter holding and for its
characterization of ORS 59.115(1)(b) as carrying "a good-faith defense for
innocent misrepresentations" (dicta). Cite 353 Or 1 for fraud-on-the-market
reliance under ORS 59.137, not for scienter.

---

### *Hooters of America, Inc. v. Phillips*, 173 F.3d 933 (4th Cir. 1999)

**Common miscitation:** cited for the proposition that a unilateral right to
modify arbitration rules renders the agreement *illusory* or unsupported by
consideration. It is collected that way in string cites by later courts,
including *Dumais v. American Golf Corp.*, 299 F.3d 1216, 1219 (10th Cir.
2002).

**What it actually holds:** the decision rests on **material breach of the
agreement and the duty of good faith**, not on illusoriness or mutuality. The
opinion contains no consideration analysis.

**Verified:** v9.1 run, 2026-09-06, by full-text search of the opinion —
`illusor` 1 match, `consideration` 1 match, `mutuality` 0 matches; the two
hits are recitals of the district court's reasoning, not the Fourth Circuit's
holding.

**Use:** *Hooters* may be cited for what it holds. It may not be offered as
federal authority on the illusoriness branch, and a report that reproduces a
later court's string-cite parenthetical should say the parenthetical
overstates it.

---

### *Grosvenor v. Qwest Corp.*, 733 F.3d 990 (10th Cir. 2013)

**Common miscitation:** treated as the appellate affirmance of the D. Colo.
illusoriness holding in *Grosvenor v. Qwest Corp.*, 854 F. Supp. 2d 1021
(D. Colo. 2012), and cited for the substantive rule.

**What it actually holds:** a **jurisdictional dismissal under 9 U.S.C.
§ 16(a)**. It does not reach the merits of the modification-clause question.

**Verified:** v9.1 run, 2026-09-06, analyzer read the full opinion and scored
it 2/5 with the correction stated.

**Use:** cite the **district court** decision for the illusoriness holding.
The Tenth Circuit decision is not authority on the substance.

---

### *Hardin v. First Cash Financial Services, Inc.*, 465 F.3d 470 (10th Cir. 2006)

**Common miscitation:** described as *distinguishing* or departing from
*Dumais v. American Golf Corp.*

**What it actually does:** it **adopts** *Dumais*'s rule — quoting "an
arbitration agreement allowing one party the unfettered right to alter the
arbitration agreement's existence or its scope is illusory" as its own
governing standard — and holds the rule **satisfied** because First Cash's
modification right was fettered by reasonable restrictions. The case it
distinguishes is *Ingle v. Circuit City* (9th Cir.), on the grounds that
*Ingle* applied California law and expressly reserved whether the modification
clause alone voids the contract.

**Verified:** v9.2 run, 2026-09-06, analyzer read the full opinion; the
adoption and the *Ingle* distinction are both quoted verbatim in the report.

**Use:** *Hardin* is not a circuit split with *Dumais*. It is the same rule
applied to a clause with limits, and it is the cleanest federal statement of
what those limits are.

---

### *Circuit City Stores, Inc. v. Najd*, 294 F.3d 1104 (9th Cir. 2002)

**Common miscitation:** cited in discussions of employer-reserved rights to
modify or terminate an arbitration program, including for a supposed 30-day
notice or December-31 limitation on that right.

**What it actually contains:** **no discussion of a modification power at
all.** The opinion is about consideration (the employer's own promise to
arbitrate) and assent by silence where a written acknowledgment explained the
consequence of not opting out. The "thirty days" in the case is the employee's
window to review and opt out, not notice of any modification.

**Verified:** v9.2 run, 2026-09-06, absence check run twice by independent
agents against the cached full text — `modif` 0 matches, `amend` 0 matches,
`terminat` 1 match (referring to the plaintiff's own termination from
employment).

**Use:** cite *Najd* for consideration and for assent-by-silence-with-opt-out.
Do not cite it on unilateral modification.

---

## Template for new entries

```
### *Case Name*, <citation> (<court> <year>)

**Common miscitation:** <what people cite it for>
**What it actually holds:** <the correction>
**Verified:** <run, date, method — full-text search terms and match counts,
or the analyzer's reading>
**Use:** <what the case may and may not be cited for>
```
