# Subagent Briefing Block

**Paste the block below VERBATIM into every subagent prompt** — search,
analyzer, verifier, all of them — or write it once to a scratch file each
agent is told to `cat` first. Do not paraphrase it and do not omit it because
a task looks simple.

---

## BEGIN CANONICAL BRIEFING — copy verbatim into subagent prompts

### Rate limits — one pool, three caps

Every CourtListener call draws on a single account-wide budget shared by
every concurrent agent: **5 per minute, 50 per hour, 125 per day.** The daily
cap is a rolling 24-hour window. All three are measured facts. The live
counters are one free call away: **`get_api_usage`** never spends the `user`
quota, works while you are throttled, and reports `used` / `remaining` /
`reset_at` for each cap. Call it if you are unsure whether a metered call
will be refused; do not count calls by hand.

| Class | Tools | Cost |
|---|---|---|
| Always metered | `call_endpoint`, `get_endpoint_item`, `get_choices`, `analyze_citations`, `extract_citations`, `get_more_results` | 1 unit per call |
| Metered by rows | `search` | **1 unit per 20 rows returned, minimum 1** — `num_results` 20 → 1 unit, 40 → 2, 100 → 5 (if that many hits exist). The 5/min window counts the same pages, so a 2-page search uses two of the five. Use the `num_results` your prompt gives; default 20 |
| Metered on first touch | `read_document`, `search_document` | 1 unit **per document** the first time it is fetched; free forever after, inside any exhausted window and across sessions |
| Never metered | `get_api_usage`; every `scripts/govinfo.py` and `scripts/statecourts.py` command (different services — see "The GovInfo lane" and "The state lanes" below) | 0 |

Consequences:

- Your call budget is stated in your prompt. **Treat it as a ceiling, not a
  target.** Return early and under budget rather than exhaustive and over.
- **Space your calls** — one at a time, ~20–30 s apart, honoring any start
  offset in your prompt.
- **Re-reads are free.** Fetch each opinion once, then grep it as much as you
  like. Reading one opinion thoroughly is cheap; sampling ten shallowly is
  expensive.
- **Batching document reads saves no quota.** Passing three unread ids costs
  three units, and the 429 comes back per document inside the results array,
  so a batch can partially succeed and still charge you. Batch at most 2–3
  unread ids. Cached documents in a batch cost nothing against any cap.

**On a 429, read the body and take the matching branch:**

| Body says | Do |
|---|---|
| `5/min` | Sleep the **stated N + 5 s** (floor 5, ceiling 90) and retry once. The stated time is accurate. Do not count the rejection — it consumed no quota and did not extend the window |
| `50/hour` | **Do not wait.** Stop; report `rate_limited: true, limit_hit: "hourly"` |
| `125/day` | **Do not wait.** Stop; report `rate_limited: true, limit_hit: "daily"` with the verbatim body. Nothing you can do recovers this today |

Never report a daily refusal as hourly — the orchestrator's next move
depends on which fired. If your one retry also fails, stop and report; a
long silent wait is a failure, not diligence.

### "Not found" is a correct answer — say it plainly

**You are never required to produce content.** Every field in every contract
accepts `null`, an empty array, or `"not found"`. Returning one of those is a
*successful* result, and far more valuable than a plausible guess: the
orchestrator can work around a gap it knows about; it cannot work around a
fabrication. This has fired for real — a prompt that demanded statute text
from a truncated page, with no way to decline, produced an invented statutory
sentence complete with a fake source-law bracket. The same request with an
explicit "not present" answer available returned the truth.

- **If the source does not contain what you were asked for, say so and
  stop.** Use the escape string your prompt gives you; otherwise say `"not
  found"` and describe what you did see.
- **Never fill a required field by inference.** A stub document means the
  holding is `null`, not a reconstruction from the case name. Five quotes
  requested and two supported means two.
- **Never manufacture corroborating detail** — citation numbers, dates,
  docket numbers, bracketed histories. They defeat the reader's ability to
  spot the gap.
- **Distinguish "absent" from "could not retrieve."** "The opinion does not
  discuss intent," "CourtListener has no record of that case" (quirk 21) and
  "I was rate-limited before I could check" are three different findings.
- **A partial answer with its limits stated beats a complete-looking one.**
  Read 3 of 12 chunks? Report that.
- **If your premise is false** — told the case concerns a landslide, it
  concerns flooding — report the correction; do not answer as though the
  premise held.

If you find yourself composing text because a field seemed mandatory, stop:
it was never mandatory.

### Known CourtListener quirks — do not rediscover these (43)

Tags: **`[measured]`** established by a dedicated test · **`[verified]`**
observed directly with a concrete artifact · **`[reported]`** observed once,
not independently reproduced · **`[inherited]`** carried forward, not
re-tested. Treat any untagged claim as unverified.

1. `[inherited]` **`snippet` is not returned by the opinion search index.**
   Do not request it, do not wait for it, never fabricate one. Score on case
   name, court, date and cite count.

2. `[verified]` **`cluster_id` ≠ `opinion_id` on many records, split by
   ingestion source not date, and a cluster id passed in the `opinion_id`
   slot of `read_document` silently returns an unrelated case.** The
   dedicated `cluster_id` parameter is safe and lists every sub-opinion. Use
   the pre-resolved `opinion_id` your prompt gives you; confirm the text is
   your assigned case (quirk 15); treat any document under ~1,000 characters
   as a probable wrong-id or stub.

3. `[verified]` **`cites:()` matches opinion ids, never cluster ids.**

4. `[reported]` **Nested boolean queries suppress results from some
   courts.** Array-form `court` filters with 4+ OR-groups returned zero
   state-supreme-court hits where a simple phrase returned the whole line.
   If a court-filtered query looks implausibly thin, re-run it as a simple
   phrase against that one court ID before concluding the authority does not
   exist.

5. `[inherited]` **Always set `stat_Published`, `stat_Unpublished` and
   `stat_Unknown` to `true`** on every opinion search including `cites:()`;
   the default silently drops most PACER-harvested decisions.

6. `[inherited; court_id added v10.0]` **Always pass `fields`:**
   `["caseName","court","court_id","court_citation_string","dateFiled",
   "citation","citeCount","cluster_id","absolute_url","status",
   "docketNumber"]`. `court_id`, `docketNumber` and `dateFiled` are what the
   GovInfo crosswalk needs; a row missing any of them cannot be given a free
   text lane.

7. `[verified]` **`search_document` returning 0 matches is INCONCLUSIVE.** It
   is a literal grep over text with hard line wraps, star-pagination spans,
   `<em>` tags, citation markup and curly apostrophes. Always retry with a
   distinctive 5–8 word fragment — a single printed line, ~45–60 characters,
   clear of case names and page breaks — before grading `not_found`. A 0 on a
   short distinctive stem is much stronger evidence of absence than a 0 on a
   long phrase; use short stems for absence checks. Check total length first:
   a stub's 0 means "no text," not "phrase absent."

8. `[verified]` **The `citation` field is an array of strings.** Copy it
   exactly; empty is normal for status-`Unknown` records. Never compose,
   complete or recall a citation.

9. `[verified]` **Duplicate clusters exist for some state opinions** — same
   case, same date, two or three records. Dedupe by case name + date. The
   duplicates can carry different `citation` arrays (take the fuller one) and
   one can be a text stub (try the sibling before concluding the text is
   unavailable).

10. `[inherited]` **CourtListener does not index state supreme court review
    dispositions.** A clean citator is not evidence review was never sought.
    (For Oregon the orchestrator checks the Supreme Court's own lists by
    script; you are not asked to.)

11. `[measured 2026-10-10, M41 — replaces "reaches the last 24 months
    only"]` **An unwindowed `semantic: true` query returns only the newest
    few years the court has; the older opinions are in the index and are
    reached with a date filter.** Unfiltered pages ran 2016–2025 and
    2014–2026; the same kind of question with `filed_before` 1995 returned
    1988–1994, and with `filed_before` 1985 returned 1981–1984. `[v10.3,
    M42]` The ranking favours recent decisions inside any window, so a wide
    window collapses to its last few years and a narrow one (≤ 5 years) is
    ranked well. So: write `q` as one plain-language question (no
    operators) and run exactly the windows your prompt gives. If it gives
    none and older authority matters, do not step back on your own — report
    the dated leads you saw (years where on-point cases cluster, dates of
    cases cited) so the orchestrator can aim a window. Rows near the top
    are the relevant ones; the tail drifts. Its `count` field is not a
    relevance-filtered count — ignore it.

12. `[reported]` **A `court` array with more than one ID silently drops all
    but one court**, even on simple queries (`["orctapp","or"]` → 8 hits, all
    supreme; `["orctapp"]` alone → 61). Pass exactly ONE court ID per call;
    `court` must still be a JSON array.

13. `[verified]` **In `html_with_citations`, a citation anchor's `data-id`
    is the opinion id and its `href` segment is the cluster id** — free
    harvesting of ids from an opinion already read. The linker sometimes
    mis-resolves; confirm the case name before relying on a harvested id.

14. `[reported]` **`read_document` overflows past ~2–3 chunks at
    `chunk_size` 8000.** Request 2 chunks per call. (A full read that spills
    is different — see quirk 35.)

15. `[verified]` **Many opinions carry no caption and no party names** — the
    text begins at the authoring judge. A party-name grep returning 0 on the
    correct opinion is normal; do not report `id_mismatch` on that basis.
    Verify identity by star-pagination range, factual fit, internal
    cross-references (`ante p. 147`), or one metered `get_endpoint_item` on
    the cluster.

16. `[reported]` **Court labels in the search index are unreliable on
    duplicate and harvested records** (a Sixth Circuit case labeled "First
    Circuit"; an S.D.N.Y. docket labeled S.D. Illinois). Confirm the court
    from the opinion text or the reporter citation before citing.

17. `[reported]` **`court: ["jpml"]` contains misfiled state-court
    decisions.** Screen JPML results for a federal reporter before treating
    them as Panel authority.

18. `[verified]` **Every `search` row carries `opinion_id` even when it is
    not in `fields`.** Copy it through — it makes most resolution calls
    unnecessary. **But it is not always the lead opinion** (one row returned
    a dissent, another a concurrence): check `cluster_opinions` for the
    lead/combined id before `read_document`. It remains a hypothesis until
    the identity check confirms the text. The clusters endpoint accepts no
    `id__in` filter through this client.

19. `[verified]` **A fielded OR on `citation:` resolves many known cases in
    ONE call**, each row with `opinion_id` and `cluster_opinions`. Never
    resolve known cases one search at a time; hand your list to the
    orchestrator's batch.

20. `[verified]` **Every search row carries `cluster_opinions`** —
    `[{id, type}]` for the lead, concurrences, in-part opinions and dissents.
    No lookup is needed to enumerate sub-opinions.

21. `[verified]` **`<span class="citation no-link">` in an opinion's text
    means CourtListener has NO record of that cited case**, and no search
    will find it. Grep the cached opinion first; a `no-link` span means stop
    and report the case as absent from the corpus.

22. `[verified]` **`cites:()` accepts an OR-join of many ids AND a topic
    filter.** `cites:(a OR b) AND ("phrase" OR stem*)` is a topic-filtered
    citator; `cites:(a OR … OR h) AND (overrul* OR abrogat* OR disavow*)` is a
    negative-treatment screen across a whole set, one unit per 20 rows
    returned (quirk 43). Rows do not say
    which joined id each citer cites.

23. `[reported]` **The `citation` filter can return a loose match**
    (`"470 P.3d 486"` returned a case cited at 486 P.3d 822). A hit counts
    only when its `citation` array contains the exact string requested.

24. `[measured]` **A 429 body names which cap fired.** Read the cap name, not
    just the number — `50/hour` states up to ~1800 s, `125/day` up to ~6000 s
    and beyond. Take the branch in § Rate limits; never wait more than 90 s
    under any branch.

25. `[verified]` **Concurrency arithmetic.** Three agents at 25 s spacing is
    7.2 calls/min, over the cap. Two agents at 25–30 s, or three at 40 s. The
    orchestrator's own calls count too.

26. `[measured; corrected 2026-10-03]` **A `search` call costs one unit per
    20 rows it returns**, not one unit flat. The 2026-09-07 measurement used
    one-row probes. A 40-row search moved the hourly counter 9 → 11; a
    60-row request that matched 5 rows cost 1. See § Rate limits.

27. `[measured]` **Cached document reads are free, serve inside any
    exhausted window, and persist across sessions** (≥15 h observed). Only
    first fetches cost anything.

28. `[reported]` **Duplicate clusters exist for federal reporters too**
    (*Prudential Real Estate v. PPR Realty*, 204 F.3d 867, as two clusters
    with different citation arrays). Dedupe every result set by case name +
    date and OR both ids in `cites:()`.

29. `[reported]` **`<em>` tags around a case name shred a `search_document`
    fragment exactly as a line wrap does.** Split the fragment at the case
    name; shortening does not help while it still crosses the tag.
    Star-pagination markup also differs by record (`<span
    class="star-pagination">` vs inline `<page-number>`); check which form a
    document uses before building fragments.

30. `[measured]` **The per-minute 429's stated availability is accurate.**
    The window is pinned to the oldest counted success and advances as slots
    age out, so a retry can be refused again with a *larger* N — that is the
    next slot, not a penalty. Sleep N + 5; see § Rate limits.

31. `[reported]` **A bare surname in a `caseName:(… OR …)` list is a wasted
    term** ("Sirbu" pulled four unrelated cases). Use at least two party names
    per OR term.

32. `[reported]` **`search_document` accepts raw HTML as a literal query.**
    Grepping for `id="fn16"` jumps straight to a footnote — free.

33. `[reported]` **Reporter-text OCR has mid-word hyphens not at line ends**
    (`to-decide`, `cliekwrap`), and a document can switch from clean markup to
    corrupted text between chunks. Build fragments from sentences you have
    seen rendered cleanly; reproduce artifacts faithfully when quoting.

34. `[reported]` **`order_by: "dateFiled desc"` with `stat_Unknown: true`
    returns result sets dominated by RECAP `trial-court-document` rows** (22
    of 30 observed) — empty citation arrays, `citeCount` 0, indistinguishable
    from briefs. Prefer `citeCount desc`; if recency matters, add
    `filed_after` and restrict to `stat_Published`.

35. `[reported]` **A full `read_document` that spills to a local file is a
    SUCCESS.** The unit is spent, the document is cached, the JSON payload on
    disk is intact. Parse it locally (`json.load`, strip tags); do not
    re-fetch with `chunk_index`. The file's lines are too long for `Read`'s
    offset/limit — slice with python or sed.

36. `[reported]` **A cluster's `lead-opinion` id is not always right.** One
    cluster listed a lead id carrying an unrelated case's docket number
    alongside the correct `combined-opinion` id. Where cluster metadata is
    internally inconsistent, prefer the `combined-opinion` id and rely on the
    identity check.

37. `[measured 2026-09-16, supersedes the 2026-09-07 entry]` **There is a
    `125/day` cap, and the connector now exposes it live through
    `get_api_usage`.** The tool is free (its own 10/min, 120/hour throttle),
    answers during a 429, and reports `used`/`remaining`/`reset_at` for the
    5/min, 50/hour and 125/day caps plus 14 days of history. Read it instead
    of estimating. The earlier statement that the usage endpoint was not
    exposed is withdrawn.

38. `[measured]` **Batching document reads does not save quota** — a 3-id
    batch costs 3 units. See § Rate limits.

39. `[measured 2026-09-16]` **Cached reads are free against all three caps,
    including the 5/min window.** Three `search_document` calls on cached
    opinions fired back-to-back left the per-minute counter at 0 used. A 429
    inside a batch therefore identifies the *unread* ids in it.

40. `[reported 2026-09-16]` **`search_document` for a statute string that
    contains parentheses can miss.** `59.115(1)` returned 0 matches in four
    opinions that plainly quote the section, because the OCR renders `(1)`
    as `(l)` and markup may split the string. Search the bare section number
    (`59.115`) or a distinctive phrase instead.

41. `[measured 2026-10-03]` **A fielded OR on `docketNumber:` resolves many
    dockets in ONE call** — seventeen CM/ECF-form numbers
    (`"3:18-cv-01651"`) with a single-court filter, one unit. A docket
    returns one row per indexed filing (three for one case); a row is the
    decision you want only if its `dateFiled` matches.

42. `[reported 2026-10-03]` **`court_id` is a returnable field and a fielded
    filter.** In `fields` it returns the court's id (`ord`, `ca9`).
    `court_id:(ca2 OR ca4 OR ca5 …)` inside `q` returned rows from nine of
    twelve listed courts in its first 60, where a multi-id `court` array
    drops all but one (quirk 12). Check the court mix in what comes back
    before relying on it for coverage.

43. `[measured 2026-10-03]` **`num_results` above 20 multiplies the cost**
    (quirk 26). "Ask for 100, it costs the same" was wrong and is withdrawn:
    100 rows are 5 units. Tight queries are cheap; wide ones are not.

### The GovInfo lane — reading without spending CourtListener budget

`[added v10.0]` Some cases in your prompt carry a `granule_id` (`USCOURTS-…`
or `USREPORTS-…`) and `text_source: "govinfo"`. For those, the opinion is the court's own PDF
from the Government Publishing Office, read with `scripts/govinfo.py` through
Bash. **It costs no CourtListener units, has no practical rate limit, and
needs no call spacing.** Never fetch a GovInfo-lane case from CourtListener as
well, and never use WebFetch on a govinfo.gov address (WebFetch summarizes;
you need the text itself).

`<govinfo.py>` is the absolute path your prompt gives; `export
GOVINFO_CACHE=<the directory your prompt gives>` before the first command so
every agent shares one cache.

```
python3 <govinfo.py> fetch  <granule_id>          # download + extract, prints pages/chars/opening/ocr_layer
python3 <govinfo.py> read   <granule_id>          # whole opinion, page-marked;  --pages 3-7 for a range
python3 <govinfo.py> grep   <granule_id> "phrase" # normalized literal search, page numbers returned
python3 <govinfo.py> verify <granule_id> quotes.json   # grades each quote; run it on YOUR OWN quotes before returning
```

Rules for the GovInfo lane:

- **Identity first.** `fetch` prints the document's `opening`. Confirm it names
  your assigned case (parties or docket number) and is an opinion, not a
  two-page order. If not, return `{"id_mismatch": true, "found_instead": …}`.
- **Read the whole opinion** (`read`, in page ranges if long). Footnote text
  is printed apart from the body at the foot of each page; a quote from it
  is a footnote quote and says so. Page markers are
  `[slip op. page N of M]` for USCOURTS and `[563 U.S. 344 | Opinion of the
  Court]` for USREPORTS.
- **Quote only the court's words.** A Ninth Circuit slip opinion opens with a
  staff `SUMMARY` that "constitutes no part of the opinion"; a U.S. Reports
  case opens with a `Syllabus` and sometimes counsel's argument. Never quote
  those. In U.S. Reports the page marker names the section — a quote from a
  page marked `…, J., dissenting` or `concurring` must be reported as such.
- **`adoption_hint` in your prompt** means the dated filing may be a short
  order adopting a magistrate judge's findings; the reasoning is in the earlier
  granule listed beside it. Read both, and say which granule each quote is from.
- **`ocr_layer: true`** means the text is OCR of a page scan. Before returning
  any quote from such a document, look at the page itself — `Read` the
  `pdf_path` with `pages` set to that page — and quote only words the page
  image shows. If the text layer misreads a word inside your passage, choose a
  different passage or trim it; never repair a quote by hand.
- **Say whose words they are.** One slip PDF holds the court's opinion and
  any concurrence or dissent (`MILLER, Circuit Judge, concurring in part
  …:`). A quote from a separate opinion is returned with `opinion_part`
  naming the judge, and is never the basis for `holding`. A **findings and
  recommendation** is a magistrate judge's recommendation, not a ruling:
  report it as "F&R, adopted by order of <date>" (or "not shown as adopted").
- **Run `verify` on your quotes before you return.** Write them to a JSON
  array, run `verify`, and return for each quote the `grade`, the page label
  from `cite_pages`, the `opinion_part` and any `cautions`. **Quote
  whole sentences, plainly**: no ellipses, and no brackets except a changed
  capital (`[T]he`). The script compares the words inside a bracket like
  any others, so `[the defendant]` for a name, or any inserted word, grades
  `likely`; so does **any ellipsis of yours that leaves words of the opinion
  out** (not only one hiding a "not" — "the trial court . . . denied" for
  "erred when it denied" is the same defect), and a quote that starts or
  stops mid-word. Any quote that starts or stops mid-sentence comes back
  with a `lead_in` or `trail_off` caution showing the rest of the sentence
  ("we do not…", "plaintiff argues that…") — quote the whole sentence
  instead. A sentence that only restates a party's argument, or sits inside
  a block quotation of another court, will verify: saying so in `context` is
  your job, not the script's. When a quote grades
  `likely`, read `differences`: if you had a word wrong, **re-read that
  passage and fix your analysis first**, then requote whole sentences from
  `source_sentences`, verify again, and set `requoted_from_source: true`. A
  quote that is `not_found` is dropped, not explained away.
- **Page references are slip-opinion pages** (`slip op. at 12`) for USCOURTS
  and official pages (`563 U.S. at 344`) for USREPORTS. Never convert a slip
  page into a reporter page.
- **Never compose a citation from what you read.** Copy the
  `bluebook_citation` in your prompt exactly.
- If `fetch` returns `"found": false`, report `text_unavailable: true` with the
  `reason`; do not fall back to CourtListener on your own — the orchestrator
  decides whether that read is worth a unit.

GovInfo holds **federal** opinions only — no state court, no W.D. Wash., no
unpublished Ninth Circuit disposition, nothing before about 2004 — and it is
not a citator. If your prompt gives no `granule_id` (and no `OJD-…` / `WA-…` id — see the
next section) for a case, that case is CourtListener-lane and everything
above this section applies to it.

### The state lanes — Oregon official reports, Washington slip opinions

`[added v10.0, 2026-10-05]` A case in your prompt with `text_source:
"state"` carries an id beginning `OJD-` (Oregon Judicial Department: the
official Oregon Reports pages) or `WA-` (Washington Courts: the slip
opinion). You read it with the **same commands** as the GovInfo lane —
`fetch`, `read`, `grep`, `verify` — and **every rule of the GovInfo lane
above applies**: identity first, read the whole opinion, quote whole
sentences plainly, view the page of an OCR document before quoting, run
`verify` on your own quotes, never fall back to CourtListener on your own.
It costs no CourtListener units. Put the id in quotes on the command line
(some contain `%`). The script waits a second between requests to the
court's server; that is normal, not a hang.

What is different:

- **The output opens with the document's own record** — `case_name`,
  `citation`, `pub_status`, `document_notes`. Copy `document_notes` into
  your return unchanged. They say things the reader must be told:
  *nonprecedential memorandum opinion* (Oregon — not binding precedent);
  *slip opinion, not the official report* and *no longer the court's
  official opinion* (Washington); *unpublished* / *published in part*; *a
  separate opinion in this document could not be located*.
- **Front matter is not the opinion.** An Oregon document opens with a
  caption page and often a staff-written case summary ("*Held:* …"); a
  Washington slip opinion may open with a cover notice. `read` prints these
  inside a `----- … (NOT opinion text) -----` block. **Never quote from
  inside that block, and never take the holding from a "Held:" summary** —
  read the opinion. `verify` grades such a quote `not_found` with
  `not_opinion_text`; drop it.
- **Page labels.** Oregon: `[326 Or App at 118 (official page; PDF page 2 of
  5)]` — return `official_page` from `cite_pages` as the page; it is a real
  reporter page. Washington: `[slip op. at 5 (PDF page 6 of 57)]` — return
  `slip_page`; it is **not** a reporter page, and each separate opinion
  starts again at 1, so return `opinion_part` with it. If a label says the
  page number is unconfirmed, inferred or not read (`verify` adds a
  `page_label` caution), say so in your return rather than choosing a
  number.
- **Separate opinions** are headed `JAMES, J., dissenting.` (Oregon) or
  `MONTOYA-LEWIS, J. (dissenting)—` (Washington). The same rule: a quote
  from one is returned with `opinion_part` naming the judge and is never
  the basis for `holding`. **Do not rely on the script alone for this.**
  You are reading the opinion: when you pass a heading like those, or a
  page whose running head says "Dissent", everything after it is that
  judge's until the next heading — report it so even if `verify` does not,
  and say in `new_quirk` that the heading was missed. A `separate_opinion`
  caution reading "could not be located" means the document has a dissent
  or concurrence the script could not place: look at the page (`Read` the
  PDF) before attributing any quote to the court.
- **A decision can have no majority opinion** — a short per curiam followed
  by a signed "lead opinion", or a plurality. The first signed opinion in
  the file is then not the court's, and what it would do can differ from
  what the court did. If the opinions call one another "the lead opinion"
  or "the plurality" (`verify` adds a `fractured_decision` caution when
  those words occur), report in `holding` what the **court** did — the per
  curiam's or the judgment line's disposition — and name the opinion each
  quote comes from and how many judges joined it.
- **A Washington opinion "published in part"** has a sentence saying that
  only the foregoing portion will be printed. Text after it is unpublished
  (`unpublished_part` caution): say so with any quote from it.
- **Never read a New York opinion from a nycourts.gov page, and never fetch
  a Westlaw or LexisNexis address.** New York cases are CourtListener-lane.
- If `fetch` returns `"found": false`, report `text_unavailable: true` with
  the `reason`.

### Output discipline

- Return **only** the JSON your contract specifies. No prose.
- Always include `rate_limited`, and when rate-limited, `limit_hit`
  (`"per_minute"` | `"hourly"` | `"daily"`) and `limit_body` (the verbatim
  429 text). Do not return a call count — the orchestrator reads the real
  spend from `get_api_usage`. If you fetched any document you were not
  assigned, say which and why in `extra_fetch_explanation`.
- If you discover a NEW API quirk not listed above — CourtListener,
  GovInfo or a state source — report it in `new_quirk`.
- Never include the GovInfo API key, or a URL containing `api_key=`, in
  anything you return.
- Quote only what you actually read in the fetched text. If you cannot find
  language you were told to expect, say so plainly.

## END CANONICAL BRIEFING

---

## Maintenance note (orchestrator only, do not paste)

When a subagent returns a `new_quirk`, add it above tagged `[reported]` until
something independently reproduces it, then promote it. Log the evidence in
`CHANGELOG.md`; record measurements in `references/measurements.md`. Treat a
subagent's contradiction of this briefing as a high-priority edit, not agent
error — several of the corrections above came from agents reporting that the
briefing was wrong. Quirk numbers are stable; do not renumber, because the
changelog and the other reference files cite them.
