# Measurements — what is known, how it was established, and what is not

**Why this file exists.** The skill has no memory between runs, so every
empirical fact it relies on must live in a file or be rediscovered by burning
calls. `CHANGELOG.md` records *why* each rule changed, but it is long and
chronological: a future editor asking "has anyone actually measured this?"
should not have to read twelve versions of narrative to find out.

**This file is the empirical ledger.** Three sections: what has been measured
and by what method; what is assumed but unmeasured; and what is openly
unknown. Read it before redesigning anything that depends on API behaviour,
and before spending a window on a test that has already been run.

**Maintenance.** A new measurement is added here *and* to the rule it
supports. When a measurement supersedes an earlier claim, list the superseded
statement in § 4 rather than editing the old changelog entry — history stays
history. Tag every row with the date and the method, never just the result.

---

## 1. The measurement instrument — the 5/min window as a ruler

Most of what is known here was measured cheaply, using the **per-minute cap as
a calibrated ruler**. The technique generalizes and is worth knowing before
designing any new test:

> The 5/min window admits exactly 5 units and refills in about 60 seconds.
> To measure what an unknown operation costs: sleep 70 s to clear the window,
> perform the operation once, then fire single trivial `search` probes back to
> back and count how many succeed before the `5/min` 429. **The operation cost
> 5 minus that count.**

The trivial probe is:

```
search(type="o", q="arbitration", num_results=1, fields=["caseName"])
```

This is dramatically cheaper than probing the hourly or daily caps: a full
measurement costs under ten units and about three minutes, versus up to 50
units and an exhausted day. Two of the measurements below were obtained this
way. A related free technique: **read the sequence of "Expected available in N
seconds" values across several rejected retries** — if N counts down toward a
fixed instant, the window has a fixed reopen time; if it holds or grows, the
rejections are being recorded.

**Design rule for future tests:** measure against the smallest cap that
exhibits the behaviour. Reserve hourly and daily probes for things that only
manifest at that scale, and expect a daily probe to cost the rest of the day.

---

## 2. Measured

| # | Finding | Date | Method | Where it is used |
|---|---|---|---|---|
| M1 | **Three caps: 5/min, 50/hour, 125/day** | 2026-09-07 | All three 429 bodies observed directly. Daily body verbatim: `Rate limit exceeded: 125/day. Expected available in 6039 seconds.` Matches CourtListener's own documentation | SKILL.md budget, briefing, banner |
| M2 | **The daily window is rolling 24h, not a midnight reset** | 2026-09-07 | Two daily-429 bodies 86 minutes apart pointed at the same recovery instant (~04:27Z), which was exactly 24 h after the *previous day's* run began its calls | SKILL.md, pipeline budget |
| M3 | **`search` costs 1 unit** (the two-unit hypothesis is falsified) — **qualified by M29 (2026-10-03): true for searches returning ≤ 20 rows; the probes used `num_results=1`** | 2026-09-07 | 46 consecutive searches on a clean window drew **no** hourly 429. At 2 units the cap refuses call 26; so cost × 46 < 50, and cost = 1 | pipeline allocation table, quirk 26 |
| M4 | **Cached document reads are free and persist across sessions (≥15 h)** | 2026-09-07 | With the daily pool exhausted, `search_document` on an opinion fetched ~15 h earlier *in a different session* returned full content, while `read_document` on a never-fetched opinion was refused — 20 s apart, same pool | quirk 27, the whole cache doctrine |
| M5 | **Rejected requests consume no quota and do not extend the window; the stated availability is accurate** | 2026-09-07 | 5/min ruler, two cycles. N sequences **50/47/45/42** and **43/41/39/36** — monotonic countdown to a fixed instant. Sleeping the last N+5 succeeded both times | quirk 30, the 429 branches, ledger rules |
| M6 | **A batched document call costs one unit PER DOCUMENT** | 2026-09-07 | 5/min ruler. 3-document batch left room for exactly 2 more calls (5−2=3); 2-document batch left room for exactly 3 (5−3=2). Both trials agree | quirk 38, `calls_metered` discipline |
| M7 | **Phase 7 quote verification catches fabrication, not just typography** | 2026-09-07 | Blind adversarial injection: 7 quotes across 4 cached opinions, 4 of them fabricated, verifier not told. Result 7/7 — all genuine verified, all fabrications `not_found` with `confirmed_absent`. It caught a **paraphrase** of real language rather than accepting the near-match, and ran exhaustive checks (all 7 "savings clause" matches enumerated and rejected) | validates the Phase 7 design |
| M8 | ~~**CourtListener publishes a Usage API, but this connector does not expose it**~~ — **superseded by M10 (2026-09-16)** | 2026-09-07 | `/api/rest/v4/api-usage/` is documented (independent throttle, reports `remaining`/`reset_at`, answers when other requests fail). `call_endpoint`'s enum does not include it; the URL is robots-disallowed to WebFetch | quirk 37 — do not spend calls hunting for it |
| M9 | **Archived ORS editions are fetchable by constructed URL; the landing page is not navigable** | 2026-09-15 | Direct WebFetch: `archives.oregonlegislature.gov/ORS_Archives/<YEAR>-Chapter-059.PDF` for 1985/1987/1989/1991/1993 and `oregonlegislature.gov/bills_laws/Archive/<YEAR>ors059.pdf` for 1999/2001 all returned ORS 59.115 body text and bracket; `1997ors059.pdf` 404. Three passes on `Pages/ORSarchive.aspx` (three casings) returned no year-specific href. OCR error rate: 4 distinct misreads across 9 fetches, none surviving the two-fetch check | statute-sources § Archived ORS editions, SKILL.md § Historical statute text |
| M10 | **The connector exposes `get_api_usage`, free, live, and usable while throttled** | 2026-09-16 | Called five times during the v9.6 run, including immediately after a `5/min` 429. Reports `used`/`remaining`/`reset_at`/`blocked` for the 5/min, 50/hour and 125/day `user` caps, a `citations` scope, a `fetch` scope, its own `api_usage` throttle (10/min, 120/hour) and 14 days of daily totals. Its summary matched the 429 bodies exactly. Supersedes M8 | SKILL.md § Budget, pipeline § Spending from live counters, briefing quirk 37, banner flags |
| M11 | **Cached document reads count against none of the three caps, including 5/min** | 2026-09-16 | With the per-minute window empty (`used: 0`), three `search_document` calls on already-fetched opinions were fired back-to-back; `get_api_usage` immediately after still showed `5/min used: 0`, hourly and daily unchanged. Separately, 15 cached verification calls between two readings left the hourly counter at 40 both times | briefing quirks 27 and 39, verification-phase concurrency rule |
| M12 | **Hourly and daily counters agree with a hand count only when cached reads and rejections are excluded** | 2026-09-16 | Between two readings (32 → 40 hourly) the orchestrator made exactly 8 first-touch calls (5 unread documents in two batches, 3 searches) plus ~10 cached calls and 0 rejections. Confirms M4/M5/M6 jointly against the live counter | retires the ledger (v9.6) |
| M13 | **GovInfo is reachable from the cloud workspace and allows 36,000 requests/hour** | 2026-10-03 | `curl` to `api.govinfo.gov/collections`: HTTP 200, header `x-ratelimit-limit: 36000`. Several hundred requests and 48 PDF downloads in the measuring session drew no 429. No daily cap is documented or was observed | SKILL.md § Budget, govinfo.md |
| M14 | **USCOURTS coverage is federal-only and court-by-court** | 2026-10-03 | `search` counts by `courtname:`/`circuit:`. D. Or. 48,098 granules (1,700–2,225 a year 2005–2025); E.D. Wash. 49,667; **W.D. Wash. district 0** (bankruptcy 282); **S.D.N.Y. district 0**; **C.D. Cal. district 0**; N.D. Cal. 441,141; 9th Cir. 11,501. No state court and no Supreme Court in the collection | govinfo.md § 1, `KNOWN_ABSENT` in govinfo.py |
| M15 | **The Ninth Circuit publishes only precedential opinions to GovInfo** | 2026-10-03 | One CourtListener `ca9` search returned 40 rows, 38 after removing duplicate clusters: 15 of 17 `Published` resolved to a granule (misses: a 2006 en banc; an original opinion later replaced by an amended one); **0 of 21 `Unpublished`** | govinfo.md G2, G5 |
| M16 | **CourtListener row → GovInfo granule by docket + date + name works for D. Or.** | 2026-10-03 | 9 CourtListener `ord` rows: 8 resolved (the miss is a 2002 `CIV.02-592-ST` docket), in 3.5 s; all 8 PDFs fetched and extracted in 2.9 s. Docket strings arrive as `6:25-cv-02069`, `No. 3:11-CV-430-BR`, `Case No. 6:13-cv-01478-AA` — all parsed | pipeline Phase 3–4, `resolve-batch` |
| M17 | **The same crosswalk across ten other federal courts: 49 of 56** | 2026-10-03 | One CourtListener search (`court_id:(…)` in `q`) returned 60 rows under nine court labels, 56 after removing duplicate clusters; one row labelled `cadc` was a D.D.C. decision (quirk 16) and is counted under `dcd`, hence ten courts. ca4 4/4, ca5 11/11, ca7 8/8, ca10 3/3, ca11 8/8, cadc 1/1, dcd 1/1, ded 1/1, ca2 8/12, cand 4/7. cand docket strings lack the office digit; the script tries offices 1–9 and requires date + name. One correct docket was refused because its GovInfo title (`In Re Uber Text Messaging`) did not match the case name — a deliberate false negative | govinfo.md § 1, § 3 |
| M18 | **CourtListener text and GovInfo text of the same opinion are not interchangeable for quote checking** | 2026-10-03 | *Willis*, 878 F. Supp. 2d 1208: 40 sentences sampled from CourtListener's reporter text, checked against the GovInfo slip PDF: 26 exact, 11 ≥92 % similar (`(# 22)`/`(#22)`, `Or.App.`/`Or. App.`, CourtListener OCR `áre`, `.require`), 3 not found (a GovInfo OCR `id` for `did`; page-break sentences) | hard rule 2, govinfo.md § 2 (the lane rule) |
| M19 | **A date-matched granule can be a bare adopting order** | 2026-10-03 | *Meunier*, 51 F. Supp. 3d 1023: GovInfo granule dated 2014-09-24 is 2 pages / 2,027 chars; CourtListener's text is 64,590 chars and a `search_document` for "Recommendation" shows the F&R printed beneath the order. The F&R is GovInfo granule `-0`, dated 2014-08-28 | govinfo.md G4, `adoption_hint` |
| M20 | **GovInfo search returns federal filings CourtListener search does not; most are not in CourtListener; half are magistrate recommendations** | 2026-10-03 | Same query, D. Or.: CourtListener 9 rows, GovInfo 25 (all 8 post-2004 CourtListener rows included). One `docketNumber:(17 numbers)` CourtListener call (1 unit) for the other 17: 5 rows on 3 dockets, none on a granule's own date. `govinfo.py docket` on the 17: **9 district-judge opinions/orders, 8 magistrate F&Rs — all 8 adopted by a later order in the same docket**; the 3 CourtListener dockets are 3 of those adopting orders. 14 of the 17 dockets are not in CourtListener | pipeline Phase 3–4, govinfo.md § 4, G15, quirk 41 |
| M21 | **`govinfo.py verify` separates genuine, altered and fabricated quotes** | 2026-10-04 (final script, after three M31 review rounds) | 21 opinions (D. Or. ×6, N.D. Cal., D. Ariz., 3d Cir., 5th Cir., 7th Cir., 9th Cir. ×4, 10th Cir., U.S. Reports ×5; 5 with OCR layers). 1,371 strings sampled from the extracted body and footnote text (up to 60 + 10 per opinion): the **54** lying in a syllabus or staff summary all refused; **10** that the sampler had cut across a footnote or section boundary refused (correctly); the other **1,307 all `verified`** — 640 with no caution, 211 `separate_opinion`, 109 `footnote`, 104 `page_break`, 31 `section_boundary`, and `lead_in` 196 / `trail_off` 228 because the sampler splits at abbreviations. The same 1,307 with one word (`not`) inserted: **all refused**. **550 of 550** single-digit changes refused. 4 invented holdings per opinion: **84 of 84** `not_found`. Sentences are sampled from the script's own extraction, so this measures the checker, not the extraction (for that see M18, M23) | pipeline Phase 7D, govinfo.md § 3 |
| M22 | **Throughput** | 2026-10-03 | 8 D. Or. PDFs fetched + extracted: 2.9 s. 15 9th Cir. PDFs: 3.7 s. `triage` of 25 D. Or. opinions on 3 terms: 4.8 s. `resolve-batch` of 56 rows (with office guessing): 21.9 s | pipeline Phase 3 "pre-read" |
| M23 | **Some GovInfo PDFs are scans with an OCR text layer; viewing the page image works** | 2026-10-03 | 6 of 25 D. Or. opinions from one search (2010–2020) flagged `ocr_layer`. Misreads seen: `id`/`did`, `contract)`/`contract]`, `V.`/`v.`, `Conception`. In the analyzer test the agent viewed pages 25, 32, 37, 38 of an OCR-layer opinion and all four quotes matched the images | govinfo.md G7, hard rule 9 |
| M24 | **U.S. Reports (USREPORTS) holds Supreme Court opinions vols. 1–586, addressable by citation** | 2026-10-03/04 | `USREPORTS-<vol>-<page>`: 563 U.S. 333, 550 U.S. 544, 584 U.S. 497, 561 U.S. 63, 304 U.S. 64 all resolved with matching titles; 587 U.S. 176 and 596 U.S. 411 → not held; an `S. Ct.`-only citation → not attempted; a wrong case name on a right citation → refused. Running heads: the first build read none in vols. 514–556 (a printer's stamp line sits above the head). After the fix the second reviewer's fifteen-granule sample (vols. 304–570) read every page in thirteen and all but one page in two | govinfo.md § 1, G9, G10 |
| M25 | **GovInfo serves the U.S. Code by section for edition years 1994–2024** | 2026-10-03 | `govinfo.py usc`: 15 U.S.C. § 1692k (2024, 2008), 9 U.S.C. § 2 (2024, 2000, 1994) returned; 1993 and 2025 → HTTP 400. Same evening the OLRC site returned a maintenance page on two fetches | statute-sources § "U.S.C. via GovInfo" |
| M26 | **GovInfo full-text search finds citing federal opinions by case name or reporter cite** | 2026-10-03 | `"Bielski v. Coinbase"` → 72 granules; with the negative-treatment terms → 22; `"836 F.3d 1102"` and `"836 F. 3d 1102"` → the same 7. Wildcard works (`unconscionab*` 483 vs 482 for the three spelled forms). Proximity does not (`"unilateral modification"~10` = the bare phrase; reversed order → 0) | govinfo.md `cites`, G13 |
| M27 | **An analyzer subagent can run the GovInfo lane end to end** | 2026-10-03 | One agent, three cases (a 9th Cir. opinion with a staff summary; an adopted F&R; an OCR-layer opinion), given only the briefing section: read 24 + 23 + 39 pages, returned 12 quotes with slip pages, self-verified; the orchestrator's independent `verify` graded all of them `verified`. It dropped its own first-choice quote when it graded `likely`. 0 CourtListener units, 145 s. (The `likely` was a Ninth Circuit running head inside a page-spanning sentence; the script now strips that head) | briefing "GovInfo lane", pipeline Phase 5 |
| M28 | **`court_id` is returnable in `fields` and usable as a fielded filter in `q`** | 2026-10-03 | Requested in `fields` on four searches: returned each time. `court_id:(12 ids)` in `q`, no `court` array: 498 hits, 9 of the 12 courts among the first 60 rows | briefing quirks 6, 42 |
| M29 | **A `search` costs one unit per 20 rows returned, not one unit per call** | 2026-10-03 | `get_api_usage` before and after a single `search(num_results=40)` that returned 40 rows: hourly 9 → 11, 5/min 0 → 2, day count 24 → 26. Consistent with the session total: seven calls moved the hourly counter 0 → 11 (rows returned 9, 40, 5, 60, 40 → 1+2+1+3+2, plus one first read and one first `search_document`). M3's 46 probes used `num_results=1`, so M3 stands only for ≤20-row searches | pipeline § Budget, courtlistener-mcp, briefing quirks 26, 43 |
| M31 | **Three rounds of independent adversarial review found false `verified` grades; every reproduced case was fixed before release** | 2026-10-03/04 | Reviewer subagents with no edit rights diffed v9.6 against the build, read every file and attacked `verify`. **Round 1** reproduced: a quote cut from inside "unenforceable" verified; an ellipsis hiding "do not" verified; `[in]correctly` and `[do not]` verified; an ellipsis joining pages 5 and 22 verified; a mid-page sentence joined to the next page's opening verified; syllabus and dissent pages unlabelled in U.S. Reports vols. 514–556; the API key echoed in a `resolve-batch` error; `resolve` accepting a row with no case name. **Round 2**, on the fixed build, reproduced: `[S]ufficient` verifying against "insufficient"; trailing brackets (`[with prejudice]`, `[Coinbase]`) ignored; five circuit dissent headings undetected (3d Cir., four 10th Cir.) of 78 surveyed; a body-text "(per curiam)" taken for an opinion's opening line; only a quote's first character checked for section; 11 of 37 real recommendations across seven districts not flagged. The fix after round 2 was a simpler rule, not more special cases: bracket *characters* are ignored and the words inside compared like any others; every part of an elided quote must be three words; a quote's whole span is checked; a sentence split by a page break is never `verified`; a mid-sentence start after a negation or an attribution raises `lead_in`. **Round 3**, on that build, reproduced: numbers changed after a comma, colon or apostrophe verifying (`$31,999` for `$31,000`; `§ 4:91` for `§ 4:19`) — a defect the round-2 fix itself introduced by ignoring footnote-call digits on both sides; a mixed-case dissent heading (`Rawlinson, Circuit Judge, …`) undetected; fragments after negators outside the word list ("nothing in", "whether", "hardly"); list items and other courts' holdings quoted without their lead-in; body text run into a footnote; quotes stopping just before "not". Fixes: every digit compared (footnote calls ignored only in the opinion, only on a second attempt, with a caution); body and footnote text matched as separate streams; `lead_in` and `trail_off` raised for *any* mid-sentence start or stop, printing the rest of the sentence; mixed-case headings detected and citation parentheticals excluded. Every reproduced input now grades `likely` / `not_found` or carries a caution, and M21 was re-run on the final script. Round 3 also listed what a string check cannot see (a party's argument restated in a whole sentence; a block quotation of another court) — see O11 | govinfo.md § 3 "What `verified` does and does not mean", cautions table |
| M32 | **Separate opinions and adopted recommendations are detectable from the document and the docket — as a backstop** | 2026-10-04 | *Bielski*: `MILLER, Circuit Judge, concurring in part and concurring in the judgment` detected; a quote from slip p. 24 carries `separate_opinion`. After the round-2 fix the five missed headings (`AMBRO, Circuit Judge, dissenting`; `PHILLIPS, J., dissenting`; `EID, J., dissenting`; `ROSSMAN, J., dissenting` ×2) are detected. *Twombly*, 550 U.S. 570: the majority's last lines sit on a page headed "Stevens, J., dissenting"; the quote is assigned to "Opinion of the Court" by the single-opening-line rule; Brennan's concurrence at 473 U.S. 594 (OCR volume) now raises `section_boundary`. Recommendations: all 8 Oregon F&Rs and the five named round-2 misses (S.D. Tex., S.D. Fla., W.D.N.Y., D. Or.) are flagged by both the docket-text and the caption detector; an adopting order and four ordinary opinions are not | govinfo.md G9, G15, G16 |
| M33 | **Three state publishers, three levels of access** | 2026-10-05 | Oregon Judicial Department collection (`ojd.contentdm.oclc.org`, CONTENTdm JSON API): open, no key, `robots.txt` `Crawl-Delay: 1`; catalogue counts — Supreme Court 3,162 items from 326 Or 1 (Aug. 21, 1997), Court of Appeals 19,480 from 152 Or App (Jan. 7, 1998; 2,447 catalogued "Nonprecedential opinion"), Tax Court 8,285 from 1 OTR (1962), 641 petitions-for-review lists from Aug. 1997. `courts.wa.gov`: `robots.txt` does not disallow `/opinions/`; year listings Supreme Court 2013 →, Court of Appeals published 2012 →, unpublished and part-published 2013 →; the search form is JavaScript-driven. `lexisnexis.com/clients/wareports` (Washington official reports): WebFetch `ROBOTS_DISALLOWED`. `govt.westlaw.com/nyofficial` (New York Official Reports): WebFetch `SITE_BLOCKED`. `nycourts.gov`: a browser check stops scripts; WebFetch reads Law Reporting Bureau pages. Neither blocked site was fetched by any other route | state-sources §§ 1, 3–5; hard rule 10; source-status rows |
| M34 | **CourtListener rows crosswalk to the state sources on three keys** | 2026-10-05 | 52 real rows from three searches (3 units): Oregon Court of Appeals 19 of 19 in-coverage rows (the 20th, 1986, predates the collection and was so reported); Washington Court of Appeals 16 of 20 under the final rules (three date mismatches — an amended opinion, a substituted "Order and Opinion", a CourtListener date one day off — and one party name the court's listing misspells; the first build's looser name test accepted that row); New York 10 of 12 rows yielded a Law Reporting Bureau URL (two 2013 rows carry no slip-opinion citation). 3 min 25 s for the batch at one request a second. Adversarial rows: "State v. Momeni" + another case's citation, "Dept. of Human Services v. T. R. S." against "v. T. R. M.", a citation paired with another case's number, a date one day off — all refused after reviews 4–5 | state-sources § 2; pipeline Phase 3–4 |
| M35 | **The Oregon collection's full-text search is comparable to CourtListener's for the same court** | 2026-10-05 | `unconscionable`, Court of Appeals, 1998 →: CourtListener `count` 91 (including duplicate clusters of recent opinions: six pairs in the first 20 rows), OJD 66 distinct opinions. Phrase "procedurally and substantively unconscionable": CourtListener 3, OJD 4 (the same three plus a nonprecedential opinion CourtListener holds but did not return). "arbitration": OJD 392 hits spread evenly 1998–2026 (7–22 a year), so the index covers every year. Newest-first only; no ranking, no proximity. 2 CourtListener units | state-sources § 3; pipeline Phase 3 |
| M36 | **`verify` on state documents separates genuine, altered and fabricated quotes, and withholds front matter** | 2026-10-05 (final engine, after reviews 4 and 5) | 97 opinions — 69 Oregon (Supreme Court, Court of Appeals 2001–2026 including OCR scans and nonprecedential memorandum opinions, Tax Court), 28 Washington (Supreme Court; Court of Appeals published, unpublished and part-published, including OCR scans). 5,358 sentences sampled from body and footnote text: 5,300 `verified`, 58 `likely` (sampled across a footnote or page boundary), 0 `not_found`. One word inserted in each verified sentence: 5,300 of 5,300 refused. One digit changed: 2,088 of 2,088 refused. Fabricated holdings: 388 of 388 `not_found`. Front matter (caption, staff case summary, counsel, disposition lines, Washington cover sheet): 551 sentences sampled, 528 refused, the 23 that verified being sentences the opinion itself repeats, located at their page in the opinion. Sample facts: every Oregon opinion dated 2001–2011 was an OCR scan, born-digital from 2012; a staff case summary in every Oregon opinion dated 2011–2021, none from 2023; Washington Court of Appeals files were scans 2013–2019. `fractured_decision` fired in 10 of the 97 | state-sources §§ 3–4, 9; hard rules 2, 10 |
| M37 | **The engine changes for the state lanes left the federal lane unchanged** | 2026-10-05 | The M21 harness on all 68 cached GovInfo documents, released v10.0 (2026-10-04) engine against this one: output identical line for line (4,193 sentences sampled; 202 syllabus/summary refused; 3,951 verified; 3,951 of 3,951 alterations refused; 1,630 of 1,630 digit changes refused; 272 of 272 fabrications `not_found`), and page bodies, footnote blocks and separate-opinion headings identical document by document — re-run after each round of fixes. One deliberate difference the harness does not exercise: a quoter's ellipsis that omits any words now grades `likely` in every lane | changelog; govinfo § 3 |
| M38 | **The New York Law Reporting Bureau page can be built from the slip-opinion number and read by WebFetch** | 2026-10-05 | `…/reporter/3dseries/<year>/<year>_<nnnnn>.htm`: 2023 NY Slip Op 04822 → *Mejia v Linares*, `[219 AD3d 1251]`, "As corrected through Wednesday, November 8, 2023"; 2019 NY Slip Op 00684 → *Patel v Macys Inc.*, `[168 AD3d 632]`; 2024 NY Slip Op 50001(U) → `[81 Misc 3d 1223(A)]`, "will not be published in the printed Official Reports". Each matched its CourtListener row. One fetch each — the two-fetch rule was not itself exercised | state-sources § 5; pipeline Phase 7 B2 |
| M39 | **Two rounds of independent adversarial review of the state lanes found real defects; each reproduced one was fixed** | 2026-10-05 | Reviewer subagents with no edit rights, instructed to break the lanes and report only what they reproduced. **Round 4** (26 new downloads): 16 defects — dissents graded as the court's opinion under three heading forms (`ARMSTRONG, P. J ., dissenting`; `MELNICK, J. (dissent in part)`; `MAXA, J. ( dissenting in part, …)`); `or-history` attributing another case's WITHDRAWN entry to the decision checked; the crosswalk name test satisfied by "State" alone; no `relates_to` without `--cite`; a wrong slip page for the unnumbered first page of a short separate opinion; body lines beginning with a number taken as footnote starts (half a page moved to the footnote stream); caption dispositions graded as opinion text; an ellipsis hiding "erred when it" graded `verified` (347 such omissions the negation list did not know); the unpublished part of a part-published opinion unflagged; OCR-era review lists missed (`(Al40553)`); a dissent's footnote attributed to the court; federal New York courts claimed; and smaller ones. **Round 5** (40 new downloads) confirmed all 16 fixed and reproduced 7 more: a three-justice lead opinion (per curiam affirming; lead opinion would vacate) labelled the court's; one judge's separate opinion attributed to another (`(Concur in part, Dissent in part)`); initials-only captions matched one letter apart; a caption's history borrowed for a decision the catalogue does not hold; a superscript call and a block-quote line taken as footnote starts; footnotes missed after an OCR misread number; the Oregon caption cross-check never firing for Supreme Court captions ("dissented and filed an opinion"). Round 5's counts on the round-4 build: 950 of 950 genuine sentences verified and 0 of ~4,500 alterations; 34 page labels against page images, 0 wrong and every inferred one flagged; 90 review-list entries, 0 wrong heading, date or attribution; no majority text attributed to a judge in any real document | state-sources §§ 2–4, 7, 9; O14 |
| M40 | **Oregon review dispositions can be read by script from the Supreme Court's own lists** | 2026-10-05 | `or-history`: A176132 → DENIED Nov. 17, 2023, 371 Or 535 ("Masih, J., would allow"); A139453 → two decisions separated (241 Or App 107, review allowed July 22, 2011, reversed 353 Or 1; 269 Or App 31, review denied May 14, 2015, 357 Or 299 — also printed in the bound-volume caption); A177959 → ALLOWED Sept. 19, 2024 and Supreme Court opinion 375 Or 580; A177883 → ALLOWED May 29, 2025, with another case's entry that only mentions it reported apart; A140553 and A138563 (2010, scanned list, numbers misread by OCR) → DENIED Dec. 23, 2010 through the OCR-variant search. Decisions affirmed without opinion share a citation with dozens of cases (`236 Or App 269`): the case number, not the citation, identifies an entry | state-sources § 3; pipeline Phase 7B; hard rule 6 |
| M41 | **Semantic search holds old opinions but, unwindowed, returns only the newest few years; a date filter reaches the rest** | 2026-10-10 | Seven `semantic: true` searches, 20 rows each (7 units), three courts, two topics. *Unfiltered:* arbitration-unconscionability question, `or` → 20 rows dated 2016–2025 (same page with `order_by: "score desc"`); cell-phone search-incident question, `scotus` → 2014–2026, *Riley* (2014) at row 11, nothing older. *Upper bound only:* `orctapp`, `filed_before` 2015 → 2007–2014 (19 of 20 from 2010–2014; *Motsinger*, *Livingston*, *Hatkoff*, *Bagley* present); `orctapp`, `filed_before` 1995 → 1988–1994 (17 of 20 from 1993–94); `scotus`, `filed_before` 1985 → 1981–1984 (*Belton* present; *Chimel* 1969 and *Robinson* 1973 absent). *Both bounds:* `orctapp` 2005–2008 → rows spread across all four years, *Motsinger*, *Sprague*, *Vasquez-Lopez* in the first six. `count` ran 301–554 throughout. The earlier finding (quirk 11: "index not backfilled") observed the unfiltered behaviour correctly and inferred the wrong cause; it never applied a date filter. **Not established:** why (recency weighting in the score, or a candidate pool cut by date) — the remedy is the same either way; how far back one window reaches in a high-volume court (it reached ~4 years in `scotus` and `orctapp`, ~9 in `or`) | quirk 11; courtlistener-mcp § Semantic search; pipeline Phase 3 and 6 |
| M42 | **Semantic ranking is recency-weighted inside any window: wide windows collapse to their last few years, narrow windows (≤ 5 years) rank well; `citeCount` ordering spans eras but has low precision** | 2026-10-12 | 12 `semantic: true` searches (12 units), checked against the suite's scored authorities for two cases. Equitable indemnity (10 scored): `or` unwindowed → 2020–25, 0 hits; `or` before 2000 → 1992–99, 0; `orctapp` 1998–2015 → 2012–14 only, 1 (*Marton*); **`orctapp` 1999–2003 → 3 (*Moore Excavating* row 2, *Maurmann* 3, *Safeco* 11)**. Tort-claims caps (8 scored): `or` unwindowed → 2019–25, 1 (*Busch*); `or` 1985–2017 → 2013–16 only, 2 (*Horton*, *Howell*); **`or` 1985–1990 → 2 (*Hale* row 1, *Rogers* row 2)**. `citeCount desc`: tort caps 1949–2016, 1 hit (*Hale*); indemnity 0. Rows are not date-sorted, so not a newest-first list. From the 2026-10-12 Utah run (v10.2, interrupted): `utd` stepped windows reached 2021–25, 2019–21, 1999–2004 — none of the four scored D. Utah authorities (1979–1995). Mechanism inferred, not documented by CourtListener | pipeline Phase 3, Phase 6 Era/Premise rows; courtlistener-mcp § Semantic search; quirk 11 |
| M43 | **On a question with a distinctive statute number, keyword search found what semantic did not; the v10.2 leads round found the one on-point decision the baseline lacked** | 2026-10-12 | ORS 12.220 question, v10.2 full run (31 units, 3 rounds, single-context agent without subagents): 4 semantic queries → no case not also found by keyword; `"12.220" AND (dismiss* OR "personal jurisdiction")`, `orctapp`, `citeCount desc` → 5 of 8 scored authorities in one call (incl. *Beetham*, which the run missed). Leads round (vocabulary row "not adjudicating the merits") → *Wallace v. Holden* (2019, personal-jurisdiction dismissal is procedural) via an unpublished Tax Court order; authority rows → *Hatley* 4/5, *White* 3/5, *Tikka* 2/5; round 3 → *Rennie* 3/5. Core recall 4/4; weighted 65% (lost the ORS 12.150 tolling branch: no sub-question or premise row covered it). Utah question, v10.2 run interrupted after round 2: two of the three authorities the July baseline found only after the user asked it to continue were reached on the first pass (*Dillon Securities*, round 1, free GovInfo search; *Dahl v. Gardner* before Phase 7) | pipeline Phase 1 granularity, Phase 3 "where semantic earns its units", Phase 6 Authority test and Premise row |
| M44 | **Search cost re-confirmed: one unit per 20-row page returned, minimum one; 429 rejections free; the 5/min window counts pages** | 2026-10-12 | Hourly counter read around 11 searches: 9 semantic (20 rows each) + 2 rejected by 5/min → +9; a 0-row keyword search at `num_results` 100 and a 26-row one → +3 (1 + 2); per-minute counter showed 5 used after those two plus two earlier pages. The v10.2 ORS run's report of 15 searches costing 26 units is not reproduced by any isolated measurement; its counter readings were taken between batches, not per call, so the excess is unattributed | pipeline § Budget concurrency; courtlistener-mcp; briefing rate table |
| M30 | **What the v10.0 investigation cost** | 2026-10-03; 2026-10-05 | 11 CourtListener units in total on 2026-10-03 (hourly counter 0 → 11); 5 more on 2026-10-05 for the state-source measurements (three searches for sample rows, two for M35). Everything else — every GovInfo measurement above, the analyzer test, the release probes — cost none | changelog v10.0 |

---

## 3. Assumed but NOT measured

Acting on these is fine. Claiming they are established is not.

- **Whether rejections also spare the hourly and daily pools.** M5 measured the
  per-minute window only. Same throttle family, so very likely — but inferred.
- **Whether the hourly window is also rolling.** M2 established it for the
  daily cap. The hourly is assumed to behave the same way.
- **The upper bound of the document cache's lifetime.** M4 proves ≥15 hours
  across sessions. Nothing establishes a ceiling, and a run should not assume
  a document from last week is still free.
- **Whether the per-document batch cost (M6) actually caused the v9.1
  anomaly.** M6 proves the mechanism exists. It does not prove it was the
  cause. See O1.
- **`[v10.0]` That a slip opinion's wording equals the reporter's.** M18
  compared typography on one case. Courts correct opinions before
  publication; a GovInfo quote is the court's filed text and is labelled
  with its slip page for that reason. Not measured: how often the final
  reporter text differs in substance.
- **`[v10.0]` That the separate-opinion and section detectors catch every
  layout.** M32 and M24 cover one circuit heading style and nine U.S.
  Reports granules. A missed heading produces no caution. The analyzer's
  attribution is the primary control; the detector is the backstop.
- **`[v10.0]` That the 400-character elision limit and the negation word
  list are the right thresholds.** Chosen, not measured. `[2026-10-05]` The
  word list was shown to be the wrong tool (M39: 347 meaning-changing
  omissions it did not know — "erred", "waived", "lacked", "void"); a
  quoter's ellipsis that omits any words now grades `likely`, and the list
  only chooses the wording of the problem.
- **`[2026-10-05]` That an Oregon advance-sheet page and the bound-volume
  page carry the same page numbers.** Recent OJD items are the advance-sheet
  pages; the pins the skill gives are the numbers printed on them. Oregon
  publishes its reports with continuous official pagination, and nothing
  seen contradicts this, but no recent opinion was compared with a bound
  volume.
- **`[2026-10-05]` That the red asterisk in a Washington listing means what
  the court's page says** — the slip has been replaced by the official
  report. Read from the listing page's legend; not otherwise verified.
- **`[2026-10-05]` The cut-off years in the samples** (Oregon scans through
  2011, staff summaries 2011–2021, Washington scans through 2019) are what
  97 documents showed, not catalogue facts. The engine does not rely on
  them: it tests each PDF.
- **`[v10.0]` That `get_more_results` costs one unit per 20-row page.**
  Inferred from M29; not isolated.
- **`[v10.0]` Coverage of courts not sampled.** M14/M17 cover the courts
  listed. Any other court is "try it": `resolve-batch` answers for free.
  `KNOWN_ABSENT` in the script lists only the three district courts
  measured at zero.
- **`[v10.0]` That GovInfo is reachable from every environment the skill
  runs in.** Measured from the cloud workspace only. A desktop session
  behind an egress allowlist may block `api.govinfo.gov`; `probe` reports
  it and the run falls back.
- **`[v10.0]` The pypdf fallback's quality.** The script falls back to pypdf
  when `pdftotext` is missing; M21 was run with `pdftotext -layout` only.
- **That `search` costs 1 unit against the *daily* pool too.** M3 measured it
  against the hourly cap. M12's hourly/daily readings moved in step (8 and 8),
  which is consistent; not yet isolated.

---

## 4. Open — never tested

Listed so that a redesign spends its budget on these rather than re-running
what § 2 already settles.

**O1 — The v9.1 hourly 429 at 32 counted calls.** `[v10.0: M29 is a second
candidate explanation alongside M6 — that run's citators and screen asked
for 100 rows each, at up to 5 units apiece, counted as 1. Neither has been
replayed.]`
Neither 1-unit nor 2-unit search costs predict it, and M5 rules out rejections as the explanation. The
leading candidate is now M6: agents reporting one unit for multi-document
batches. **Since v9.6 this is moot for operations** — `get_api_usage` makes
the count authoritative (M10, M12) — but the historical discrepancy remains
unexplained. Closed as "not worth a window."

**O8 — v10.0 has not run a full research session.** `[opened v10.0]` Every
component was measured (M13–M29) and one analyzer ran the GovInfo lane on
three cases (M27), but no query has gone Phase 1 → Phase 8 under v10.0.
Unexercised joins: the Phase 3 merge of GovInfo and CourtListener rows; lane
assignment feeding the wave gate; the About table's **Text sources** row; a
GovInfo-only authority in Leading Authorities; the `cites` leads in
Subsequent History. **Test:** a federal question in the Ninth Circuit /
District of Oregon (most cases GovInfo-lane) and a state-court question with
a federal tail. Compare units spent with the v9.6 allocation.

**O9 — Does GovInfo search rank well enough to be a discovery channel on its
own?** M20 shows it returns more; nothing yet shows its top-ranked rows are
the better ones. `triage` is the safeguard. **Test:** on a question with a
known leading federal case, check its rank in `search`.

**O10 — How often does a reporter-published federal opinion have an
`ambiguous` or adopting-order granule?** Seen once in 9 D. Or. rows (M19).
A higher rate would argue for always passing every same-docket granule to
the analyzer.

**O11 — The verifier has had three adversarial reviews, each of which found real holes, and the last fixes have not themselves been reviewed.** `[opened v10.0]` There is no reason to think the third found the last. What stands between a residual hole and a published error is the rest of the protocol — whole-sentence quoting, the analyzer's own reading, the orchestrator's `verify` of record, the cautions — not the script alone. Known and unfixable by string matching: a whole sentence restating a party's argument, or a block quotation of another court, verifies cleanly; a dissent under an unrecognized heading carries no caution; a footnote continued from the previous page reads as body. **Test:** a fourth independent adversarial pass on `verify`, the footnote splitter and the section/separate-opinion detectors before relying on v10.0 for filed work; and, in ordinary use, open the PDF for any quote a memo leans on.

**O12 — No full Phase 1 → 8 run has been made with the state lanes.** `[opened 2026-10-05]` Every component was exercised on its own — crosswalk, text commands, verifier, history check, banner — and none inside a run. Unknown: how long `resolve-batch` and first fetches take inside a real wave at one request a second; whether analyzers honour the front-matter block and the document notes; how often `page_label`, `fractured_decision` and `separate_opinion` cautions fire on a real authority set and what settling them costs. **Test:** an Oregon-law question (and one Washington) run end to end; compare units spent with a v9.6 run of the same question on fresh authorities.

**O13 — How much does a Washington official report differ from its slip opinion?** `[opened 2026-10-05]` The official text is not reachable, so this cannot be measured here; the court's notice says pre-publication edits are "for style, grammar, citation, format, punctuation". The skill therefore labels every Washington quote as slip-opinion text and marks superseded slips. **Test:** a person with access compares ten quoted sentences against the bound volume.

**O14 — The state lanes have had two adversarial reviews, each of which found real defects, and the last fixes have not themselves been reviewed.** `[opened 2026-10-05]` Round 5 found fewer and narrower defects than round 4, and no false `verified` grade; that is a trend, not a proof. Known and not fully fixable by pattern: a footnote whose number an OCR scan misreads, or whose first line the PDF's text order puts above its number, stays in the body (verifies without a `footnote` caution, or fails across the page); a decision with no majority opinion is flagged only when the text says "lead opinion" or "plurality"; a separate opinion under a heading form not yet seen is caught only by the caption or listing cross-check, and a second opinion of the same listed kind ("Con/Dis Opinions") is not counted; an Oregon caption whose author line is followed by more than about 1,000 characters would be cut wrongly (largest seen: 610); `or-history` on a pre-2012 decision depends on OCR text. **Test:** a sixth independent pass before relying on these lanes for filed work; in ordinary use, open the PDF page for any quote a memo leans on — the same advice as O11.

**O15 — Semantic search: what is not yet known.** `[opened 2026-10-10; narrowed 2026-10-12 by M42]` Settled: old opinions are indexed; ranking is recency-weighted inside any window; narrow windows rank well; `citeCount` ordering is honoured but imprecise. Still open: (b) whether keyword operators or field prefixes in `q` do anything in semantic mode; (d) window reach in the busiest courts (`ca9`, `cal`) — may be months; (e) recall of an aimed-window semantic strategy against keyword on a question with a known answer set and no distinctive term, over several runs (M42 is two questions). (b) costs one unit.

**O16 — The lead ledger has not run in production.** `[opened 2026-10-10]` The fruitful-lead tests in pipeline Phase 6 are a design, not a measurement. Watch the first runs for two failures: every run finding a "fruitful" lead (the tests are too loose and the leads-only round has become mandatory in effect), and refinement queries whose `derived_from` is nominal (the query is a reworded round-1 query). Record what the *Leads* row of the About table shows over the first five runs.

**O17 — The Premise row and the fact-granular sub-questions are untested.** `[opened 2026-10-12]` Both were added in v10.3 from one run's miss (ORS 12.150). Watch whether the Premise row produces findings or routine "nothing found" closings, and whether fact-granular sub-questions make the sufficiency test fail too often (forcing rounds the user would not want).

**O7 — Whether `get_api_usage`'s `reset_at` for the hourly cap is the
oldest-request expiry or a fixed reopen instant.** The summary text says "the
oldest request expires at …", which implies a rolling window that frees one
unit at a time, consistent with M2 for the daily cap. Untested whether a
partial refill is visible in `remaining` before `reset_at`. **Test:** read
`remaining` once a minute across a reset boundary after a known burst; free.

**O2 — Does the pipeline pad when the honest answer is "no authority"?**
Hard rule 7 ("not found is always an available answer") is load-bearing and
has only ever been tested incidentally, by premise corrections that happened
to arise. **Test:** a deliberate null query — a plausible-sounding doctrine
that does not exist, or a real doctrine in a jurisdiction with no cases.
Success is an empty or near-empty Leading Authorities, the research-exhausted
banner, and a Short Answer that says so. Failure is loosely-related cases
promoted to fill the section. Cheapest high-value test outstanding; one run,
unmistakable failure mode.

**O3 — Phase 2 (anchor citator) has never executed in production.** Two live runs, neither
with anchor cases. The batched anchor resolution, the raw citator and the
topic-filtered citator are specified from earlier evidence but unexercised
under v9.2/v9.3 — and Phase 2 is the phase the pipeline claims replaces two
whole search strategies. If it underperforms, the Phase 3 strategy count is
mis-tuned. **Test:** any query naming a starting case.

**O4 — The statute chapter-truncation protocol has never been exercised on a
page that actually truncates.** Both live runs used per-section federal
sources. This is the **highest-risk untested path in the skill**, because its
failure mode is a confident false quote rather than a missing one — the
protocol exists because a fabricated statutory quotation once reached a
published report. **Test:** a query turning on a long ORS or Delaware chapter.
Success is the provision reported as *"the official chapter page truncates
before this section; text not retrieved"* with a link — never as "could not be
resolved."

**O5 — The Leading Authorities contrary-slot rule is untested where it
matters.** It passed in the v9.2 run only because two contrary cases happened
to score 5. **Test:** a query where the best contrary authority scores 3, and
confirm the reserved slots actually promote and mark it.

**O6 — Cross-run cost comparison is contaminated and will stay that way.**
Because of M4, any query run twice has a warm cache the second time. The
unilateral-modification/arbitration query is permanently compromised as a cost
benchmark; keep it as a *quality* benchmark and use fresh queries for cost.

---

## 5. Superseded — do not act on these older statements

Earlier changelog entries remain as written, because history should not be
edited. These specific claims in them are now wrong:

| Superseded claim | Where it appears | Corrected by |
|---|---|---|
| "the 10/min and 100/hour limits" | v9 and earlier entries | M1 — the caps are 5/min, 50/hour, 125/day |
| "Whether cached-document lifetime is per-session or global is untested" | v9-era entry | M4 — global, ≥15 h across sessions |
| "A `search` call probably costs TWO units" | v9.2 entry, quirk 26 as shipped in v9.2 | M3 — one unit |
| "Rejected requests appear to count toward (and extend) the per-minute window" | v9.2 briefing | M5 — they do neither |
| "A 429 body can understate the wait" | v9.2 quirk 30 | M5 — the stated availability is accurate; sleep N+5 |
| "the ledger undercounts … [because rejections] possibly [consume] quota" | v9-era entry | M5 — rejections are free; the real undercount risk is M6 |
| "CourtListener publishes a Usage API, but this connector does not expose it" (M8; briefing quirk 37 as shipped in v9.3–v9.5; pipeline "Spending without memory"; report-format "Daily pool" rationale) | v9.3–v9.5 | M10 — `get_api_usage` is exposed, free and live; the ledger is retired in v9.6 |
| "Every subagent returns `calls_metered` … sum after each wave" | v9.1–v9.5 pipeline | M10/M12 — the counters are read, not summed |
| "`search` costs **1** unit" stated without qualification (M3; quirk 26 as shipped v9.3–v9.6; pipeline "Costs"; source-status CourtListener row) | v9.3–v9.6 | M29 — 1 unit **per 20 rows returned** |
| "Prefer a generous `num_results` … one call beats two"; "Ask for 100; the call costs the same" | courtlistener-mcp through v9.6 | M29 — 100 rows cost 5 units; default 20 |
| "2 Anchor: 3 per anchor"; "4 Select: 1" | pipeline allocation through v9.6 | M29 — a 100-row raw citator alone was up to 5; now 40 rows (2 units), so 3–4 per anchor and 1–2 for the screen |
| "Reading the selected cases ~8 minimum" as an unconditional spine cost; "Minimum viable run ≈ 13 units" | pipeline through v9.6 | M13–M16 — reads on the GovInfo lane cost 0; the floor is ≈ 5 when everything selected is federal and held |
| "Every state court … Always the CourtListener lane"; "State courts … are never on it … reading state authority" as CourtListener-only work | govinfo § 1, SKILL § Budget as shipped 2026-10-04 | M33–M36 — Oregon appellate opinions (1998 →) and Washington slip opinions (2013 →) have a text lane of their own |
| "`filed_before` = the oldest `dateFiled` on page 1 of the query before it" (stepped semantic windows) | pipeline Phase 3, courtlistener-mcp, briefing quirk 11 as shipped in v10.2 | M42 — a stepped window reaches ~3 years of a busy court; windows are narrow and aimed at evidenced eras |
| "Ordering a semantic query by `citeCount` is untested" | courtlistener-mcp v10.2 | M42 — honoured, imprecise |
| "`semantic: true` only reaches recent opinions" / "roughly the last 24 months only — the embedding index is not backfilled"; "No `semantic: true` when pre-2019 authority matters"; "Semantic search for triage — not tried; quirk 11's recency limit makes it unsuitable" | briefing quirk 11, pipeline Phase 3, courtlistener-mcp through v10.1; changelog v9-era entries | M41 — the index holds opinions back to at least 1981; an unwindowed query shows only the newest few years; date windows reach the rest |
| Refinement skipped whenever round 1 is sufficient and the request is not `deep`; "Plan from accumulated `follow_up` leads" as the whole instruction | pipeline Phase 6 through v10.1 | v10.2 — a lead ledger is written on every non-`quick` run; a fruitful lead triggers one scoped round; every refinement query records the finding it derives from |
| Oregon review dispositions "— a WebFetch" of the contentdm API | statute-sources, pipeline 7B, courtlistener-mcp through 2026-10-04 | M40 — `statecourts.py or-history`; WebFetch only as a network-failure fallback |
| "an ellipsis that omits a negation" as the only elision graded `likely`; the `elision` caution on a verified quote | govinfo § 3, pipeline 7D, briefing as shipped 2026-10-04 | M39 — any quoter's ellipsis that omits words grades `likely` |
| "GovInfo — the second source"; "Two sources now feed it" | govinfo, pipeline as shipped 2026-10-04 | M33 — three kinds of source |
| "Quotes … verified verbatim against CourtListener opinion text" as the only path | report/memo format through v9.6 | hard rule 2 as amended v10.0 — verified against the source the case was read from |
