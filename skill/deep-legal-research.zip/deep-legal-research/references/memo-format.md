# Companion Memo Format

After the chat report is rendered (Phase 8), build a Word memo and deliver it
as a `.docx` file — **without waiting for the user to ask**. The memo is the
portable, printable form of the same research; the chat report remains the
primary rendering and is never skipped in its favor.

## The one rule that governs everything here

**The memo is a re-presentation of the verified report, not a second research
product.** Every authority, quotation, citation, statute text, and
characterization in the memo must already appear in the rendered report.
The memo step adds NO new research, NO new authorities, NO new quotes, and NO
new characterizations of cases — if something feels missing while drafting
the memo, that is a follow-up refinement round, not a memo-time fix. All of
the skill's hard rules apply unchanged; in particular:

- Citations are copied verbatim from the report (which copied them from the
  API). Never compose or complete one while reformatting.
- Only quotes graded `verified` or `likely` in Phase 7 may appear —
  `likely` on the CourtListener lane only; a GovInfo-lane or state-lane
  quote appears only if it reached the report as `verified` with no
  unsettled caution. Drop
  `not_found` quotes entirely — the ⚠ convention does not carry into a
  polished memo a reader may forward.
- Cases surfaced but not read in full may be listed only under an explicit
  "surfaced but not read in full — do not rely on characterizations" label,
  exactly as in the report.
- The AI-research notice appears in the memo, near the top, along with any
  banners (partial results / budget-limited / research-exhausted, and the
  source notes for GovInfo or a state source being unreachable) the report
  carried, plus one line stating that all quotations were verified verbatim
  against the opinion text each was read from — CourtListener opinion text,
  the court's own PDF from GovInfo, the Oregon Judicial Department's
  official-reports page, or a Washington Courts slip opinion — with the
  count for each (noting any OCR-artifact corrections and any page images
  viewed, and that Washington quotes were checked against slip opinions,
  not the official reports).
- `[v10.0]` GovInfo-lane page references stay `slip op. at N` / `<vol> U.S.
  at N` exactly as the report gave them; GovInfo-only authorities keep their
  slip citation and their "not in CourtListener; not citator-covered" mark.
- `[v10.0]` State-lane references are copied the same way: Oregon official
  pages as pins, Washington `slip op. at N` with the judge named for a
  separate opinion. The labels *nonprecedential memorandum opinion*,
  *unpublished*, *published in part*, *unreported disposition* and
  *slip opinion; official report may differ in wording* travel with every
  citation and quote that carried them in the report — a memo a reader may
  forward is where dropping one does the most harm.

## Mechanics

Use the **docx skill**: `Read` its `SKILL.md` for current guidance before
writing the generation script (docx npm package, US Letter
`{ width: 12240, height: 15840 }`, no literal `\n` in runs, bullet lists via
a numbering config — its gotchas list is authoritative). Then:

1. Write a Node script that builds the document (Times New Roman 12pt body,
   1″ margins, hyperlinked case names).
2. Render to PDF and view at least the first page and one middle page before
   delivering — broken tables and overflow are invisible until rendered.
3. Deliver with `SendUserFile` and a one-line caption. File name:
   `Memo - <short topic>.docx`. A worked build script from the 2026-09-06 run
   (docx-js, header block, monospace Data Sources, hyperlinked case names,
   block quotes, bullets via numbering config, 2-column About table) is a
   sound starting point; keep body text Times New Roman 12pt, notice block
   9.5pt italic, footer 9pt.

If the docx toolchain is unavailable, deliver the memo as a single `.md`
file with the same structure rather than skipping the deliverable, and say
why.

## Structure

1. **Header** — centered `MEMORANDUM`; then, as a hanging-indent block
   with bold labels: **To** (the user), **From**
   (`Claude — deep-legal-research (CourtListener + GovInfo)`, with the
   state sources appended exactly as in the report's footer), **Skill** (`[added
   v9.2]` one line, built from `VERSION` and a closing `get_api_usage`:
   `deep-legal-research v<version> · last modified <Mon. D, YYYY> · created
   by <author> · run <YYYY-MM-DD> · <n> CourtListener calls (<n> of 125
   daily) · <g> opinions via GovInfo · <s> via state court sources · <agents> subagents`), **Date** (with `(rev. <date>)` on a
   follow-up), **Re** (one-sentence restatement of the question and its
   doctrinal handles). A thin rule closes the header. The Skill line exists
   because the memo travels without the chat: a reader who receives only the
   file must be able to tell which version of the tool produced it and how
   much of its budget it had.
2. **Notice block** (small italic) — the AI-research notice, verbatim from
   `report-format.md`; any banners (partial results / budget-limited /
   research-exhausted), each with the one-clause specifics — *which* check
   was cut short and for how many cases; the quote-verification line (count
   verified, count unfound, any artifact conventions such as star-pagination
   markers reproduced in place); then the banner's **Data Sources** lines,
   verbatim from the report, set in a monospace font (Courier New 8.5–9pt)
   so the status marks and dates line up.
3. **Question Presented** — the parsed query as a neutral question, from the
   report's headline and Read-as line.
4. **Brief Answer** — condensed from the report's Short Answer, with the same
   inline citations (hyperlinked case names, citation tails in plain text).
5. **Discussion** — organized by the sub-questions identified in Phase 1, one
   subsection each, drawing on the Short Answer and Leading Authorities
   material. Block-indent key verified quotes with their citations. If the
   user's question was practical ("do I need to worry?"), close the
   Discussion with a practical-assessment subsection presenting risks and
   mitigations as bullets — analysis, not advice.
6. **Statutory Text** — only provisions the report quoted under the two-fetch
   rule, block-indented, with the same source links and any tier-2/currency
   disclosures.
7. **Authorities Analyzed** — every analyzed case, one bullet each: linked
   name, verbatim citation, relevance score, one-clause role, any
   citator-screen result. Then the "surfaced but not read in full" list with
   its disclaimer.
8. **About This Research** — the report's About table, reproduced (a 2-column
   table), including the history-check caveat that absence of a flag is not
   confirmation of good law, the `Text sources` and `Pool at close` rows, and **a
   final `Skill` row** repeating the version, last-modified date and run date. Every figure is copied from the verified report, which
   computed it — the memo step never restates a count from memory.
9. **Footer** — `Generated <YYYY-MM-DD> · deep-legal-research skill (Claude +
   CourtListener + GovInfo)`, small and muted — the report's footer verbatim,
   including whether `+ GovInfo` and the state sources apply.

Sections with nothing in them drop out, as in the report. Subsequent-history
flags, if any, are presented as callouts inside the relevant Discussion
subsection AND kept in the Authorities list — a reader skimming either path
must encounter them.

## Follow-ups

When a follow-up in the same chat triggers a scoped refinement, re-render the
affected report sections first (per SKILL.md), then regenerate and re-send
the memo so the file never lags the chat. Same file name; note "(rev. <date>)"
in the header's Date line.
