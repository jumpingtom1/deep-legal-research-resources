# Changelog — deep-legal-research

This file is the skill's memory. The rules in `SKILL.md` and `references/` are
terse by design; this is where the *reasons* live, so that a future editor can
tell a hard-won constraint from an arbitrary one and not delete the former.

## How to maintain this file

- **Add an entry for every substantive change**, dated, before you ship it.
- **Record the evidence, not just the change.** "Capped strategies at 5
  queries" is unmaintainable. "Capped at 5 because six overlapping strategies
  returned ~180 rows that deduped to ~60 unique cases" survives contact with a
  future editor who thinks the cap is fussy.
- **Say how confident you are.** The briefing quirks carry
  `[verified]` / `[reported]` / `[inherited]` tags for this reason — see the
  legend at the top of that list. Mirror the tag here.
- **When you remove a rule, say what evidence justified removing it.** A rule
  that was added because of a real failure should not disappear because it
  looked untidy.
- **Check "Load-bearing rules" below before editing anything.**

## Release checklist — run in full before shipping ANY version (added v9.1)

Any change to any file in this skill is a release. Before it ships:

1. **Corpora.** `python scripts/or_lookup.py --list`. Re-ingest with
   `scripts/or_corpus_build.py` anything flagged STALE or EXPIRED. Record the
   capture dates in `references/source-status.md`.
2. **Every statute/rule family.** For each row of `source-status.md`, run its
   probe — one WebFetch asking only whether the page contains the body text
   of the probe citation (YES/NO + first words + currency statement for
   tier-2 indexes). Record date and result. A FAIL is fixed (pattern
   corrected, as Delaware was in v9.1) or marked unreachable with its
   fallback named (as OAR was) — never left silently stale.
3. **Review-disposition entry points.** Fetch each verified entry point in
   `statute-sources.md` § "State-court review dispositions" and confirm it
   still lists dated dispositions. For Oregon, run `python3
   scripts/statecourts.py or-history A176132 --cite "326 Or App 117"`
   (expected: DENIED, November 17, 2023, 371 Or 535) and note
   `newest_list_in_collection`.
4. **Never spend a CourtListener call on this checklist.** The API is
   confirmed at runtime by the first metered call of every run.
4a. **GovInfo.** `[added v10.0]` `python3 scripts/govinfo.py probe`, then one
   `resolve` of the probe docket and one `resolve --court scotus --cite` in
   `source-status.md`, and `usc --title 15 --section 1692k`. Free. If the
   coverage of a court the skill relies on has changed (a court joining or
   leaving GovInfo), update `govinfo.md` § 1 and `KNOWN_ABSENT` in
   `govinfo.py`.
4b. **State court sources.** `[added 2026-10-05]` `python3
   scripts/statecourts.py probe`, then the `or-resolve` and `wa-resolve`
   probes in `source-status.md`, `ny-url` plus one WebFetch of the address
   it returns, and one WebFetch each of the two BLOCKED rows to record
   whether they still refuse (if one has opened, that is a finding for the
   user, not a licence to build on it unasked). One request a second; free.
   After any change to `govinfo.py`, re-run the federal comparison (M37):
   the engine must give the same output as the previous release on the
   cached GovInfo documents, or the difference must be explained here.
5. **Bump `VERSION`** (version, last_modified). The banner reads it; the
   SKILL.md footer must match it.
6. **Add the changelog entry** below, with evidence, before shipping.
7. **Update `references/measurements.md`** if the release establishes,
   supersedes or opens any empirical question. That file — not this one — is
   where a future editor looks to find out whether something has already been
   measured. A finding recorded only as narrative here will be re-tested by
   somebody, at cost. `[added v9.3]`
8. **Package the whole tree and verify the manifest.** `zip -r
   deep-legal-research-v<X.Y>.zip deep-legal-research/` from the parent
   directory, then `unzip -l` and check every file in SKILL.md § Packaging
   and release is present — 26 files at v10.4; 25 files at v10.3 back to v10.0 as rebuilt 2026-10-05 (23 on
   2026-10-04; 20 at v9.6). `find . -name __pycache__` must print nothing. Deliver the zip; never deliver
   `SKILL.md` alone and never use the `propose_skills` review card, which
   saves only `SKILL.md`. `[added v9.6]`

A version whose `source-status.md` dates are older than its `VERSION` date
was not released correctly — **except** a documentation-only release that
changes no source pattern, URL or protocol, which may carry forward a full
probe under 7 days old and must say so in its entry. `[added v9.4]`

## Load-bearing rules — do not remove without reading this

Each of these looks like fussy over-specification and is not. Every one was
added after a concrete failure.

| Rule | Where | What happens without it |
|---|---|---|
| A blocked or refusing publisher is never fetched by another route; each state source is used only for what it allows | SKILL.md hard rule 10; state-sources §§ 1, 5; source-status BLOCKED rows | The New York Official Reports (Westlaw) and the Washington official reports (LexisNexis) refuse automated access (M33). A "helpful" fallback — a script where WebFetch was refused, a mirror, an archive — is circumvention, and a Washington slip opinion presented as the official report, or a New York page read through a summarizing model and quoted, is a misattributed source. |
| A state document is used only on a match of key + date + a distinctive party name on each side; a near miss is the CourtListener lane | SKILL.md hard rule 10; state-sources § 2 | The first build's name test was satisfied by "State" alone: `State v. Momeni` with a wrong citation matched `State v. Marshall` (M39, round 4); initials-only juvenile captions one letter apart matched (round 5). Amended and substituted opinions carry their own dates (3 of 20 Washington rows, M34). |
| Front matter is not the opinion: Oregon caption and staff case summary, Washington cover sheet | state-sources § 3; `verify` (`not_opinion_text`); briefing | The staff summary's "*Held:*" sentence is the most quotable text in an Oregon opinion and is not the court's. The first build read a caption disposition as opinion text when the opening fell outside the pages it scanned (M39). |
| A separate opinion is cross-checked three ways, a lead or plurality opinion is flagged, and the analyzer's own reading still comes first | state-sources §§ 3–4; `separate_opinion`, `fractured_decision`; briefing | Heading patterns alone missed three dissents (round 4) and attributed one judge's opinion to another (round 5). A three-justice lead opinion that would vacate was labelled "the court's opinion" in a case the court affirmed per curiam. |
| Washington text is slip text: `slip op. at N`, never a reporter pin; superseded, unpublished and unpublished-portion labels travel with every quote | hard rules 1 and 10; state-sources § 4; report and memo formats | The official report is not reachable (O13); the court itself says slips are edited before publication. An unpublished portion of a part-published opinion verified with no flag in the first build (M39). |
| An Oregon review-list entry is this decision's only if its own citation block names the case number and prints the citation checked; empty is "none located", incomplete is "not checked" | state-sources § 3 (`relates_to`, `complete`); pipeline 7B | One case number can have several decisions; an entry's commentary can name another case; decisions without opinion share a citation with dozens of cases; lists before 2012 are scans. The first build reported another case's WITHDRAWN entry as the disposition of the decision checked (M39). |
| One request a second to each court's server, never parallelized around the lock | `statecourts.py` throttle; state-sources § 2, S11 | The Oregon collection's `robots.txt` asks for it. A skill that fans out fifteen analyzers would otherwise hit a court's public server fifteen at a time. |
| A quoter's ellipsis that omits any words never verifies | `verify`; govinfo.md § 3; briefing | "the trial court . . . denied defendants' motion" verified against "erred when it denied" (M39). No word list distinguishes a harmless omission. |
| Semantic windows are narrow (≤ 5 years) and aimed at evidenced eras — never one wide window, never stepped back blindly | pipeline Phase 3; courtlistener-mcp § Semantic search; briefing quirk 11 | Ranking is recency-weighted inside any window (M42): 1985–2017 returned only 2013–16; stepped windows in D. Utah spent three units to reach 1999 and found none of the authorities. Aimed 5-year windows put the leading cases in the top three. |
| A semantic query is run in date windows, never only unwindowed when older authority matters | pipeline Phase 3; courtlistener-mcp § Semantic search; briefing quirk 11 | Unwindowed, every page measured held only the newest few years the court has (M41). The first reading of that behaviour — "the index is not backfilled" — took semantic search out of the skill for a month; the opposite misreading would put it back as a single unwindowed query that silently omits the foundational cases. |
| The lead ledger is written on every non-`quick` run, and every refinement query records the finding it derives from | pipeline Phase 6; report-format *Leads* row | Through v10.1 a round that met its numbers ended the research even when the cases read pointed at an unread controlling authority, and the one-line instruction "plan from accumulated leads" let a second round re-run the first round's queries reworded. Iteration — the second search built from the first search's results — is the feature the user named as the reason for the skill. |
| Ship the entire folder as a `.zip`; never `SKILL.md` alone; never `propose_skills` | SKILL.md hard rule 8 and § Packaging and release; checklist step 8 | The v9.5 sync carried only `SKILL.md`, `VERSION`, `CHANGELOG.md`, three reference files and `banner.py`. The next run had no `pipeline.md`, no briefing block to give subagents, no query recipes, no `known-corrections.md`, no report or memo format, no `or_lookup.py` and no corpora, and rebuilt what it could from this changelog. The `propose_skills` tool, by design, writes `SKILL.md` only. |
| One text lane per case: read and quote-verify in the same source | SKILL.md hard rule 2; govinfo.md § 2; state-sources.md § 1; pipeline Phase 4 and 7D | CourtListener's reporter text and GovInfo's slip PDF differ in typography and OCR. Checked across lanes, 14 of 40 true sentences failed an exact match (M18) — the pressure that produces a hand-"corrected" quote. |
| A GovInfo granule is used only on a docket + date + name match; a miss is the CourtListener lane | SKILL.md hard rule 9; `resolve-batch` | A docket holds many filings. The date-matched filing for a reported case was a two-page adopting order (M19); a same-number docket in another office is a different case; an amended opinion replaces the original (M15). Guessing reads the wrong document with full confidence — the cluster-id failure again, in a new place. |
| GovInfo-lane and state-lane quotes are published only as `verified`; `likely` means replace-and-recheck | govinfo.md § 3; pipeline 7D; report-format | A one-word insertion (`not`) grades `likely` at 97–99 % similarity (M21). Published as "≈ close match" it would reverse a holding. |
| View the page image before quoting an OCR-layer PDF (GovInfo, and Oregon and Washington scans) | SKILL.md hard rule 9; govinfo.md G7; state-sources §§ 3–4; briefing | The text layer of a scanned opinion reads `id` for `did` and `)` for `]` (M23). `verify` checks a quote against that layer, so it cannot see the layer's own errors. |
| Never quote a staff summary or syllabus as the court | govinfo.md G8–G9; `verify` | Ninth Circuit slip opinions and every U.S. Reports case open with text that "constitutes no part of the opinion." It reads like a holding and is the most quotable passage in the file. |
| GovInfo text only through `scripts/govinfo.py`, never WebFetch | SKILL.md hard rule 9; briefing | WebFetch answers through a summarizing model. The v5 fabricated-statute failure was exactly a model asked to return text it did not have. |
| GovInfo `cites` and docket history are leads, never clearances | pipeline 7A; report-format | They see participating federal courts only. "No negative federal citer in GovInfo" printed as clean history would be hard rule 4's failure with a second source's name on it. |
| `num_results` defaults to 20; a search costs a unit per 20 rows | pipeline § Budget; courtlistener-mcp; quirks 26, 43 | "Ask for 100; the call costs the same" was false (M29): a 100-row citator is 5 units. Three of those and a 100-row screen are 20 units booked as 4. |
| Quote whole sentences plainly; a `verified` quote with an unsettled caution is not publishable; a `likely` quote sends you back to the passage | govinfo.md § 3; pipeline 7D; briefing | The first three builds' `verify` passed "enforceable" cut from "unenforceable", `[S]ufficient` for "insufficient", an ellipsis over "do not", `[in]correctly`, a trailing `[with prejudice]`, and `$31,999` for `$31,000` (M31). A checker that says ✓ is trusted more than an analyzer; it must not say ✓ to a reversed holding. |
| A findings-and-recommendation is authority only as adopted | SKILL.md hard rule 9; govinfo.md G15; pipeline Phase 4 | 8 of 17 GovInfo-found filings were magistrate recommendations (M20). Reported as holdings they would be wrong about who decided what, and one rejected on review would be wrong about the law. |
| Anchors go through the Phase 4 screen | pipeline Phase 2, 4 | A top-N-by-cite-count citator shows the most-cited citers; an overruling decision is recent and little-cited. |
| Read `get_api_usage` before the banner, before every metered wave, and at close; never keep a hand ledger | SKILL.md § Budget; pipeline § Spending from live counters | Hand ledgers undercounted (v9.1: 32 counted, cap fired) and were carried over from memory (v9.2 About table). The live counter is free and exact (M10, M12). |
| Fire the one-call negative-treatment screen **before the analysis wave** | pipeline Phase 4 | The optional work consumes the budget and the mandatory check is the call the cap rejects — 13 of 19 cases went externally unscreened in the v9.1 run. v9.2 moved it ahead of refinement; v9.3 moved it ahead of the 12–18 unit analysis wave as well, because that is the only position from which it cannot be the casualty. |
| Read WHICH cap a 429 names before responding | SKILL.md, briefing rate-limit section | A `125/day` refusal reported as hourly tells the orchestrator to retry in an hour when the truth is tomorrow. There are three caps, not two. |
| Recalled citations are search inputs only, and never reach the report unconfirmed | pipeline Phase 4 | A citation recalled from training that the API does not confirm is indistinguishable from a fabricated one. Hard rule 1 governs. |
| Every About-table number is computed, not recalled | report-format | A screened-candidate figure was carried over from the previous run's report and published in both the chat report and the Word memo. Narrated numbers are invisible defects. |
| `references/known-corrections.md` is read at triage and pasted into analyzer prompts | SKILL.md § Corrections that must survive the run | The skill has no memory. v9.1 established that *Hooters* is miscited for a holding it does not contain; v9.2, on the identical query, lost the finding entirely. |
| `references/measurements.md` is the empirical ledger, updated at every release | SKILL.md § Budget, release checklist step 7 | Findings recorded only as changelog narrative get re-tested. Four of this skill's budget rules were guesses that survived multiple versions because nobody could tell a measurement from an assumption at a glance. |
| Resolve `opinion_id` centrally before the analysis wave | pipeline Phase 4 | Analyzers silently read *unrelated cases* — a Nebraska mill-race decision, an SDNY order — and report confident findings about them. `cluster_id` ≠ `opinion_id` on many records, and a cluster id passed *as* an `opinion_id` returns the wrong case (the dedicated `cluster_id` parameter is safe — v9). |
| Grep cached opinions before searching for a case they cite | pipeline Phases 3–4, briefing quirk 21 | Metered calls are spent hunting a case CourtListener does not hold. Five calls in one run; the `citation no-link` marker in an already-cached opinion would have said so for free. |
| Paste the briefing block verbatim into every subagent prompt | SKILL.md | Each agent rediscovers the same API quirks by burning calls, or doesn't, and analyzes the wrong document. |
| The anchored 1–5 rubric + `scale_confirmation` echo | pipeline Phase 5 | Bare 1–5 scales get inverted. An analyzer once returned `relevance_ranking: 1` alongside "directly on point and unusually valuable," which would have corrupted the sufficiency gate. |
| One court ID per search call | pipeline Phase 3, mcp | Multi-ID arrays silently drop all but one court. A query returned 8 hits, all from the supreme court, while the appeals court alone had 61. |
| Retry `search_document` with a short single-line fragment | briefing quirk 7 | Verbatim quotes grade as `not_found` because the fragment spanned a hard line wrap. Five true quotes failed this way in one run. |
| Verify every quote; no sampling | pipeline Phase 7D | Unverified quotes reach the report. Cheap to do — the documents are already cached. |
| Absence check on quotes you didn't source yourself | pipeline Phase 7D, mcp | A famous passage attributed to *Suess Builders* for decades is not in the opinion. Only an explicit "0 matches" check caught it. |
| State-court review disposition check (Oregon: by script, every Court of Appeals leading authority) | SKILL.md hard rule 6, statute-sources, state-sources § 3 | CourtListener does not index these at all. A clean citator looks like clean history and isn't. |
| Citations API-sourced, never composed (the Oregon catalogue and a twice-fetched New York official page may **add** an official citation the API lacks — never replace one) | SKILL.md hard rule 1; courtlistener-mcp | Fabricated reporter citations. This is the highest-severity failure the skill can produce. |
| Every contract field accepts `null`; prompts must supply an escape string | SKILL.md hard rule 7, briefing "Not found is a correct answer" | Demanding content with no sanctioned way to decline induces fabrication. Directly measured — see v5. |
| One provision per statute fetch + two-fetch agreement before quoting | statute-sources long-page protocol | Batched statute prompts produced invented statutory text *with an invented citation bracket*. |

---

## v10.4 — 2026-10-17 (update check against the published release)

**What changed**
- `scripts/update_check.py` (new): compares `VERSION` with
  `skill/latest.json` in github.com/jumpingtom1/deep-legal-research-resources
  (raw.githubusercontent.com, `main`).
  - When a newer release exists, it downloads the zip and checks its sha256
    against the manifest, its single `deep-legal-research/` root, and that
    its `VERSION` matches.
  - It copies `scripts/govinfo.key` from the running installation into the
    zip and writes `deep-legal-research-v<X.Y>.zip`.
  - It never blocks a run: any failure prints UNREACHABLE or INVALID and
    exits 0.
- SKILL.md § "Update check — first thing in every run".
  - On UPDATE: deliver the zip, give the upgrade steps, print one `UPD`
    line, and carry on with the installed version.
  - On UNREACHABLE/INVALID: print one `UPD` line and carry on.
- New console tag `UPD`.
- Manifest: 26 files (`scripts/update_check.py` added).
- § Packaging and release: public releases are published only with the
  resources repo's `scripts/release_skill.py`, which leaves
  `scripts/govinfo.key` out of the public zip.

**Why**
- Users were updating by hand from zips passed around.
- A public repo is the one place every installation can reach. GitHub raw
  sits in the default "package managers" network tier on Team/Enterprise.

**Why the key is left out of the public zip**
- § Packaging and release says the bundled api.data.gov key "may be passed
  to colleagues, not posted publicly". A zip in a public repo is posted
  publicly.
- Copying the key from the user's own installation keeps upgrades one-step
  without ever publishing it.
- A first install still comes from a colleague's full zip.

**Upgrade path**
- Claude documents no in-place replace for an uploaded skill. The steps the
  script prints are therefore: Customize > Skills, then delete the old
  skill, then "+" > "+ Create skill" > "Upload a skill", then a new chat.
  Source: support.claude.com articles 12512180 and 12512198, read
  2026-10-17. `[verified]`
- Org-provisioned skills: the owner republishes.

**Release checklist, as run on 2026-10-17**
- Free probes, all OK:
  - `or_lookup.py --list`: ORCP 80 days old, UTCR 87 days old.
  - `govinfo.py probe`: ok, 4,648,261 USCOURTS granules, limit 36,000/hour.
  - `statecourts.py probe`: Oregon ok, Washington ok.
  - `statecourts.py or-history A176132 --cite "326 Or App 117"`: DENIED,
    November 17, 2023, 371 Or 535. Newest list in the collection:
    "Petitions for review, October 8, 2026".
- **Not re-run: step 2.** The one-WebFetch probe of every
  `source-status.md` row (dates there are still 2026-10-05). This release
  changes no source pattern, URL or protocol, but the last full probe is 12
  days old, beyond the 7-day carry-forward allowed for documentation-only
  releases.
- **Outstanding before the next release:** run step 2 in full and update
  `source-status.md`.
- No CourtListener units spent.

## v10.3 — 2026-10-12 (v10.2 tested against the regression suite)

**Research-rule release; no source pattern, URL, script or corpus changed.**
Scripts and corpora byte-identical to v10.2. The 2026-10-05 statute probe is
carried forward under the v9.4 exception (seven days); the free probes
(`govinfo.py probe`, `statecourts.py probe`) were run by the test runs today
and returned `ok`.

### Why

The user supplied a regression suite built from his chat history
(`dlr-testsuite-2026-10-10.zip`: 40 cases, baselines, scorer, 106 checks
from this changelog) and asked that it be used to design tests and validate
v10.2 — then to improve the skill, not to answer the research questions.

### Tests run `[measured 2026-10-12; M42–M44; ~80 units incl. two runs]`

1. **Full pipeline run, ORS 12.220 case (T1)** on v10.2, by a delegated
   agent kept blind to the baseline. Completed; 3 rounds, 31 units, 18 cases.
   Core recall 4/4, weighted 65%. The leads round produced the run's best
   find (*Wallace v. Holden*); the semantic strategy produced no unique find;
   the ORS 12.150 tolling branch was lost (M43). Graded review in the suite
   at `results/v10.2/2026-10-08_ors-12-220-refiling/review.md`.
2. **Full pipeline run, Utah blue-sky case (T2, late-find class)** —
   interrupted by an account usage limit after round 2, before the report.
   From its working files: two of the three authorities the July baseline
   found only after "continue research" were reached on the first pass.
3. **Semantic windowing probe** — 12 queries on two suite cases whose scored
   authorities span decades (M42). Established the recency-weighted ranking
   and that narrow aimed windows work where wide or stepped ones do not.
4. **Cost probe** — the per-page model holds; the per-minute window counts
   pages (M44).
5. **Lead-ledger replay** against the follow-ups the user had to type in
   the original chats: Utah (two late finds now reached unprompted);
   ORS 12.220 (the follow-up's cross-forum question was partly answered by
   the federal applications the v10.2 run found, 15% recall against that
   follow-up's set — a different question, noted only).

### Changed

- **Semantic strategy** (pipeline Phase 3; courtlistener-mcp; quirk 11):
  unwindowed first, then ≤ 5-year windows aimed at eras dated by the other
  rows (anchor, keyword year-clusters, enactment, cited cases); no blind
  stepping; no wide windows; guidance on when semantic earns its units
  (doctrine-named questions) and when keyword should lead (distinctive
  strings). The connector's "start with semantic" advice is kept — the
  unwindowed query still runs first.
- **Phase 1** — sub-questions at the granularity of the user's facts; a
  one-line *premise*.
- **Phase 6 ledger** — Authority test requires the role to be on the
  question's issue (background citations never fruitful); new **Premise**
  row; Era rows worked first with an aimed semantic window; lead-found
  cases read in full before Leading Authorities.
- **state-sources** — a non-opinion Oregon item may be read as a lead
  source, never cited as an opinion.
- **Budget** — per-minute spacing counts pages.
- **report-format** — *Leads* row adds the premise check; new *Semantic*
  row (queries, windows, on-point rows, unique finds) so later runs measure
  semantic yield without a special probe.
- measurements M42–M44, O15 narrowed, O17 opened, superseded rows.
  `VERSION` 10.3. Manifest unchanged: 25 files.

### Not changed, deliberately

- Refinement stays optional (user's instruction): `quick` skips it; a
  sufficient run with no fruitful lead stops.
- Semantic stays a required strategy (user's instruction); what changed is
  how its windows are placed.

### Not verified `[reported]`

- No full run has been made on v10.3. The semantic rule rests on 12 probe
  queries over two questions plus two runs; the Premise row and the
  sub-question rule on one run's miss (O17).
- The suite's check `semantic-search-recent-only` encodes the v9 rule and
  will flag v10.2+ runs falsely; it needs rewriting in the suite
  ("no semantic query run only unwindowed, or in one wide window, when
  older authority matters").
- Both test runs were made by delegated agents **without subagents**
  (single context). Agent-count and wall-clock comparisons with the T1
  baselines are not meaningful.

---

## v10.2 — 2026-10-10 (iterative refinement restored; semantic search re-measured)

**Research-rule release; no source pattern, URL, script or corpus changed.**
The three scripts and both corpora are byte-identical to v10.1. Under the
v9.4 exception this release carries forward the full statute/rule probe of
2026-10-05 (five days old). Re-run today, free: `or_lookup.py --list` (both
corpora `[ok]`), `govinfo.py probe` (`ok: true`, 4,644,164 USCOURTS
granules) and `statecourts.py probe` (Oregon and Washington `ok: true`;
newest Oregon Supreme Court opinion 375 Or 728, 2026-10-08). Seven
CourtListener units were spent — not on the checklist, which forbids it, but
on the measurement below, at the user's request.

### Why

The user reviewed the skill against what he valued in the original
(`legal-research`) and asked three things: is iterative searching still
there, has CourtListener's search been narrowed, and what sets the depth.
The answers, from the files: iteration survived only as a conditional Phase
6 with a one-line instruction; semantic search had been barred wherever
older authority mattered, on quirk 11; depth was as documented. He then
directed two changes and one investigation:

1. Keep skipping refinement on `quick` requests — but on any other request,
   **fruitful leads are to be followed even when round 1 met its numbers**.
2. Spell out how the new searches use the findings of the earlier ones:
   "That iterative process is key to good legal research."
3. He doubted quirk 11 ("just a bad test on our part") and wanted semantic
   search restored as a key part of the strategy, as the connector's own
   instructions recommend.

### What was measured `[measured 2026-10-10; M41; 7 units]`

Quirk 11 was half right. Its observation was accurate and is reproduced:
an unfiltered semantic query in the Oregon Supreme Court returned 20 rows
dated 2016–2025, and one in the U.S. Supreme Court 2014–2026. Its inference
— "the embedding index is not backfilled" — was wrong, and had never been
tested with a date filter. With `filed_before` 2015 the Oregon Court of
Appeals returned 2007–2014; with 1995, 1988–1994; the U.S. Supreme Court
with 1985, 1981–1984. With both bounds (2005–2008) the first six rows held
*Motsinger*, *Sprague* and *Vasquez-Lopez*, the foundational line for the
question asked — the "entire foundational line of authority" the v9 entry
said semantic search silently omitted. Every page sat just under its upper
bound. So the user's doubt was justified as to the conclusion, and simply
deleting the restriction would have been wrong too: a single unwindowed
semantic query does omit older authority. The rule is now "window it".

Not established: the mechanism, and how far one window reaches in a
high-volume court (O15).

### Changed

- **Quirk 11 rewritten** (`subagent-briefing.md`), tag `[reported]` →
  `[measured]`: old opinions are indexed; unwindowed pages show the newest
  few years; step `filed_before` back to reach the rest.
- **`courtlistener-mcp.md` § Semantic search (new).** The recipe, the
  measured behaviour, the windowing rule, what `count` does not mean, and
  what is untested. The one-line bar on semantic search is gone.
- **`pipeline.md` Phase 3.** At least one strategy is semantic and it is
  designed first, as the connector's instructions advise; its 3–4 queries
  are date windows of one plain-language question. Keyword strategies are
  kept for what only they do: phrases, citations, statute sections, the
  citator, ordering by citation count. The constraint "No `semantic: true`
  when pre-2019 authority matters" became "never only unwindowed".
- **`pipeline.md` Phase 6, rewritten.**
  - *Lead ledger*, written on every non-`quick` run before the sufficiency
    test: authorities the analyzed cases point to, the courts' own
    vocabulary, statutes, splits, eras, gaps — each with a stated test for
    "fruitful".
  - *Trigger.* A sufficient, non-`deep` run with a fruitful lead now gets
    one round scoped to those leads (a second only if the first produces a
    ≥4 case that opens another). `quick` still skips Phase 6 entirely;
    sufficient-with-no-leads still stops. Refinement was **not** made
    mandatory — the user rejected that.
  - *Method.* Each kind of lead has a stated conversion into a search or
    citator, every query records `derived_from`, and "a query that could
    have been written before round 1 was read is not a refinement query."
    Negative results carry forward. Rows are closed with what they produced.
  - Fruitful leads left unworked for budget are reported, not dropped.
- **Analyzer contract** (`pipeline.md` Phase 5): `follow_up.search_terms`
  and `citations_to_trace` are defined — the court's own words where they
  differ from the question's; the authorities treated as controlling, as
  the rule's origin, or as contrary. Field names unchanged.
- **`report-format.md`.** The *Rounds* row says why a later round ran; a
  new *Leads* row lists leads followed and not followed.
- **Phase 1** `depth_preference: unspecified` now documented; allocation
  table Phase 6 note; SKILL.md summary, workflow steps 3 and 6, footer.
- `measurements.md`: M41, O15, O16, two superseded rows. Two load-bearing
  rows added above. `VERSION` 10.2. Manifest unchanged: 25 files.

### Not changed, deliberately

- Depth constants, the round cap of 4, the budget model, the spine, the
  stop conditions on budget. A leads-only round costs the same 4–8 units as
  any other and is cut by the same rules.
- The hard rules. A lead is a search input; nothing reaches the report
  without being read and verified as before.
- The older changelog entries that state quirk 11's first form. They are
  history; `measurements.md` § 5 marks them superseded.

### Not verified `[reported]`

- **No full research run has been made on v10.2.** The semantic findings
  are measured; the Phase 3 windowing procedure and the whole Phase 6
  ledger are designs built on them (O16). The first run should be read for
  whether the ledger finds a "fruitful" lead every time, and whether
  windows 2–3 of the semantic strategy earn their units.
- The M41 sample is seven queries, two topics, three courts. Low-volume
  courts (`or`) reached about nine years per window; `scotus` and `orctapp`
  about four. A busy court may reach far less (O15d).
- That semantic-first ordering improves results over the v10.1 keyword-led
  design is the connector's advice and the user's judgment, not something
  this release measured.

---

## v10.1 — 2026-10-08 (shareable build: first-run connector setup)

**Documentation-only release.** No source pattern, URL, protocol, script or
research rule changed; the three scripts and both corpora are byte-identical
to v10.0 as rebuilt 2026-10-05. Under the v9.4 exception this release
carries forward the full probe of 2026-10-05 (three days old). Re-run today
all the same, free: `or_lookup.py --list` (both corpora `[ok]`),
`govinfo.py probe` (`ok: true`) and `statecourts.py probe` (Oregon and
Washington `ok: true`). No CourtListener call was spent.

### Why

The user asked for a copy to give colleagues that does not carry his
CourtListener API key and that walks each colleague through getting their
own. Checking the tree first `[verified 2026-10-08: grep of every file for
tokens, keys and 40-hex strings]` showed **the skill has never contained a
CourtListener credential**. The only key in it is `scripts/govinfo.key`.
CourtListener is reached through the directory connector, added in the
Claude app (+ → Connectors → Add connectors → Browse connectors →
"CourtListener") and signed in per person; the credential lives in each
person's Claude account. So the design the user first proposed — collect a
key in chat, write it into the skill, re-export the zip, walk them through
re-uploading it — was not needed and was not built. Nothing in the skill
differs per user.

### What changed

- **SKILL.md § First-run setup (new).** Before v10.1 a missing connector
  produced one line ("enable it under Settings → Connectors, then ask
  again") and a stop. That is adequate for the author and a dead end for a
  colleague who has never heard of CourtListener. Now: detect with the free
  `get_api_usage` Phase 1 already makes; if the tools are missing or the
  call fails on authentication, walk the user through account creation,
  adding the connector and signing in, one step at a time; confirm with
  `get_api_usage`; then resume the original question without being asked
  again. There is deliberately no "first run" flag — a skill cannot persist
  one, and the check is free on every run.
- **Credentials never pass through the chat.** The walkthrough forbids
  asking for or accepting a password or API token; the connector's sign-in
  page is the only place they go. Do not "simplify" setup by having the user
  paste a token.
- **Prerequisites, Workflow step 1, `pipeline.md` Phase 1** point to the new
  section instead of stopping.
- **Budget** now says the pool is per CourtListener account. Each colleague
  has their own 5/50/125; runs by one do not draw on another's.
- **Packaging step 4.** `govinfo.key` was described as the user's own key in
  a zip "for the user's own account". The user decided to share that key
  with colleagues (it is not short on quota: 36,000 an hour at the probe),
  so the text now says the key is bundled on purpose, the zip may go to
  colleagues, and it is still not for public posting.
- `VERSION` 10.1, 2026-10-08. Manifest unchanged: 25 files.

### Not verified `[reported]`

- The Claude menu path in step 2 of the walkthrough is as the user described
  it on 2026-10-08, from his own account. It was not re-walked on a fresh
  account, and the wording of the connector's sign-in screen is not quoted
  because it was not seen. The walkthrough gives Settings → Connectors as a
  fallback for when the labels move.
- Whether a Team/Enterprise owner must allow the connector before members
  see it was not tested; the walkthrough says "may".
- The walkthrough has not yet been run end to end by a colleague without the
  connector. The first colleague's experience is the test; record it here.

## v10.0 — rebuilt 2026-10-05 with state court sources

**Same version number, at the user's request ("re-create v10.0").** This
build replaces the 23-file build of 2026-10-04 and contains everything in
it; discard the earlier zip. `VERSION` carries the new date. What it adds:
the courts' own publishers for three states, each used for exactly what it
allows.

### What was asked, and what turned out to be reachable `[measured 2026-10-05; M33]`

The user named three collections. One is open; two refuse automated access
and were not fetched by any route.

| Asked for | Result | Used instead |
|---|---|---|
| Oregon Judicial Department digital collection (CONTENTdm) | Open: JSON API, no key, `Crawl-Delay: 1` | — it is the lane: official Oregon Reports pages, with official page numbers |
| Washington official reports (the LexisNexis site the courts.wa.gov "Lexis overview" page points to) | `ROBOTS_DISALLOWED` | courts.wa.gov **slip opinions** by year listing — labelled as slip text everywhere |
| New York Official Reports on govt.westlaw.com | `SITE_BLOCKED` | The Law Reporting Bureau's own page on nycourts.gov, through WebFetch only (a browser check stops scripts), for an official-citation and status check — **not** a text lane |

### What it buys

- **Oregon appellate opinions since 1998 and Washington slip opinions since
  2013 are read and quote-checked for zero CourtListener units**, on the
  same deterministic verifier as the GovInfo lane. For an Oregon-law
  question that is most of the reading budget.
- **Oregon pins are official.** The PDF is the Oregon Reports page; the
  verifier returns the official page a quote is on.
- **Oregon review dispositions by script** (`or-history`): the Supreme
  Court's petitions-for-review lists since 1997, read from the list PDF
  itself, with any Supreme Court opinion on review. Hard rule 6's check is
  now free for Oregon and is run on every Court of Appeals leading
  authority regardless of age.
- **A free second discovery channel for Oregon** (`or-search`), measured
  against CourtListener on the same court (M35).
- **New York**: the official citation, corrected-through date and
  publication status of a decision, from the official page, under the
  two-fetch rule.

### What was measured `[M33–M40; 5 CourtListener units]`

- Crosswalk on 52 real CourtListener rows (M34): Oregon 19 of 19 in
  coverage; Washington 16 of 20 (every miss a refusal: three dates, one
  misspelled name in the court's listing); New York URL for 10 of 12.
- Verifier on 97 state opinions (M36): 5,358 sentences sampled; 5,300
  verified, 58 `likely`, 0 not found; 5,300 of 5,300 one-word alterations
  refused; 2,088 of 2,088 digit changes refused; 388 of 388 fabrications
  `not_found`; 528 of 551 front-matter sentences refused (the rest repeated
  in the opinion).
- Federal lane unchanged (M37): 68 GovInfo documents, output identical to
  the 2026-10-04 engine line for line, after each round of fixes.
- **Two rounds of independent adversarial review (M39).** Round 4 reproduced
  sixteen defects in the first build of these lanes, round 5 confirmed them
  fixed and reproduced seven more; all were fixed and re-tested on the
  reviewers' files. The ones that would have reached a memo: three dissents
  graded as the court's opinion; a three-justice lead opinion labelled the
  court's when the court (per curiam) did the opposite; a review
  disposition attributed to a case that was only mentioned in another
  case's entry; a crosswalk name test that "State" alone satisfied; a
  caption disposition read as opinion text; half a page of opinion read as
  a footnote; and "the trial court . . . denied" graded `verified` for
  "erred when it denied".

### Changed

- **scripts/statecourts.py** — new. `probe`, `resolve-batch`, `or-resolve`,
  `or-search`, `or-history`, `wa-resolve`, `wa-list`, `ny-url`; forwards the
  text commands. One request a second per host, enforced across processes
  by a lock file in the cache. Never guesses: citation or case number (or
  docket), date **and** a distinctive party name on each side of the
  caption; for Oregon also the row's case number against the item's.
- **scripts/govinfo.py** — the text engine now serves `OJD-…` and `WA-…`
  ids. New: per-source page furniture; a third "front matter" stream
  (Oregon caption, staff case summary, counsel, disposition lines;
  Washington cover sheet) that `verify` refuses as `not_opinion_text`;
  official page labels read from the running head and trusted only when
  they continue their neighbours (lettered insert pages kept as printed);
  slip-page labels that restart in each separate opinion; state heading
  forms for separate opinions with three cross-checks (Oregon caption,
  Washington running head, Washington listing); footnote sequences that
  restart inside a separate opinion; document notes (nonprecedential,
  unpublished, published in part, superseded slip, order in file,
  unresolved file); cautions `page_label`, `unpublished_part`,
  `fractured_decision`, and `separate_opinion` in two new forms. Federal
  behaviour unchanged except one rule, below.
- **A quoter's ellipsis that omits any words of the opinion now grades
  `likely` — in every lane.** Previously only an omitted negation did, by a
  word list; review 4 found 347 meaning-changing omissions the list did not
  know. The `elision` caution is retired. Analyzers were already told to
  quote whole sentences.
- **SKILL.md** — hard rule 10 (state sources used for what each allows; a
  blocked publisher stays blocked, and no fallback route to a host that
  refused); rules 1, 2, 6, 8 amended; prerequisites; "State lanes are
  outside the pool too"; the `ST` console line; banner flags; manifest 25
  files.
- **references/state-sources.md** — new: access table, the extended lane
  rule, commands, what each text is and is not, `or-history` and its
  `relates_to` table, the New York page check, Oregon-collection-only
  authorities, quirks S1–S30, budget, measurements.
- **pipeline.md** — state probe (Phase 1); Oregon strategies and the free
  pre-read (Phase 3); resolving `or-search` candidates by case number, lane
  table (Phase 4); state-lane analyzer contract (Phase 5); Oregon history
  by script and the New York page check B2 (Phase 7); state cautions (7D).
- **subagent-briefing.md** — "The state lanes" section inside the canonical
  block; do-not-rely-on-the-script rule for separate opinions; decisions
  with no majority opinion; part-published opinions.
- **courtlistener-mcp.md, report-format.md, memo-format.md,
  statute-sources.md, govinfo.md** — citation and pin rules for the three
  states; labels (nonprecedential, unpublished, unpublished portion,
  unreported, slip opinion, lead opinion); the Text sources row; Oregon
  review route now scripted, WebFetch only as a network-failure fallback.
- **source-status.md** — every row re-probed 2026-10-05; five rows added
  (Oregon opinions, Washington slip opinions, New York official pages, and
  the two BLOCKED collections, recorded so no later run retries them); the
  GovInfo probe commands corrected to carry `--name`.
- **banner.py** — Oregon and Washington text lines from the state probe;
  the New York page family; a fixed "blocked to automation" line; the
  bundled-corpus family no longer flips to `[!]` at 91 days (it is
  re-ingested yearly); `--need Washington` now lights the review family.
- **measurements.md** — M33–M40; three new assumptions; O12–O14 opened;
  four superseded statements listed.

### Not changed, deliberately

- **CourtListener remains the only relevance-ranked search, the only source
  of parallel and regional citations, and the only citator.** None of the
  state sources clears a case's history.
- **Hard rules 3, 4, 5, 7 and 9.** The eight phases, depth constants,
  rubric, sufficiency test and stop conditions.
- **Washington review dispositions** — still the WebFetch route.
- **Every other state court** — the CourtListener lane, as before.
- The 2026-10-04 "Not changed" entry below says "everything about state
  courts"; that sentence is superseded by this entry.

### Open

- **O12** — no full Phase 1 → 8 run has been made with the state lanes.
- **O13** — a Washington official report has never been compared with its
  slip opinion; the skill labels instead of assuming.
- **O14** — the round-5 fixes are tested but unreviewed, and footnote
  detection in scanned pages is known to be incomplete: a missed footnote
  verifies as body text. Open the PDF page for any quote a memo leans on.
- The version number was kept at 10.0 because the user asked for v10.0 to
  be re-created. Two different trees therefore exist under one number; the
  `VERSION` date and the file count (25, not 23) tell them apart.

## v10.0 — 2026-10-04 (first build; superseded by the rebuild above, kept as the record of the GovInfo work)

**Adds GovInfo as a second source.** CourtListener keeps the jobs only it
can do — search in every court, reporter citations, the citator. The *text*
of federal opinions GovInfo holds is now read, triaged and quote-checked
through `scripts/govinfo.py`, outside the 125-a-day pool. Also corrects the
cost of a CourtListener search, which turned out to depend on rows returned.

### The problem that prompted it

The daily cap (M1, M2) allows about four runs. Twelve to eighteen of a
run's ~32–40 units were spent reading opinions. The user asked whether
GovInfo's court-opinion collection — 36,000 requests an hour — could carry
the reading while CourtListener kept searching and the citator, without
weakening the citation, quotation and "not found" protocols.

### What was measured `[measured 2026-10-03/04; M13–M32; 11 CourtListener units]`

- GovInfo holds federal opinions only, court by court: D. Or. and E.D. Wash.
  yes, **W.D. Wash. no**, Ninth Circuit **published opinions only**, no
  state court, Supreme Court through the separate U.S. Reports collection
  to vol. 586 (M14, M15, M24).
- A CourtListener row maps to a GovInfo document by court + docket number +
  decision date + case name: 8 of 9 D. Or. rows, 15 of 17 published Ninth
  Circuit rows, 49 of 56 across ten other courts (M16, M17). Misses are
  coverage gaps or deliberate refusals, never wrong documents.
- The two sources' texts of one opinion are not interchangeable (M18), and
  a date-matched GovInfo filing can be an adopting order with the reasoning
  elsewhere (M19).
- A deterministic local quote check on the GovInfo text graded 1,307/1,307
  genuine strings verified, refused 1,307/1,307 one-word alterations,
  550/550 single-digit changes and 84/84 fabrications, and refused 54/54
  syllabus or staff-summary sentences (M21, final script, 21 opinions).
- **Three rounds of independent adversarial review each found ways to get
  a false `verified`** — mid-word quotes, ellipses hiding negations,
  brackets inserting words, stitched passages, a syllabus/dissent guard
  that failed on a band of U.S. Reports volumes, undetected dissent
  headings, and (introduced by a round-2 fix, caught in round 3) changed
  numbers — plus an API-key leak in an error message. Every reproduced case
  was fixed and re-tested before release (M31). The last fixes have not
  themselves been reviewed (O11).
- Half of the federal filings GovInfo search surfaced that CourtListener
  did not were magistrate judges' recommendations, not rulings (M20, G15).
- GovInfo's own full-text search returned 25 District of Oregon decisions
  where CourtListener returned 9; CourtListener held none of the other 17
  on the same date (M20).
- **A CourtListener `search` costs one unit per 20 rows returned (M29).**

### Changed

- **SKILL.md** — description and opening name both sources; hard rules 1
  and 2 amended (slip citations for GovInfo-only decisions; verify in the
  lane read; GovInfo quotes published only as `verified`); **new hard
  rule 9**; GovInfo prerequisite (optional, never blocking); new § "GovInfo
  reads are outside the pool"; search cost stated per 20 rows; workflow
  summary; `GOV` exception line and `DONE` figure; banner `--govinfo` flag;
  manifest now 23 files; daily-cap stop now offers a GovInfo-only run.
- **references/govinfo.md** — new: coverage table, the lane rule, every
  script command, the `verified`/`cautions` semantics, GovInfo-only
  authorities, quirks G1–G18, budget effect, GovInfo-only mode.
- **scripts/govinfo.py** — new: `probe`, `resolve`, `resolve-batch`,
  `fetch`, `read`, `grep`, `triage`, `verify`, `docket`, `search`, `cites`,
  `usc`.
  **scripts/govinfo.key** — new: the api.data.gov key.
- **pipeline.md** — § Budget (search cost per 20 rows; GovInfo cost zero;
  spine and allocation); Phase 1 probe; Phase 3 GovInfo strategies and the
  free pre-read (`resolve-batch` + `triage`); Phase 4 resolution of
  GovInfo-found candidates (`docket` first; F&Rs only as adopted) and
  **lane assignment** before the screen; raw anchor citator at 40 rows;
  **anchors now join the Phase 4 screen** instead of being treated as
  screened by their own citator; the screen stays at 100 rows with its true
  cost stated and a rule to page until `count` is exhausted or print `CUT`;
  Phase 5 contract by lane (with `opinion_part`); Phase 6
  free GovInfo searches; Phase 7A federal leads from docket history and
  `cites`; Phase 7D verification by lane, with the caution-settling and
  `likely`-requote rules.
- **subagent-briefing.md** — rate table (search by rows; GovInfo never
  metered); quirk 6 gains `court_id`; quirk 26 corrected; **new quirks 41**
  (`docketNumber:` batch), **42** (`court_id`), **43** (`num_results`);
  **new section "The GovInfo lane"** inside the canonical block.
- **courtlistener-mcp.md** — `num_results` guidance replaced; docket batch
  recipe; slip-citation forms; reading and verification sections scoped to
  the CourtListener lane.
- **report-format.md / memo-format.md** — notice line; GovInfo-unavailable
  banner; page-labelled quote lines (`slip op. at N`, `563 U.S. at 344`);
  GovInfo-only authority mark; Subsequent History wording for GovInfo
  leads; **Text sources** row; footer.
- **statute-sources.md** — U.S.C. via GovInfo row and section (annual
  editions 1994–2024; one of the two sources; historical federal text).
- **source-status.md** — three GovInfo rows; **every row probed on
  2026-10-03 and again on 2026-10-04** (48 WebFetch calls in all, 0
  CourtListener units). **Two FAILs:**
  Oregon OAR tier 1 (robots timeout, twice) and U.S.C. via OLRC
  (maintenance page, twice); fallbacks named. California and New York
  public.law dates moved; Oregon petitions list moved to September 24.
- **banner.py** — GovInfo line; U.S.C. family spans three sources; a
  family with one failed source prints `[x]` with the failure named
  beneath, instead of `[!]` or a silent `[x]`; continuation lines can no
  longer exceed 78 columns (the OAR fallback line did, the first time it
  ever printed).
- **measurements.md** — M13–M32; seven new assumptions; O8–O11 opened; O1
  annotated; five superseded statements listed.
- **VERSION** — 10.0, 2026-10-04.

### Not changed, deliberately

- **Everything about state courts.** GovInfo has none. An Oregon or
  Washington state-court question runs as in v9.6 except that federal
  decisions applying that state's law are read free.
- **CourtListener remains the only source of reporter citations** and the
  only citator. Hard rules 3–7 are untouched; rule 8 changed only in its
  list of files. Phase 7B and 7C are untouched.
- **The eight phases, the depth constants, the rubric, the sufficiency test
  and the stop conditions.**
- **The CourtListener quote check** for CourtListener-lane cases (quirk 7
  retry rule, absence checks, `likely` → "≈ close match").
- The negative-treatment screen is the same query at the same 100 rows; it
  now also covers anchors and must be paged to exhaustion or declared cut.
  Sweeps default to 20 rows and the raw anchor citator to 40, because rows
  cost units (M29).

### Open

- **O8 — no full Phase 1 → 8 run has been made under v10.0.** Components
  and one three-case analyzer test only. The first production run should be
  watched: lane assignment, the wave gate, the Text sources row, and a
  GovInfo-only authority in the report are all first-time joins.
- O9 (GovInfo search ranking), O10 (how common adopting-order and
  ambiguous granules are), **O11 (the verifier was broken three times by
  review; the final fixes are tested but unreviewed, and some things — a
  party's argument restated in a whole sentence, a block quotation of
  another court — no string check can see)**.
- The key sits in `scripts/govinfo.key` in plain text because a skill has
  nowhere else to keep it. It is a free api.data.gov key (rate limiting
  only). Regenerate it at api.data.gov if the zip is ever shared.
- GovInfo was reached from the cloud workspace only; a desktop session's
  egress allowlist may need `api.govinfo.gov` and `www.govinfo.gov`.

## v9.6 — 2026-09-16

**Restores the complete skill tree, replaces the call ledger with the live
`get_api_usage` counter, and makes whole-tree packaging a hard rule.** Built
from the user's `deep-legal-research-v9.4.zip` plus the v9.5 deltas, because
the synced v9.5 copy had lost twelve of its twenty files.

### The failures that prompted it

1. **The v9.5 sync was incomplete.** The synced folder held `SKILL.md`,
   `VERSION`, `CHANGELOG.md`, `measurements.md`, `source-status.md`,
   `statute-sources.md` and `banner.py` — and nothing else. Missing:
   `pipeline.md`, `subagent-briefing.md`, `courtlistener-mcp.md`,
   `known-corrections.md`, `report-format.md`, `memo-format.md`,
   `or_lookup.py`, `or_corpus_build.py` and the whole `or-corpus/`
   directory. The 2026-09-16 research run (ORS 59.115(1)(b) seller
   scienter, anchored on 269 Or App 31) discovered this at Phase 1,
   reconstructed the citator and screen recipes from this changelog, and ran
   without subagents because there was no briefing block to give them. The
   report was sound but the run was slower, the report format was
   improvised, and none of the load-bearing quirks reached an agent. Cause:
   the v9.5 delivery went through a path that carries `SKILL.md` and a
   subset — most likely the `propose_skills` review card, which by design
   saves only `SKILL.md`, or a partial upload. Whatever the path, the rule
   that prevents it did not exist. Now it does (hard rule 8; § Packaging and
   release; checklist step 8; load-bearing table).

2. **The connector exposes the usage endpoint after all.** The first
   per-minute 429 of the run carried the hint "Call `get_api_usage` to see
   current usage"; the tool was in the deferred list. Five calls across the
   run (M10) showed it free, live, accurate to the 429 bodies, and usable
   while throttled. It also settled two open budget questions cheaply (M11:
   cached reads count against none of the three caps, 5/min included; M12:
   the counter agrees with a hand count of first-touch calls exactly). With
   that, the `calls_metered` ledger — summed across agents, undercounted in
   v9.1, carried over from memory in v9.2 — has no reason to exist.

### Changed `[verified 2026-09-16]`

- **SKILL.md** — hard rule 8 (ship whole, never `propose_skills`); § Budget
  rewritten around `get_api_usage` with the four read points (before banner,
  before each metered wave, after a 429, at close); the "plan as if the
  window is full" heuristic replaced by "plan from the counters"; `NOTE`
  line now triggers on hourly `remaining` ≤ 20; `DONE` figures come from the
  closing usage call; session model starts follow-ups with a usage call; new
  § Packaging and release with the 20-file manifest; quirk count 40.
- **pipeline.md** — § Budget: "Spending without memory" → "Spending from
  live counters"; "Ledger and concurrency" → "Counters and concurrency";
  wave gate is `hourly remaining − 6`; the `ledger ≥ 44` stop condition is
  `hourly remaining ≤ 6`; every subagent contract drops `calls_metered` and
  `calls_explanation` and gains `limit_body` (verbatim 429) and, for
  analyzers, `extra_fetch_explanation`; Phase 1 banner call carries the
  three usage flags; Phase 8 About numbers named as counter-sourced.
- **subagent-briefing.md** — rate-limit section names `get_api_usage`;
  quirk 37 rewritten (supersedes the 2026-09-07 text; number kept); quirk 38
  loses its `calls_metered` sentence; **new quirks 39** (cached reads free
  against all caps, M11) and **40** (`search_document` for `59.115(1)` misses
  because OCR renders `(1)` as `(l)` — search the bare number or a phrase);
  output discipline drops the call count.
- **report-format.md** — About table: "Searches" row computed from closing
  minus opening usage readings; "Daily pool" row becomes "Pool at close"
  with both caps and both `reset_at` times; rationale paragraph rewritten.
- **memo-format.md** — Skill line built from the closing usage call.
- **banner.py** — `--used` replaced by `--hourly-used`, `--daily-used`,
  `--daily-reset`; Budget line prints the live figures or `get_api_usage not
  read [!]` when none were passed; line kept under 78 columns.
- **known-corrections.md** — two entries: *Sanders v. Francis*, 277 Or 593
  (a UTPA case misrecalled as securities; caught by a full read and dropped
  with a `FIX` line), and the three *Marsh & McLennan* decisions (which one
  holds what on scienter; the official annotations page's citation string
  for the 59.137 annotation could not be extracted consistently).
- **measurements.md** — M10, M11, M12 added; M8 struck and listed as
  superseded; O1 closed as moot; O7 opened (does `remaining` refill before
  `reset_at`); the "search costs 1 daily unit" assumption annotated.
- **source-status.md** — every row re-probed 2026-09-16 (21 WebFetch calls,
  0 CourtListener units; no FAIL). Movements: California public.law
  "Updated September 14, 2026"; Oregon petitions list September 10, 2026; WA
  ORDERS September 3, 2026; OAR tier 1 fourth consecutive OK; ORS chapter 12
  returned two different truncation points on two fetches (recorded as an
  extraction hazard); NV/TX still May 26, 2025. CourtListener row corrected
  for `get_api_usage`. This clears the two-day allowance overrun v9.5
  recorded.
- **VERSION** — 9.6, 2026-09-16.

### Evidence for the budget measurements `[measured 2026-09-16]`

| Reading | Hourly used | Daily used | 5/min used | What happened in between |
|---|---|---|---|---|
| 04:59Z | 5 | 24 | 1 | (opening; 24 daily units were an earlier run's) |
| 05:08Z | 32 | 51 | 0 | 27 first-touch calls + rejections |
| 05:18Z | 40 | 59 | 0 | exactly 8 first-touch calls, ~10 cached calls |
| 05:31Z | 40 | 59 | 0 | 15 cached verification calls |
| 05:32Z | 40 | 59 | 0 | 3 cached calls fired back-to-back |

Cached calls never moved any counter; first-touch calls moved hourly and
daily in step; the 5/min counter read 0 after three back-to-back cached
calls. The per-minute 429s in the run all occurred on batches containing
unread ids.

### Not changed, deliberately

- The three caps, the per-document batch cost, the 429 branches and the
  "spine first" allocation — all still measured facts; only the bookkeeping
  changed.
- `get_api_usage` is not a substitute for the first metered call as the
  connector check: it has its own throttle and could in principle answer
  while the `user` scope is blocked. The banner still says "status confirmed
  on first call."
- Quirk numbering is stable; 37 keeps its number with new text so that the
  older changelog entries that cite it remain readable.

### Open

- O7 (refill granularity of `remaining`) — free to test, not yet run.
- Whether the v9.5 sync loss came from `propose_skills` or from a partial
  upload is inferred, not observed. The rule covers both.

## v9.5 — 2026-09-16

**Adds the archived-ORS-edition route for statutory-history questions.**
One new SKILL.md section, one new statute-sources section, two new
source-status rows, one new banner family, measurement M9. No change to the
CourtListener pipeline.

### The failure that prompted it

Query: "What year did ORS 59.115 first contain [the current subsection (6)
limitations text]?" The current chapter page shows only the latest text and
a bracket of fourteen amending acts; the skill had no allowlisted route to
any earlier edition. The first report (2026-09-15) answered "1987" from the
*Anderson v. Carden* dissent's recitation of Or Laws 1987 ch 603 §6 — correct
as to substance — but had to mark as **unverifiable** (a) which edition first
printed the exact cross-reference wording quoted, and (b) when the
subsection was renumbered (5)→(6), because the 1953–1997 ORS archive
"could not be retrieved." Three WebFetch passes on the archive landing page
(`bills_laws/Pages/ORSarchive.aspx`, three casings) had returned no
year-specific href; the file it does link (`Chapters%20020-061.pdf`) is a
1953 prior-history table; `archives.oregonlegislature.gov/Pages/ORS-Archives.aspx`
is a redirect notice.

When the user asked whether the archive could be reached, a web-search hit on
`archives.oregonlegislature.gov/ORS_Archives/1953-Chapter-087.PDF` exposed
the file-naming pattern. Constructing `1987-Chapter-059.PDF` worked first
time. Five editions (1985, 1987, 1989, 1991, 1993) then dated every step:
substance enacted 1987 c.603 §6 and first printed in the 1987 edition at
subsection (5); renumbered to (6) in the 1991 edition; cross-reference
restyled to "subsection (1)(b)" in the 1993 edition (1993 c.508 §28). The
"unverifiable" answer was wrong by two editions on the exact-wording
question. **A plausible, well-sourced, incomplete answer went out because the
route was undocumented** — which is exactly the failure this file exists to
prevent recurring.

### What changed `[verified 2026-09-15]`

- **SKILL.md** — hard rule 3 now says a "what did it say in year X" question
  is answered from an archived edition, never the current page or an
  opinion's paraphrase; new § "Historical statute text" carries both URL
  patterns, the bisect method, the OCR cautions, and the two-dates reporting
  rule (substance vs exact wording).
- **statute-sources.md** — two new tier-1 rows in the family table; new
  § "Archived ORS editions" with the discovery narrative (so the landing page
  is never navigated again), what is *not* online (pre-1999 Oregon Laws; the
  `lawsstatutes/<year>.pdf` index tables are unreliable under WebFetch — one
  found `158 §10` and missed `603 §6` for the same section), and the method.
- **source-status.md** — rows for both archive libraries, probed 2026-09-15;
  v9.5 probe-coverage note. Other rows carry forward the 2026-09-07 probe:
  **nine days old at ship, two beyond the documentation-release allowance.**
  Recorded rather than hidden; the next release re-probes every row.
- **banner.py** — family `Oregon ORS archived editions 1953-2023 (PDF)`,
  lit by `--need archived`. Verified: prints `verified 2026-09-15 [x]`.
- **measurements.md** — M9: the two patterns, the 404 boundary (1997 is not
  under the 1999–2023 pattern), the landing-page dead end, and the OCR error
  rate observed (4 distinct misreads in 9 fetches; none survived two-fetch).

### Evidence for the OCR rules `[verified 2026-09-15]`

| Edition | Misread | Truth | Caught by |
|---|---|---|---|
| 1991 | `paragraph (h) of subsection (1)` | `(b)` | second fetch + impossibility |
| 1991 | `1891 EDITION` | 1991 | impossibility (ch. 59 enacted 1967) |
| 1993 | `1991 c.62 §1` / `1991 062 §1` / `§281` | `1991 c.762 §1` / `§28]` | current-page bracket |
| 1993 | subsection (6) returned as first sentence only | three sentences | reworded second fetch asking for "the SECOND sentence" |
| 1989 | ORS 59.115 returned through (3) only | (4)–(5) present | reworded second fetch |

Every misread was caught by the existing two-fetch rule once the second
prompt was *specific* (a named sentence, a named cross-reference). A
same-wording second fetch would have reproduced the first-sentence
truncation. Hence the new rule that the second prompt names the sentence.

### Not changed, deliberately

- Pre-1999 Oregon Laws are not added as a source: nothing official serves
  them. The bracket plus the edition PDFs date an amendment without them.
- No tier-2 fallback for the archives: Public.Law publishes current text
  only, and no other aggregator is permitted.
- Banner family label says "1953-2023 (PDF)" rather than listing both hosts,
  to fit 78 columns. The two hosts are in source-status.md.

## v9.4 — 2026-09-08

**A streamlining release. No behavioural change.** The v9.3 procedure was
taken as fixed and the four CourtListener-side files were rewritten to
describe it once, clearly, without the sediment of how it got there.

### What changed in the documents

- **Eight whole-numbered phases** replace 0 / 0.5 / 1 / 2 / 2.5 / 2.75 / 3 /
  3.5 / 4 / 4.5 / 5: Parse · Anchor · Search · Select · Analyze · Refine ·
  Verify · Report. Strategy design merged into Search (it was orchestrator
  prep with no call between); id resolution and the history screen merged
  into Select (consecutive, and the screen needs only the ids); the
  sufficiency test merged into Refine. Every cross-reference in every file
  and the banner's Stages list updated.
- **`pipeline.md` 44.7 KB → 18.6 KB.** Same rules, same contracts, same
  thresholds. Removed: version-history tags, "in a prior run" narratives,
  "why this phase exists" paragraphs, the duplicated console spec, and a
  duplicated budget explanation. Evidence lives in this file and in
  `measurements.md`.
- **`subagent-briefing.md` 34.2 KB → 15.9 KB.** This block is pasted into
  every subagent prompt, so its size is paid on every agent. All 38 quirks
  kept with their numbers (the changelog and other files cite them) and
  their confidence tags; each compressed to its operative instruction plus
  at most one concrete artifact. The six rate-limit quirks (24, 26, 27, 30,
  37, 38) are now one-line pointers to the rate-limit section, which states
  the model once. Supersession language ("the earlier claim is withdrawn")
  removed — that record is in `measurements.md` § 5.
- **`courtlistener-mcp.md` 18.5 KB → 9.1 KB** and **`SKILL.md` 19.6 KB →
  9.8 KB.** The console-output spec now lives only in SKILL.md; the budget
  model is stated in full only in `pipeline.md` § Budget and the briefing,
  with SKILL.md carrying the two governing principles and the 429 table.

### Inconsistencies found and fixed on the way

These were latent in v9.3 and would have confused a run:

- The Phase 2 search-agent prompt still said "its 2-call budget" while
  Phase 1 had been raised to 3–4 queries. Now 3–4 throughout.
- Refinement stop condition 7 said "ledger ≥ 40" while the budget section
  said 44. Now 44 throughout.
- The pipeline's opening paragraph still required "one-line progress updates
  at every phase boundary," which v9.2 abolished. Removed.
- The search-agent contract lacked `limit_hit`, which the briefing's output
  discipline requires. Added to every contract.

### Release checklist

No source pattern, URL or protocol changed; statute files were deliberately
left alone apart from phase-number references. The full 2026-09-07 probe is
carried forward (one day old) under the documentation-only provision added
to the checklist above. `measurements.md` reviewed; nothing to add.

---

## v9.3 — 2026-09-07

The budget model was wrong in both directions. This release replaces guesses
with measurements, and restructures spending so that running out degrades the
report instead of breaking it.

### The measurements (a dedicated calibration, 2026-09-07 02:33–02:47 UTC)

A calibration subagent fired spaced `search` calls on a clean window until
refused. It failed at its stated objective and produced three better results.

1. **There is a third cap nobody knew about: `125/day`.** Verbatim body:
   `Rate limit exceeded: 125/day. Expected available in 6039 seconds.` It is a
   **rolling 24-hour window, not a midnight reset** — two independent 429
   bodies, 86 minutes apart, pointed at the same recovery time, which was
   exactly 24 hours after the *previous day's* run began. The skill had no
   concept of this. It is the real ceiling: ~4 runs per day. CourtListener
   documents it ("5 requests per minute, 50 requests per hour, and 125
   requests per day"), and also publishes a Usage API at
   `/api/rest/v4/api-usage/` reporting remaining quota on an independent
   throttle — **which this MCP connector does not expose**, and which is
   robots-disallowed, so it cannot be reached. Recorded as quirk 37 so no
   future run spends calls looking for it.

2. **`search` costs ONE unit. The v9.2 two-unit hypothesis is falsified.**
   46 consecutive searches ran with **no `50/hour` 429 at all**; at two units
   the cap refuses call 26. So cost × 46 < 50, and the cost is 1. Quirk 26 is
   rewritten from `[reported]` to `[measured]`. Consequence: v9.2's
   conservatism was calibrated on a false premise, and the strategy query cap
   goes back up from 2 to 3–4. The v9.1 observation that started it all — an
   hourly 429 at 32 counted calls, which 1-unit costs do not explain either —
   remains **unexplained**; rejected requests counting against the pool is the
   leading untested candidate.

3. **Cached document reads are free, and the cache persists across sessions.**
   With the daily pool exhausted, a `search_document` on an opinion fetched
   ~15 hours earlier *in a different session* returned full content, while a
   `read_document` on a never-fetched opinion was refused — twenty seconds
   apart, same pool. Quirk 27 promoted to `[measured]` and extended. This also
   means cross-run cost comparisons are contaminated by whatever the previous
   run cached: the v9.2 run reported ~37 units and actually spent closer to
   16.

### A second calibration, same day: rejections are free `[measured 2026-09-07 15:09–15:11]`

The one thing v9.3's first draft had to hedge — whether 429-rejected requests
consume quota — was tested directly at the per-minute scale, where a cycle is
60 seconds rather than an hour and the evidence comes from the 429 bodies
themselves.

**Protocol.** Burst five calls to fill the 5/min window, then fire four more in
immediate succession and read the "Expected available in N seconds" from each
refusal. If N counts down, the reopen instant is fixed and rejections cost
nothing; if N holds or grows, they are being recorded.

**Result, two cycles:** N sequences of **50 / 47 / 45 / 42** and **43 / 41 /
39 / 36** — monotonically decreasing at wall-clock rate toward a fixed point.
Sleeping the last stated N plus 5 seconds produced a success both times.

Three consequences:

1. **Rejections consume no quota and do not extend the window.** Excluding
   them from `calls_metered` — which this skill has always done — is confirmed
   correct rather than merely assumed. The v9.3 draft's "assume they might"
   hedge is removed.
2. **The stated availability is accurate; quirk 30 is rewritten.** The earlier
   `[reported]` claim that a 429 body understates the wait is **withdrawn** —
   the runs that seemed to show it had slept far longer than stated and never
   tested the boundary. The per-minute branch now sleeps **N+5 (floor 5 s,
   ceiling 90 s)** instead of a flat 62, which is both more accurate and
   faster. The related claim that early retries lengthen the wait is also
   withdrawn: the window is pinned to the **oldest counted success** and
   advances as slots age out, so a retry refused with a *larger* N is seeing
   the next slot, not a penalty.
3. **The v9.1 anomaly now has a better leading suspect.** An hourly 429 at 32
   counted calls is explained by neither 1-unit nor 2-unit search costs, and
   now not by rejections either. The remaining candidate is the ledger itself:
   **a batched document call spends one unit per DOCUMENT**, and an agent
   reporting one unit for a three-id batch understates by two. The rule
   existed; it was easy to miss. It is now stated emphatically in the
   briefing's output discipline, in pipeline.md and in SKILL.md, flagged as
   the known undercount risk. Untested, and labelled as such.

Measured at per-minute scale only. The hourly and daily caps are the same
throttle family and very likely behave identically, but that is inference.

### The structural change: spine first

Not all spending is equal, and v9.1 failed not by overspending but by
spending in the wrong order — six optional refinement units before one
mandatory screen unit, so the report went out unable to say whether its
authorities were good law.

- **New `Phase 2.75`**: the negative-treatment screen moves ahead of the
  analysis wave. It needs only the ids Phase 2.5 just produced, costs the same
  one unit, and can now never be the casualty. Bonus: a case the screen flags
  can be dropped from the wave before it is paid for.
- **Minimum viable run defined** (~13 units: ~4 searches + 1 screen + ~8
  reads). Everything above the spine is enhancement and is what gets cut. A
  cap that fires above the spine shortens the report; below it, the run aborts
  and says so.
- **Plan every run as though the full hourly window is available.** Budgeting
  defensively against an unknown prior spend degrades every run for certain to
  avoid an occasional wall-hit. The first metered call is a free probe: a
  `125/day` refusal aborts the run at call one having spent nothing.

### Three-branch 429 handling

`5/min` → sleep 62 s and retry once. `50/hour` → stop, recoverable this hour.
`125/day` → stop, print the new `DAY` console line, tell the user. Subagents
now return `limit_hit` alongside `rate_limited`. Previously everything was
reported as "hourly window exhausted," which is actively misleading advice
when the day is what ran out.

### Batched document reads measured, and the verification stage blind-tested

Two more calibrations the same afternoon, both using the 5/min window as a
cheap ruler or costing nothing at all.

**Batched reads cost per DOCUMENT — measured.** `[measured 2026-09-07]` Fire a
batch, then count how many single calls fit in the remainder of the minute. A
3-document `search_document` batch left room for exactly 2 more (5 − 2 = 3
units); a 2-document batch left room for exactly 3 (5 − 3 = 2 units). Both
trials agree: cost equals batch size. The rule was already in the briefing as
an assertion; it is now measured, promoted to quirk 38, and paired with an
explicit instruction to report **documents, not calls** in `calls_metered`.
Batching buys latency and turn-count, never quota. This remains the leading
explanation for the v9.1 hourly 429 at 32 counted calls, and it is now a
measured mechanism rather than a guess — though whether it actually caused
that failure is still untested.

**The quote verifier passed a blind adversarial test, 7 for 7.** A verifier
subagent was given seven quotations across four cached opinions without being
told that four were fabricated — plausible in register, on-topic, attributed
to the right cases. It graded all three genuine quotes `verified` and all four
fabrications `not_found` with `confirmed_absent`, each supported by multiple
line-length fragments returning zero. Two details make the result stronger
than the score:

- The *Douglas* fabrication was a **paraphrase of real language** — the
  opinion does contain "no occasion to visit" — and the verifier identified it
  as a paraphrase rather than accepting the near-match, quoting what the
  opinion actually says instead.
- For *Carey* and *Sevier County* it ran **exhaustive** checks: all 7 matches
  for "savings clause" and all 6 for "good faith and fair dealing" enumerated
  and individually rejected, rather than inferring absence from a couple of
  misses.

This is the first direct evidence that Phase 4.5 catches fabrication and not
merely typography. It cost zero API budget, because the documents were already
cached. **Re-run it whenever the verification prompt changes** — it is the
skill's last line of defense against its worst failure mode, and until now
nobody had watched it work.

### Full source probe, and five corrections it produced

Unlike the first v9.3 draft, which probed only the rows it touched, **every
row of `source-status.md` was re-probed on 2026-09-07**, plus both bundled
corpora and both review-disposition entry points. No row failed; five changed
materially:

1. **Oregon OAR (tier 1)** has flipped FAIL → OK → OK on three consecutive
   days, the last confirmed on two independent URLs on the host. Reclassified
   **intermittent, not restored** — try tier 1 every run, keep the fallback.
   The old row asserted flat unreachability and "currently via tier 2 only",
   which is now wrong in the other direction.
2. **Oregon OAR (tier 2)** now shows dates where it showed none — but they are
   **access dates, not currency**, and the source credit's "last accessed" is
   *earlier* than the page date. Recorded with an instruction never to present
   them as currency. Also noted: tier 2 titles the rule "Calculating Support"
   where the official page says "Calculating Child Support".
3. **Oregon petitions for review**: the documented navigation route is
   **dead** — no such link exists on the appellate page, several supreme-court
   URLs are hard 404s, the media-release route renders client-side only, and
   the contentdm HTML UI is Javascript-only. The working route is the
   contentdm **JSON API**, and the lists live in collection `p17027coll3`
   ("Opinions -- Oregon Supreme Court"), not in a dedicated advance-sheet
   collection as the old entry implied. Full URLs now in `statute-sources.md`.
   Most recent list at probe: August 27, 2026.
4. **Washington petitions for review** is an **intermediate page** carrying no
   cases, numbers or dates — one more hop is always required, and a run that
   stops there and reports "no disposition located" is producing a false
   negative on the one check CourtListener cannot do at all. Also recorded:
   never construct a `courts.wa.gov` query URL, because a guessed one returned
   a ColdFusion error *inside normal page chrome*, which reads like an empty
   result rather than a failure.
5. **Colorado public.law** rephrased its currency line to "Current through
   Fall 2025" (from "Up to date through Fall 2025"), same coverage. Trivial in
   substance, but these strings are printed verbatim in reports.

Two standing cautions added: **Nevada and Texas public.law share an identical
"Updated May 26, 2025"** — one stalled ingest covering two states, ~15.5
months behind and spanning multiple legislative sessions in both, with no
tier-1 fallback in this file; and **ORAP cannot be quoted from its official
page at all** (no edition date, rule text injected client-side), which is
precisely the situation the new opinion-corroboration fallback exists for.

Also confirmed unchanged and worth keeping: both RCW URL casings still serve
identical text (the two-fetch independence trick survives); ORS chapter 12
renders complete, but only because it is short — **not** evidence the
truncation problem is fixed, and the long-page protocol stays in force.

### Reproducibility and provenance

- **Existence framings set `deep`** (pipeline Phase 0). "Are there any cases
  where…", "has any court…", "is there authority for…". Evidence: two runs of
  the *identical* query parsed it as `deep` and `unspecified`; the `deep` run
  analyzed two additional relevance-5 cases (*Johnson v. Continental Finance*,
  *Comb v. PayPal*) and preserved the *Hooters* correction the other lost.
  This was a coin-flip, and coin-flips in Phase 0 propagate through everything.
- **Orchestrator-recalled citations are sanctioned, with four guardrails**
  (pipeline Phase 2.5). One batched `citation:()` call resolved fifteen
  recalled cases for one unit in the v9.2 run and anchored the whole
  pipeline — eight of ten Leading Authorities entered through it. The
  technique will be used whether the spec allows it or not, so it is governed:
  inputs only; a row counts only if its `citation` array literally contains
  the requested string (quirk 23); an unconfirmed citation never reaches the
  report in any form; and **the About table reports recall-vs-discovery
  counts**, because a run that looks efficient because the model already knew
  the answer is not the same as one that found it.
- **`references/known-corrections.md`** (new). Verified findings about what
  specific opinions are miscited for, with the method that established each.
  Read at triage, pasted into the analyzer prompt for any listed case. Seeded
  with *Hooters of America v. Phillips* (not an illusoriness holding —
  material breach and good faith; `illusor` 1, `consideration` 1, `mutuality`
  0), *Grosvenor v. Qwest* 10th Cir. (§ 16(a) jurisdictional dismissal only),
  *Hardin v. First Cash* (adopts *Dumais*, does not distinguish it), and
  *Circuit City v. Najd* (contains no modification-power discussion — `modif`
  0, `amend` 0, `terminat` 1). This is the skill's answer to having no memory:
  a correction survives only by being written in and reinstalled.

### Reporting fixes

- **Every About-table number is computed, not recalled.** In the v9.2 run a
  screened-candidate figure (118) was carried over from the v9.1 report and
  published in both the chat report and the Word memo; the true figure was
  ~77. `screened` is now defined as the cardinality of the deduped candidate
  union, and call figures as summed `calls_metered`.
- **New `Daily pool` row** — units used of 125 and when they return. The skill
  has no memory; the reader does. Give them the number.
- **Data Sources late additions** are appended and marked `[+]`, never
  back-edited into the banner. The v9.2 run added a Delaware row mid-run and
  quietly broke the "verbatim" rule; now there is a sanctioned way to do it.
- **Subsequent History renders for cleared flag candidates too.** A same-name
  citer chased to a conclusion is worth reporting even when the conclusion is
  "not negative treatment" — it distinguishes checked-clean from unchecked.

### Statute protocol

- **Opinion corroboration is a permitted second source for single-source
  families** (Delaware Code, federal rules, ORAP — collections with a tier-1
  source and no permitted tier-2). The second fetch may be the same language
  quoted verbatim inside an opinion read this session and verified against it;
  a court reproducing a provision is genuinely independent of the publisher's
  page. Disclosed on the provision line. Without this the fallback gets
  invented mid-run, which is what happened to 5 Del. C. § 952(a).

### New quirks (34–37)

34. `order_by: "dateFiled desc"` with `stat_Unknown` returns result sets
    dominated by RECAP `trial-court-document` rows — 22 of 30 in one
    observation — indistinguishable from briefs. Prefer `citeCount desc`.
35. A long `read_document` that spills to a local file is a **success**: the
    unit is spent, the document is cached, the payload is intact. Parse it
    locally; re-fetching in chunks buys nothing. Three analyzers hit this.
36. A cluster's `lead-opinion` id is not always right — *Najd*'s cluster lists
    a lead id carrying an unrelated 2018 case's docket number alongside the
    correct `combined-opinion` id.
37. The `125/day` cap and the unexposed Usage API (see above).

### Screen construction

`vacat*` is noise in arbitration, award, injunction and stay questions — it
returned 360 citers dominated by "vacate an award" and forced a second call.
Match the verb set to the subject matter, and order screens by `citeCount
desc` so same-name and higher-court citers surface early.

### `references/measurements.md` — new

An audit at the end of this release asked a simple question: does v9.3 record
its test *results* well enough that a future redesign need not repeat them?
Conclusions, yes — tagged `[measured 2026-09-07]` across six files. But three
things were missing, and all three are the ones that actually prevent repeat
work:

- **The methods were not recorded.** The "5/min window as a ruler" technique
  is what made three of these tests cost under ten units instead of a whole
  day, and it existed only as a passing phrase. It is now written up as a
  reusable protocol.
- **There was no index of measured vs. assumed vs. unknown.** Findings were
  scattered across 1,200 lines of chronological changelog, where an assumption
  reads exactly like a measurement.
- **The untested gaps were recorded nowhere at all** — not the null-query
  test, not the fact that Phase 0.5 has never executed in production, not the
  statute-truncation path.

`measurements.md` fixes all three: eight measurements with their methods, five
assumptions explicitly labelled as unmeasured, six open questions with test
designs, and a superseded-claims table so that stale statements in older
changelog entries (the "10/min and 100/hour" limits, "cached-document lifetime
is untested") are not acted on. Release checklist step 7 now requires updating
it.

### Release checklist

Re-probed 2026-09-07: OLRC, Cornell, Delaware Code, and both bundled Oregon
corpora (ORCP 40 days, UTCR 47 days). Washington, Oregon and Public.Law rows
carried forward from the 2026-09-06 full probe — one day old, well inside the
90-day rule, and untouched by this release. `source-status.md` records the
coverage explicitly rather than implying a full re-probe.

---

## v9.2 — 2026-09-06

Post-mortem release after the first live run of v9.1 (federal question:
enforceability of an arbitration clause added under a no-notice unilateral
modification clause; complex profile; 28 subagents; report + memo
delivered). Owner-directed. Release checklist run in full: all 22
`source-status.md` rows re-probed on 2026-09-06 (WebFetch only; zero
CourtListener calls); Oregon OAR at sos.state.or.us is reachable again and
its row returns to OK with the tier-2 fallback retained; both
review-disposition entry points probed for the first time since v8; ORCP and
UTCR corpora 39 and 46 days old.

### What the run showed

- **Per-case cost roughly halved versus v8.** 32 counted metered calls for 19
  fully-read opinions, 118 candidates screened, 22 of 22 quotes verified and
  one FAA provision double-fetched — against 46 calls for 16 cases on
  2026-09-05. The staggered analysis wave ran 15 analyzers in six minutes
  with zero 429s. Quote verification and the absence check cost nothing, as
  designed. Wall clock, invocation to report: ~50 minutes.
- **But the single-window promise did not hold.** The `50/hour` 429 arrived
  on the 33rd *counted* call, so the ledger undercounted by ~14–18 units.
  Four rejected requests were reported; they do not close the gap. The
  arithmetic does close if each `search` costs two API requests (13
  searches × 2 + 19 reads + 4 rejections ≈ 50). Recorded as quirk 26
  `[reported]`, with a calibration recipe in pipeline.md; the budget tables
  now plan `search` at 2 units.
- **The casualty was the mandatory check, not the optional one.** The
  optional refinement round (6 units) ran before the one-call history
  screen (1 search), and the screen was the call the cap rejected, leaving
  13 of 19 analyzed cases externally unscreened. Ordering flaw, fixed below.
- **"Not found is a correct answer" worked.** Seven of nineteen analyzers
  corrected the premise they were handed (a jurisdictional dismissal
  presented as a merits case; "without notice" meaning nondisclosure of
  litigation rather than of the amendment; a material-breach case cited
  everywhere for illusoriness). Two of those corrections — *Hooters* and
  *Tinder* — are findings a commercial headnote would not supply.
- **The v9.1 console log cost turns, not tokens.** Banner plus eight log
  lines were under 1% of a ~2.4M-token run, but they took ten tool turns,
  the banner spec's prose alignment rules contradicted its own example (the
  orchestrator wrote a script mid-run to satisfy it), the `[HH:MM]` stamps
  could not be produced honestly without a `date` call per line, and the
  routine lines duplicated the About table.
- **Strict top-10-by-score produced a one-sided Leading Authorities.** Ten
  relevance-5 holdings all cut one way; the two current enforcement-side
  circuit decisions and the leading assent case fell to Also Reviewed while
  the Short Answer described a split.

### Changed

- **Console output → banner + exceptions only** (SKILL.md § Console output;
  pipeline.md § "Exception lines" replaces § "Log lines"). The banner stays —
  it is the provenance stamp the report and memo reproduce — and is now
  assembled by `scripts/banner.py` from `VERSION` and `source-status.md`
  (added; `--need`, `--used`, `--no-federal`, `--list`; warns on lines over
  78 columns). After it, only `API`, `WAIT`, `NOTE`, `CUT`, `FIX` and `DONE`
  lines; no timestamps, no budget meter, no phase transitions. A clean run
  prints three things.
- **History screen moved to Phase 4 step 0**, before any refinement spend
  (pipeline.md Phase 4; SKILL.md workflow summary). Added to the
  load-bearing table.
- **`search` budgeted at 2 units** (SKILL.md budget section, pipeline.md
  budget table, courtlistener-mcp.md, briefing quirk 26). Phase 2 strategy
  cap lowered from 5 queries to 2 (third only if thin) — the run got every
  eventual leading authority from 11 queries across five strategies. Reserve
  lowered to ≥6 to keep the table honest; the "complex + one refinement
  round fits one window" claim from v9 is withdrawn and replaced with the
  two options that do fit.
- **Leading Authorities reserves up to two slots for contrary authority**
  regardless of score, marked *(contrary authority)* (report-format.md).
- **Memo header carries a `Skill` line** — version, last-modified date,
  author, run date, calls used, agent count — and the About table gains a
  `Skill` row; notice-block banners must name which check was cut and for how
  many cases (memo-format.md). The Data Sources block was already specified
  in v9.1; the 2026-09-04 example memo predates it.

### Added — briefing quirks 26–33, refinements to 11 and 18

All `[reported 2026-09-06]` except 27, which was directly observed. 26 search
cost; 27 cached reads serve inside an exhausted hourly window at any rate;
28 duplicate clusters for federal reporters (*Prudential*, *Iberia*,
*Heckman*); 29 `<em>` tags shred fragments, and star-pagination markup varies
by ingestion source; 30 a 429 body can understate the wait; 31 bare surnames
in `caseName:` OR-lists are wasted; 32 `search_document` accepts raw HTML
(`id="fn16"`) to jump to a footnote; 33 mid-word OCR hyphens and mid-document
markup switches. Quirk 11: the semantic index is a ~24-month window, not
"since 2019". Quirk 18: a search row's `opinion_id` can be a dissent or
concurrence (*Walther*, *Morrow*) — check `cluster_opinions` before reading.

### Not changed, deliberately

- The Phase 3 analyzer contract, the anchored rubric and the
  `scale_confirmation` echo — every analyzer returned the echo, no Guard-2
  correction fired, and the premise-correction behaviour is exactly what the
  contract was written to produce.
- The two-fetch statute rule — 9 U.S.C. § 2 from OLRC and Cornell agreed to
  the character, including the 2022 source credit.
- Hard rule 6 (state review dispositions) — not triggered (the only state
  case was 1998, and its review denial is in the opinion record), but the
  entry points are now re-probed and dated.

---

## v9.1 — 2026-09-05

Owner-directed changes, same day as v9.

### Added — release checklist, `VERSION`, and `references/source-status.md`

Rule: every change to the skill re-verifies every code/statute/rule
repository and updates its date. Implemented as the checklist above, a
`VERSION` file the banner reads, and a per-source verification log that is
the single source of truth for the banner's Data Sources lines. Running the
checklist for this release found two allowlist defects that had survived
since v5:

- **OAR (secure.sos.state.or.us) is unreachable via WebFetch** — robots.txt
  fetch failed twice (ConnectTimeout, then parse failure). The Public.Law
  OAR pattern works (verified 2026-09-05, no currency statement on the
  page). The table now routes OAR through tier 2 with disclosure until the
  official host is reachable again.
- **The Delaware Code chapter-index pattern returns navigation only.**
  `delcode.delaware.gov/title6/c018/index.html` lists subchapters with no
  section text; the text is on `…/c018/sc01/index.html`. The v5 "long-page
  truncation" protocol would have reported § 18-101 as NOT PRESENT rather
  than fabricating it — the escape hatch worked — but the pattern was wrong.
  Corrected to index-then-subchapter navigation.

All other rows verified OK on 2026-09-05; Public.Law currency statements
recorded per collection (CA "Updated August 17, 2026"; CO and FL "Fall
2025"; TX "May 26, 2025"; OR "early 2026"; NV and NY none on the index).

### Changed — console-style banner and log replace the prose Sources block

The v9 "Sources for this research" paragraph (same day) is replaced by a
fixed-width banner — title rule, version/date from `VERSION`, author,
purpose, Data Sources with `[x] [!] [ ] [-]` marks and verification dates
from `source-status.md`, budget line, stage list — followed by timestamped
`[HH:MM] P<n>` log lines with a right-aligned budget meter, through to a
`DONE` line after the memo. Templates and line rules in `pipeline.md`. The
report's fixed-opening item 6 and the memo's notice block now carry the
banner's Data Sources lines verbatim in monospace. Sample A of three offered
was selected by the owner.

### Decided — no dedicated CourtListener status call

The banner prints `connector loaded [x] (status confirmed on first call)`.
The MCP tools' presence proves the connector is loaded; `get_endpoint_schema`
is off the metered list but proves only that the MCP server answers; neither
proves authentication or an open rate window. The first real metered call
(Phase 0.5 anchor resolution) is the check, and its P0.5 log line prints
`status confirmed` or the failure. If that first call 429s, the body's
availability figure seeds the budget meter with a real number.

### Known gaps — carried forward

- OAR official host: re-probe each release; restore tier 1 when reachable.
- Review-disposition entry points were not re-probed this release (v8 dates
  stand); do so at the next.
- The 90-day `[!]` threshold for banner marks is a policy choice, not
  evidence-based; adjust if it nags.

---

## v9 — 2026-09-05

Source run: a complex Washington contract question (unilateral change-of-terms
clauses in consumer adhesion contracts; 16 cases analyzed, 42 quotes verified
with 0 not-found). The run produced a correct report — but spent 46 of the
50-call hourly pool, lost ~15 calls to work that yielded nothing, hit the
hourly cap during the finishing wave, and left one subsequent-history flag
unconfirmed. Every change below is either a tested API recipe that removes
metered calls, or a rule derived from a measured failure. **No load-bearing
rule was weakened.** One new user-facing element (the Sources block) was
added at the owner's request.

### Where the 46 calls went (the evidence for everything below)

| Phase | Calls | Avoidable | Cause |
|---|---|---|---|
| 0 / 0.5 | 3 (+2 rejected) | 1 | a `get_endpoint_item` to confirm a court ID; two calls fired in parallel and both 429'd |
| 2 search | 12 | ~5 | single-citation lookups of cases already known by name, one per call |
| 3 analysis | 17 for 13 opinions | 4 | two analyzers reported 3 units for one opinion and gave no reason |
| 4 refinement | 9 | 3 | three calls hunting *Burnett v. Pagliacci Pizza* (Wash. 2020) — not in the corpus |
| top-up | 3 | 2 | two more calls on *Burnett* |
| 4.5 | 2 (+1 rejected) | 0 | one OR-joined history screen; one read; the *Coneff* read was refused by the hourly cap |

Replayed against the v9 recipes the same 16 analyzed cases cost roughly 27
calls: 2 (batched anchor resolution + raw citator) + 1 (filtered citator) +
8 (two search agents × 4) + 1 (batched resolution of six known cases) + 13
(one unit per opinion, enforced) + 1 (*Rekhter* dissent) + 1 (OR-joined
history screen) — with 0 spent on *Burnett* (quirk 21) and 0 on the court
ID. That leaves room inside one window for the two reads the source run
could not afford.

### Verified today — four live tests, three metered calls

All run against the MCP on 2026-09-05 after the hourly window had reset;
artifacts are in the session transcript.

- **Batched citation resolution** `[verified]`.
  `q: 'citation:("148 Wash. App. 52" OR "116 Wash. 2d 563" OR "153 Wash. 2d 331" OR "180 Wash. 2d 102")'`
  returned all four cases (*Duncan*, *Badgett*, *Adler*, *Rekhter*) in one
  unit, each row with `opinion_id` and a `cluster_opinions` array. The
  source run spent ~8 calls resolving these and similar cases one at a time.
  → new recipe in courtlistener-mcp.md; Phase 0.5 step 1 and Phase 2.5
  rewritten; briefing quirk 19.
- **`cluster_opinions` on every search row** `[verified]`. *Rekhter*'s row
  listed 4710694 (lead), 4710695 (in-part), 4710696 (dissent); *Adler*'s
  listed lead + concurrence. This closes the v8 "known gap" about
  multi-opinion clusters: the `get_endpoint_item` exception for
  citator-bound cases is removed. → briefing quirk 20.
- **`citation no-link` = not in the corpus** `[verified]`, zero metered
  calls. A `search_document` on the cached *Tadych* opinion for "Pagliacci"
  returned `<span class="citation no-link">196 Wn.2d 38</span>` — the
  CourtListener linker had no record to link to. Five metered calls across
  two agents had already failed to find that case by `case_name`, `q`, and
  two `citation` filters. → new "Harvest before you search" section in
  courtlistener-mcp.md; Phase 1 and 2.5 rules; briefing quirk 21; new
  load-bearing row.
- **Topic-filtered citator** `[verified]`.
  `cites:(4713957 OR 2630496) AND ("continued use" OR "change of terms" OR "unilateral modification" OR "right to modify")`
  cut *McKee*'s 63 citers (two duplicate clusters OR-joined) to 6 that
  discuss the clause, and surfaced *Bennett v. T-Mobile* (W.D. Wash. 2024),
  which none of the run's keyword strategies found. Five of the run's
  name-triaged reads scored ≤ 2. → Phase 0.5 step 3; courtlistener-mcp.md
  step 2b; briefing quirk 22.
- **`read_document(cluster_id=…)` is safe** `[verified]`. Cluster 4908388
  (*Adler*) returned `doc_id 4713080` — the correct lead opinion — with
  `cluster_opinions` including types and authors. Quirk 2 reworded: the
  hazard is a cluster id passed *as* `opinion_id`. The v8 "try
  `read_document` on the cluster id and check" advice is replaced by the
  dedicated parameter.
- **OR-joined negative-treatment screen** `[verified in the run]`.
  `cites:(<8 ids>) AND (overrul* OR abrogat* OR disavow* OR "no longer good law")`
  screened eight analyzed opinions for one unit (52 rows). → Phase 4.5A
  rewritten; courtlistener-mcp.md; briefing quirk 22.

### Corrected — concurrency arithmetic

`[verified]` The v8 rule "3 concurrent search agents, calls ~20–30 s apart"
is 6–9 calls/min against a 5/min cap. Search agent 2 in the source run was
rate-limited at its fourth call, as the arithmetic predicts. All three files
now say **2 concurrent at 25–30 s, or 3 at 40 s**, and the orchestrator's own
calls are paced the same way (it lost calls 2 and 3 to a 429 by firing them
in parallel). Analyzer stagger tightened from 15–20 s to 12–15 s (one call
per 12 s is the cap; 13 analyzers at 20 s spent >4 min on offsets).

### Added — 429 body may report the hourly window (quirk 24) `[reported]`

An analyzer's `read_document` on an uncached opinion returned "Expected
available in 1787 seconds." The briefing said "wait the stated availability
or 60 s, whichever is longer" — literally a 30-minute sleep, which the same
briefing forbids. Rule: if the stated availability exceeds 90 s, stop and
report immediately. Single instance; promote with a second observation.

### Added — loose `citation` filter match (quirk 23) `[reported]`

`citation: "470 P.3d 486"` returned *State v. Ralston*, whose citation is
486 P.3d 822. Single instance. Rule: a single citation-filter hit is
unverified until its `citation` array contains the requested string. This
also applies to the batched query above.

### Added — analyzer `calls_explanation`

Two analyzers reported `calls_metered: 3` for a single opinion with no
explanation and no `id_mismatch`. The contract now requires a
`calls_explanation` field whenever `calls_metered > 1`, and states the
one-fetch rule explicitly (by `opinion_id`, with a chunk list; no re-fetch
by `cluster_id`; no batched `search_document` over unread ids).

### Added — statute fetches are front-loaded

WebFetch has its own session quota, separate from CourtListener. The source
run did the first fetch of each RCW provision early (during a 429 cooldown —
the right instinct) but deferred the second confirming fetch to Phase 4.5,
where the WebFetch quota was exhausted; two provisions went to the report
cite-only. Rule: both fetches of every provision happen back to back, early,
alternating URL casing where the host permits so the second is not the
15-minute cache. The two-fetch rule itself (load-bearing) is unchanged.

### Added — court-ID table (courtlistener-mcp.md)

One unit was spent on `get_endpoint_item(courts, "washctapp")`. The IDs
verified in use across runs are now listed so that never recurs.

### Added — the "Sources for this research" block (owner request)

A ≤110-word paragraph emitted after the "Read as:" line and before the
first search, then reproduced in the report's fixed opening (item 6) and the
memo's notice block. Built from four slots — courts (federal courts named
unless `federal_excluded`), statute families matched against the
statute-sources tiers (official / bundled / Public.Law-only / none), a fixed
"not available" line (citator flags, secondary sources, state review
dispositions), and the fixed verification sentence. The four statute
sentences are the only four the tier tables can produce, so the block can
never claim a source the allowlist lacks. Explicitly excludes any mention of
the API rate budget. New parsed field `federal_excluded`.

While drafting the templates a contradiction in statute-sources.md surfaced
and was fixed: the tier-2 table lists six state collections as permitted,
while a later paragraph said "none are in this skill's allowlist." The
table is right; the paragraph now says so and distinguishes tier-2-only
states (Colorado, …) from states with no source at all (Idaho, …).

### Changed — briefing delivery mechanism (evidence, not a rule change)

The source run did not paste the ~5k-token briefing into 24 prompts; it
wrote the verbatim block to a scratch file and made `cat` of that file each
agent's mandatory first step. 24 of 24 agents complied; zero wrong-document
analyses; ~100k orchestrator output tokens saved. SKILL.md now permits this
delivery explicitly. The load-bearing rule — every agent has the verbatim
block — is unchanged; only the copy mechanism is relaxed, on this evidence.
If a future run shows an agent skipping the `cat`, revert to paste-only.

### Considered and deferred

- **Role-scoped briefing annexes** — still deferred (v8 reasoning stands);
  the `cat` delivery removes most of the token cost that motivated it.
- **Semantic search for triage** — not tried; quirk 11's recency limit makes
  it unsuitable for the state-law questions this skill mostly sees.
- **Reading by `cluster_id` as the default** — works, but `opinion_id` is
  already on every search row; no reason to change the default.

### Known gaps — carried forward

- Quirks 23 and 24 are single observations; promote or drop.
- The batched `citation:` query was tested with four cites; the practical
  upper bound per call is untested (try 8–10 and record).
- Whether `cites:(…)` OR-joins degrade above ~10 ids is untested.
- The replay arithmetic above is a paper estimate, not a measured run; the
  first v9 run should record its actual ledger here.
- v8 gaps (cap plan-dependence, cache lifetime, inherited quirks 1/5/6/10)
  remain.

---

## v8 — 2026-08-08

Source run: a 12-case federal-procedure question (overlapping consumer class
actions — first-to-file / § 1404(a) / § 1407). The run finished correctly but
spent ~35 of ~75 minutes stalled on an exhausted rate window and ~35% of its
metered calls on ID resolution. Every change below is conservative: budgets,
recipes, and one new deliverable — no load-bearing rule was weakened.

### Corrected — the rate caps are 5/min and 50/hour, not 10/100

`[verified]` Three subagents and the orchestrator independently read the 429
bodies: `Rate limit exceeded: 5/min` and `Rate limit exceeded: 50/hour`
(`Expected available in N seconds`). Consequence of the wrong constants: a
7-analyzer wave dispatched onto a "safe-on-paper" window exhausted the hour
mid-wave; one analyzer failed (returning honest nulls — the hard-rule-7
escape hatch worked exactly as designed) and the pipeline stalled ~35 minutes.
This is the same failure class as v4's "uncapped document tools": an
unverified constant trusted over observation.

- All four files now state 5/min / 50/hour, with an adaptive rule: **the 429
  body is authoritative — if it reports different numbers, rescale to 80% of
  what it says and file a `new_quirk`.**
- Phase budget table rescaled to the 50 pool (search 20→14, resolution 12→2
  batched, analysis 25→15, refinement 15→8, finishing 10→5, reserve 15→8);
  ledger stop threshold 80→40. A baseline run now provably fits one window
  (sum 47); the table says explicitly what does not fit (complex×15, any
  refinement round) and what to do about it.
- New wave-size precondition: `wave_cost ≤ 50 − ledger − reserve`, else split.
  Evidence: the staggered 5-analyzer wave on a fresh window ran with zero
  429s; the unstaggered-onto-spent-window wave lost an analyzer.
- Stagger guidance added (agents space calls ~20–30s; analyzers get start
  offsets ~15–20s apart). `[verified]` — same comparison.
- During an unavoidable wait, do the zero-cost work (statute WebFetch,
  cached-doc verification, drafting). The source run recovered ~10 minutes of
  its stall this way; codified.

### Changed — Phase 2.5 resolution is now (usually) free

Per-case `get_endpoint_item` resolution of a 15-case selection cost 15
metered calls (~35% of the run's entire spend) plus ~4 minutes of pacing
sleeps. Two candidate replacements were checked live against the MCP before
shipping:

- **`id__in` batching: falsified.** `[verified 2026-08-08]` The MCP client's
  clusters schema permits only `gt/gte/lt/lte/range` lookups on `id`;
  `call_endpoint(clusters, {"id__in": …})` fails client-side validation
  (no quota cost). The recipe drafted for it was removed before release.
- **Search-row `opinion_id`: verified.** `[verified 2026-08-08]` Every
  `search` result row carries `opinion_id` even when not requested via
  `fields`. Checked against two pairs this skill had already resolved with
  metered cluster lookups — *Baatz* 3179996→3179978 and *Lou v. Belzberg*
  8965002→8956294 — both matched. Phase 2's candidate contract now carries
  `opinion_id` through (new briefing quirk 18), so resolution costs zero
  metered calls for search-surfaced candidates. Metered cluster lookups
  remain for the listed exceptions: no search row, possible multi-opinion
  clusters bound for citator OR-joins, and `id_mismatch` recovery.

The central-resolution requirement itself (load-bearing, v3) is unchanged —
the source run had **zero** wrong-case analyses, versus three in the run that
created the rule, and the analyzer identity check remains the last line of
defense over whatever supplied the id.

### Added — per-sub-question sufficiency

`[verified]` The global high-relevance count passed (7 ≥ target 4) while the
§ 1407 prong had zero analyzed authorities — the two JPML orders were queued
in the second half of the wave. Only manual override kept the report whole.
Phase 3.5 now additionally requires ≥1 relevance-4+ case per Phase 0
sub-question, and Phase 3 orders the wave so each sub-question's top case is
in the first half dispatched. Depth constants and the rubric are unchanged.

### Added — quirks 16–17; citator width; statute-source hardening

- **Quirk 16** `[reported]`: search-index court labels unreliable on
  duplicate/harvested records (*AmSouth Bank v. Dale*, 386 F.3d 763, labeled
  "1st Cir."; *Casey v. Odwalla* labeled S.D. Ill. with an S.D.N.Y. docket;
  duplicate *Lou*/*DiRienzo* clusters mislabeled). Confirm court from opinion
  text or reporter before citing.
- **Quirk 17** `[reported]`: `court: ["jpml"]` works (recorded as a verified
  ID in courtlistener-mcp.md) but the bucket holds misfiled Texas state
  MDL-panel decisions with S.W.3d cites — screen for a federal reporter.
- **Citator `num_results` 30→100** `[verified 2026-08-08]`: same one-unit
  cost; a 30-row screen silently covered 30 of *Baatz*'s 55 citers, and a
  live `num_results=100` call returned 100 rows of *Kohn*'s 159-citer set.
- **429 retries extend the per-minute lockout** `[reported]`: an immediate
  retry made at "Expected available in 4 seconds" produced a fresh 32-second
  lockout. Briefing now says to wait the stated availability or 60s,
  whichever is longer.
- **U.S.C. two-source check** `[verified 2026-08-08]`: added the official
  OLRC per-section pattern
  (`uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title{T}-section{S}&num=0&edition=prelim`),
  verified against § 1404 — text and source credit matched Cornell exactly.
  Documented that WebFetch's ~15-minute URL cache means a same-URL double
  fetch validates extraction only; where two allowlisted sources exist, the
  two-fetch rule now uses one of each. The v5 same-URL protocol remains the
  floor for single-source families.

### Added — companion Word memo as a standard deliverable (owner decision)

Phase 5 now produces the chat report AND a `.docx` memo per the new
`references/memo-format.md`, without further prompting. The memo is
constrained to be a re-presentation of the verified report: no new
authorities, no new quotes, `not_found` quotes dropped rather than ⚠-labeled,
AI notice and banners carried over, "surfaced but not read in full"
disclaimer preserved, About table reproduced. Built via the docx skill,
rendered to PDF and visually checked before delivery. Rationale: the source
run's user asked for the memo immediately after the report; the format is
the one shipped and accepted there.

### Considered and deferred

- **Role-scoped briefing blocks** (search/analyze/verify annexes) would cut
  ~half of the ~3.5k-token briefing × ~20 agents per run. Deferred: the
  single verbatim block is load-bearing (see table above), and splitting it
  creates a new failure mode — an agent missing a rule that "wasn't for its
  role." Revisit only with evidence that a scoped block missed nothing.
- Narrowing the Phase 3 fan-out. The evidence (as in v4) points at ordering
  and window arithmetic, not width. Width kept.

### Known gaps — carried forward

- Search-row `opinion_id` was verified on two ground-truth pairs; whether it
  reliably points at the LEAD opinion on multi-opinion clusters (majority vs.
  syllabus vs. dissent) is untested — hence the cluster-lookup exception for
  citator-bound cases. The first run through the new Phase 2.5 should record
  its mismatch rate here.
- The "rejected requests extend the per-minute window" observation is a
  single instance (`[reported]`); promote or drop with more evidence.
- Whether the 5/min and 50/hour caps are plan-dependent (free vs. paid
  CourtListener tiers) is unknown; the adaptive 429-body rule covers either
  case.
- v7 gaps (ledger undercount, cache lifetime, inherited quirks 1/5/6/10)
  remain.

---

## v7 — 2026-07-29

### Added — tier 0: bundled ORCP and UTCR corpora

Complete offline copies of the **ORCP (79 rules)** and **UTCR (242 rules)** now
ship inside the skill, ~800k characters total, queried one provision at a time.
This closes the gap v6 could only work around: ORCP 47 is now retrievable in
full, from a source more current than either web option.

**Why bundling doesn't cost context.** Bundled files are read by Python, never
by the model. `docx` ships 1.1 MB with a 6.9 KB SKILL.md; the same applies
here. The always-loaded footprint grew by ~2 lines.

**Design:**
- `scripts/or_corpus_build.py` — one-time ingest (PDF/HTML/DOCX/TXT → JSONL of
  individual provisions). Regenerates `MANIFEST.md` on every run so it cannot
  drift from what is bundled. **Refuses to write a corpus that matched zero
  provisions** rather than shipping an empty one.
- `scripts/or_lookup.py` — retrieval. `"ORCP 47"`, `"ORCP 47 C"` (subdivision
  isolation), `--search`, `--list`. A miss returns `NOT FOUND` plus nearby
  provisions, never a reconstruction.
- **Staleness is evaluated at query time**, not baked in: STALE at 365 days,
  EXPIRED at 730 (Oregon rules run on a biennial amendment cycle). Every result
  carries a capture-date banner; EXPIRED prints a do-not-quote warning.
- Precedence set to tier 0 → tier 1 → tier 2, per skill-owner decision.

**Quality note — the bundled ORCP beats both web sources.** `ORCP 47 C` from
the bundle includes the full modern standard ("no genuine issue as to a
material fact exists if... no objectively reasonable juror could return a
verdict..."). Public.Law's 2018-dated page returned only the opening sentence.

### Ingest bugs found and fixed — all three were silent data loss

`[verified]` Recorded because each would have corrupted a legal corpus without
erroring, and the same traps apply to any future ingest:

1. **Case-insensitive rule matching.** `RULE\s+\d` with `re.I` matched inline
   cross-references ("Rule 9 A. Proof of service...") as if they were headers.
   Case-sensitive matching gives exactly 79 real headers, no ToC duplicates.
2. **Heading test run against normalised text.** The furniture stripper
   normalises digits to `#`, so `RULE 47` reads `RULE #` and a `\d`-based guard
   never fires — it stripped *every* rule header. The build script's
   zero-provision guard caught this; without that guard it would have shipped
   an empty corpus. Test heading-likeness on the original line.
3. **Frequency-based furniture detection destroying real structure.** On
   ORCP.html it deleted ~11k characters: subdivision markers (`A(1)`, `B(2)`,
   bare `C`) and amendment histories (`[CCP 12/2/78;`) all repeat dozens of
   times legitimately. On the UTCR it would have eaten the 20 `1987 Commentary:`
   / `1991 Commentary:` headings. **Fixed twice:** stripping is now PDF-only
   (HTML has no page furniture), and furniture is identified **positionally** —
   only lines within 3 lines of a page break are candidates. Result: 244
   furniture lines removed, all 20 Commentary headings preserved. A few running
   headers survive mid-page; leaving one in is far better than deleting content.

Also: reserved rules are retained. ORCP 11 and 42 are `(Reserved for
Expansion)`; a minimum-length filter had been dropping them, which would have
told an agent `NOT FOUND` and implied the corpus was incomplete.

**Not bundled:** OARs (the official per-rule source already works and stays
current — bundling would add staleness risk without solving anything) and the
attorney reference manual (owner decision).

---

## v6 — 2026-07-29

### Added — Public.Law as a permitted tier-2 source

**Why.** v5 made the ORS truncation *safe* but not *solved*: late-chapter
sections still could not be retrieved at all. Testing established that no
official source can reach them.

`[verified]` Every official avenue for ORS 527.770:

| Source | Reaches |
|---|---|
| `ors527.html` (current) | 527.710 |
| `2021ors527.pdf` | 527.765 |
| `2017ors527.pdf` | 527.755 |
| `2011ors527.pdf` | 527.760 |
| `2025ors527.pdf` | 404 — does not exist |
| ORS archive site | multi-chapter bundles (`Chapters 001-019.pdf`) — worse |
| per-section official URL | none exists |

Two findings kill the obvious workarounds: older editions are **not** reliably
shorter (2011 reached *less* far than 2021), and truncation happens during
fetch-to-markdown conversion, before any summarizer sees the page — so no
prompt can recover it. A source-escalation ladder would widen the reachable
band from 527.710 to 527.765 but still misses the section that prompted this.

**Decision (skill owner):** permit Public.Law across all of its collections.

**Fidelity check** `[verified]`: Public.Law's ORS 12.080 text and bracket
matched the official Oregon Legislature page **exactly**, including
`[Amended by 1957 c.374 §3; 1961 c.726 §396; 1973 c.363 §1; 1983 c.437 §2;
1987 c.705 §3; 1991 c.968 §2]`. Independently, Public.Law and Justia returned
identical text and identical brackets for ORS 527.770. Two independent sources
agreeing is a stronger check than the two-fetch test built in v5.

**Structure of the change:**
- Two tiers. Tier 1 = official publisher, always tried first, always cited and
  linked. Tier 2 = Public.Law, on truncation/failure, **disclosed in the report
  with its stated currency date**. No other aggregator, for any purpose.
- **Constructible patterns verified:** ORS (`ors_527.770`) and OAR
  (`oar_137-050-0710`). These may be built directly.
- **Index-anchored collections:** ORCP, California Codes, Colorado C.R.S.,
  Florida Statutes, Nevada NRS, New York Laws, Texas Statutes, Rome Statute,
  International Dictionary. Their per-section slugs embed code and rule names
  (`orcp-47-summary-judgment`, `n.y._business_corporation_law`) and the
  hierarchy runs several levels deep, so the section URL is **not** derivable
  from a citation. Index URLs are verified; section URLs must be reached by
  navigating from the index. Constructing one is guessing a URL.
- The six new state collections have **no tier-1 entry** — they extend the
  skill into new jurisdictions rather than backstopping an official source, so
  Public.Law is the source of record there and the report must say so.
- `report-format.md` gained an inline disclosure format for tier-2 text.
- Hard rule 3 rewritten around the two tiers.

**Verified absent — do not assume a `<state>.public.law` host exists:**
Washington (`washington.public.law` fails DNS, not 404), U.S.C., federal rules,
Delaware Code, WA court rules, UTCR, ORAP. For those, tier 1 is already
per-section (app.leg.wa.gov, Cornell), so no fallback is needed.

### Corrected — ORCP official page is worse than v6 first recorded

`[verified]` Re-probed the ORCP page directly rather than trusting a single
summarizer's account. Body text stops **partway through Rule 9 of 85** — the
last words are "cannot support the required", mid-sentence — followed by the
`[Content truncated due to length...]` marker, while the table of contents
still lists Rules 10 through 85. Spot checks with the strict template: Rule 10
NOT PRESENT, Rule 21 NOT PRESENT, Rule 47 NOT PRESENT.

Roughly **90% of the ORCP is unreachable** from the official URL, including
nearly everything in practical use: Rule 21 (motions to dismiss), 36–46
(discovery), 47 (summary judgment), 68 (attorney fees). v6 initially recorded
this as "truncates after Rule 9"; corrected to mid-Rule 9, and the official
page is now marked usable only for **Rule 8 and below**.

**Cautions carried forward:**
- Public.Law's **ORCP** page reported a last-modified date of 2018 and may be
  stale — but the official page reaches only Rule 8, so for most rules there is
  no official alternative to compare against. State the currency date.
- Per-section patterns for the six new state collections are **unverified** —
  that is why they are index-anchored. Verifying one and promoting it to the
  constructible table is a welcome future change; record the date when you do.

---

## v5 — 2026-07-29

### Fixed — ORS/ORCP chapter pages truncate, and the failure is silent

**The report.** A prior run reported that an Oregon statute lookup failed
because the allowlisted URL covers an entire ORS chapter and was "too long to
parse."

**What testing found.** `[verified]` The problem is real, worse than reported,
and it does not announce itself. `WebFetch` truncates these pages — the
markdown ends with a literal `[Content truncated due to length...]` — but the
**table of contents at the top survives**. Section numbers and headings for the
whole chapter therefore remain visible while the body text of later sections is
gone.

Measured boundaries (2026-07-29):

| Page | Body ends at | Unreachable |
|---|---|---|
| `ors012.html` | complete | — |
| `ors030.html` | ~ORS 30.275, mid-citation | 30.300 upward |
| `ors527.html` | ~ORS 527.710 | 527.755, .765, .770, .990 |
| `ORCP.html` | **Rule 9** | Rules 10–85, incl. ORCP 47 |

Chapter PDFs are not a workaround: the archived `2017ors527.pdf` truncated at
ORS 527.755. There is no per-section official ORS URL.

**The dangerous part — silent fabrication.** Asked naively to quote ORS
527.770, the fetch summarizer saw the heading in the surviving ToC and invented
statutory text. Asked for ORS 30.300 in a *batched* prompt, it invented both
the body text and a plausible bracketed source-law citation
(`[1967 c.627 §6; 1975 c.609 §10; 1987 c.705 §10]`). The real provision reads
"...are exclusive and supersede all home rule charter provisions and conflicting
laws and ordinances on the same subject" `[1967 c.627 §11]`. Nothing errored.

This defeated hard rule 3 ("never quote statute text from memory") because the
fabrication happened downstream, in the fetch tool's summarizer, not in
Claude's memory. The rule did not anticipate that.

**Root cause of the fabrication — no sanctioned way to say "not there."**
The controlled comparison, same page and same minute:

| Prompt | Result |
|---|---|
| "Extract the verbatim text of ORS 527.770" | Fabricated text |
| Two sections batched, loose format | Fabricated text **and** fabricated bracket |
| One section, anti-inference lead, bracket required, exact escape string supplied | `NOT PRESENT — table-of-contents entry only` ✓ |

Validated 3/3: correct refusal on ORS 527.770 and ORCP 47, correct retrieval
with bracket on ORS 527.620 — no false negative.

**Fixes applied:**
- New "Long-page truncation" section in `statute-sources.md` with the measured
  boundary table and a mandatory retrieval protocol: **one provision per
  fetch**, anti-inference lead, bracketed source-law citation as proof-of-body,
  exact escape string.
- **Two-fetch agreement before quoting.** The bracket is proof-of-body, not
  proof-of-truth — it can itself be fabricated. Statute text destined for the
  report must be fetched twice with different phrasings and the brackets must
  match. Costs zero CourtListener budget.
- Phase 4.5C now carries the same verbatim discipline as case quotes. Until now
  the skill verified every case quote and **zero** statute quotes; that
  asymmetry is precisely where the fabrication reached a published report.
- `report-format.md` distinguishes "could not be resolved" from "the official
  page truncates before this section" — a truncation must never read as an
  absence.
- ORCP row downgraded to link-only for Rule 10 and above.

### Added — "not found" as a first-class result

`[verified]` Generalizing the root cause above. The skill's output contracts
demanded fields (`holding`, `key_quotes`, `factual_background`) with no
sanctioned empty value, which is the same pressure that produced the statutory
fabrication.

- New briefing section, **"'Not found' is a correct answer — say it plainly"**,
  pasted into every subagent prompt. Every field accepts `null`; a stated gap
  beats a plausible guess; distinguish "absent" from "I could not retrieve it";
  report a false premise rather than answering as though it held.
- New **hard rule 7** in `SKILL.md`, including the instruction to the
  orchestrator: when you write a prompt, always give the agent an explicit,
  easy way to report nothing.
- Explicit `null`/empty allowances added to the Phase 2 search contract and the
  Phase 3 analyzer contract.

### Known gaps — carried forward

- Boundaries **will drift** as chapters grow. They are dated; re-measure rather
  than trusting them.
- Only ORS 12/30/527 and ORCP were measured. Other ORS chapters, and the
  Delaware Code chapter pages in the allowlist, are untested and presumed at
  risk.
- Aggregators (`oregon.public.law`, `law.justia.com`) carry per-section pages
  and were correct in every spot-check here. They remain **banned for
  quotation**; they were used only to verify this investigation. Whether to
  admit them as a disclosed cross-check is an open policy question for the
  skill's owner.

---

## v4 — 2026-07-29

### Corrected — the budget model was wrong

**The change.** v3 described two quota buckets and told every agent that
`read_document` and `search_document` were *uncapped*. That is false. There is
**one** account-wide pool (~10/min, ~100/hour). The document tools draw on it
too — metered on the first fetch of a given document, then free forever after,
because the document is cached server-side.

**Evidence.** `[verified]` During an Oregon inverse-condemnation run:
- A 16-analyzer wave early in the hour completed with zero rate limiting.
- The refinement wave that followed could not read the cases it had just
  found. `search_document` returned, verbatim:
  `Rate limit exceeded: 100/hour. Expected available in 680 seconds.`
- Two independent subagents reported the contradiction unprompted. One noted
  that a batched call spends a unit **per document**, returns 429s per-document
  inside the results array, and that a batch can partially succeed while still
  charging for what came back.
- Cached documents kept serving normally *inside* the 429 window — which is
  what isolated the cause to first-fetch metering rather than tool-level
  throttling.

**Why it survived several runs.** The claim read exactly as authoritative as
the true rules beside it, and agents trusted the briefing over their own
observations. This is the origin of the provenance tags added in this version.

**Consequences applied:**
- `pipeline.md` budget table now has a **Phase 3 line (25 units)** for first
  reads. Previously the single largest consumer was unbudgeted.
- Phase 2 search trimmed 24 → 20; ID resolution 15 → 12; refinement 20 → 15;
  reserve 20 → 15. Quote verification is listed at ~0 *with the reason stated*
  (Phase 3 already paid for those documents), so nobody re-derives it as "free
  tool."
- Added an explicit cache-ordering rule: read each opinion once, early, and
  let later phases grep it free.
- Phase 3 fan-out **kept at ~15**. The evidence did not support narrowing it —
  that wave ran clean; the failure was ordering, not width. Guidance is now
  "run it early and count it," not "run it small."
- `calls_capped` → `calls_metered` throughout. **Breaking change** for any
  saved prompt or harness that reads that field.

### Added — briefing quirks 11–15

- **11. `semantic: true` only reaches recent opinions.** `[reported]` Two
  semantic queries returned nothing older than 2019 (Or. supreme) / 2021
  (Or. appellate) across 30 results each, silently omitting the entire
  foundational line of authority on the topic. Also: the `count` field on a
  semantic query is not a relevance-filtered count — 547/578/535 for three
  unrelated queries against the same court.
- **12. Multi-ID `court` arrays silently drop courts.** `[reported]` Same
  phrase: `court: ["orctapp","or"]` → 8 hits, all supreme court;
  `court: ["orctapp"]` alone → 61.
- **13. `data-id` is the opinion id, `href` is the cluster id.** `[verified]`
  Free way to harvest opinion ids from an already-read opinion. *Two subagents
  agreed on the fact and disagreed on the recommendation* — one advised
  trusting `href`, which is the cluster id and therefore the wrong one. Settled
  by independent resolution: Morrison's `data-id` 3837093 matched the true
  opinion id; its `href` 4078848 was the cluster. Recorded here because it is a
  good example of why a lone subagent recommendation is `[reported]`, not
  `[verified]`.
- **14. `read_document` overflows past ~2–3 chunks** at chunk_size 8000.
  `[reported]` by two independent analyzers; spills to a file that then exceeds
  the read cap, costing an extra round-trip.
- **15. Many opinions carry no caption or party names.** `[verified]` Hit
  independently by five analyzers (1924, 1933, 1979 ×2, 2015 records). The text
  begins at the authoring judge. A literal party-name search returns zero *on
  the correct opinion*, so the old "check chunk 0 names your case" instruction
  produced false `id_mismatch` reports. Replaced with star-pagination range,
  factual fit, `ante p.` cross-references, or one metered cluster lookup.

### Corrected — existing quirks

- **Quirk 2 — the cluster/opinion id split is by INGESTION SOURCE, not date.**
  `[verified]` v3 said "records after roughly 2010." False in both directions:
  Gearin (1924) cluster 7007923 → opinion 6908115, while Suess Builders (1982)
  had cluster == opinion == 2612675. Confirmed divergent this run: Morrison
  4078848→3837093, Walton 9509354→9975967, Roberts 10932137→11399679, Bazzaz
  8165463→8127160, Turner 8166082→8127802. Added: a wrong id often returns a
  short stub, so treat anything under ~1,000 chars as a probable wrong id.
- **Quirk 7 — hard line wraps, not hyphenation, are the dominant cause** of
  false `search_document` zeros. `[verified]` Build fragments from a single
  printed line (~45–60 chars). Added the inverse: a zero on a *short* stem
  (e.g. `negligen`) is strong evidence of true absence, because a short stem
  cannot span a break. Added: check document length before grading `not_found`.
- **Quirk 9 — duplicate clusters can carry different `citation` arrays**
  `[verified]` (one holds the official state cite, the other the regional
  reporter), and one of a pair is sometimes a text stub. Prefer the fuller
  array; try the sibling before concluding text is unavailable.

### Added — quote absence check

`[verified]` A verifier was asked to confirm that "tantamount to a public
appropriation" appears in *Suess Builders* — a phrase widely attributed to its
footnote 5. Result: 0 matches for "tantamount," 0 for "public appropriation,"
and the single "appropriat" hit was an unrelated quotation of "de facto
appropriation" from a New York case. Publishing it would have been a fabricated
attribution. `confirmed_absent` is now a defined, publishable verifier outcome.

### Added — maintenance guidance

- Briefing quirks now carry `[verified]` / `[reported]` / `[inherited]` tags
  with a legend, and an explicit instruction to treat an untagged claim in that
  block as unverified.
- The maintenance note now says: treat subagent contradictions of the briefing
  as high-priority edits, not agent error. Two independent reports of the same
  contradiction should be believed.
- This file.

### Also

- Strategy cap 6 → 5 queries, with an added instruction to issue them one at a
  time. `[reported]` 2–3 simultaneous searches from a *single* agent tripped the
  10/min limit on its own.
- `report-format.md` "Searches" row now reports metered calls, rate-limit
  rejections, and document operations separately — the old row implied document
  reads were free.
- Phase 4.5A now says explicitly: if budget runs out, screening only the
  controlling modern cases is acceptable, but presenting it as a full history
  check is not.

### Known gaps — carried forward

- The ledger **undercounts**. 429-rejected requests return no data, so agents
  don't count them, but they still consume wall-clock and possibly quota. Treat
  the ledger as a lower bound.
- Whether the 10/min and 100/hour limits are separate counters or one is
  unresolved. Behaviour is consistent with two.
- Whether cached-document lifetime is per-session or global is untested. All
  observations here are within a single session.
- Quirks 1, 5, 6, 10 are `[inherited]` and were not exercised this run.

---

## v3 — date unknown (reconstructed from the version footer)

Added the two-bucket budget model *(wrong — corrected in v4)*, the one-call
citator recipe, central opinion-ID resolution (Phase 2.5), the anchored
relevance rubric with its `scale_confirmation` guard, and the state-court
review-disposition rule.

Evidence for these was not recorded at the time; what survives is embedded in
the reference files as inline "in a prior run…" anchors — the ~180-rows-to-60
dedupe finding, the 25-case anchor citator yield, the inverted relevance
ranking, the three analyzers reading wrong cases, and the February 2025 Oregon
decision whose review history was invisible to the citator. Those anchors are
load-bearing; do not strip them as verbose.

## v1–v2 — not recorded

No record survives. If you are reading this wondering why some rule exists and
it is not explained anywhere, it probably dates from here. Prefer investigating
over deleting.
